// ============================================================
// ボスの技ライブラリ (boss-moves.js)
//  ・ステージ(ボス)ごとに「得意技」を3〜5個持ち、順番に繰り出す
//  ・各ボスに必ず1つ「スタン技」がある。当たると約3秒、動けず攻撃も回避もできなくなる
//    （予告は黄色い範囲＋⚡。遠くへ逃げる／ダッシュで避ければ当たらない）
//  ・技は「ステップ（時刻つきの命令）」の並びで定義し、実行は stage.js の runMove() が行う
//
//  ステップの種類（t は技の開始からの秒数）
//    cone  : 扇形の範囲攻撃（r=半径, arc=角度°, tele=予告秒, dm=威力倍率, rep/gap=持続して複数回ヒット）
//    line  : 直線のレーザー/斬撃（len=長さ, w=幅）
//    ring  : ボスを中心にした円（近づくと危険）
//    donut : ドーナツ形（ri より内側は安全）
//    at    : プレイヤーの足元に円（who: 'all' 全員 / 'rand' ランダム1人）
//    rain  : プレイヤー周辺にランダムな円を降らせる（n 個）
//    warn  : ダメージ無しの予告線（このあと dash するときの合図）
//    dash  : ボスの体当たり突進（接触でダメージ）
//    leap  : 飛び上がって着地点に落下（着地時に円の範囲ダメージ）
//    fan / rad / spiral : 弾（扇状／全方位／渦巻き）
//    summon: 手下を呼ぶ
//  ゲートキーパー専用（ゲートから剣とビームを撃つ）
//    ports : 「門」を開く（mode: around=標的の周囲 / sky=頭上に横並び / side=左右から横ビーム用 / diag=四隅の斜め）。life 秒だけ開いている
//    swords: 開いている門から剣を撃つ（per=1門あたりの本数, frac=撃つ門の割合, track=撃つ瞬間に標的を狙い直す）
//    beams : 開いている門からビームを撃つ（tele=予告秒, w=幅, r=長さ, frac=撃つ門の割合）
//  ボスラッシュFinal・無限回廊のボス用（ビーム／弾幕）
//    beamfan: ボスから扇状に細いビームを何本も撃つ（n=本数, sp=扇の角度°, len=長さ, w=幅）
//    beamAt : アリーナの外周などの「決まった位置」から撃つビーム（fx,fy=アリーナ内の位置の割合0〜1, a=向き°。track=true で撃つ瞬間に標的を狙う）
//    blast  : 標的の周囲に砲口（ガスターブラスター風）を並べて、標的へ向けて撃つ（n=個数, R=標的からの距離）
//    wall   : 画面を横切る弾の壁（隙間が1か所だけある。dir=h/v/rand, gapW=隙間の幅）
//  aim は 'l'＝技の開始時に狙った方向で固定 / 't'＝そのときのプレイヤーの方向（既定）、off は角度°のずらし
// ============================================================
(function () {
    'use strict';
    const D = Math.PI / 180;
    const MOVES = {};
    const SETS = {};

    // ---------- ステップ生成の短縮記法 ----------
    const cone   = (t, r, arc, tele, dm, o) => Object.assign({ t: t, k: 'cone', r: r, arc: arc * D, tele: tele, dm: dm }, o);
    const line   = (t, len, w, tele, dm, o) => Object.assign({ t: t, k: 'line', r: len, w: w, tele: tele, dm: dm }, o);
    const ring   = (t, r, tele, dm, o) => Object.assign({ t: t, k: 'ring', r: r, tele: tele, dm: dm }, o);
    const donut  = (t, r, ri, tele, dm, o) => Object.assign({ t: t, k: 'donut', r: r, ri: ri, tele: tele, dm: dm }, o);
    const at     = (t, r, tele, dm, o) => Object.assign({ t: t, k: 'at', r: r, tele: tele, dm: dm, who: 'all' }, o);
    const rain   = (t, n, r, tele, dm, o) => Object.assign({ t: t, k: 'rain', n: n, r: r, tele: tele, dm: dm, gap: 0.15 }, o);
    const warn   = (t, len, w, tele, o) => Object.assign({ t: t, k: 'warn', r: len, w: w, tele: tele, aim: 'l' }, o);
    const dash   = (t, dur, spd, o) => Object.assign({ t: t, k: 'dash', dur: dur, spd: spd, aim: 'l' }, o);
    const leap   = (t, dur, r, dm, o) => Object.assign({ t: t, k: 'leap', dur: dur, r: r, dm: dm }, o);
    const fan    = (t, n, spread, spd, dm, o) => Object.assign({ t: t, k: 'fan', n: n, sp: spread * D, spd: spd, dm: dm }, o);
    const rad    = (t, n, spd, dm, o) => Object.assign({ t: t, k: 'rad', n: n, spd: spd, dm: dm }, o);
    const spiral = (t, dur, spd, dm, o) => Object.assign({ t: t, k: 'spiral', dur: dur, spd: spd, dm: dm, arms: 2 }, o);
    const summon = (t, n) => ({ t: t, k: 'summon', n: n });
    const ports  = (t, mode, n, R, life, o) => Object.assign({ t: t, k: 'ports', mode: mode, n: n, R: R, life: life }, o);
    const swords = (t, o) => Object.assign({ t: t, k: 'swords', per: 1, spd: 520, dm: 0.5, frac: 1 }, o);
    const beams  = (t, len, w, tele, dm, o) => Object.assign({ t: t, k: 'beams', r: len, w: w, tele: tele, dm: dm, frac: 1 }, o);
    const pull   = (t, dur, force, o) => Object.assign({ t: t, k: 'pull', dur: dur, force: force }, o);   // 全員をボスの方へ引き寄せる（force=px/秒）
    const blink  = (t, gap, o) => Object.assign({ t: t, k: 'tp', gap: gap }, o);      // 瞬間移動：いちばん近いプレイヤーの近く（gap px）へ一瞬で詰める
    const STUN = { stun: true };

    function stepEnd(s) {
        switch (s.k) {
            case 'cone': case 'line': case 'ring': case 'donut': case 'at': return s.t + s.tele + (s.rep || 0) * (s.gap || 0.3);
            case 'rain': return s.t + s.tele + s.n * (s.gap || 0.15);
            case 'warn': return s.t + s.tele;
            case 'beams': case 'beamfan': case 'beamAt': case 'blast': return s.t + s.tele + (s.rep || 0) * (s.gap || 0.3);
            case 'dash': case 'leap': case 'spiral': case 'pull': return s.t + s.dur;
            default: return s.t;
        }
    }
    // 技の登録。dur(全体の長さ)はステップから自動計算。recは技のあとの硬直（秒）
    function def(id, name, steps, o) {
        steps = steps.slice().sort((a, b) => a.t - b.t);
        const m = Object.assign({ id: id, name: name, steps: steps, rec: 0.5 }, o || {});
        m.stun = steps.some(s => s.stun);
        m.ult = !!(o && o.ult);
        if (m.stun && !(o && 'rec' in o)) m.rec = 1.2;
        m.dur = Math.max.apply(null, steps.map(stepEnd)) + 0.1;
        MOVES[id] = m;
        return id;
    }
    // ステージ(ボス)ごとの技セット。stun は必ず1つ
    // o.ult: 大技（HPが ultAt の割合を切るたびに1回ずつ、激昂中はときどき繰り出す）
    function set(stageId, moves, stun, o) { SETS[stageId] = { moves: moves, stun: stun, ult: o && o.ult, ultAt: (o && o.ultAt) || [0.7, 0.35] }; }

    // ============================================================
    // 第一世界
    // ============================================================
    // --- ゴブリンキング：力任せの大振りと家臣 ---
    set('meadow', [
        def('gk_swing', '王の二連撃', [cone(0, 240, 100, 0.75, 1.5), cone(0.85, 240, 100, 0.6, 1.5)]),
        def('gk_stomp', '玉座の地鳴り', [ring(0, 170, 0.9, 1.6), donut(1.0, 340, 190, 0.85, 1.3)]),
        def('gk_call', '家臣召集', [summon(0, 4), rad(0.5, 12, 230, 0.8)])
    ], def('gk_scepter', '黄金の王笏', [at(0, 105, 1.2, 0.9, STUN)]));

    // --- 森の魔女：呪い弾と毒の大釜 ---
    set('whisper_forest', [
        def('wt_hex', '呪いの三連弾', [fan(0, 5, 11, 380, 0.8), fan(0.5, 5, 11, 380, 0.8), fan(1.0, 7, 11, 380, 0.8)]),
        def('wt_cauldron', '大釜の毒霧', [rain(0, 6, 95, 1.0, 1.1, { gap: 0.2 }), ring(0.8, 130, 0.9, 1.4)]),
        def('wt_broom', '箒の突進', [warn(0, 540, 80, 0.7), dash(0.7, 0.6, 780)], { rec: 0.7 })
    ], def('wt_curse', '石化の呪眼', [cone(0, 500, 55, 1.2, 0.8, Object.assign({ aim: 't' }, STUN))]));

    // --- サンドワーム：地中からの奇襲 ---
    set('sand_ruins', [
        def('sw_burrow', '潜行突き上げ', [at(0, 100, 1.0, 1.4), at(0.7, 100, 0.9, 1.4)]),
        def('sw_charge', '大地裂き', [warn(0, 600, 90, 0.8), dash(0.8, 0.7, 760), ring(1.6, 150, 0.7, 1.2)], { rec: 0.7 }),
        def('sw_spit', '砂弾連射', [fan(0, 5, 12, 360, 0.8), fan(0.4, 5, 12, 360, 0.8), rad(1.0, 14, 240, 0.7)])
    ], def('sw_quake', '砂嵐の大地震', [ring(0, 310, 1.3, 0.9, STUN)]));

    // --- アイスゴーレム：氷の拳と冷気 ---
    set('frost_lab', [
        def('ig_smash', '氷拳の叩きつけ', [cone(0, 230, 90, 0.85, 1.8), ring(1.0, 160, 0.7, 1.3)]),
        def('ig_shard', '氷柱の雨', [rain(0, 7, 75, 1.1, 1.2, { gap: 0.17 })]),
        def('ig_nova', '絶対零度', [donut(0, 430, 150, 1.1, 1.4), rad(1.3, 16, 230, 0.7)])
    ], def('ig_freeze', '凍結の吐息', [cone(0, 520, 70, 1.2, 0.8, Object.assign({ aim: 't' }, STUN))]));

    // --- オークの戦将：斧と突撃 ---
    set('wasteland', [
        def('og_axe', '戦斧の連撃', [cone(0, 250, 110, 0.7, 1.5), cone(0.8, 250, 110, 0.6, 1.5), cone(1.5, 280, 140, 0.8, 1.9)]),
        def('og_charge', '突撃の号令', [warn(0, 560, 80, 0.7), dash(0.7, 0.55, 800), warn(1.5, 560, 80, 0.5, { aim: 't' }), dash(2.0, 0.55, 800, { aim: 't' })], { rec: 0.8 }),
        def('og_horn', '進軍の角笛', [summon(0, 4), rad(0.5, 14, 240, 0.8)])
    ], def('og_bash', '盾砕きの一撃', [at(0, 110, 1.2, 0.9, STUN)]));

    // --- ヨルムンガンド：毒霧のブレスと締め付け ---
    set('toxic_swamp', [
        def('ym_breath', '毒霧のブレス', [cone(0, 660, 70, 1.1, 0.5, { aim: 't', rep: 5, gap: 0.3 })]),
        def('ym_coil', 'とぐろ締め', [ring(0, 200, 0.9, 1.5), donut(1.0, 400, 200, 0.9, 1.3)]),
        def('ym_spit', '毒液弾', [fan(0, 7, 9, 340, 0.8), rain(0.6, 5, 90, 1.0, 1.0)])
    ], def('ym_fang', '麻痺の牙', [leap(0, 0.85, 150, 0.9, STUN)]));

    // --- 岩石トロール：棍棒と落石 ---
    set('rocky_mountain', [
        def('rt_club', '岩棍棒の振り下ろし', [cone(0, 240, 80, 0.9, 2.0), ring(1.1, 170, 0.7, 1.3)]),
        def('rt_fall', '落石', [rain(0, 8, 85, 1.2, 1.2, { gap: 0.2 })]),
        def('rt_roll', 'ロックロール', [warn(0, 640, 100, 0.8), dash(0.8, 0.8, 720)], { rec: 0.8 })
    ], def('rt_quake', '大地震動', [donut(0, 430, 130, 1.3, 0.9, STUN)]));

    // --- 雷神ガルーダ：急降下と落雷 ---
    set('thunder_canyon', [
        def('gd_dive', '雷光の急降下', [leap(0, 0.8, 180, 1.8)]),
        def('gd_bolts', '落雷の連鎖', [rain(0, 9, 62, 0.8, 1.2, { gap: 0.14 })]),
        def('gd_wing', '羽根の乱射', [fan(0, 7, 10, 380, 0.8), rad(0.5, 16, 250, 0.7), fan(1.0, 7, 10, 380, 0.8)])
    ], def('gd_judgement', '天罰の雷', [at(0, 115, 1.2, 0.9, STUN)]));

    // --- フレイムドラゴン：広範囲の灼熱ブレス ---
    set('magma_core', [
        def('fd_breath', '灼熱の大ブレス', [cone(0, 580, 105, 1.0, 0.65, { aim: 't', rep: 4, gap: 0.3 })]),
        def('fd_tail', '尾薙ぎ', [cone(0, 270, 230, 0.8, 1.7)]),
        def('fd_meteor', '火口の落石', [rain(0, 7, 85, 1.0, 1.2, { gap: 0.18 })]),
        def('fd_dive', '飛翔急降下', [leap(0, 0.9, 190, 2.0)])
    ], def('fd_roar', '竜の咆哮', [ring(0, 270, 1.2, 0.9, STUN)]));

    // --- 深海クラーケン：触手と大渦 ---
    set('deep_sea', [
        def('kr_tentacle', '触手の連打', [at(0, 85, 0.8, 1.2, { who: 'rand' }), at(0.5, 85, 0.8, 1.2, { who: 'rand' }), at(1.0, 85, 0.8, 1.2)]),
        def('kr_ink', '墨の渦', [spiral(0, 2.2, 240, 0.8)], { rec: 0.8 }),
        def('kr_whirl', '大渦', [donut(0, 410, 140, 1.1, 1.4), ring(1.2, 120, 0.7, 1.5)])
    ], def('kr_grip', '巻き付き', [at(0, 125, 1.2, 0.9, STUN)]));

    // --- 血の伯爵：蝙蝠と十字斬 ---
    set('haunted_graveyard', [
        def('bc_bats', '蝙蝠の群れ', [fan(0, 5, 14, 370, 0.8), fan(0.4, 5, 14, 370, 0.8), fan(0.8, 5, 14, 370, 0.8)]),
        def('bc_cross', '鮮血の十字斬', [0, 90, 180, 270].map(a => line(0, 520, 64, 0.85, 1.6, { aim: 'l', off: a }))),
        def('bc_vortex', '血の渦', [donut(0, 400, 130, 1.0, 1.4), summon(0.6, 3)])
    ], def('bc_gaze', '魅了の邪眼', [cone(0, 520, 60, 1.2, 0.8, Object.assign({ aim: 't' }, STUN))]));

    // --- セレスティアルガーディアン：光の裁き ---
    set('sky_castle', [
        def('cg_pillar', '裁きの光柱', [at(0, 90, 0.9, 1.4), at(0.7, 90, 0.9, 1.4), rain(1.0, 4, 80, 0.9, 1.1)]),
        def('cg_sword', '聖剣の一閃', [line(0, 680, 90, 0.9, 1.8)]),
        def('cg_halo', '光輪', [rad(0, 18, 250, 0.8), ring(0.5, 170, 0.8, 1.4)])
    ], def('cg_seal', '封印の光', [at(0, 150, 1.3, 0.9, STUN)]));

    // --- 堕天使ルシフェル：黒羽根と堕天の十字 ---
    set('fallen_church', [
        def('lf_feather', '黒羽根の弾幕', [spiral(0, 1.8, 250, 0.8), fan(1.9, 7, 10, 370, 0.8)]),
        def('lf_cross', '堕天の十字', [line(0, 640, 70, 0.9, 1.7, { aim: 't' }), line(0.5, 640, 70, 0.9, 1.7, { aim: 't', off: 90 })]),
        def('lf_fall', '堕天急降下', [leap(0, 0.85, 180, 2.0)])
    ], def('lf_gospel', '闇の福音', [ring(0, 330, 1.3, 0.9, STUN)]));

    // --- 深淵ヲ廻ルモノ：鎌の二連撃→飛び上がりの一撃 ---
    set('abyssal_rift', [
        def('ab_reap', '死神の三連鎌', [cone(0, 260, 115, 0.75, 1.3), cone(0.85, 260, 115, 0.6, 1.3), leap(1.7, 0.75, 175, 2.1)], { rec: 0.8 }),
        def('ab_orbit', '廻転断ち', [cone(0, 340, 80, 0.8, 1.4, { aim: 'l', off: 0 }), cone(0.5, 340, 80, 0.7, 1.4, { aim: 'l', off: 120 }), cone(1.0, 340, 80, 0.7, 1.4, { aim: 'l', off: 240 })]),
        def('ab_spiral', '虚空の渦', [spiral(0, 2.4, 240, 0.8), rad(2.5, 20, 230, 0.7)], { rec: 0.8 }),
        def('ab_summon', '眷属召喚', [summon(0, 4), donut(0.5, 400, 140, 1.0, 1.3)])
    ], def('ab_grasp', '虚無の掌握', [ring(0, 290, 1.3, 0.9, STUN)]));

    // ---- ミニステージ ----
    // --- キングスライム ---
    set('slime_burrow', [
        def('ks_press', 'ボディプレス', [leap(0, 0.8, 170, 1.7)]),
        def('ks_split', '分裂', [summon(0, 4), rad(0.5, 12, 220, 0.8)]),
        def('ks_splash', '粘液飛沫', [rain(0, 6, 85, 1.0, 1.1, { gap: 0.18 })])
    ], def('ks_sticky', '粘着ボディ', [ring(0, 240, 1.2, 0.8, STUN)]));

    // --- ホブゴブリン将軍 ---
    set('goblin_camp', [
        def('hg_chop', '二連斬り', [cone(0, 240, 100, 0.7, 1.5), cone(0.8, 240, 100, 0.6, 1.5)]),
        def('hg_charge', '突撃命令', [warn(0, 540, 80, 0.7), dash(0.7, 0.55, 780)], { rec: 0.7 }),
        def('hg_bomb', '爆弾投げ', [rain(0, 5, 90, 1.1, 1.3, { gap: 0.2 }), fan(0.5, 5, 12, 360, 0.7)])
    ], def('hg_helm', '兜割り', [cone(0, 240, 70, 1.1, 1.0, Object.assign({ aim: 't' }, STUN))]));

    // --- 禁書の番人 ---
    set('haunted_library', [
        def('fb_pages', '飛び散る頁', [fan(0, 9, 8, 360, 0.8), fan(0.5, 9, 8, 360, 0.8)]),
        def('fb_ink', 'インク沼', [rain(0, 6, 95, 1.0, 1.1, { gap: 0.18 })]),
        def('fb_chant', '禁呪詠唱', [donut(0, 410, 140, 1.1, 1.4), summon(0.6, 3)])
    ], def('fb_close', '書を閉じる', [at(0, 135, 1.2, 0.9, STUN)]));

    // --- メカ・タイタン ---
    set('clockwork_factory', [
        def('mt_punch', 'ロケットパンチ', [line(0, 720, 85, 0.9, 1.8)]),
        def('mt_gatling', 'ガトリング', [fan(0, 3, 6, 420, 0.6), fan(0.2, 3, 6, 420, 0.6), fan(0.4, 3, 6, 420, 0.6), fan(0.6, 3, 6, 420, 0.6), spiral(0.9, 1.4, 260, 0.6)]),
        def('mt_stomp', '重力脚', [ring(0, 170, 0.9, 1.5), donut(1.0, 400, 170, 0.9, 1.3)])
    ], def('mt_emp', 'EMPパルス', [ring(0, 340, 1.3, 0.9, STUN)]));

    // ============================================================
    // 第二世界「次元の裏側」
    // ============================================================
    // --- 次元狼フェンリル・ゼロ：牙の連撃と瞬影の突進 ---
    set('rift_plains', [
        def('fz_fang', '牙の三連撃', [cone(0, 230, 90, 0.6, 1.3), cone(0.65, 230, 90, 0.5, 1.3), cone(1.25, 260, 130, 0.65, 1.7)]),
        def('fz_howl', '次元の咆哮', [rad(0, 22, 250, 0.8), ring(0.4, 180, 0.9, 1.5)]),
        def('fz_rush', '瞬影突進', [warn(0, 600, 80, 0.55), dash(0.55, 0.5, 900), warn(1.2, 600, 80, 0.45, { aim: 't' }), dash(1.65, 0.5, 900, { aim: 't' })], { rec: 0.8 })
    ], def('fz_bite', '喰らいつき', [leap(0, 0.8, 150, 1.0, STUN)]));

    // --- 嘆きの樹母：這う根と毒花粉 ---
    set('rift_forest', [
        def('tm_roots', '這う根', [line(0, 640, 70, 0.9, 1.5, { aim: 'l', off: -28 }), line(0, 640, 70, 0.9, 1.5, { aim: 'l', off: 0 }), line(0, 640, 70, 0.9, 1.5, { aim: 'l', off: 28 }), line(1.1, 640, 70, 0.8, 1.5, { aim: 't' })]),
        def('tm_pollen', '毒花粉', [donut(0, 430, 150, 1.1, 1.4), rain(0.6, 5, 90, 1.0, 1.1)]),
        def('tm_sprout', '若木の呼び声', [summon(0, 5), rain(0.5, 4, 85, 1.0, 1.2)])
    ], def('tm_bind', '絡み付く蔓', [at(0, 135, 1.3, 0.9, STUN)]));

    // --- ミラージュ・スフィンクス：爪の乱舞と蜃気楼 ---
    set('rift_desert', [
        def('ms_claw', '爪の乱舞', [cone(0, 250, 90, 0.6, 1.3), cone(0.65, 250, 90, 0.5, 1.3), cone(1.25, 250, 90, 0.5, 1.3), cone(1.8, 280, 140, 0.7, 1.8)]),
        def('ms_mirage', '蜃気楼', [rain(0, 9, 80, 1.0, 1.2, { gap: 0.15 }), at(0.9, 95, 0.9, 1.3, { who: 'rand' })]),
        def('ms_riddle', '謎かけの光線', [line(0, 700, 80, 0.9, 1.6, { aim: 'l', off: -35 }), line(0.45, 700, 80, 0.9, 1.6, { aim: 'l', off: 0 }), line(0.9, 700, 80, 0.9, 1.6, { aim: 'l', off: 35 })])
    ], def('ms_gaze', '石化の視線', [cone(0, 580, 55, 1.2, 0.9, Object.assign({ aim: 't' }, STUN))]));

    // --- 刻喰らいクロノス：時計の針と砂の雨 ---
    set('rift_clock', [
        def('ch_hands', '針の回転', [0, 1, 2, 3, 4, 5].map(i => line(i * 0.3, 620, 62, 0.55, 1.3, { aim: 'l', off: i * 32 }))),
        def('ch_rewind', '時間遡行', [at(0, 100, 1.0, 1.3), at(1.1, 100, 0.8, 1.3), at(1.9, 100, 0.8, 1.3)]),
        def('ch_sand', '砂時計の雨', [rain(0, 10, 70, 1.0, 1.2, { gap: 0.13 }), donut(1.3, 400, 140, 0.9, 1.3)])
    ], def('ch_stop', '時間停止', [ring(0, 370, 1.4, 0.9, STUN)]));

    // --- 星砕きの巨神：踏みつけと流星群 ---
    set('rift_battlefield', [
        def('sg_slam', '星砕きの一撃', [leap(0, 0.9, 235, 2.2), ring(1.1, 150, 0.7, 1.3)], { rec: 0.8 }),
        def('sg_meteor', '流星群', [rain(0, 11, 78, 1.0, 1.3, { gap: 0.13 })]),
        def('sg_beam', '星光線', [line(0, 740, 90, 0.9, 1.7, { aim: 't' }), line(0.8, 740, 90, 0.9, 1.7, { aim: 't' }), rad(1.7, 18, 240, 0.7)])
    ], def('sg_nova', '超新星', [donut(0, 460, 150, 1.4, 0.9, STUN)]));

    // --- 次元竜王バハムート・ノヴァ：超広範囲ブレスと竜爪 ---
    set('rift_throne', [
        def('dk_breath', '次元の大ブレス', [cone(0, 720, 135, 1.1, 0.6, { aim: 't', rep: 5, gap: 0.28 })], { rec: 0.8 }),
        def('dk_claw', '裂爪と急降下', [cone(0, 270, 100, 0.65, 1.4), cone(0.75, 270, 100, 0.55, 1.4), leap(1.5, 0.8, 200, 2.2)], { rec: 0.8 }),
        def('dk_meteor', '竜星群', [rain(0, 10, 85, 1.0, 1.3, { gap: 0.14 }), at(1.0, 95, 0.9, 1.3, { who: 'rand' })]),
        def('dk_storm', '終焉の嵐', [spiral(0, 2.2, 250, 0.8, { arms: 3 }), donut(1.0, 440, 150, 1.0, 1.4)], { rec: 0.8 })
    ], def('dk_roar', '竜王の咆哮', [ring(0, 350, 1.4, 1.0, STUN)]));

    // ============================================================
    // ゲートキーパー（世界の門番）
    //  門の前から動かず、周囲に無数の「門」を開いて、そこから剣やビームを撃ち込んでくる。
    //  門は開いてからしばらく光っている（予告）。剣は門の向き＝標的に向かって真っすぐ飛ぶ。ビームは細い予告線のあとに発射。
    //  大技は、HPが減るたびに1回ずつ（激昂中はさらにときどき）。ほかのボスの技とは別物。
    // ============================================================
    // --- 次元の門番：第一世界→第二世界 ---
    set('gate_world2', [
        def('g1_blades', '剣の門', [ports(0, 'around', 6, 440, 3.6),
            swords(1.0), swords(1.6, { track: true, frac: 0.8 }), swords(2.2, { track: true, frac: 0.8 }), swords(2.8, { track: true, per: 3, sp: 0.14, frac: 0.6 })]),
        def('g1_beams', '光条の門', [ports(0, 'side', 5, 560, 3.0, { gapY: 190 }), beams(0.9, 1500, 64, 0.9, 1.2),
            ports(2.0, 'sky', 5, 540, 2.4, { gapX: 230 }), beams(2.9, 1500, 70, 0.9, 1.2)], { rec: 0.8 }),
        def('g1_rain', '千剣の雨', [ports(0, 'sky', 9, 520, 3.8, { gapX: 130 }),
            swords(0.9, { frac: 0.6, spd: 500 }), swords(1.4, { frac: 0.6, spd: 500 }), swords(1.9, { frac: 0.6, spd: 500 }), swords(2.4, { frac: 0.6, spd: 500 }), swords(2.9, { frac: 0.6, spd: 500 })])
    ], def('g1_seal', '封門の鎖', [ports(0, 'around', 4, 380, 2.0), at(0.3, 125, 1.3, 0.9, STUN)]),
    { ult: def('g1_ult', '万象開門・千剣', [
        ports(0, 'around', 12, 520, 7.2),
        swords(1.4), swords(2.1, { track: true, frac: 0.7 }), swords(2.7, { track: true, frac: 0.7 }), swords(3.3, { track: true, frac: 0.7 }),
        beams(3.4, 1500, 56, 0.95, 1.3, { frac: 0.4 }),
        swords(4.4, { track: true, frac: 0.6, spd: 560 }), swords(5.0, { track: true, frac: 0.6, spd: 560 }),
        ports(5.0, 'side', 6, 600, 2.6, { gapY: 150 }), beams(6.0, 1500, 60, 0.9, 1.4)
    ], { ult: true, rec: 1.2 }), ultAt: [0.65, 0.3] });

    // --- 終焉の門番：第二世界→第三世界 ---
    set('gate_world3', [
        def('g2_blades', '剣の門・双', [ports(0, 'around', 8, 480, 4.0),
            swords(1.0, { per: 2, sp: 0.1 }), swords(1.5, { track: true }), swords(2.0, { track: true }), swords(2.5, { track: true, per: 2, sp: 0.12 }), swords(3.0, { track: true })]),
        def('g2_beams', '光条の門・交', [ports(0, 'side', 7, 600, 3.2, { gapY: 150 }), beams(0.9, 1500, 58, 0.9, 1.3),
            ports(1.9, 'diag', 4, 650, 2.6), beams(2.8, 1300, 80, 0.9, 1.4)], { rec: 0.8 }),
        def('g2_rain', '千剣の豪雨', [ports(0, 'sky', 11, 520, 4.4, { gapX: 120 }),
            swords(0.9, { frac: 0.55, spd: 560 }), swords(1.3, { frac: 0.55, spd: 560 }), swords(1.7, { frac: 0.55, spd: 560 }), swords(2.1, { frac: 0.55, spd: 560 }), swords(2.5, { frac: 0.55, spd: 560 }), swords(2.9, { frac: 0.55, spd: 560 }),
            beams(1.6, 1500, 56, 0.8, 1.2, { frac: 0.2, track: true })]),
        def('g2_close', '閉門衝撃', [ring(0, 360, 1.2, 1.4), donut(1.3, 620, 360, 1.0, 1.3), ports(1.0, 'around', 6, 420, 3.0), swords(2.4, { track: true, per: 2, sp: 0.12 })])
    ], def('g2_seal', '封門の大鎖', [ports(0, 'around', 6, 420, 2.2), at(0.2, 135, 1.3, 0.9, STUN)]),
    { ult: def('g2_ult', '天地開闢・全門解放', [
        ports(0, 'around', 16, 600, 9.2),
        swords(1.4, { per: 2, sp: 0.1 }), swords(2.0, { track: true, frac: 0.8 }), swords(2.5, { track: true, frac: 0.8 }), swords(3.0, { track: true, frac: 0.6, per: 2, sp: 0.12 }), swords(3.5, { track: true, frac: 0.6, per: 2, sp: 0.12 }),
        beams(3.0, 1500, 52, 0.9, 1.4, { frac: 0.35 }),
        ports(4.2, 'diag', 4, 700, 3.2), beams(5.0, 1500, 90, 0.9, 1.6),
        ports(5.6, 'side', 8, 650, 2.8, { gapY: 150 }), beams(6.5, 1500, 56, 0.9, 1.4),
        line(7.6, 2600, 220, 1.6, 2.4, { aim: 't' }),
        ports(8.4, 'sky', 9, 540, 2.6, { gapX: 130 }), swords(9.4, { frac: 0.7, spd: 560 }), swords(9.9, { frac: 0.7, spd: 560 })
    ], { ult: true, rec: 1.4 }), ultAt: [0.75, 0.5, 0.25] });

    // ============================================================
    // 第三世界「神域」
    // ============================================================
    // --- 熾天使ケルビム：六枚の翼と光輪 ---
    set('god_garden', [
        def('ke_wings', '六翼の斬撃', [cone(0, 270, 100, 0.6, 1.3, { aim: 'l', off: -40 }), cone(0.55, 270, 100, 0.5, 1.3, { aim: 'l', off: 40 }), cone(1.1, 290, 140, 0.65, 1.7, { aim: 't' })]),
        def('ke_halo', '光輪の舞', [rad(0, 24, 250, 0.7), ring(0.4, 190, 0.9, 1.5), rad(1.4, 24, 280, 0.7)]),
        def('ke_judge', '裁きの光', [rain(0, 10, 78, 1.0, 1.2, { gap: 0.14 }), at(0.9, 100, 0.9, 1.3, { who: 'rand' })])
    ], def('ke_seal', '聖印の封縛', [ring(0, 340, 1.4, 0.9, STUN)]));

    // --- 鍛冶神ヘパイストス：鉄槌と溶岩 ---
    set('god_forge', [
        def('fg_hammer', '神鉄の大槌', [leap(0, 0.9, 210, 2.1), ring(1.1, 160, 0.7, 1.3)], { rec: 0.8 }),
        def('fg_sparks', '火花の連打', [fan(0, 9, 8, 380, 0.7), fan(0.4, 9, 8, 380, 0.7), fan(0.8, 9, 8, 380, 0.7), rain(1.0, 6, 85, 1.0, 1.1)]),
        def('fg_lava', '溶岩流', [line(0, 700, 80, 0.9, 1.7, { aim: 'l', off: -30 }), line(0, 700, 80, 0.9, 1.7, { aim: 'l', off: 0 }), line(0, 700, 80, 0.9, 1.7, { aim: 'l', off: 30 }), donut(1.2, 440, 150, 1.0, 1.3)])
    ], def('fg_anvil', '金床落とし', [leap(0, 0.95, 200, 1.0, STUN)]));

    // --- 星喰いの鯨ケートス：大潮と星の吐息 ---
    set('god_ocean', [
        def('ct_tide', '大潮', [donut(0, 460, 160, 1.1, 1.4), ring(1.3, 140, 0.7, 1.5), donut(2.0, 460, 160, 0.9, 1.4)]),
        def('ct_breath', '星の吐息', [cone(0, 720, 90, 1.0, 0.6, { aim: 't', rep: 6, gap: 0.28 })], { rec: 0.8 }),
        def('ct_swim', '潜行突進', [warn(0, 680, 90, 0.7), dash(0.7, 0.6, 880), warn(1.5, 680, 90, 0.5, { aim: 't' }), dash(2.0, 0.6, 880, { aim: 't' })], { rec: 0.8 })
    ], def('ct_whirl', '星海の大渦', [ring(0, 380, 1.4, 0.9, STUN)]));

    // --- 記録の大天使メタトロン：光の頁と聖典 ---
    set('god_archive', [
        def('mm_pages', '光の頁', [fan(0, 11, 8, 360, 0.7), fan(0.5, 11, 8, 360, 0.7), fan(1.0, 11, 8, 360, 0.7)]),
        def('mm_script', '聖典の断罪', [0, 1, 2, 3].map(i => line(i * 0.45, 720, 62, 0.8, 1.5, { aim: 't', off: (i - 1.5) * 14 }))),
        def('mm_rain', '記録の雨', [rain(0, 12, 75, 1.1, 1.2, { gap: 0.12 }), rad(1.6, 22, 240, 0.7)])
    ], def('mm_seal', '封印の文字', [at(0, 150, 1.3, 0.9, STUN), ring(0.3, 120, 1.0, 1.0)]));

    // --- 混沌の母ティアマト：混沌のブレスと眷属 ---
    set('god_chaos', [
        def('tm_breath', '混沌のブレス', [cone(0, 760, 130, 1.1, 0.6, { aim: 't', rep: 5, gap: 0.28 })], { rec: 0.8 }),
        def('tm_claw', '竜爪の連撃', [cone(0, 270, 100, 0.65, 1.4), cone(0.7, 270, 100, 0.55, 1.4), leap(1.4, 0.8, 200, 2.2)], { rec: 0.8 }),
        def('tm_spawn', '眷属産み', [summon(0, 6), rad(0.5, 18, 230, 0.7)]),
        def('tm_storm', '混沌の嵐', [spiral(0, 2.3, 250, 0.8, { arms: 3 }), donut(1.0, 460, 150, 1.0, 1.4)], { rec: 0.8 })
    ], def('tm_roar', '母なる咆哮', [ring(0, 380, 1.4, 1.0, STUN)]));

    // --- 創世神アルカディア：創世の陽光と審判 ---
    set('god_throne', [
        def('ar_sun', '創世の陽光', [0, 1, 2, 3, 4, 5].map(i => line(i * 0.3, 700, 66, 0.6, 1.4, { aim: 'l', off: i * 30 }))),
        def('ar_stars', '星生み', [rain(0, 12, 78, 1.0, 1.3, { gap: 0.12 }), rad(1.3, 20, 250, 0.7)]),
        def('ar_judge', '審判の剣', [cone(0, 290, 140, 0.7, 1.7, { aim: 't' }), cone(0.8, 290, 140, 0.6, 1.7, { aim: 't' }), leap(1.6, 0.85, 220, 2.3)], { rec: 0.9 }),
        def('ar_genesis', '天地創造', [spiral(0, 2.4, 250, 0.8, { arms: 3 }), donut(1.0, 480, 160, 1.0, 1.4), summon(1.4, 4)], { rec: 0.9 })
    ], def('ar_silence', '静寂の世界', [ring(0, 420, 1.5, 1.0, STUN)]));

    // ---- スタンダード専用エンドコンテンツ「永劫の玉座」永劫の裁定者 ----
    set('eternal_throne', [
        def('et_rain', '永劫の驟雨', [rain(0, 14, 82, 1.0, 1.3, { gap: 0.1 }), rad(1.4, 24, 260, 0.7)]),
        def('et_blades', '終局の連剣', [0, 1, 2, 3, 4, 5, 6].map(i => line(i * 0.26, 760, 70, 0.55, 1.5, { aim: 'l', off: i * 28 - 84 }))),
        def('et_judge', '裁定の一閃', [cone(0, 320, 150, 0.75, 1.8, { aim: 't' }), cone(0.9, 320, 150, 0.6, 1.8, { aim: 't' }), leap(1.7, 0.9, 240, 2.4)], { rec: 0.9 }),
        def('et_end', '世界の終端', [spiral(0, 2.6, 260, 0.8, { arms: 4 }), donut(1.1, 520, 170, 1.0, 1.5), summon(1.5, 5)], { rec: 0.9 })
    ], def('et_silence', '永劫の静寂', [ring(0, 460, 1.4, 1.0, STUN)]));

    // ============================================================
    // 第四世界「機神の都」
    // ============================================================
    set('gate_world4', [
        def('g3_blades', '歯車剣の門', [ports(0, 'around', 9, 500, 4.2),
            swords(1.0, { per: 2, sp: 0.1 }), swords(1.5, { track: true }), swords(2.0, { track: true }), swords(2.5, { track: true, per: 3, sp: 0.12 }), swords(3.0, { track: true })]),
        def('g3_beams', '電光条の門', [ports(0, 'side', 8, 620, 3.4, { gapY: 140 }), beams(0.9, 1500, 60, 0.9, 1.3),
            ports(1.9, 'diag', 4, 660, 2.8), beams(2.8, 1300, 84, 0.9, 1.5)], { rec: 0.8 }),
        def('g3_rain', '千剣の鉄雨', [ports(0, 'sky', 12, 520, 4.6, { gapX: 112 }),
            swords(0.9, { frac: 0.55, spd: 580 }), swords(1.3, { frac: 0.55, spd: 580 }), swords(1.7, { frac: 0.55, spd: 580 }), swords(2.1, { frac: 0.55, spd: 580 }), swords(2.5, { frac: 0.55, spd: 580 }),
            beams(1.6, 1500, 56, 0.8, 1.2, { frac: 0.2, track: true })]),
        def('g3_close', '閉門圧搾', [ring(0, 380, 1.2, 1.5), donut(1.3, 640, 380, 1.0, 1.4), ports(1.0, 'around', 6, 420, 3.0), swords(2.4, { track: true, per: 3, sp: 0.12 })])
    ], def('g3_seal', '封門の鉄鎖', [ports(0, 'around', 6, 420, 2.2), at(0.2, 140, 1.3, 0.9, STUN)]),
    { ult: def('g3_ult', '機構開闢・全門解放', [
        ports(0, 'around', 18, 620, 9.6),
        swords(1.4, { per: 2, sp: 0.1 }), swords(2.0, { track: true, frac: 0.8 }), swords(2.5, { track: true, frac: 0.8 }), swords(3.0, { track: true, frac: 0.6, per: 3, sp: 0.12 }),
        beams(3.0, 1500, 52, 0.9, 1.5, { frac: 0.35 }), ports(4.2, 'diag', 4, 720, 3.2), beams(5.0, 1500, 92, 0.9, 1.7),
        ports(5.6, 'side', 9, 660, 2.8, { gapY: 140 }), beams(6.5, 1500, 56, 0.9, 1.5), line(7.6, 2600, 240, 1.6, 2.6, { aim: 't' }),
        ports(8.4, 'sky', 10, 540, 2.6, { gapX: 120 }), swords(9.4, { frac: 0.7, spd: 580 }), swords(9.9, { frac: 0.7, spd: 580 })
    ], { ult: true, rec: 1.4 }), ultAt: [0.75, 0.5, 0.25] });

    // --- 蒸気竜機スチームドレイク：蒸気と突進 ---
    set('steam_bridge', [
        def('sd_steam', '蒸気噴射', [cone(0, 700, 100, 1.0, 0.6, { aim: 't', rep: 4, gap: 0.3 })], { rec: 0.8 }),
        def('sd_piston', 'ピストン連打', [ring(0, 150, 0.7, 1.4), ring(0.8, 240, 0.7, 1.3), donut(1.6, 420, 230, 0.8, 1.3)]),
        def('sd_rush', '蒸気突進', [warn(0, 620, 90, 0.7), dash(0.7, 0.6, 800), cone(1.4, 300, 120, 0.6, 1.4)], { rec: 0.7 })
    ], def('sd_whistle', '破裂の汽笛', [ring(0, 330, 1.3, 0.9, STUN)]));

    // --- 大司教機ギアビショップ：讃美歌と鐘 ---
    set('gear_cathedral', [
        def('gb_hymn', '歯車の讃美歌', [rad(0, 16, 230, 0.7), rad(0.6, 16, 260, 0.7), rad(1.2, 16, 290, 0.7)]),
        def('gb_bell', '鐘の轟音', [ring(0, 200, 0.9, 1.5), donut(1.1, 480, 200, 1.0, 1.3)]),
        def('gb_gears', '歯車の雨', [rain(0, 9, 85, 1.0, 1.2, { gap: 0.14 }), summon(1.2, 3)]),
        def('gb_cross', '鎖十字', [0, 90, 180, 270].map(o => line(0, 700, 60, 0.8, 1.5, { aim: 'l', off: o })), { rec: 0.8 })
    ], def('gb_confess', '懺悔の鐘', [at(0, 115, 1.2, 0.9, STUN), ring(0.2, 130, 1.0, 0.8)]));

    // --- 電脳の守護者サイバーウォーデン：削除と転送 ---
    set('cyber_corridor', [
        def('cw_scan', 'スキャンビーム', [0, 1, 2, 3].map(i => line(i * 0.4, 740, 56, 0.8, 1.5, { aim: 't', off: (i - 1.5) * 18 }))),
        def('cw_glitch', 'グリッチ弾幕', [fan(0, 9, 8, 400, 0.7), fan(0.4, 9, 8, 400, 0.7), fan(0.8, 9, 8, 400, 0.7)]),
        def('cw_delete', '強制削除', [rain(0, 12, 70, 1.1, 1.2, { gap: 0.1 }), at(1.3, 100, 0.9, 1.3, { who: 'rand' })]),
        def('cw_warp', 'ワープ強襲', [leap(0, 0.8, 190, 2.0), cone(1.0, 300, 110, 0.6, 1.4)], { rec: 0.8 })
    ], def('cw_lock', 'ロックオン', [at(0, 110, 1.3, 0.9, STUN), ring(0.2, 120, 1.0, 0.8)]));

    // --- 剣闘機グラディエーター・ゼロ：連斬と突撃 ---
    set('steel_arena', [
        def('gz_slash', '剣闘の連斬', [cone(0, 260, 90, 0.55, 1.3, { aim: 'l', off: -30 }), cone(0.5, 260, 90, 0.5, 1.3, { aim: 'l', off: 30 }), cone(1.0, 320, 120, 0.6, 1.6, { aim: 't' })]),
        def('gz_charge', '二連突撃', [warn(0, 640, 90, 0.6), dash(0.6, 0.55, 880), warn(1.3, 640, 90, 0.5, { aim: 't' }), dash(1.8, 0.55, 880, { aim: 't' })], { rec: 0.8 }),
        def('gz_net', '投網', [rain(0, 8, 95, 1.0, 1.1, { gap: 0.2 }), ring(1.2, 150, 0.7, 1.4)]),
        def('gz_cheer', '観客の声援', [summon(0, 4), rad(0.6, 14, 240, 0.7)])
    ], def('gz_bash', '盾打ち', [cone(0, 260, 80, 1.1, 0.9, Object.assign({ aim: 't' }, STUN))]));

    // --- 工廠長オートマ・マザー：プレスと組立 ---
    set('zero_foundry', [
        def('om_press', 'プレス機', [at(0, 110, 0.9, 1.5), at(0.5, 110, 0.9, 1.5), at(1.0, 110, 0.9, 1.5)]),
        def('om_molten', '溶鉄流', [line(0, 720, 80, 0.9, 1.7, { aim: 'l', off: -20 }), line(0, 720, 80, 0.9, 1.7, { aim: 'l', off: 20 }), donut(1.2, 460, 160, 1.0, 1.3)]),
        def('om_assemble', '緊急組立', [summon(0, 6), rad(0.6, 18, 230, 0.7)]),
        def('om_spin', '回転刃', [spiral(0, 2.4, 260, 0.8, { arms: 4 }), ring(1.4, 140, 0.7, 1.3)], { rec: 0.8 })
    ], def('om_clamp', 'クランプ固定', [ring(0, 320, 1.4, 0.9, STUN)]));

    // --- 機神王ゴッドマキナ：主砲と巨神の踏みつけ ---
    set('mech_throne', [
        def('gm_laser', '王の主砲', [cone(0, 760, 50, 1.1, 0.7, { aim: 't', rep: 5, gap: 0.26 })], { rec: 0.8 }),
        def('gm_barrage', '全砲門斉射', [fan(0, 13, 6, 420, 0.7), fan(0.4, 13, 6, 420, 0.7), rad(0.9, 24, 260, 0.7)]),
        def('gm_stomp', '巨神の踏みつけ', [leap(0, 0.85, 230, 2.2), ring(1.1, 180, 0.7, 1.4), donut(1.8, 520, 200, 1.0, 1.4)], { rec: 0.9 }),
        def('gm_deploy', '機兵投下', [summon(0, 5), rain(0.5, 8, 80, 1.0, 1.1)])
    ], def('gm_emp', '電磁パルス', [ring(0, 420, 1.4, 1.0, STUN)]),
    { ult: def('gm_ult', '神機解放', [spiral(0, 3, 260, 0.8, { arms: 4 }), ring(1.0, 300, 1.2, 1.5), line(1.8, 900, 70, 0.9, 1.7, { aim: 't' }), donut(2.6, 560, 220, 1.0, 1.5)], { ult: true, rec: 1.2 }), ultAt: [0.7, 0.35] });

    // ============================================================
    // 第五世界「虚空の彼方」
    // ============================================================
    set('gate_world5', [
        def('g4_blades', '虚剣の門', [ports(0, 'around', 10, 520, 4.4),
            swords(1.0, { per: 3, sp: 0.1 }), swords(1.5, { track: true }), swords(2.0, { track: true, per: 2, sp: 0.12 }), swords(2.5, { track: true }), swords(3.0, { track: true, per: 3, sp: 0.12 })]),
        def('g4_beams', '虚光条の門', [ports(0, 'side', 9, 640, 3.4, { gapY: 130 }), beams(0.9, 1500, 62, 0.9, 1.4),
            ports(1.9, 'diag', 4, 680, 2.8), beams(2.8, 1300, 88, 0.9, 1.6), ports(3.2, 'sky', 6, 540, 2.2, { gapX: 180 }), beams(4.0, 1500, 60, 0.8, 1.4)], { rec: 0.8 }),
        def('g4_rain', '千剣の虚雨', [ports(0, 'sky', 13, 520, 4.8, { gapX: 104 }),
            swords(0.9, { frac: 0.5, spd: 600 }), swords(1.3, { frac: 0.5, spd: 600 }), swords(1.7, { frac: 0.5, spd: 600 }), swords(2.1, { frac: 0.5, spd: 600 }), swords(2.5, { frac: 0.5, spd: 600 }), swords(2.9, { frac: 0.5, spd: 600 }),
            beams(1.6, 1500, 56, 0.8, 1.3, { frac: 0.25, track: true })]),
        def('g4_collapse', '門の崩落', [ring(0, 400, 1.2, 1.6), donut(1.3, 660, 400, 1.0, 1.5), ports(1.0, 'around', 8, 440, 3.2), swords(2.4, { track: true, per: 3, sp: 0.12 }), beams(3.0, 1400, 70, 0.9, 1.5, { frac: 0.4, track: true })])
    ], def('g4_seal', '無限の封門', [ports(0, 'around', 8, 440, 2.4), at(0.2, 145, 1.3, 0.9, STUN)]),
    { ult: def('g4_ult', '終焉門・万象解放', [
        ports(0, 'around', 20, 640, 10.4),
        swords(1.4, { per: 3, sp: 0.1 }), swords(2.0, { track: true, frac: 0.8 }), swords(2.5, { track: true, frac: 0.8 }), swords(3.0, { track: true, frac: 0.7, per: 3, sp: 0.12 }), swords(3.5, { track: true, frac: 0.7, per: 3, sp: 0.12 }),
        beams(3.0, 1500, 52, 0.9, 1.5, { frac: 0.35 }), ports(4.2, 'diag', 4, 740, 3.4), beams(5.0, 1500, 96, 0.9, 1.8),
        ports(5.6, 'side', 10, 680, 3.0, { gapY: 130 }), beams(6.5, 1500, 58, 0.9, 1.6), line(7.6, 2800, 260, 1.6, 2.8, { aim: 't' }),
        ports(8.4, 'sky', 12, 540, 2.8, { gapX: 110 }), swords(9.4, { frac: 0.7, spd: 600 }), swords(9.9, { frac: 0.7, spd: 600 }), beams(10.2, 1500, 60, 0.9, 1.6, { frac: 0.4 })
    ], { ult: true, rec: 1.5 }), ultAt: [0.8, 0.6, 0.4, 0.2] });

    // --- 星喰らいの屍竜スターイーター ---
    set('stardust_graveyard', [
        def('se_gnaw', '屍竜の連撃', [cone(0, 300, 110, 0.6, 1.5), cone(0.7, 300, 110, 0.5, 1.5), leap(1.4, 0.8, 210, 2.2)], { rec: 0.8 }),
        def('se_dust', '星屑のブレス', [cone(0, 740, 120, 1.0, 0.6, { aim: 't', rep: 5, gap: 0.28 })], { rec: 0.8 }),
        def('se_rain', '流星群', [rain(0, 12, 80, 1.0, 1.2, { gap: 0.12 }), rad(1.5, 20, 250, 0.7)])
    ], def('se_wail', '亡者の慟哭', [ring(0, 360, 1.4, 0.9, STUN)]));

    // --- 渦の巫女ギャラクシア ---
    set('galaxy_vortex', [
        def('gv_spin', '銀河の渦', [spiral(0, 2.6, 240, 0.8, { arms: 3 }), donut(1.2, 460, 170, 1.0, 1.3)], { rec: 0.8 }),
        def('gv_orbs', '星珠の舞', [fan(0, 7, 10, 380, 0.8), fan(0.4, 7, 10, 380, 0.8), fan(0.8, 7, 10, 380, 0.8), at(1.0, 100, 0.9, 1.3, { who: 'rand' })]),
        def('gv_pull', '重力崩壊', [ring(0, 160, 0.8, 1.5), donut(0.9, 480, 160, 1.0, 1.4), ring(1.8, 260, 0.8, 1.3)]),
        def('gv_call', '星の使い', [summon(0, 5), rad(0.6, 16, 230, 0.7)])
    ], def('gv_fate', '運命の糸', [at(0, 125, 1.3, 0.9, STUN), ring(0.3, 140, 1.0, 0.8)]));

    // --- 地平の番人ホライゾン ---
    set('event_horizon', [
        def('eh_pull', '引力波', [donut(0, 500, 180, 1.1, 1.4), ring(1.2, 150, 0.7, 1.5), donut(1.9, 500, 180, 0.9, 1.4)]),
        def('eh_rift', '地平の亀裂', [0, 1, 2, 3, 4].map(i => line(i * 0.2, 820, 64, 0.9, 1.5, { aim: 'l', off: (i - 2) * 22 }))),
        def('eh_dash', '影の突進', [warn(0, 700, 90, 0.6), dash(0.6, 0.6, 900), warn(1.3, 700, 90, 0.5, { aim: 't' }), dash(1.8, 0.6, 900, { aim: 't' }), ring(2.5, 200, 0.7, 1.3)], { rec: 0.8 }),
        def('eh_swarm', '影の使徒', [summon(0, 4), spiral(0.4, 2, 240, 0.8, { arms: 2 })])
    ], def('eh_void', '無明の闇', [ring(0, 400, 1.5, 1.0, STUN)]));

    // --- 滅星の巨人ノヴァ・タイタン ---
    set('dying_star', [
        def('nt_fist', '灼熱の拳', [leap(0, 0.9, 220, 2.2), ring(1.1, 170, 0.7, 1.4)], { rec: 0.8 }),
        def('nt_flare', 'フレア弾', [fan(0, 11, 7, 400, 0.7), fan(0.4, 11, 7, 400, 0.7), rain(0.9, 8, 85, 1.0, 1.1)]),
        def('nt_wave', '熱波', [donut(0, 520, 200, 1.1, 1.4), donut(1.2, 520, 200, 0.9, 1.4), cone(2.2, 700, 90, 0.8, 1.5, { aim: 't' })])
    ], def('nt_core', '星核崩壊', [at(0, 140, 1.3, 0.9, STUN), ring(0.3, 130, 1.0, 1.0)]));

    // --- 虚空鯨ヴォイドリヴァイアサン ---
    set('void_sea', [
        def('vl_tide', '虚空の大潮', [donut(0, 500, 170, 1.1, 1.4), ring(1.2, 150, 0.7, 1.5), donut(1.9, 520, 170, 0.9, 1.4)]),
        def('vl_song', '鯨の歌', [rad(0, 22, 240, 0.7), rad(0.7, 22, 270, 0.7), spiral(1.2, 2, 240, 0.8, { arms: 2 })]),
        def('vl_swim', '潜行突進', [warn(0, 720, 100, 0.7), dash(0.7, 0.6, 920), warn(1.5, 720, 100, 0.5, { aim: 't' }), dash(2.0, 0.6, 920, { aim: 't' })], { rec: 0.8 }),
        def('vl_spawn', '稚魚の群れ', [summon(0, 6), rain(0.6, 8, 80, 1.0, 1.1)])
    ], def('vl_whirl', '虚空の大渦', [ring(0, 400, 1.4, 0.9, STUN)]));

    // --- 虚空の王アビス・オブ・ゼロ ---
    set('void_throne', [
        def('az_edict', '虚王の勅令', [cone(0, 330, 130, 0.7, 1.6, { aim: 't' }), cone(0.8, 330, 130, 0.6, 1.6, { aim: 't' }), leap(1.6, 0.85, 240, 2.4)], { rec: 0.9 }),
        def('az_zero', 'ゼロの光条', [0, 1, 2, 3, 4, 5, 6].map(i => line(i * 0.18, 900, 62, 0.9, 1.6, { aim: 'l', off: (i - 3) * 20 }))),
        def('az_nova', '終末の星屑', [rain(0, 14, 80, 1.0, 1.3, { gap: 0.1 }), rad(1.5, 26, 270, 0.7)]),
        def('az_court', '近衛召喚', [summon(0, 6), spiral(0.5, 2.4, 250, 0.8, { arms: 3 })]),
        def('az_abyss', '深淵の顎', [donut(0, 560, 200, 1.1, 1.5), ring(1.2, 200, 0.8, 1.5), donut(2.0, 560, 200, 1.0, 1.5)], { rec: 0.9 })
    ], def('az_silence', '無音の世界', [ring(0, 450, 1.4, 1.0, STUN)]),
    { ult: def('az_ult', '虚無への回帰', [spiral(0, 3, 260, 0.8, { arms: 5 }), ring(1.0, 320, 1.2, 1.5), line(1.8, 1000, 90, 1.0, 1.8, { aim: 't' }), donut(2.8, 600, 240, 1.0, 1.6), rain(3.4, 16, 80, 1.0, 1.3, { gap: 0.1 })], { ult: true, rec: 1.3 }), ultAt: [0.75, 0.5, 0.25] });

    // ============================================================
    // ギミックボス（第四・第五世界）。ギミック本体は stage.js（stigma / pressure / gravity / twin / dimension）
    // ============================================================
    // --- 炉心の巨人ブラスト：25秒ごとに圧力を溜めて大爆発（安全弁を壊すと阻止）---
    set('boiler_heart', [
        def('bh_vent', '蒸気噴射', [cone(0, 300, 100, 0.75, 1.5, { aim: 't' }), cone(0.9, 300, 100, 0.6, 1.5, { aim: 't' })]),
        def('bh_rivet', 'リベット弾', [fan(0, 7, 10, 380, 0.8), fan(0.5, 7, 10, 380, 0.8), fan(1.0, 9, 10, 380, 0.8)]),
        def('bh_crush', '圧壊', [ring(0, 200, 0.9, 1.6), donut(1.0, 520, 210, 0.9, 1.4)]),
        def('bh_run', '暴走蒸気', [warn(0, 640, 90, 0.7), dash(0.7, 0.6, 820), ring(1.6, 170, 0.7, 1.2)], { rec: 0.7 })
    ], def('bh_scald', '高圧蒸気', [cone(0, 520, 70, 1.2, 0.8, Object.assign({ aim: 't' }, STUN))]));

    // --- 死神グリム・リーパー：10秒ごとにスティグマ。13個で死亡 ---
    set('grave_of_gears', [
        def('gg_scythe', '死神の三連鎌', [cone(0, 280, 110, 0.7, 1.5, { aim: 't' }), cone(0.8, 280, 110, 0.6, 1.5, { aim: 't' }), cone(1.5, 320, 150, 0.8, 1.9, { aim: 't' })]),
        def('gg_souls', '魂狩りの雨', [rain(0, 11, 80, 1.0, 1.3, { gap: 0.12 }), at(1.2, 105, 0.9, 1.4, { who: 'rand' })]),
        def('gg_reap', '刈り取りの円環', [0, 1, 2, 3, 4, 5].map(i => line(i * 0.22, 860, 56, 0.85, 1.5, { aim: 'l', off: i * 60 })).concat([ring(1.6, 220, 0.8, 1.4)])),
        def('gg_veil', '死の帳', [spiral(0, 2.6, 250, 0.8, { arms: 3 }), rad(1.2, 22, 250, 0.7)]),
        def('gg_call', '亡者の招集', [summon(0, 5), fan(0.5, 9, 8, 380, 0.7)])
    ], def('gg_gaze', '死の凝視', [cone(0, 560, 60, 1.2, 0.8, Object.assign({ aim: 't' }, STUN))]),
    { ult: def('gg_ult', '終末の鐘', [ring(0, 260, 1.2, 1.5), donut(1.3, 640, 260, 1.0, 1.6), rain(2.2, 14, 80, 1.0, 1.3, { gap: 0.1 }), line(3.2, 1200, 120, 1.0, 1.8, { aim: 't' })], { ult: true, rec: 1.3 }), ultAt: [0.7, 0.4] });

    // --- 重力喰らいグラビトン：全員を中心へ引き寄せてから押し潰す ---
    set('gravity_well', [
        def('gw_pull', '重力井戸', [pull(0, 2.2, 260), ring(1.9, 230, 0.8, 1.6)], { rec: 0.9 }),
        def('gw_orbit', '周回する星', [spiral(0, 2.8, 240, 0.8, { arms: 3 }), rad(1.4, 20, 250, 0.7)]),
        def('gw_meteor', '隕石の落下', [rain(0, 13, 80, 1.0, 1.3, { gap: 0.1 }), at(1.3, 110, 0.9, 1.4, { who: 'rand' })]),
        def('gw_crush', '重力崩壊', [pull(0, 1.4, 320), donut(1.0, 560, 200, 0.9, 1.5), ring(1.6, 200, 0.8, 1.5)])
    ], def('gw_singularity', '特異点', [pull(0, 1.8, 300), ring(1.2, 380, 1.0, 1.0, STUN)]));

    // --- 雷神ゼウス＆火の巨人プロメテウス（ニコイチ。片方を倒すと残った方が15秒で蘇らせる）---
    set('olympus_zeus', [
        def('zs_bolt', '雷霆の矢', [line(0, 1000, 60, 0.8, 1.6, { aim: 't' }), line(0.5, 1000, 60, 0.8, 1.6, { aim: 't', off: -18 }), line(1.0, 1000, 60, 0.8, 1.6, { aim: 't', off: 18 })]),
        def('zs_storm', '雷雨', [rain(0, 13, 78, 1.0, 1.3, { gap: 0.1 }), at(1.3, 100, 0.9, 1.4, { who: 'rand' })]),
        def('zs_chain', '連鎖雷', [at(0, 95, 0.8, 1.5), at(0.5, 95, 0.8, 1.5, { who: 'rand' }), at(1.0, 95, 0.8, 1.5, { who: 'rand' }), at(1.5, 95, 0.8, 1.5, { who: 'rand' })]),
        def('zs_orb', '雷球', [fan(0, 5, 14, 420, 0.8), fan(0.5, 7, 14, 420, 0.8), rad(1.2, 18, 260, 0.7)])
    ], def('zs_judge', '雷霆の裁き', [at(0, 125, 1.2, 0.9, STUN), ring(0.3, 170, 1.0, 1.0)]),
    { ult: def('zs_ult', '神雷・天罰', [rain(0, 18, 84, 1.0, 1.4, { gap: 0.08 }), line(1.6, 1300, 150, 1.0, 2.0, { aim: 't' }), ring(2.6, 300, 1.1, 1.6), donut(3.5, 640, 300, 1.0, 1.6)], { ult: true, rec: 1.3 }), ultAt: [0.65, 0.3] });
    set('olympus_prometheus', [
        def('pm_flame', '炎の噴流', [cone(0, 320, 100, 0.7, 1.5, { aim: 't' }), cone(0.8, 320, 100, 0.6, 1.5, { aim: 't' }), cone(1.5, 360, 150, 0.8, 1.9, { aim: 't' })]),
        def('pm_gift', '火の贈り物', [rad(0, 24, 230, 0.8), ring(0.8, 200, 0.8, 1.4), rad(1.6, 24, 260, 0.8)]),
        def('pm_dash', '業火の突進', [warn(0, 640, 90, 0.7), dash(0.7, 0.6, 860), warn(1.5, 640, 90, 0.5, { aim: 't' }), dash(2.0, 0.6, 860, { aim: 't' })], { rec: 0.8 }),
        def('pm_ember', '火の粉の雨', [rain(0, 13, 80, 1.0, 1.3, { gap: 0.1 }), donut(1.4, 520, 200, 0.9, 1.4)])
    ], def('pm_bind', '業火の拘束', [ring(0, 330, 1.3, 1.0, STUN)]),
    { ult: def('pm_ult', '天の火・神罰', [spiral(0, 3, 250, 0.8, { arms: 4 }), ring(1.0, 280, 1.2, 1.6), line(1.8, 1100, 120, 1.0, 1.8, { aim: 't' }), donut(2.8, 620, 260, 1.0, 1.6)], { ult: true, rec: 1.3 }), ultAt: [0.65, 0.3] });

    // --- 双界の覇竜ツイン・エレメンタル（大討伐戦）：赤と青の二重奏。予告の色（赤・青・紫）がそのまま攻撃の色 ---
    //  フィールドの割れ目・属性シールド・カタストロフ・レイン・双界終焉は practice.js の gimmick:'duality' が担当
    const RED = '#ff5a3a', BLUE = '#4ac8ff', PUR = '#b060ff';
    const tc = (c, o) => Object.assign({ c: c }, o);
    set('raid_duality', [
        // ツイン・ブレス・スウィープ：右の首の赤い火炎と、左の首の青い吹雪が、左右から挟み込むように薙ぎ払う（2本の間が安全地帯）
        def('rd_breath', 'ツイン・ブレス・スウィープ', [
            line(0, 1500, 150, 1.5, 1.4, tc(RED, { aim: 'l', off: -34 })), line(0, 1500, 150, 1.5, 1.4, tc(BLUE, { aim: 'l', off: 34 })),
            line(1.7, 1500, 150, 1.2, 1.4, tc(RED, { aim: 'l', off: -16 })), line(1.7, 1500, 150, 1.2, 1.4, tc(BLUE, { aim: 'l', off: 16 })),
            line(3.2, 1500, 170, 1.1, 1.5, tc(RED, { aim: 'l', off: -12 })), line(3.2, 1500, 170, 1.1, 1.5, tc(BLUE, { aim: 'l', off: 12 }))], { rec: 0.9 }),
        // 竜の爪：扇状の薙ぎ払いと、足もとの輪
        def('rd_claw', '双頭の爪撃', [cone(0, 420, 110, 0.9, 1.5, tc(RED, { aim: 't' })), cone(0.9, 420, 110, 0.9, 1.5, tc(BLUE, { aim: 't' })), ring(1.9, 260, 0.9, 1.5, tc(PUR))]),
        // 弾幕：赤い弾の輪と青い弾の輪を、交互に放つ
        def('rd_orbs', '炎珠と氷珠', [rad(0, 18, 230, 0.8, tc(RED)), rad(0.7, 18, 230, 0.8, tc(BLUE, { off: 10 })), rad(1.4, 18, 230, 0.8, tc(RED, { off: 20 })), rad(2.1, 18, 230, 0.8, tc(BLUE, { off: 30 }))])
    ], def('rd_stun', '双界の咆哮', [ring(0, 380, 1.4, 1.0, STUN)]));
    // 第二形態：臨界突破・紫炎の崩壊（HP50%以下）。攻撃がすべて「紫」になり、威力とスピードが跳ね上がる
    set('raid_duality2', [
        def('rd2_breath', '紫炎のブレス・スウィープ', [
            line(0, 1500, 170, 1.2, 1.7, tc(PUR, { aim: 'l', off: -26 })), line(0, 1500, 170, 1.2, 1.7, tc(PUR, { aim: 'l', off: 26 })),
            line(1.4, 1500, 170, 1.0, 1.7, tc(PUR, { aim: 'l', off: -10 })), line(1.4, 1500, 170, 1.0, 1.7, tc(PUR, { aim: 'l', off: 10 })),
            line(2.6, 1500, 190, 0.9, 1.9, tc(PUR, { aim: 'l', off: 0 }))], { rec: 0.7 }),
        def('rd2_beam', '紫炎のビーム', [0, 1, 2, 3, 4, 5, 6].map(i => line(i * 0.25, 1500, 64, 0.9, 1.5, tc(PUR, { aim: 't', off: (i - 3) * 16 })))),
        def('rd2_orbs', '紫炎の弾幕', [rad(0, 24, 300, 0.9, tc(PUR)), rad(0.5, 24, 300, 0.9, tc(PUR, { off: 7 })), rad(1.0, 24, 300, 0.9, tc(PUR, { off: 14 })), spiral(1.6, 2.4, 260, 0.8, tc(PUR, { arms: 3 }))]),
        def('rd2_fall', '紫炎の崩落', [rain(0, 16, 90, 1.0, 1.6, tc(PUR, { gap: 0.1 })), donut(1.8, 640, 240, 1.0, 1.8, tc(PUR))])
    ], def('rd2_stun', '紫炎の咆哮', [ring(0, 420, 1.2, 1.1, STUN)]));

    // --- ディメンション・キーパー：第一形態（核で守られている。放射弾の反射は stage.js が担当）---
    set('dim_keeper1', [
        def('d1_rift', '次元の裂け目', [0, 1, 2, 3, 4].map(i => line(i * 0.2, 1000, 60, 0.9, 1.5, { aim: 't', off: (i - 2) * 22 }))),
        def('d1_fall', '空間の崩落', [rain(0, 12, 80, 1.0, 1.3, { gap: 0.1 }), ring(1.4, 190, 0.8, 1.4)]),
        def('d1_ring', '次元輪', [donut(0, 520, 200, 1.0, 1.4), ring(1.0, 200, 0.8, 1.4)])
    ], def('d1_seal', '次元封印', [ring(0, 380, 1.4, 1.0, STUN)]));
    // --- ディメンション・キーパー：第二形態（強化ゲートキーパー。ゲートから剣とビーム）---
    set('dim_keeper2', [
        def('d2_blades', '次元剣の門', [ports(0, 'around', 12, 540, 4.6),
            swords(1.0, { per: 3, sp: 0.1 }), swords(1.5, { track: true }), swords(2.0, { track: true, per: 2, sp: 0.12 }), swords(2.5, { track: true }), swords(3.0, { track: true, per: 3, sp: 0.12 })]),
        def('d2_beams', '次元光条の門', [ports(0, 'side', 9, 640, 3.4, { gapY: 130 }), beams(0.9, 1500, 62, 0.9, 1.5),
            ports(1.9, 'diag', 4, 680, 2.8), beams(2.8, 1300, 90, 0.9, 1.7), ports(3.2, 'sky', 6, 540, 2.2, { gapX: 180 }), beams(4.0, 1500, 60, 0.8, 1.5)], { rec: 0.8 }),
        def('d2_rain', '千剣の次元雨', [ports(0, 'sky', 14, 520, 4.8, { gapX: 100 }),
            swords(0.9, { frac: 0.5, spd: 620 }), swords(1.3, { frac: 0.5, spd: 620 }), swords(1.7, { frac: 0.5, spd: 620 }), swords(2.1, { frac: 0.5, spd: 620 }), swords(2.5, { frac: 0.5, spd: 620 }), swords(2.9, { frac: 0.5, spd: 620 }),
            beams(1.6, 1500, 56, 0.8, 1.4, { frac: 0.25, track: true })]),
        def('d2_collapse', '門の崩落・極', [ring(0, 420, 1.2, 1.7), donut(1.3, 680, 420, 1.0, 1.6), ports(1.0, 'around', 8, 440, 3.2), swords(2.4, { track: true, per: 3, sp: 0.12 }), beams(3.0, 1400, 72, 0.9, 1.6, { frac: 0.4, track: true })])
    ], def('d2_seal', '終端の封門', [ports(0, 'around', 8, 440, 2.4), at(0.2, 150, 1.3, 0.9, STUN)]),
    { ult: def('d2_ult', '次元崩壊・万象回帰', [
        ports(0, 'around', 20, 640, 10.4),
        swords(1.4, { per: 3, sp: 0.1 }), swords(2.0, { track: true, frac: 0.8 }), swords(2.5, { track: true, frac: 0.8 }), swords(3.0, { track: true, frac: 0.7, per: 3, sp: 0.12 }), swords(3.5, { track: true, frac: 0.7, per: 3, sp: 0.12 }),
        beams(3.0, 1500, 52, 0.9, 1.6, { frac: 0.35 }), ports(4.2, 'diag', 4, 740, 3.4), beams(5.0, 1500, 96, 0.9, 1.9),
        ports(5.6, 'side', 10, 680, 3.0, { gapY: 130 }), beams(6.5, 1500, 58, 0.9, 1.7), line(7.6, 2800, 260, 1.6, 3.0, { aim: 't' }),
        ports(8.4, 'sky', 12, 540, 2.8, { gapX: 110 }), swords(9.4, { frac: 0.7, spd: 620 }), swords(9.9, { frac: 0.7, spd: 620 }), beams(10.2, 1500, 60, 0.9, 1.7, { frac: 0.4 })
    ], { ult: true, rec: 1.5 }), ultAt: [0.8, 0.6, 0.4, 0.2] });

    // ============================================================
    // スタンダードワールド
    // ============================================================
    set('std_gate', [
        def('sg_hammer', '番人の大槌', [leap(0, 0.9, 230, 2.4), ring(1.1, 190, 0.7, 1.5), donut(1.8, 500, 210, 1.0, 1.4)], { rec: 0.9 }),
        def('sg_pillars', '石柱の連撃', [at(0, 105, 0.9, 1.5), at(0.4, 105, 0.9, 1.5), at(0.8, 105, 0.9, 1.5), at(1.2, 105, 0.9, 1.5)]),
        def('sg_call', '番兵召喚', [summon(0, 6), rad(0.6, 20, 240, 0.7)])
    ], def('sg_seal', '封門の石眼', [ring(0, 380, 1.4, 1.0, STUN)]));
    set('std_time', [
        def('st_sand', '砂の奔流', [cone(0, 760, 100, 1.0, 0.6, { aim: 't', rep: 6, gap: 0.26 })], { rec: 0.8 }),
        def('st_tick', '秒針の斬撃', [0, 1, 2, 3, 4, 5].map(i => line(i * 0.3, 860, 56, 0.8, 1.6, { aim: 'l', off: i * 60 }))),
        def('st_rewind', '巻き戻し', [ring(0, 170, 0.8, 1.5), donut(0.9, 520, 170, 1.0, 1.5), ring(1.8, 300, 0.8, 1.4), spiral(2.0, 2, 250, 0.8, { arms: 3 })]),
        def('st_rain', '砂時計の雨', [rain(0, 13, 80, 1.0, 1.3, { gap: 0.11 }), summon(1.3, 4)])
    ], def('st_stop', '時間停止', [ring(0, 440, 1.5, 1.0, STUN)]));
    set('std_cause', [
        def('sc_verdict', '因果の断罪', [cone(0, 340, 120, 0.65, 1.7, { aim: 't' }), cone(0.7, 340, 120, 0.55, 1.7, { aim: 't' }), leap(1.5, 0.85, 240, 2.5)], { rec: 0.9 }),
        def('sc_chain', '因果の鎖', [0, 1, 2, 3].map(i => line(i * 0.35, 900, 60, 0.85, 1.6, { aim: 't', off: (i - 1.5) * 16 })).concat([ring(1.8, 200, 0.8, 1.4)])),
        def('sc_cause', '原因の雨', [rain(0, 14, 76, 1.0, 1.3, { gap: 0.1 }), at(1.4, 110, 0.9, 1.4, { who: 'rand' })]),
        def('sc_effect', '結果の顕現', [summon(0, 6), fan(0.4, 15, 6, 420, 0.7), fan(0.8, 15, 6, 420, 0.7)])
    ], def('sc_cut', '因果断絶', [at(0, 135, 1.3, 0.9, STUN), ring(0.3, 150, 1.0, 1.0)]));
    set('std_loop', [
        def('sl_loop', '回廊の周回', [warn(0, 760, 100, 0.6), dash(0.6, 0.6, 940), warn(1.3, 760, 100, 0.5, { aim: 't' }), dash(1.8, 0.6, 940, { aim: 't' }), warn(2.5, 760, 100, 0.5, { aim: 't' }), dash(3.0, 0.6, 940, { aim: 't' })], { rec: 0.9 }),
        def('sl_mirror', '鏡像の弾幕', [spiral(0, 3, 250, 0.8, { arms: 4 }), rad(1.0, 26, 260, 0.7), rad(1.8, 26, 290, 0.7)]),
        def('sl_maze', '迷宮の壁', [0, 1, 2, 3, 4].map(i => line(i * 0.25, 900, 70, 0.9, 1.7, { aim: 'l', off: i * 72 })).concat([donut(1.6, 560, 220, 1.0, 1.5)])),
        def('sl_again', 'もう一度', [summon(0, 6), rain(0.5, 12, 80, 1.0, 1.2, { gap: 0.12 }), ring(2.0, 260, 0.9, 1.5)])
    ], def('sl_trap', '無限の罠', [ring(0, 460, 1.5, 1.0, STUN)]));


    // ============================================================
    // ボスラッシュ Final：強化ディメンション・キーパー（アンダーテールのサンズ風）
    //  ・ブラスター（標的を囲む砲口）／骨の壁（隙間をくぐる弾の壁）／重力／連続斬撃 を組み合わせた、避ける攻撃が中心
    // ============================================================
    const beamfan = (t, n, spread, len, w, tele, dm, o) => Object.assign({ t: t, k: 'beamfan', n: n, sp: spread * D, r: len, w: w, tele: tele, dm: dm }, o);
    const beamAt  = (t, fx, fy, aDeg, len, w, tele, dm, o) => Object.assign({ t: t, k: 'beamAt', fx: fx, fy: fy, a: aDeg * D, r: len, w: w, tele: tele, dm: dm }, o);
    const blast   = (t, n, R, len, w, tele, dm, o) => Object.assign({ t: t, k: 'blast', n: n, R: R, r: len, w: w, tele: tele, dm: dm }, o);
    const wall    = (t, dir, spd, dm, o) => Object.assign({ t: t, k: 'wall', dir: dir, spd: spd, dm: dm, gapW: 190 }, o);

    // アリーナの外周に砲口を並べ、一斉に内側へビームを撃つ。volleys 回、向きを rot° ずつ回しながら撃ち続ける
    //  o: { n:砲口の数, volleys:回数, gap:間隔(秒), rot:1回ごとに回す角度°, rot0:最初の角度°, w:幅, tele:予告秒, dm:威力, every:「k番目の砲口おきに撃つ」(隙間づくり) }
    function wallSweep(t0, o) {
        const out = [], n = o.n || 14, V = o.volleys || 8, gap = o.gap || 0.55, every = o.every || 2;
        for (let v = 0; v < V; v++) {
            for (let k = 0; k < n; k++) {
                if (every > 1 && ((k + v) % every) !== 0) continue;
                const u = (k + 0.5) / n * 4, side = Math.floor(u), q = u - side;
                let fx, fy, nrm;
                if (side === 0) { fx = q; fy = 0; nrm = 90; } else if (side === 1) { fx = 1; fy = q; nrm = 180; } else if (side === 2) { fx = 1 - q; fy = 1; nrm = -90; } else { fx = 0; fy = 1 - q; nrm = 0; }
                out.push(beamAt(t0 + v * gap, fx, fy, nrm + (o.rot0 || 0) + v * (o.rot || 12), o.len || 2800, o.w || 46, o.tele || 0.8, o.dm || 1.4, { rep: o.rep != null ? o.rep : 2, gap: 0.14 }));
            }
        }
        return out;
    }
    // 往復：順回転のあと、逆回転でもう一度撃つ（不壊の悪魔の大技）
    function wallSweepRev(t0, o) {
        const V = o.volleys || 8, gap = o.gap || 0.55, rot = o.rot || 12;
        const fwd = wallSweep(t0, Object.assign({}, o, { rot0: o.rot0 || -50 }));
        const back = wallSweep(t0 + V * gap + (o.pause != null ? o.pause : 0.9), Object.assign({}, o, { rot0: (o.rot0 || -50) + (V - 1) * rot, rot: -rot, every: o.every2 || o.every }));
        return fwd.concat(back);
    }
    const spokes = (t0, n, step, len, w, tele, dm, o) => { const out = []; for (let i = 0; i < n; i++) out.push(line(t0 + i * step, len, w, tele, dm, Object.assign({ aim: 'l', off: i * (o && o.rot != null ? o.rot : 30) }, o))); return out; };

    // --- ディメンション・キーパー・極（Final）---
    set('dk_final', [
        def('dkf_blasters', '次元ブラスター', [blast(0, 6, 430, 1400, 70, 0.9, 1.6, { rep: 2, gap: 0.18 }), blast(1.1, 7, 470, 1400, 70, 0.8, 1.6, { rep: 2, gap: 0.18 }), blast(2.2, 8, 500, 1400, 74, 0.75, 1.7, { rep: 2, gap: 0.18 })], { rec: 0.8 }),
        def('dkf_bones', '骨の壁', [wall(0, 'h', 300, 0.9), wall(1.1, 'v', 320, 0.9), wall(2.2, 'h', 340, 0.9), wall(3.3, 'v', 360, 0.9)], { rec: 0.8 }),
        def('dkf_slash', '審判の連斬', [0, 1, 2, 3, 4, 5, 6].map(i => line(i * 0.32, 1500, 64, 0.5, 1.5, { aim: 't', off: (i % 2 ? 8 : -8) }))),
        def('dkf_gravity', '重力反転', [pull(0, 1.6, 340), ring(0.3, 220, 1.1, 1.5), blast(1.4, 6, 380, 1300, 66, 0.8, 1.6, { rep: 2, gap: 0.16 })], { rec: 0.9 }),
        def('dkf_mix', '無慈悲な連撃', [wall(0, 'h', 340, 0.9), blast(0.6, 6, 460, 1400, 68, 0.85, 1.6, { rep: 2, gap: 0.18 }), wall(1.8, 'v', 360, 0.9), blast(2.4, 8, 520, 1400, 70, 0.8, 1.7, { rep: 2, gap: 0.18 })], { rec: 0.9 })
    ], def('dkf_seal', '魂の拘束', [blast(0, 4, 380, 1200, 70, 1.0, 0.9, { rep: 1 }), at(0.2, 130, 1.3, 0.9, STUN)]),
    { ult: def('dkf_ult', '最後の審判', [
        blast(0, 8, 520, 1500, 76, 0.9, 1.7, { rep: 2, gap: 0.18 }), wall(1.4, 'h', 360, 1.0), wall(2.6, 'v', 380, 1.0),
        blast(3.4, 10, 560, 1500, 76, 0.8, 1.8, { rep: 2, gap: 0.18 }), wall(4.4, 'h', 400, 1.0, { gapW: 170 }), wall(5.0, 'v', 400, 1.0, { gapW: 170 })
    ].concat(wallSweepRev(6.2, { n: 14, volleys: 7, gap: 0.5, rot: 14, w: 52, tele: 0.85, dm: 1.6, every: 2 })).concat([line(14.2, 3000, 300, 1.6, 3.0, { aim: 't' })]), { ult: true, rec: 1.6 }), ultAt: [0.8, 0.6, 0.4, 0.2] });

    // ============================================================
    // 無限回廊のボス10体（不壊の悪魔を頂点に、ビーム攻撃の系譜）
    //  共通の流れ：①通常攻撃＝細いビームを絶え間なく撃つ ②得意技 ③スタン技 ④大技（壁から大量のビーム）
    //  tier が上がるほど、ビームの本数・回数・大技の長さが増える
    // ============================================================
    // 絶え間ないビーム（通常攻撃）：標的へ扇状に撃ち、少しずらしてまた撃つ。技の合間がほぼ無いので撃ち続けているように見える
    function stream(tier, w) {
        const n = 4 + Math.min(7, Math.floor(tier / 2) + 1), rounds = 5 + (tier >= 5 ? 1 : 0) + (tier >= 8 ? 2 : 0), out = [];
        for (let r = 0; r < rounds; r++) {
            out.push(beamfan(r * 0.34, n + (r % 2), 52 + tier * 2.5, 1600, (w || 30) + 4, 0.5, 1.0 + tier * 0.02, { aim: 't', off: (r % 2 ? 5 : -5), rep: 1, gap: 0.12 }));
            if (tier >= 3 && r % 2 === 1) out.push(beamfan(r * 0.34 + 0.12, 3, 150, 1600, (w || 30), 0.6, 0.9 + tier * 0.02, { aim: 't', off: 180 }));      // 背後からも撃つ
        }
        return out;
    }
    // 大技の共通部分
    const ultCommon = (tier, kind) => {
        const V = 8 + Math.min(6, Math.floor(tier / 2)), n = 12 + Math.min(8, tier);
        const o = { n: n, volleys: V, gap: Math.max(0.36, 0.56 - tier * 0.02), rot: 13 + (tier >= 8 ? 2 : 0), w: 48 + tier, tele: Math.max(0.62, 0.9 - tier * 0.02), dm: 1.5 + tier * 0.06, every: 2 };
        if (kind === 'rev') return wallSweepRev(0.4, Object.assign({ rot0: -48 }, o));
        if (kind === 'double') return wallSweep(0.4, Object.assign({ rot0: -48 }, o)).concat(wallSweep(0.4, Object.assign({ rot0: 48, rot: -(o.rot) }, o, { rot: -o.rot, rot0: 48, every: 2 })));
        if (kind === 'cross') { const a = wallSweep(0.4, Object.assign({}, o, { rot0: 0, rot: 0, volleys: 4, gap: 0.9, every: 2 })); return a.concat(wallSweep(1.0, Object.assign({}, o, { rot0: 90, rot: 0, volleys: 4, gap: 0.9, every: 2 }))); }
        return wallSweep(0.4, Object.assign({ rot0: -48 }, o));
    };

    // 1. 灼眼の小悪魔
    set('cb1', [
        def('cb1_stream', '灼眼ビーム連射', stream(1), { rec: 0.15 }),
        def('cb1_rain', '業火の雨', [rain(0, 8, 80, 1.0, 1.1, { gap: 0.16 }), ring(1.4, 170, 0.8, 1.2)]),
        def('cb1_stream2', '灼眼ビーム連射・偏差', stream(1, 34), { rec: 0.15 })
    ], def('cb1_seal', '炎の拘束', [at(0, 105, 1.2, 0.9, STUN)]),
    { ult: def('cb1_ult', '壁際の炎線', ultCommon(1, 'one').concat([]), { ult: true, rec: 1.2 }), ultAt: [0.6, 0.3] });
    // 2. 氷獄の番犬
    set('cb2', [
        def('cb2_stream', '氷息ビーム連射', stream(2), { rec: 0.15 }),
        def('cb2_nova', '凍てつく輪', [ring(0, 190, 0.9, 1.3), donut(1.0, 460, 190, 0.9, 1.3)]),
        def('cb2_fan', '三首の氷線', [beamfan(0, 3, 40, 1500, 58, 0.9, 1.4, { aim: 't' }), beamfan(1.0, 5, 60, 1500, 50, 0.9, 1.4, { aim: 't' })])
    ], def('cb2_freeze', '凍結の咆哮', [cone(0, 520, 70, 1.2, 0.8, Object.assign({ aim: 't' }, STUN))]),
    { ult: def('cb2_ult', '氷柱の壁線', ultCommon(2, 'cross'), { ult: true, rec: 1.2 }), ultAt: [0.65, 0.3] });
    // 3. 雷鳴の処刑人
    set('cb3', [
        def('cb3_stream', '雷光ビーム連射', stream(3), { rec: 0.15 }),
        def('cb3_track', '追雷', [0, 1, 2, 3, 4].map(i => line(i * 0.4, 1600, 52, 0.55, 1.4, { aim: 't' }))),
        def('cb3_dash', '雷速突進', [warn(0, 600, 80, 0.6), dash(0.6, 0.55, 860), ring(1.3, 150, 0.7, 1.3)], { rec: 0.7 })
    ], def('cb3_stun', '落雷の裁き', [at(0, 115, 1.1, 0.9, STUN)]),
    { ult: def('cb3_ult', '格子雷', ultCommon(3, 'cross'), { ult: true, rec: 1.2 }), ultAt: [0.7, 0.35] });
    // 4. 鏡面の悪魔
    set('cb4', [
        def('cb4_stream', '鏡写しビーム連射', stream(4), { rec: 0.15 }),
        def('cb4_mirror', '挟み撃ち', [beamfan(0, 5, 70, 1600, 56, 0.9, 1.5, { aim: 't' }), beamfan(0.1, 5, 70, 1600, 56, 0.9, 1.5, { aim: 't', off: 180 })]),
        def('cb4_split', '虚像', [summon(0, 3), rad(0.5, 16, 240, 0.8)])
    ], def('cb4_stun', '反転の瞳', [ring(0, 360, 1.4, 0.9, STUN)]),
    { ult: def('cb4_ult', '鏡の回転線', ultCommon(4, 'double'), { ult: true, rec: 1.3 }), ultAt: [0.7, 0.4] });
    // 5. 虚無の司祭
    set('cb5', [
        def('cb5_stream', '虚無ビーム連射', stream(5), { rec: 0.15 }),
        def('cb5_ports', '虚無の門', [ports(0, 'around', 8, 460, 3.6), beams(0.9, 1500, 56, 0.9, 1.5, { track: true }), beams(1.9, 1500, 56, 0.9, 1.5, { track: true })]),
        def('cb5_spiral', '渦の祈り', [spiral(0, 2.4, 240, 0.8, { arms: 3 }), ring(2.6, 220, 0.8, 1.4)])
    ], def('cb5_seal', '虚無の封印', [ports(0, 'around', 6, 420, 2.2), at(0.2, 140, 1.3, 0.9, STUN)]),
    { ult: def('cb5_ult', '虚無の渦線', ultCommon(5, 'rev'), { ult: true, rec: 1.3 }), ultAt: [0.7, 0.4] });
    // 6. 時喰らいの時計悪魔
    set('cb6', [
        def('cb6_stream', '刻針ビーム連射', stream(6), { rec: 0.15 }),
        def('cb6_hands', '長針と短針', spokes(0, 6, 0.3, 1600, 60, 1.2, 1.5, { rot: 60 })),
        def('cb6_tick', '秒針の雨', [rain(0, 12, 76, 1.0, 1.3, { gap: 0.11 }), ring(1.6, 230, 0.8, 1.4)])
    ], def('cb6_stop', '時間停止', [ring(0, 420, 1.5, 1.0, STUN)]),
    { ult: def('cb6_ult', '正時の大鐘', ultCommon(6, 'rev'), { ult: true, rec: 1.3 }), ultAt: [0.75, 0.5, 0.25] });
    // 7. 重力の暴君
    set('cb7', [
        def('cb7_stream', '重圧ビーム連射', stream(7), { rec: 0.15 }),
        def('cb7_pull', '引力ビーム', [pull(0, 1.4, 320), beamfan(0.4, 7, 80, 1500, 56, 0.9, 1.5, { aim: 't' }), ring(1.5, 220, 0.8, 1.5)], { rec: 0.9 }),
        def('cb7_rain', '隕鉄の雨', [rain(0, 13, 82, 1.0, 1.4, { gap: 0.1 }), donut(1.4, 540, 210, 1.0, 1.5)])
    ], def('cb7_crush', '重力崩壊', [pull(0, 0.8, 380), at(0.6, 150, 1.0, 0.9, STUN)]),
    { ult: def('cb7_ult', '収束する壁線', ultCommon(7, 'rev'), { ult: true, rec: 1.4 }), ultAt: [0.75, 0.5, 0.25] });
    // 8. 星砕きの魔神
    set('cb8', [
        def('cb8_stream', '星砕きビーム連射', stream(8), { rec: 0.15 }),
        def('cb8_barrage', '星屑の弾幕', [spiral(0, 3, 250, 0.8, { arms: 4 }), rad(1.0, 24, 260, 0.7), rad(1.8, 24, 290, 0.7)]),
        def('cb8_star', '五芒星', [0, 1, 2, 3, 4].map(i => line(i * 0.25, 1700, 58, 1.0, 1.6, { aim: 'l', off: i * 144 })))
    ], def('cb8_stun', '流星の鉄槌', [at(0, 130, 1.1, 0.9, STUN), ring(0.3, 180, 1.0, 1.0)]),
    { ult: def('cb8_ult', '星の壁線', ultCommon(8, 'double'), { ult: true, rec: 1.4 }), ultAt: [0.75, 0.5, 0.25] });
    // 9. 終焉の魔王
    set('cb9', [
        def('cb9_stream', '終焉ビーム連射', stream(9), { rec: 0.15 }),
        def('cb9_combo', '魔王の連携', [blast(0, 6, 440, 1400, 64, 0.9, 1.6, { rep: 2, gap: 0.16 }), beamfan(1.0, 7, 70, 1600, 52, 0.8, 1.6, { aim: 't' }), ring(1.9, 210, 0.8, 1.5)]),
        def('cb9_walls', '骨牢', [wall(0, 'h', 330, 0.9), wall(1.1, 'v', 350, 0.9), wall(2.2, 'h', 370, 0.9)], { rec: 0.8 })
    ], def('cb9_seal', '魔王の封印', [blast(0, 4, 380, 1200, 66, 1.0, 0.9, { rep: 1 }), at(0.2, 140, 1.3, 0.9, STUN)]),
    { ult: def('cb9_ult', '終焉の二重回転', ultCommon(9, 'double'), { ult: true, rec: 1.5 }), ultAt: [0.8, 0.6, 0.4, 0.2] });
    // 10. 不壊の悪魔（最強）：通常攻撃で大量のビームを常に放ち続ける。大技は壁から大量のビームを撃ち切り、逆回転でもう一度撃つ
    set('cb10', [
        def('cb10_stream', '不壊の連射', stream(10, 34), { rec: 0.08 }),
        def('cb10_stream2', '不壊の連射・奔流', stream(11, 30).concat(stream(11, 30).map(s => Object.assign({}, s, { t: s.t + 1.7, off: (s.off || 0) + 9 }))), { rec: 0.08 }),
        def('cb10_pull', '不壊の引力', [pull(0, 1.3, 330), beamfan(0.4, 9, 90, 1600, 54, 0.85, 1.6, { aim: 't' }), blast(1.5, 6, 440, 1400, 62, 0.8, 1.6, { rep: 2, gap: 0.16 })], { rec: 0.8 })
    ], def('cb10_seal', '不壊の封印', [blast(0, 4, 360, 1200, 64, 0.95, 0.9, { rep: 1 }), at(0.2, 140, 1.2, 0.9, STUN)]),
    { ult: def('cb10_ult', '無限の壁線・逆回転', ultCommon(10, 'rev').concat(wallSweep(2 * 8 * 0.42 + 1.6, { n: 16, volleys: 4, gap: 0.8, rot0: 0, rot: 0, every: 2, w: 54, tele: 0.8, dm: 1.8 })), { ult: true, rec: 1.2 }), ultAt: [0.85, 0.65, 0.45, 0.25] });


    // ============================================================
    // 無限回廊のボスの強化：威力アップ・予告を少し短く・硬直を短く／新しい技を追加／大技を二段構えに／大技の回数を増やす
    //  （予告は 0.45 秒を下回らない＝見てから避けられる範囲にとどめる）
    // ============================================================
    (function buffCorridorBosses() {
        const tierOf = { cb1: 1, cb2: 2, cb3: 3, cb4: 4, cb5: 5, cb6: 6, cb7: 7, cb8: 8, cb9: 9, cb10: 10 };
        const TELE_KINDS = { line: 1, ring: 1, cone: 1, donut: 1, at: 1, rain: 1, beams: 1, beamfan: 1, beamAt: 1, blast: 1 };
        function empower(mid, fd) {
            const m = MOVES[mid]; if (!m) return;
            m.steps.forEach(s => {
                if (s.dm) s.dm = Math.round(s.dm * fd * 100) / 100;
                if (TELE_KINDS[s.k] && s.tele > 0.5) s.tele = Math.max(0.45, Math.round(s.tele * 0.9 * 100) / 100);
            });
            m.rec = Math.max(m.stun ? 0.9 : 0.05, Math.round(m.rec * (m.stun ? 0.75 : 0.55) * 100) / 100);
            m.dur = Math.max.apply(null, m.steps.map(stepEnd)) + 0.1;
        }
        Object.keys(tierOf).forEach(id => {
            const t = tierOf[id], S = SETS[id]; if (!S) return;
            const fd = 1.16 + 0.02 * t, seen = {};
            S.moves.concat([S.stun, S.ult]).forEach(mid => { if (mid && !seen[mid]) { seen[mid] = 1; empower(mid, fd); } });
            // 新しい技
            const dm = 1.4 + t * 0.04, ex = [];
            ex.push(def(id + '_lattice', '格子ビーム',
                wallSweep(0, { n: 12 + t, volleys: 4, gap: 0.7, rot0: 0, rot: 0, every: 2, w: 46 + t, tele: 0.75, dm: dm }).concat(wallSweep(0.35, { n: 12 + t, volleys: 4, gap: 0.7, rot0: 90, rot: 0, every: 2, w: 46 + t, tele: 0.75, dm: dm })), { rec: 0.4 }));
            ex.push(def(id + '_barrage', '一斉砲撃', [
                blast(0, 5 + Math.floor(t / 2), 420 + t * 8, 1500, 60 + t, 0.8, dm, { rep: 2, gap: 0.16 }),
                beamfan(0.9, 7 + Math.floor(t / 2), 80, 1600, 50, 0.7, dm, { aim: 't' }),
                blast(1.8, 6 + Math.floor(t / 2), 470, 1500, 60 + t, 0.7, dm + 0.05, { rep: 2, gap: 0.16 })], { rec: 0.4 }));
            ex.push(def(id + '_chase', '追尾連斬', Array.from({ length: 6 + Math.floor(t / 2) }, (_, i) => line(i * 0.28, 1700, 54 + t, 0.5, dm, { aim: 't', off: (i % 2 ? 6 : -6) })), { rec: 0.3 }));
            if (t >= 4) ex.push(def(id + '_bones', '骨牢', [wall(0, 'h', 330 + t * 8, 1.0), wall(0.9, 'v', 350 + t * 8, 1.0), wall(1.8, 'h', 370 + t * 8, 1.0), wall(2.7, 'v', 390 + t * 8, 1.0)], { rec: 0.4 }));
            if (t >= 7) ex.push(def(id + '_spokes', '回転ビーム', spokes(0, 8, 0.22, 1700, 56, 0.9, dm, { rot: 45 }).concat(rain(1.8, 14, 80, 0.9, dm, { gap: 0.09 })), { rec: 0.4 }));
            S.moves = S.moves.concat(ex);
            // 大技：もとの大技のあとに、逆回転つきの壁ビームをもう一度（二段構え）。発動のたびに間が空かない
            const U = MOVES[S.ult];
            if (U) {
                const end = U.dur + 0.5, more = wallSweepRev(end, { n: 12 + t, volleys: 4 + Math.floor(t / 2), gap: 0.5, rot: 14, w: 46 + t, tele: 0.78, dm: dm + 0.1, every: 2, pause: 0.6 });
                const steps = U.steps.map(x => Object.assign({}, x)).concat(more);
                S.ult = def(id + '_ult2', U.name + '・極', steps, { ult: true, rec: 1.0 });
            }
            S.ultAt = t >= 8 ? [0.92, 0.78, 0.64, 0.5, 0.36, 0.22, 0.1] : (t >= 4 ? [0.88, 0.7, 0.52, 0.34, 0.16] : [0.85, 0.6, 0.35]);
        });
    })();

    // ============================================================
    // 大討伐戦ボス共通の「技の拡張キット」
    //  新しい大討伐戦ボスは、set('raid_xxx', [基本の技…], スタン技) で登録したあと、
    //      BOSS_MOVES.raid.extend('raid_xxx', { colors: [色1, 色2, 色3], tier: 1〜10, patterns: ['cross', 'chain', …], power: 1.18 })
    //  を呼ぶだけで、次の3つが自動で入る。
    //    (1) 既存の技の強化（威力×power・予告を少し短く・硬直を短く）
    //    (2) 共通パターン（RAID_PATTERNS）の追加。色は colors の順に使われる（patterns を省くと全種類）
    //    (3) 技の合間を短く（cdMul）・技の順番をランダムに（rnd）
    //  大技は BOSS_MOVES.raid.ult('raid_xxx', id, 名前, ステップ, [発動するHP割合…]) で登録する
    //  共通パターン：cross 十字砲火 / chain 連鎖爆撃 / crush 収束崩壊 / barrage 一斉砲撃 / lattice 格子ビーム / chase 追尾連斬
    //                bones 檻の壁 / dashpair 双牙の突進 / rainfall 破片の雨 / summon 眷属召喚
    // ============================================================
    const RAID_TELE = { line: 1, ring: 1, cone: 1, donut: 1, at: 1, rain: 1, beams: 1, beamfan: 1, beamAt: 1, blast: 1 };
    const RAID_PATTERNS = {
        cross: (c, dm) => ({ name: '十字砲火', rec: 0.8, steps: [0, 1].reduce((a, w) => a.concat([0, 1, 2, 3, 4, 5, 6, 7].map(i => line(w * 1.5 + i * 0.07, 1700, 96, 1.1, dm, { c: c[(i + w) % 2], aim: 'l', off: w * 22.5 + i * 45 }))), []) }),
        chain: (c, dm) => ({ name: '連鎖爆撃', rec: 0.6, steps: [at(0, 110, 0.9, dm, { c: c[0] })].concat([0, 1, 2, 3, 4].map(i => at(0.5 + i * 0.4, 105, 0.8, dm, { c: c[(i + 1) % 2], who: 'rand' }))) }),
        crush: (c, dm) => ({ name: '収束崩壊', rec: 0.9, steps: [pull(0, 1.5, 300), ring(1.3, 230, 0.8, dm + 0.1, { c: c[0] }), donut(2.2, 640, 230, 1.0, dm + 0.1, { c: c[1] })] }),
        barrage: (c, dm, t) => ({ name: '一斉砲撃', rec: 0.5, steps: [blast(0, 5 + (t >> 1), 430, 1500, 60 + t, 0.85, dm, { rep: 2, gap: 0.16, c: c[0] }), beamfan(0.9, 7, 80, 1600, 50, 0.75, dm, { aim: 't', c: c[1] }), blast(1.9, 6 + (t >> 1), 470, 1500, 60 + t, 0.75, dm + 0.05, { rep: 2, gap: 0.16, c: c[0] })] }),
        lattice: (c, dm, t) => ({ name: '格子ビーム', rec: 0.5, steps: wallSweep(0, { n: 12 + t, volleys: 4, gap: 0.7, rot0: 0, rot: 0, every: 2, w: 46 + t, tele: 0.8, dm: dm }).concat(wallSweep(0.35, { n: 12 + t, volleys: 4, gap: 0.7, rot0: 90, rot: 0, every: 2, w: 46 + t, tele: 0.8, dm: dm })).map(s => Object.assign(s, { c: c[2] })) }),
        chase: (c, dm, t) => ({ name: '追尾連斬', rec: 0.4, steps: Array.from({ length: 6 + (t >> 1) }, (_, i) => line(i * 0.28, 1700, 56 + t, 0.55, dm, { aim: 't', off: i % 2 ? 6 : -6, c: c[i % 2] })) }),
        bones: (c, dm, t) => ({ name: '檻の壁', rec: 0.5, steps: [wall(0, 'h', 340 + t * 6, 1.0, { c: c[0] }), wall(0.9, 'v', 360 + t * 6, 1.0, { c: c[1] }), wall(1.8, 'h', 380 + t * 6, 1.0, { c: c[0] }), wall(2.7, 'v', 400 + t * 6, 1.0, { c: c[1] })] }),
        dashpair: (c, dm) => ({ name: '双牙の突進', rec: 0.8, steps: [warn(0, 900, 110, 0.7, { c: c[0] }), dash(0.7, 0.6, 940, { c: c[0] }), warn(1.5, 900, 110, 0.5, { aim: 't', c: c[1] }), dash(2.0, 0.6, 960, { aim: 't', c: c[1] }), ring(2.8, 200, 0.7, dm, { c: c[2] })] }),
        rainfall: (c, dm) => ({ name: '破片の雨', rec: 0.6, steps: [rain(0, 14, 84, 1.0, dm, { gap: 0.09, c: c[0] }), rain(1.5, 12, 84, 1.0, dm, { gap: 0.09, c: c[1] }), donut(2.8, 620, 230, 1.0, dm + 0.1, { c: c[2] })] }),
        summon: (c, dm) => ({ name: '眷属召喚', rec: 0.6, steps: [summon(0, 6), fan(0.5, 9, 8, 380, 0.8, { c: c[0] }), fan(1.0, 9, 8, 380, 0.8, { c: c[1], off: 8 })] })
    };
    function raidEmpower(mid, power) {
        const m = MOVES[mid]; if (!m || m.raidBuff) return; m.raidBuff = true;
        m.steps.forEach(s => {
            if (s.dm) s.dm = Math.round(s.dm * power * 100) / 100;
            if (RAID_TELE[s.k] && s.tele > 0.6) s.tele = Math.max(0.55, Math.round(s.tele * 0.92 * 100) / 100);      // 予告は0.55秒を下回らない（見てから避けられる範囲）
        });
        m.rec = Math.max(m.stun ? 0.9 : 0.1, Math.round(m.rec * (m.stun ? 0.8 : 0.65) * 100) / 100);
        m.dur = Math.max.apply(null, m.steps.map(stepEnd)) + 0.1;
    }
    function raidExtend(setId, o) {
        o = o || {}; const S = SETS[setId]; if (!S) return null;
        const c = (o.colors && o.colors.length ? o.colors : ['#ff5a3a', '#4ac8ff', '#b060ff']).slice(); while (c.length < 3) c.push(c[c.length - 1]);
        const t = Math.max(1, o.tier || 1), power = o.power || 1.18, dm = Math.round((1.5 + 0.04 * t) * power * 100) / 100, seen = {};
        S.moves.concat([S.stun, S.ult]).forEach(mid => { if (mid && !seen[mid]) { seen[mid] = 1; raidEmpower(mid, power); } });
        (o.patterns || Object.keys(RAID_PATTERNS)).forEach(key => {
            const P = RAID_PATTERNS[key], id = setId + '_x_' + key; if (!P || MOVES[id]) return;
            const r = P(c, dm, t); def(id, r.name, r.steps, { rec: r.rec }); MOVES[id].raidBuff = true; S.moves.push(id);
        });
        S.cdMul = o.cdMul || 0.8; S.rnd = o.random !== false;
        return S;
    }
    function raidUlt(setId, id, name, steps, ultAt) {
        const S = SETS[setId]; if (!S) return null;
        S.ult = def(id, name, steps, { ult: true, rec: 1.3 }); S.ultAt = ultAt || [0.75, 0.5, 0.25];
        return id;
    }

    // ============================================================
    // 大討伐戦 第二幕：ワールドワーム（砂色の巨大な蟲）。ステージ全体のギミック（足場の崩壊・アンカー・体内）は practice.js の worm* 関数
    //   ここは、地上にいるときの技だけ：突進・尻尾叩きつけ・土砂吐き・地中の突き上げ・大薙ぎ
    // ============================================================
    const SAND = '#d8a85a', ROCK = '#a07040', ACID = '#9bd84a';
    set('raid_worm', [
        def('rw_charge', '大地を割る突進', [warn(0, 1100, 130, 0.9, tc(SAND, { aim: 't' })), dash(0.9, 0.7, 1000, tc(SAND)), warn(1.9, 1100, 130, 0.7, tc(SAND, { aim: 't' })), dash(2.6, 0.7, 1040, tc(SAND))], { rec: 0.9 }),
        def('rw_tail', '尻尾叩きつけ', [ring(0, 260, 1.0, 1.8, tc(ROCK)), donut(1.1, 720, 260, 0.9, 1.6, tc(ROCK)), ring(2.2, 200, 0.7, 1.7, tc(SAND))], { rec: 0.8 }),
        def('rw_spit', '土砂吐き', [cone(0, 620, 56, 1.0, 1.5, tc(SAND, { aim: 't', off: -30 })), cone(0, 620, 56, 1.0, 1.5, tc(SAND, { aim: 't', off: 30 })), fan(0.9, 9, 8, 420, 0.8, tc(ROCK))]),
        def('rw_rumble', '地中の突き上げ', [at(0, 110, 0.9, 1.8, tc(ROCK))].concat([0, 1, 2, 3, 4].map(i => at(0.5 + i * 0.4, 105, 0.8, 1.8, tc(ROCK, { who: 'rand' }))))),
        def('rw_sweep', '大薙ぎ', [line(0, 1500, 150, 1.1, 1.8, tc(SAND, { aim: 'l', off: -40 })), line(0.3, 1500, 150, 1.1, 1.8, tc(SAND, { aim: 'l', off: 0 })), line(0.6, 1500, 150, 1.1, 1.8, tc(SAND, { aim: 'l', off: 40 }))], { rec: 0.8 })
    ], def('rw_stun', 'ワームの咆哮', [ring(0, 380, 1.4, 1.0, STUN)]));
    raidExtend('raid_worm', { colors: [SAND, ROCK, ACID], tier: 5, power: 1.1, patterns: ['chain', 'crush', 'barrage', 'rainfall', 'dashpair'] });
    raidUlt('raid_worm', 'rw_ult', '世界喰らいの咆哮', [ring(0, 300, 1.2, 1.8, tc(SAND)), donut(1.3, 760, 300, 1.0, 1.9, tc(ROCK)), rain(2.4, 14, 90, 1.0, 1.7, tc(SAND, { gap: 0.09 })), line(3.4, 1700, 220, 1.2, 2.2, tc(ROCK, { aim: 't' }))], [0.8, 0.55, 0.3]);

    // --- 双界の覇竜ツイン・エレメンタル：技の追加と強化 ---
    //  第一形態：赤と青の技を増やす。大技「双界共鳴」はHP80%・62%を切るたびに
    def('rd_pincer', '灼熱と極寒の挟撃', [ring(0, 230, 1.1, 1.7, tc(RED)), donut(1.3, 640, 230, 1.0, 1.7, tc(BLUE)), ring(2.5, 230, 0.9, 1.8, tc(PUR))], { rec: 0.9 });
    def('rd_meteor', '炎と氷の連続カタストロフ', [rain(0, 12, 90, 1.0, 1.5, tc(RED, { gap: 0.1 })), rain(1.6, 12, 90, 1.0, 1.5, tc(BLUE, { gap: 0.1 })), at(3.0, 110, 0.9, 1.6, tc(PUR, { who: 'rand' }))]);
    def('rd_wings', '双翼の薙ぎ払い', [cone(0, 520, 56, 1.0, 1.6, tc(RED, { aim: 't', off: -34 })), cone(0, 520, 56, 1.0, 1.6, tc(BLUE, { aim: 't', off: 34 })), cone(1.3, 520, 56, 0.9, 1.7, tc(RED, { aim: 't', off: 34 })), cone(1.3, 520, 56, 0.9, 1.7, tc(BLUE, { aim: 't', off: -34 }))], { rec: 0.8 });
    def('rd_call', '眷属の呼び声', [summon(0, 6), fan(0.5, 9, 8, 380, 0.8, tc(RED)), fan(1.0, 9, 8, 380, 0.8, tc(BLUE, { off: 8 }))]);
    SETS.raid_duality.moves.push('rd_pincer', 'rd_meteor', 'rd_wings', 'rd_call');
    raidExtend('raid_duality', { colors: [RED, BLUE, PUR], tier: 6, power: 1.2, patterns: ['cross', 'chain', 'lattice', 'barrage', 'dashpair'] });
    raidUlt('raid_duality', 'rd_ult', '双界共鳴・赤と青の大海嘯', [
        rain(0, 16, 90, 1.0, 1.6, tc(RED, { gap: 0.08 })), donut(1.6, 700, 260, 1.0, 1.8, tc(BLUE)),
        line(2.8, 1500, 170, 1.1, 1.9, tc(RED, { aim: 't', off: -14 })), line(2.8, 1500, 170, 1.1, 1.9, tc(BLUE, { aim: 't', off: 14 })), ring(3.9, 300, 1.1, 1.9, tc(PUR))
    ], [0.8, 0.62]);
    //  第二形態（紫炎の崩壊）：さらに攻撃的に。大技「臨界・紫炎終焉」はHP42%・30%・18%・8%を切るたびに
    def('rd2_pull', '紫炎の渦', [pull(0, 1.6, 300), ring(1.4, 240, 0.8, 2.0, tc(PUR)), donut(2.3, 640, 240, 1.0, 2.0, tc(PUR))], { rec: 0.8 });
    def('rd2_chain', '紫炎の連鎖', [at(0, 110, 0.9, 1.8, tc(PUR))].concat([0, 1, 2, 3, 4, 5].map(i => at(0.45 + i * 0.35, 105, 0.8, 1.8, tc(PUR, { who: 'rand' })))));
    SETS.raid_duality2.moves.push('rd2_pull', 'rd2_chain');
    raidExtend('raid_duality2', { colors: [PUR, PUR, PUR], tier: 7, power: 1.25, cdMul: 0.72, patterns: ['cross', 'crush', 'lattice', 'barrage', 'chase', 'bones', 'dashpair', 'rainfall'] });
    raidUlt('raid_duality2', 'rd2_ult', '臨界・紫炎終焉', [
        spiral(0, 3, 270, 0.9, tc(PUR, { arms: 5 })), ring(1.0, 300, 1.2, 2.0, tc(PUR))
    ].concat(spokes(1.8, 8, 0.18, 1700, 70, 1.0, 2.0, { c: PUR, rot: 45 })).concat([
        donut(3.8, 700, 260, 1.0, 2.0, tc(PUR)), rain(4.6, 16, 90, 1.0, 1.8, tc(PUR, { gap: 0.08 })), line(5.6, 2800, 240, 1.5, 2.6, tc(PUR, { aim: 't' }))
    ]), [0.42, 0.3, 0.18, 0.08]);

    // ============================================================
    // 大討伐戦 第六幕：魔装合体ヴェルスザーク
    //   最初は「天使ヴェルス」（不壊の悪魔のようなビーム）と「悪魔ザーク」（超インファイト）の2体。どちらかが倒れると合体する（HPは満タンから）
    //   合体後は「瞬間移動」で一瞬で詰めてくる。遠くにいるとヴェルスの技か瞬間移動、近くにいるとザークの技（practice.js の vzPick が距離で選ぶ）
    // ============================================================
    const VZ_GOLD = '#ffe27a', VZ_CRIM = '#ff3a52', VZ_WHITE = '#d8efff';
    // ヴェルス（天使）：不壊の悪魔の系譜。距離をとってビームの雨
    set('vz_velus', [
        def('vz_v_stream', '聖光の連射', stream(10, 34).map(s => Object.assign(s, { c: VZ_WHITE })), { rec: 0.08 }),
        def('vz_v_pull', '天使の引力', [pull(0, 1.3, 330), beamfan(0.4, 9, 90, 1600, 54, 0.85, 1.6, tc(VZ_WHITE, { aim: 't' })), blast(1.5, 6, 440, 1400, 62, 0.8, 1.6, tc(VZ_GOLD, { rep: 2, gap: 0.16 }))], { rec: 0.8 }),
        def('vz_v_sweep', '聖壁の薙ぎ', wallSweep(0, { n: 14, volleys: 6, gap: 0.5, rot: 12, w: 46, tele: 0.8, dm: 1.4, every: 2 }).map(s => Object.assign(s, { c: VZ_GOLD })), { rec: 0.9 }),
        def('vz_v_blast', '光の砲列', [blast(0, 6, 430, 1400, 66, 0.9, 1.5, tc(VZ_GOLD, { rep: 2, gap: 0.18 })), wall(1.4, 'h', 330, 0.9, tc(VZ_WHITE))], { rec: 0.8 })
    ], def('vz_v_seal', '天使の拘束', [blast(0, 4, 360, 1200, 64, 0.95, 0.9, tc(VZ_WHITE, { rep: 1 })), at(0.2, 140, 1.2, 0.9, STUN)]));
    raidExtend('vz_velus', { colors: [VZ_WHITE, VZ_GOLD, VZ_WHITE], tier: 6, power: 1.15, cdMul: 0.8, patterns: [] });

    // ザーク（悪魔）：ボスの中でも初めての超インファイト。近づいて殴り、叩きつけ、突進し、跳ぶ
    set('vz_zark', [
        def('vz_z_claw', '魔爪の連撃', [cone(0, 320, 110, 0.7, 1.7, tc(VZ_CRIM, { aim: 't' })), cone(0.55, 320, 110, 0.6, 1.7, tc(VZ_CRIM, { aim: 't', off: 28 })), cone(1.1, 340, 150, 0.65, 1.9, tc(VZ_CRIM, { aim: 't' }))], { rec: 0.7 }),
        def('vz_z_smash', '魔拳の叩きつけ', [ring(0, 270, 0.85, 1.9, tc(VZ_CRIM)), ring(1.0, 360, 0.75, 2.0, tc(VZ_CRIM)), donut(1.8, 640, 360, 0.85, 1.8, tc(VZ_CRIM))], { rec: 0.8 }),
        def('vz_z_rush', '暴走突進', [warn(0, 950, 130, 0.65, tc(VZ_CRIM, { aim: 't' })), dash(0.65, 0.5, 1250, tc(VZ_CRIM)), cone(1.25, 280, 130, 0.55, 1.9, tc(VZ_CRIM, { aim: 't' })), warn(1.8, 950, 130, 0.6, tc(VZ_CRIM, { aim: 't' })), dash(2.4, 0.5, 1300, tc(VZ_CRIM)), ring(3.0, 270, 0.6, 2.0, tc(VZ_CRIM))], { rec: 0.8 }),
        def('vz_z_leap', '魔王の跳躍', [leap(0, 0.9, 240, 2.2, tc(VZ_CRIM)), ring(1.2, 300, 0.65, 1.8, tc(VZ_CRIM)), cone(1.9, 300, 120, 0.55, 1.8, tc(VZ_CRIM, { aim: 't' }))], { rec: 0.8 }),
        def('vz_z_flurry', '千烈乱打', [ring(0, 230, 0.7, 1.5, tc(VZ_CRIM, { rep: 4, gap: 0.3 })), cone(0.4, 300, 90, 0.6, 1.6, tc(VZ_CRIM, { aim: 't', rep: 2, gap: 0.35 }))], { rec: 0.8 })
    ], def('vz_z_grab', '魔手の鷲掴み', [ring(0, 300, 1.2, 1.2, STUN)]));
    raidExtend('vz_zark', { colors: [VZ_CRIM, VZ_CRIM, VZ_CRIM], tier: 6, power: 1.15, cdMul: 0.75, patterns: [] });

    // 魔装合体ヴェルスザーク：遠い→ヴェルスの強化技／瞬間移動、近い→ザークの強化技。大技「魔装解放・終焉の双翼」
    const vzFar = [
        def('vzf_stream', '聖光の連射・奔流', stream(11, 34).map(s => Object.assign(s, { c: VZ_WHITE })).concat(stream(11, 30).map(s => Object.assign({}, s, { t: s.t + 1.7, off: (s.off || 0) + 9, c: VZ_GOLD }))), { rec: 0.08 }),
        def('vzf_pull', '天使の引力・極', [pull(0, 1.3, 340), beamfan(0.4, 13, 110, 1700, 54, 0.85, 1.7, tc(VZ_WHITE, { aim: 't' })), blast(1.5, 8, 460, 1500, 62, 0.8, 1.7, tc(VZ_GOLD, { rep: 3, gap: 0.16 }))], { rec: 0.7 }),
        def('vzf_sweep', '聖壁の薙ぎ・往復', wallSweepRev(0, { n: 16, volleys: 6, gap: 0.45, rot: 13, w: 50, tele: 0.8, dm: 1.6, every: 2 }).map(s => Object.assign(s, { c: VZ_GOLD })), { rec: 0.8 }),
        def('vzf_blink_a', '瞬間移動・断罪', [blink(0.3, 110), cone(0.9, 340, 110, 0.55, 2.2, tc(VZ_CRIM, { aim: 't' })), cone(1.45, 340, 110, 0.55, 2.2, tc(VZ_CRIM, { aim: 't', off: 30 })), ring(2.0, 280, 0.7, 2.3, tc(VZ_GOLD))], { rec: 0.6 }),
        def('vzf_blink_b', '瞬間移動・連鎖', [blink(0.2, 120), ring(0.8, 250, 0.6, 2.2, tc(VZ_CRIM)), blink(1.6, 130), ring(2.2, 250, 0.6, 2.2, tc(VZ_CRIM)), blink(3.0, 110), donut(3.6, 650, 260, 0.8, 2.0, tc(VZ_GOLD))], { rec: 0.7 }),
        def('vzf_blink_c', '瞬間移動・背後の一閃', [blink(0.2, 100), line(0.8, 1500, 150, 0.55, 2.2, tc(VZ_WHITE, { aim: 't' })), line(1.0, 1500, 150, 0.55, 2.2, tc(VZ_WHITE, { aim: 't', off: 90 })), line(1.2, 1500, 150, 0.55, 2.2, tc(VZ_WHITE, { aim: 't', off: 180 })), line(1.4, 1500, 150, 0.55, 2.2, tc(VZ_WHITE, { aim: 't', off: 270 }))], { rec: 0.7 })
    ];
    const vzNear = [
        def('vzf_claw', '魔爪の連撃・合体', [cone(0, 340, 110, 0.7, 1.9, tc(VZ_CRIM, { aim: 't' })), cone(0.5, 340, 110, 0.6, 1.9, tc(VZ_CRIM, { aim: 't', off: 28 })), cone(1.0, 340, 110, 0.6, 1.9, tc(VZ_CRIM, { aim: 't', off: -28 })), cone(1.55, 380, 160, 0.65, 2.1, tc(VZ_GOLD, { aim: 't' }))], { rec: 0.6 }),
        def('vzf_smash', '魔拳の叩きつけ・合体', [ring(0, 290, 0.85, 2.0, tc(VZ_CRIM)), ring(0.9, 380, 0.75, 2.1, tc(VZ_CRIM)), donut(1.7, 700, 380, 0.85, 2.0, tc(VZ_GOLD)), ring(2.6, 260, 0.6, 2.2, tc(VZ_CRIM))], { rec: 0.7 }),
        def('vzf_rush', '暴走突進・合体', [warn(0, 1000, 130, 0.6, tc(VZ_CRIM, { aim: 't' })), dash(0.6, 0.5, 1350, tc(VZ_CRIM)), cone(1.2, 300, 130, 0.55, 2.0, tc(VZ_CRIM, { aim: 't' })), blink(1.7, 110), cone(2.3, 300, 130, 0.55, 2.0, tc(VZ_GOLD, { aim: 't' })), ring(2.9, 280, 0.6, 2.1, tc(VZ_CRIM))], { rec: 0.7 }),
        def('vzf_flurry', '千烈乱打・合体', [ring(0, 240, 0.7, 1.6, tc(VZ_CRIM, { rep: 5, gap: 0.28 })), cone(0.4, 320, 90, 0.6, 1.7, tc(VZ_GOLD, { aim: 't', rep: 3, gap: 0.33 }))], { rec: 0.7 }),
        def('vzf_halo', '光輪と魔炎の爆裂', [ring(0, 250, 0.7, 2.0, tc(VZ_GOLD)), beamfan(0.8, 12, 330, 1500, 50, 0.7, 1.6, tc(VZ_WHITE, { aim: 't' })), ring(1.8, 330, 0.7, 2.1, tc(VZ_CRIM))], { rec: 0.7 })
    ];
    set('raid_vz_fusion', vzFar.concat(vzNear), def('vzf_grab', '魔装・鷲掴み', [blink(0, 90), ring(0.5, 300, 1.2, 1.3, STUN)]));
    SETS.raid_vz_fusion.far = vzFar; SETS.raid_vz_fusion.near = vzNear;
    raidExtend('raid_vz_fusion', { colors: [VZ_GOLD, VZ_CRIM, VZ_WHITE], tier: 8, power: 1.25, cdMul: 0.62, patterns: [] });
    raidUlt('raid_vz_fusion', 'vzf_ult', '魔装解放・終焉の双翼', [
        blink(0, 120), ring(0.7, 300, 1.0, 2.1, tc(VZ_CRIM)), donut(1.9, 760, 300, 1.0, 2.0, tc(VZ_GOLD))
    ].concat(wallSweepRev(3.2, { n: 14, volleys: 5, gap: 0.5, rot: 14, w: 52, tele: 0.85, dm: 1.7, every: 2 }).map(s => Object.assign(s, { c: VZ_WHITE }))).concat([
        blink(9.6, 100), cone(10.2, 380, 150, 0.6, 2.4, tc(VZ_CRIM, { aim: 't' })), blink(11.0, 100), cone(11.6, 380, 150, 0.6, 2.4, tc(VZ_CRIM, { aim: 't' })), line(12.6, 2800, 260, 1.4, 2.8, tc(VZ_GOLD, { aim: 't' }))
    ]), [0.8, 0.6, 0.4, 0.2]);

    // ============================================================
    // 緊急ステージ「○○ニグス」の技（stage-data.js の EMERGENCY / ステージID は emg_元のID）
    //  元のボスの技を「別IDのコピー」にして強化する（元のボスの技は変えない）→ ニグス専用の新技を足す → 大技を二段構え・5回にする。
    //   ・コピーの強化：威力×1.45／予告を短く（0.5秒を下回らない＝見てから避けられる）／硬直を短く／予告の色をニグスの色に
    //   ・スタン技の予告は、いつもの黄色のまま（見分けがつくように）
    //  技の中身を変えたいときは NIGS_PALETTE（色）と、下の nigsMoves（新技）を触る。
    // ============================================================
    (function buildEmergencySets() {
        const SRC = { emg_stardust_graveyard: 'stardust_graveyard', emg_galaxy_vortex: 'galaxy_vortex', emg_event_horizon: 'event_horizon', emg_dying_star: 'dying_star',
            emg_void_sea: 'void_sea', emg_gravity_well: 'gravity_well', emg_olympus: 'olympus_zeus', emg_void_throne: 'void_throne' };
        const NIGS_PALETTE = {      // [主色, 副色, 差し色]
            emg_stardust_graveyard: ['#b34dff', '#ff4d8d', '#ffd36a'], emg_galaxy_vortex: ['#7a6bff', '#ff5ad8', '#6af0ff'], emg_event_horizon: ['#8a2bff', '#ff3a52', '#c8c8ff'],
            emg_dying_star: ['#ff5a2a', '#ff2a6a', '#ffe27a'], emg_void_sea: ['#2ab0ff', '#9a5bff', '#a8fff0'], emg_gravity_well: ['#a040ff', '#ff4060', '#9ad0ff'],
            emg_olympus: ['#ffe14d', '#ff5a3a', '#b8d8ff'], emg_void_throne: ['#d02bff', '#ff2a4a', '#ffffff']
        };
        const POWER = 1.45, TELE_MIN = 0.5;
        const TELE = { line: 1, ring: 1, cone: 1, donut: 1, at: 1, rain: 1, beams: 1, beamfan: 1, beamAt: 1, blast: 1 };
        function cloneMove(srcId, newId, pal) {       // 元の技を丸ごと別IDにコピーして強化する
            const m = MOVES[srcId]; if (!m) return null;
            const steps = m.steps.map(st => {
                const x = Object.assign({}, st);
                if (x.dm) x.dm = Math.round(x.dm * POWER * 100) / 100;
                if (TELE[x.k] && x.tele > TELE_MIN + 0.05) x.tele = Math.max(TELE_MIN, Math.round(x.tele * 0.86 * 100) / 100);
                if (!x.stun && !x.c && x.k !== 'summon') x.c = pal[0];          // 予告の色をニグスの色に（スタンは黄色のまま）
                if (x.rep) x.rep = x.rep + 1;                                   // 連続ヒットの技は、もう1回多く
                return x;
            });
            return def(newId, m.name + '・ニグス', steps, { rec: m.stun ? Math.max(0.9, m.rec * 0.8) : Math.max(0.1, Math.round(m.rec * 0.55 * 100) / 100), ult: m.ult });
        }
        function nigsMoves(id, pal, t) {          // ニグス専用の新技（見た目も動きも元のボスとは別物）
            const A = pal[0], B = pal[1], C = pal[2], dm = Math.round(1.9 * 100) / 100, out = [];
            // 1. 断罪の十字：回転しながら増える十字のレーザー → 足元爆撃
            out.push(def(id + '_n_cross', 'ニグス・断罪の十字', [0, 1, 2, 3].reduce((a, w) => a.concat([0, 1, 2, 3].map(i => line(w * 0.7 + i * 0.05, 1700, 84, 0.95, dm, { c: i % 2 ? A : B, aim: 'l', off: w * 22.5 + i * 90 }))), [])
                .concat([at(3.1, 120, 0.8, dm, { c: C }), at(3.5, 120, 0.8, dm, { c: C, who: 'rand' })]), { rec: 0.5 }));
            // 2. 輪舞：渦巻く弾幕と、内側→外側へ広がる輪
            out.push(def(id + '_n_round', 'ニグス・星喰みの輪舞', [spiral(0, 3.2, 260, 0.85, { arms: 4, c: A }), ring(0.8, 170, 0.7, dm, { c: B }), donut(1.7, 440, 170, 0.8, dm, { c: A }), donut(2.6, 740, 440, 0.8, dm, { c: B }), rad(3.4, 24, 300, 0.8, { c: C })], { rec: 0.6 }));
            // 3. 影縫い：瞬間移動で背後へ → 三方向の斬撃 → 離脱前の衝撃
            out.push(def(id + '_n_shadow', 'ニグス・影縫い', [blink(0.2, 110), cone(0.8, 360, 100, 0.55, dm, { c: A, aim: 't' }), cone(0.8, 360, 100, 0.55, dm, { c: A, aim: 't', off: 120 }), cone(0.8, 360, 100, 0.55, dm, { c: A, aim: 't', off: -120 }),
                blink(1.8, 130), line(2.4, 1600, 110, 0.55, dm, { c: B, aim: 't' }), line(2.4, 1600, 110, 0.55, dm, { c: B, aim: 't', off: 90 }), ring(3.1, 260, 0.7, dm + 0.1, { c: C })], { rec: 0.6 }));
            // 4. 終焉の檻：引き寄せ → 壁の弾幕（隙間をくぐる）→ 降り注ぐ破片
            out.push(def(id + '_n_cage', 'ニグス・終焉の檻', [pull(0, 1.4, 320), ring(1.3, 220, 0.8, dm, { c: A }), wall(1.8, 'h', 340 + t * 4, 1.0, { c: B }), wall(2.9, 'v', 360 + t * 4, 1.0, { c: A }), rain(3.9, 14, 86, 0.95, dm, { gap: 0.09, c: C })], { rec: 0.8 }));
            // 5. 追尾の連斬＋砲列：狙われ続けるので、動き続けないと当たる
            out.push(def(id + '_n_hunt', 'ニグス・追尾連斬', Array.from({ length: 8 }, (_, i) => line(i * 0.26, 1700, 62, 0.52, dm, { aim: 't', off: i % 2 ? 8 : -8, c: i % 2 ? A : B }))
                .concat([blast(2.4, 6, 440, 1500, 60, 0.8, dm, { rep: 2, gap: 0.16, c: C })]), { rec: 0.5 }));
            // 6. 双牙の突進：二連突進＋着地の円
            out.push(def(id + '_n_fang', 'ニグス・双牙の突進', [warn(0, 950, 120, 0.65, { c: A }), dash(0.65, 0.5, 1150, { c: A }), warn(1.4, 950, 120, 0.55, { aim: 't', c: B }), dash(1.95, 0.5, 1180, { aim: 't', c: B }), ring(2.6, 240, 0.65, dm + 0.1, { c: C }), donut(3.4, 620, 240, 0.8, dm, { c: A })], { rec: 0.8 }));
            return out;
        }
        Object.keys(SRC).forEach(id => {
            const base = SETS[SRC[id]]; if (!base) return;
            const pal = NIGS_PALETTE[id], seen = {};
            const cp = mid => { if (!mid) return null; if (seen[mid]) return seen[mid]; return (seen[mid] = cloneMove(mid, id + '__' + mid, pal)); };
            const moves = base.moves.map(cp).filter(Boolean);
            const stun = cp(base.stun);
            const extra = nigsMoves(id, pal, 6);
            const dm = 1.9;
            // 大技（二段構え）：HPの節目ごとに「全方位の弾幕＋輪＋壁＋極太レーザー」を繰り出す
            const ult = def(id + '_ult', 'ニグス・終焉の顕現', [
                pull(0, 1.2, 330), ring(1.0, 280, 1.0, dm, { c: pal[0] }), donut(2.0, 760, 280, 1.0, dm, { c: pal[1] }),
                spiral(3.0, 3, 270, 0.9, { arms: 5, c: pal[2] })
            ].concat(spokes(4.0, 8, 0.2, 1700, 70, 0.95, dm, { c: pal[0], rot: 45 })).concat([
                rain(6.0, 16, 90, 1.0, dm, { gap: 0.08, c: pal[1] }), blink(7.4, 120), ring(8.0, 300, 0.8, dm + 0.2, { c: pal[0] }),
                line(9.0, 2800, 240, 1.2, dm + 0.6, { aim: 't', c: pal[1] }), line(9.0, 2800, 240, 1.2, dm + 0.6, { aim: 't', off: 120, c: pal[2] }), line(9.0, 2800, 240, 1.2, dm + 0.6, { aim: 't', off: -120, c: pal[2] })
            ]), { ult: true, rec: 1.2 });
            SETS[id] = { moves: moves.concat(extra), stun: stun, ult: ult, ultAt: [0.85, 0.68, 0.5, 0.32, 0.15], cdMul: 0.62, rnd: true };
        });
    })();

    window.BOSS_MOVES = { MOVES: MOVES, SETS: SETS, STUN_SECONDS: 3.0, STUN_IMMUNE: 3.5, raid: { extend: raidExtend, ult: raidUlt, empower: raidEmpower, PATTERNS: RAID_PATTERNS } };
})();
