// ============================================================
// 町(ロビー)側のUI (stage-lobby.js)
//  ・ステージゲート：ステージを選んで「ソロ／部屋を作る／クイック参加／募集中の部屋に参加」
//  ・武器庫：ハクスラ武器の装備・オーブのはめ込み(PoE風)・売却
//  どちらも世界(world.js)の建物から window.openStageGate() / window.openArmory() で開く
// ============================================================
(function () {
    'use strict';

    const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

    // 大きな数を「1.2億」「3,600万」のように読みやすくする
    function fmtBig(n) {
        n = Math.round(n);
        if (n >= 1e8) return (Math.round(n / 1e7) / 10) + '億';
        if (n >= 1e4) return Math.round(n / 1e4).toLocaleString() + '万';
        return n.toLocaleString();
    }

    // ---------- 共通のモーダル枠 ----------
    function injectStyle() {
        if (document.getElementById('sbLobbyStyle')) return;
        const st = document.createElement('style');
        st.id = 'sbLobbyStyle';
        st.textContent = `
        .sbl-ov { position: fixed; inset: 0; z-index: 100001; background: rgba(5,7,12,.86); display: flex; align-items: center; justify-content: center; padding: 8px; }
        .sbl-box { background: #171b26; color: #eee; border: 2px solid #2b3550; border-radius: 14px; width: min(1000px, 100%); max-height: 94vh; max-height: 94dvh; display: flex; flex-direction: column; overflow: hidden; }
        .sbl-head { display: flex; justify-content: space-between; align-items: center; padding: 10px 14px; border-bottom: 1px solid #2b3550; }
        .sbl-head h2 { margin: 0; font-size: 1.15rem; }
        .sbl-x { background: #44495a; color: #fff; border: 0; border-radius: 8px; padding: 6px 12px; cursor: pointer; }
        .sbl-body { display: flex; gap: 12px; padding: 12px; overflow: hidden; flex: 1; min-height: 0; }
        .sbl-col { overflow-y: auto; min-height: 0; }
        .sbl-left { flex: 1.2; } .sbl-right { flex: 1; }
        .sbl-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 8px; }
        .sbl-card { background: #232a3d; border: 2px solid transparent; border-radius: 10px; padding: 8px; cursor: pointer; }
        .sbl-card.sel { border-color: #ffd84a; } .sbl-card:hover { background: #2b3450; }
        .sbl-card small { color: #9fb3d9; display: block; }
        .sbl-btn { background: #3a6ee8; color: #fff; border: 0; border-radius: 8px; padding: 9px 14px; margin: 4px 4px 0 0; cursor: pointer; font-size: .95rem; }
        .sbl-btn.green { background: #1f9a5a; } .sbl-btn.orange { background: #d9812a; } .sbl-btn.gray { background: #44495a; } .sbl-btn.red { background: #b03a3a; }
        .sbl-btn:disabled { opacity: .45; cursor: default; }
        .sbl-sec { margin: 10px 0 4px; font-weight: bold; color: #9fb3d9; font-size: .85rem; }
        .sbl-room { display: flex; justify-content: space-between; align-items: center; background: #232a3d; border-radius: 8px; padding: 6px 10px; margin: 4px 0; font-size: .85rem; }
        .sbl-wl { display: flex; justify-content: space-between; gap: 6px; padding: 6px 8px; border-radius: 8px; cursor: pointer; border: 2px solid transparent; background: #1f2536; margin-bottom: 4px; font-size: .85rem; }
        .sbl-wl.sel { border-color: #fff; } .sbl-wl.eq { background: #223a2c; }
        .sbl-slot { display: inline-block; width: 52px; height: 52px; border-radius: 50%; border: 3px dashed #556; margin: 4px; text-align: center; line-height: 46px; cursor: pointer; font-size: 1.2rem; background: #11151f; vertical-align: top; }
        .sbl-slot.full { border-style: solid; border-color: #9fe0ff; background: #1c3144; }
        .sbl-fx { font-size: .85rem; padding: 2px 0; color: #cfe3ff; }
        .sbl-orb { background: #232a3d; border-radius: 8px; padding: 6px 8px; margin: 4px 0; cursor: pointer; font-size: .82rem; }
        .sbl-orb:hover { background: #2f3a58; }
        /* スマホ：2列を縦に積む。各列は中身の高さぶん確保し、全体を縦スクロールにする
           （以前は列の高さが0基準で縮み、はみ出した中身が隣の列に重なっていた） */
        @media (max-aspect-ratio: 1/1) {
            .sbl-ov { align-items: flex-start; padding: max(6px, env(safe-area-inset-top)) 6px max(6px, env(safe-area-inset-bottom)); }
            .sbl-box { max-height: 100%; }
            .sbl-body { flex-direction: column; overflow-y: auto; -webkit-overflow-scrolling: touch; overscroll-behavior: contain; touch-action: pan-y; display: block; }
            .sbl-col { flex: none; min-height: auto; overflow: visible; margin-bottom: 14px; }
            .sbl-left, .sbl-right { flex: none; }
            .sbl-grid { grid-template-columns: repeat(auto-fill, minmax(128px, 1fr)); }
            .sbl-btn { padding: 11px 14px; }
        }
        @media (min-aspect-ratio: 1/1) { .sbl-col { touch-action: pan-y; -webkit-overflow-scrolling: touch; overscroll-behavior: contain; } }
        /* スマホ横向き（高さが低い）：余白と文字を詰める */
        @media (max-height: 480px) and (min-aspect-ratio: 1/1) {
            .sbl-ov { padding: 4px max(6px, env(safe-area-inset-right)) 4px max(6px, env(safe-area-inset-left)); }
            .sbl-box { max-height: 100%; border-radius: 10px; }
            .sbl-head { padding: 5px 10px; } .sbl-head h2 { font-size: .95rem; }
            .sbl-body { padding: 8px; gap: 8px; }
            .sbl-grid { grid-template-columns: repeat(auto-fill, minmax(116px, 1fr)); gap: 6px; }
            .sbl-card { padding: 5px 6px; font-size: .78rem; } .sbl-card > div:first-child { font-size: 1.15rem !important; }
            .sbl-btn { padding: 6px 10px; font-size: .82rem; }
            .sbl-sec { margin: 6px 0 2px; font-size: .78rem; }
            .sbl-wl, .sbl-orb, .sbl-fx { font-size: .78rem; }
            .sbl-slot { width: 42px; height: 42px; line-height: 36px; }
        }
        `;
        document.head.appendChild(st);
    }
    function modal(title, onClose) {
        injectStyle();
        const ov = document.createElement('div'); ov.className = 'sbl-ov';
        ov.innerHTML = '<div class="sbl-box"><div class="sbl-head"><h2></h2><button type="button" class="sbl-x">閉じる ✕</button></div><div class="sbl-body"></div></div>';
        ov.querySelector('h2').textContent = title;
        const close = () => { ov.remove(); if (onClose) onClose(); };
        ov.querySelector('.sbl-x').addEventListener('click', close);
        ov.addEventListener('mousedown', (e) => { if (e.target === ov) close(); });
        document.body.appendChild(ov);
        return { ov: ov, body: ov.querySelector('.sbl-body'), close: close };
    }

    // ============================================================
    // ステージゲート
    // ============================================================
    let rooms = [];
    // 町ページで共有しているソケット(window.socket)があればそれを使い、無ければステージ用に接続する
    function getSock() {
        if (window.socket) return window.socket;
        if (!window.sbStageSocket && typeof io === 'function') { try { window.sbStageSocket = io({ transports: ['websocket', 'polling'] }); } catch (e) { window.sbStageSocket = null; } }
        return window.sbStageSocket || null;
    }
    const bmEvent = n => { try { window.SbBeginner && window.SbBeginner.event(n); } catch (e) {} };   // ビギナーミッションに「行動した」と知らせる
    function openStageGate() {
        bmEvent('gate');
        if (!window.STAGE_DATA || !window.HW) { alert('ステージデータの読み込みに失敗しました'); return; }
        const hack = HW.load();
        const allStages = window.STAGE_DATA.STAGES;
        const WORLDS = window.STAGE_DATA.WORLDS || [];
        let world = 1;                                   // 表示中の世界。第二世界は解放後だけタブが現れる
        // 世界をまたぐ「門」のステージは、門が現れる条件（前の世界の最終ステージをクリア）を満たしてから表示する
        const gateOpen = s => { if (!s.gateTo) return true; const w = WORLDS.find(x => x.id === s.gateTo); return !!(w && w.unlock && hack[w.unlock.gateFlag]); };
        const SS = window.SeasonSys || null;
        // スタンダードキャラは、無限回廊（どちらのキャラでも入れる領域）にいつでも入れる（解放条件なし）
        const stdChar = () => !!(SS && SS.isSeasonChar && !SS.isSeasonChar());
        const progressOpen = w => w.id === 1 || !!w.alwaysOpen || (!!w.anyChar && stdChar()) || !!(w.unlock && hack[w.unlock.flag]);
        // シーズンキャラは、進行状況に加えて「週ごとの解放」も必要。スタンダード専用の領域は、スタンダードキャラだけ
        const worldOpen = w => progressOpen(w) && (!SS || SS.canEnterWorld(w.id));
        const timeLocked = () => (SS && SS.isSeasonChar()) ? WORLDS.filter(w => w.id > 1 && !w.standardOnly && progressOpen(w) && !SS.canEnterWorld(w.id)) : [];
        const worldStages = () => allStages.filter(s => !s.pvp && !s.raid && !s.ambush && (s.world || 1) === world && gateOpen(s));
        // ボスラッシュ／無限回廊：解放条件（ディメンション・キーパー討伐／ボスラッシュのクリア。無限回廊はスタンダードキャラならいつでもOK）
        const stageUnlocked = s => { const u = s.unlock; if (!u) return true; if (s.anyChar && stdChar()) return true; if (u.cleared) return (hack.cleared[u.cleared] || 0) > 0; if (u.flag) return !!hack[u.flag]; return true; };
        const RD = window.STAGE_DATA.RUSH_DIFFS, RUSH = window.STAGE_DATA.RUSH;
        const diffsOf = s => s && s.rush ? RD : window.STAGE_DATA.DIFFS;
        // ボスラッシュのエクストリームは、ディメンション・キーパーをナイトメアでクリアしていないと入れない
        const dimNm = () => ((hack.clearedDiff && hack.clearedDiff[RUSH.extremeNeed.stageId]) || {})[RUSH.extremeNeed.diff] > 0;
        const diffLocked = (s, i) => s && s.rush && RD[i].needDimNightmare && !dimNm();
        // シーズンキャラの週ごとの難易度解放は、通常ステージの難易度の番号で判定する（ボスラッシュ：イージー=0／ハード=1／ナイトメア・エクストリーム=2）
        const gateIdx = (s, i) => s && s.rush ? [0, 1, 2, 2][i] : i;
        // いま入れる世界から開く（スタンダードキャラはスタンダードワールドから、シーズンキャラは第一世界から）
        world = (WORLDS.find(w => worldOpen(w) && !(w.anyChar && stdChar())) || WORLDS.find(worldOpen) || { id: 1 }).id;      // 無限回廊は最初に開かない（スタンダードキャラはまずスタンダードワールド）
        if (!worldStages().length) { alert(SS && SS.isSeasonChar() ? 'いま入れるステージがありません。' : 'スタンダードキャラは「スタンダードワールド」に挑戦できます。シーズンワールド（第一〜第五世界）はシーズンキャラで遊べます。'); return; }
        let selId = worldStages()[0].id;
        let selDiff = Math.min(window.STAGE_DATA.DIFFS.length - 1, parseInt(hack.lastDiff, 10) || 0);
        // エクストリーム以上は、ひとつ下の難易度でそのステージをクリアしていると解放される
        const diffGate = (s, i) => (s && !s.rush && !s.corridor && i >= 3 && !((((hack.clearedDiff || {})[s.id]) || {})[i - 1] > 0)) ? window.STAGE_DATA.DIFFS[i - 1].name + 'でこのステージをクリアすると解放されます。' : '';
        if (window.SeasonSys) while (selDiff > 0 && !window.SeasonSys.canUseDiff(selDiff)) selDiff--;
        const m = modal('🚪 ステージゲート', () => { const sk = getSock(); if (sk) sk.off('stage:rooms', onRooms); });
        m.body.innerHTML = '<div class="sbl-col sbl-left" id="sbStageList"></div><div class="sbl-col sbl-right" id="sbStageDetail"></div>';
        const listEl = m.body.querySelector('#sbStageList'), detEl = m.body.querySelector('#sbStageDetail');

        function onRooms(list) { rooms = list || []; renderDetail(); }
        const sock = getSock();
        if (sock) { sock.on('stage:rooms', onRooms); sock.on('connect', refreshRooms); }
        function refreshRooms() { if (sock && sock.connected) sock.emit('stage:list', { stageId: selId }); }

        function renderList() {
            const wdef = WORLDS.find(w => w.id === world) || {};
            const openWorlds = WORLDS.filter(worldOpen);
            const tabs = openWorlds.length > 1 ? '<div style="margin-bottom:6px">' + openWorlds.map(w => '<button class="sbl-btn' + (w.id === world ? '' : ' gray') + '" data-world="' + w.id + '" style="' + (w.id === world ? 'background:' + w.color : '') + '">' + w.icon + ' ' + esc(w.name) + '</button>').join('') + '</div>' : '';
            const locks = timeLocked().map(w => '<div style="font-size:.78rem;color:#ffb86a;margin-bottom:3px">🔒 ' + w.icon + ' ' + esc(w.name) + '：シーズン' + SS.worldOpenWeek(w.id) + '週目から解放</div>').join('');
            listEl.innerHTML = costBannerHtml() + tabs + locks + (world > 1 ? '<div style="font-size:.8rem;color:#d8b8ff;margin-bottom:4px">' + esc(wdef.note || '') + '</div>' : '') + '<div class="sbl-sec">ダンジョン＋ボス（約5分／最大4人で協力）</div><div class="sbl-grid">' + worldStages().map(s => {
                const c = hack.cleared[s.id] || 0;
                if (s.rush || s.corridor) {
                    const un = stageUnlocked(s), best = s.rush ? Math.max.apply(null, [0].concat(Object.keys(hack.rushBest || {}).map(k => hack.rushBest[k] | 0))) : (hack.corridorBest | 0);
                    return '<div class="sbl-card' + (s.id === selId ? ' sel' : '') + '" data-id="' + s.id + '" style="' + (un ? 'border-color:#ffd84a' : 'opacity:.7') + '"><div style="font-size:1.5rem">' + (un ? s.icon : '🔒') + '</div><b>' + esc(s.name) + '</b><small style="color:#ffd36a">' + (s.rush ? 'フェーズ制ボス連戦' : '無限に続く迷宮') + '</small><small>' + (un ? (s.rush ? (c ? '✔ 制覇 ' + c + '回' : (best ? '最高：フェーズ' + best + 'まで' : '未挑戦')) : (best ? '最深：地下' + best + '階' : '未挑戦')) : '🔒 ' + esc(s.unlock.text)) + '</small></div>';
                }
                return '<div class="sbl-card' + (s.id === selId ? ' sel' : '') + '" data-id="' + s.id + '"><div style="font-size:1.5rem">' + s.icon + '</div><b>' + esc(s.name) + '</b><small>推奨Lv ' + s.ilvl + (s.mini ? '・ミニ' : '') + '</small><small style="color:#ffd36a">推奨合計 ' + fmtBig(s.req || 0) + (s.bossHp ? '　ボスHP ' + fmtBig(s.bossHp) : '') + '</small><small>ボス：' + esc(s.boss.name) + '</small><small>' + (c ? '✔ クリア ' + c + '回' : '未クリア') + '</small></div>';
            }).join('') + '</div>';
            listEl.querySelectorAll('.sbl-card').forEach(c => c.addEventListener('click', () => { selId = c.dataset.id; renderList(); renderDetail(); refreshRooms(); }));
            listEl.querySelectorAll('[data-world]').forEach(b => b.addEventListener('click', () => { world = parseInt(b.dataset.world, 10); selId = worldStages()[0].id; renderList(); renderDetail(); refreshRooms(); }));
            if (window.SBProg) SBProg.decorateCards(listEl);
        }
        function matLine(s) {
            const seen = {}, out = [];
            ['mob', 'elite', 'boss'].forEach(k => (s.mats[k] || []).forEach(r => { if (!seen[r[0]]) { seen[r[0]] = 1; out.push({ id: r[0], boss: k === 'boss' }); } }));
            return out.map(o => { const m = (typeof MATERIAL_DATA !== 'undefined') ? MATERIAL_DATA[o.id] : null; return esc(m ? m.name : o.id) + (o.boss ? '<small style="display:inline;color:#ffd84a">(ボス)</small>' : ''); }).join('、 ');
        }
        function dropNames(ids) { return ids.map(id => { const b = HW.BASE_BY_ID[id]; return b ? esc(b.name) + '<small style="display:inline;color:#8a97b8">(' + (HW.TYPES[b.type] || {}).label + ')</small>' : ''; }).join('、 '); }
        let selStart = Math.max(1, (hack.corrStart | 0) || 1);      // 無限回廊：スタートする階層（最深まで選べる）
        let selRush = Math.min(RD.length - 1, parseInt(hack.lastRushDiff, 10) || 0);
        function roomsHtml() {
            return '<div class="sbl-sec">募集中の部屋 <button class="sbl-btn gray" id="sbRefresh" style="padding:3px 8px;font-size:.75rem">更新</button></div>' +
                '<div id="sbRooms">' + ((rooms.length && rooms.filter(r => r.stageId === selId).length) ? rooms.filter(r => r.stageId === selId).map(r => '<div class="sbl-room"><span>' + esc(r.members[0] ? r.members[0].name : '?') + ' の部屋 (' + r.members.length + '/' + r.max + ')</span><button class="sbl-btn" data-room="' + r.id + '" style="margin:0">参加</button></div>').join('') : '<div style="font-size:.8rem;color:#889">このステージの募集はありません</div>') + '</div>';
        }
        // ボスラッシュの詳細（4つの難易度・フェーズ一覧・解放条件）
        function renderRush(s) {
            const un = stageUnlocked(s), eq = HW.getEquipped(hack), bestOf = i => (hack.rushBest || {})[i] | 0, clr = i => ((hack.clearedDiff || {})[s.id] || {})[i] | 0;
            const phases = RUSH.phases.map(p => '<div style="font-size:.82rem;margin:2px 0"><b style="color:' + (p.final ? '#f0b0ff' : '#ffd36a') + '">' + p.label + '</b>　' + (p.final ? '🌀 ディメンション・キーパー 極' : '第' + p.world + '世界のボスから' + RUSH.bossCount + '体が同時に出現') + '</div>').join('');
            detEl.innerHTML =
                '<h3 style="margin:0 0 4px">' + s.icon + ' ' + esc(s.name) + '</h3><div style="font-size:.85rem;color:#b8c4e0">' + esc(s.desc) + '</div>' +
                (un ? '' : '<div style="margin:8px 0;padding:8px;border:2px solid #ffb86a;border-radius:8px;color:#ffd9a0;font-weight:bold">🔒 ' + esc(s.unlock.text) + '</div>') +
                '<div class="sbl-sec">フェーズ（ボスは第四世界のボス並に強化され、進むほど強くなる）</div>' + phases +
                '<div class="sbl-sec">難易度</div><div id="sbDiffs">' + RD.map((d, i) => { const lk = !un || diffLocked(s, i) || (SS && !SS.canUseDiff(gateIdx(s, i))); return '<button class="sbl-btn' + (i === selRush && !lk ? '' : ' gray') + '" data-rdiff="' + i + '" style="' + (i === selRush && !lk ? 'background:' + d.color : '') + (lk ? ';opacity:.55' : '') + '">' + (lk ? '🔒 ' : '') + d.name + '</button>'; }).join('') + '</div>' +
                '<div style="font-size:.78rem;color:#9fb3d9;margin-top:2px">' + esc(RD[selRush].note) + '　（1フェーズ ' + RD[selRush].phaseMin + '分）</div>' +
                (RD[selRush].needDimNightmare && !dimNm() ? '<div style="font-size:.8rem;color:#ffb86a;margin-top:3px">🔒 エクストリームは、ディメンション・キーパーを「ナイトメア」でクリアすると挑戦できます</div>' : '') +
                '<div class="sbl-sec">記録</div><div style="font-size:.8rem;color:#c8d4ee">' + RD.map((d, i) => d.name + '：' + (clr(i) ? '✔制覇 ' + clr(i) + '回' : (bestOf(i) ? 'フェーズ' + bestOf(i) + 'まで' : '未挑戦'))).join('　／　') + '</div>' +
                '<div class="sbl-sec">装備中：<span style="color:' + HW.rarityOf(eq).color + '">' + esc(eq.name) + '</span></div>' +
                (un ? '<div><button class="sbl-btn green" id="sbSolo">ソロで出発</button><button class="sbl-btn" id="sbCreate">部屋を作って募集</button><button class="sbl-btn orange" id="sbQuick">クイック参加</button></div>' + roomsHtml() : '');
            bindDetail(true);
        }
        // 無限回廊の詳細
        function renderCorr(s) {
            const un = stageUnlocked(s), items = HW.SPECIAL_ORDER.map(k => HW.SPECIAL_ITEMS[k].icon + HW.SPECIAL_ITEMS[k].name + '×' + HW.itemCount(hack, k)).join('　');
            detEl.innerHTML =
                '<h3 style="margin:0 0 4px">' + s.icon + ' ' + esc(s.name) + '</h3><div style="font-size:.85rem;color:#b8c4e0">' + esc(s.desc) + '</div>' +
                (un ? '' : '<div style="margin:8px 0;padding:8px;border:2px solid #ffb86a;border-radius:8px;color:#ffd9a0;font-weight:bold">🔒 ' + esc(s.unlock.text) + '</div>') +
                '<div class="sbl-sec">ルール</div><div style="font-size:.82rem;line-height:1.6">・階層ごとにランダムな迷路。<b>下への階段</b>を見つけて進む（深いほど敵は強い）<br>・敵の強さは<b>あなたのステータス合計</b>と階層で決まる<br>・宝箱：武器・防具・特殊アイテムが出る。<b>ミミック</b>の罠に注意<br>・ときどき<b>ボス部屋</b>の入口が現れる（行かなくてもよい。倒すと特別な報酬）<br>・<b>持ち帰れるのは「脱出ゲート」から脱出したときだけ</b>。各階層のどこかにある。<b>倒れると、手に入れた報酬はすべてゼロ</b><br>・仲間と一緒に潜れる（最大4人）。階段・ボス部屋は全員で移動。宝箱の中身は開けた人のもの。脱出は一人ずつ</div>' +
                '<div class="sbl-sec">特殊アイテム（武器庫で使う）</div><div style="font-size:.82rem;color:#ffd9a0">' + items + '</div>' +
                '<div class="sbl-sec">記録</div><div style="font-size:.85rem">最深：' + ((hack.corridorBest | 0) ? '地下' + (hack.corridorBest | 0) + '階' : '未挑戦') + '</div>' +
                (un && (hack.corridorBest | 0) > 1 ? '<div class="sbl-sec">スタートする階層（行ったことのある階まで選べる）</div><div><select id="sbStartFloor" style="padding:5px;min-width:160px">' + startFloorOptions().map(f => '<option value="' + f + '"' + (f === Math.min(selStart, hack.corridorBest | 0) ? ' selected' : '') + '>地下' + f + '階' + (f === (hack.corridorBest | 0) ? '（最深）' : '') + '</option>').join('') + '</select><span style="font-size:.76rem;color:#9fb3d9;margin-left:6px">深い階から始めるほど敵は強く、報酬も良い</span></div>' : '') +
                (un ? '<div style="margin-top:8px"><button class="sbl-btn green" id="sbSolo">ソロで潜る</button><button class="sbl-btn" id="sbCreate">部屋を作って募集</button><button class="sbl-btn orange" id="sbQuick">クイック参加</button></div>' +
                    '<div class="sbl-sec">募集中の部屋 <button class="sbl-btn gray" id="sbRefresh" style="padding:3px 8px;font-size:.75rem">更新</button></div>' +
                    '<div id="sbRooms">' + (rooms.length ? rooms.filter(r => r.stageId === selId).map(r => { const sf = r.startFloor || 1, ok = corrRoomOk(r); return '<div class="sbl-room"><span>' + esc(r.members[0] ? r.members[0].name : '?') + ' の部屋 (' + r.members.length + '/' + r.max + ')　<b style="color:' + (ok ? '#9fe8b0' : '#ff9a9a') + '">地下' + sf + '階から</b></span>' + (ok ? '<button class="sbl-btn" data-room="' + r.id + '" style="margin:0">参加</button>' : '<button class="sbl-btn gray" data-room-locked="' + sf + '" style="margin:0">🔒 未到達</button>') + '</div>'; }).join('') || '<div style="opacity:.7;font-size:.85rem">募集中の部屋はありません</div>' : '<div style="opacity:.7;font-size:.85rem">募集中の部屋はありません</div>') + '</div>' : '');
            const sf = detEl.querySelector('#sbStartFloor'); if (sf) sf.addEventListener('change', () => { selStart = parseInt(sf.value, 10) || 1; hack.corrStart = selStart; HW.save(hack); });
            bindDetail(false);
        }
        // 無限回廊の部屋に入れるのは、その部屋のスタート階層まで、一度でも到達したことがある人だけ
        function corrRoomOk(r) { return (r.startFloor || 1) <= Math.max(1, hack.corridorBest | 0); }
        // スタート階層の選択肢：1階、5の倍数、最深
        function startFloorOptions() {
            const best = Math.max(1, hack.corridorBest | 0), out = [1];
            if (best <= 30) { for (let f = 2; f <= best; f++) out.push(f); }
            else { for (let f = 5; f < best; f += 5) out.push(f); out.push(best); }
            return out.filter((f, i) => out.indexOf(f) === i).sort((a, b) => a - b);
        }
        function bindDetail(rush) {
            const q = id => detEl.querySelector(id);
            if (rush) detEl.querySelectorAll('[data-rdiff]').forEach(b => b.addEventListener('click', () => { const di = parseInt(b.dataset.rdiff, 10), s = window.getStageById(selId);
                if (!stageUnlocked(s)) return;
                if (diffLocked(s, di)) { alert('エクストリームは、ディメンション・キーパーを「ナイトメア」でクリアすると挑戦できます。'); return; }
                if (SS && !SS.canUseDiff(gateIdx(s, di))) { alert('この難易度は、シーズン' + SS.diffOpenWeek(gateIdx(s, di)) + '週目から解放されます。'); return; }
                selRush = di; hack.lastRushDiff = di; HW.save(hack); renderDetail(); }));
            if (q('#sbSolo')) q('#sbSolo').addEventListener('click', () => launch('solo'));
            if (q('#sbCreate')) q('#sbCreate').addEventListener('click', () => launch('create'));
            if (q('#sbQuick')) q('#sbQuick').addEventListener('click', () => launch('quick'));
            if (q('#sbRefresh')) q('#sbRefresh').addEventListener('click', refreshRooms);
            detEl.querySelectorAll('[data-room]').forEach(b => b.addEventListener('click', () => launch('join', b.dataset.room)));
            detEl.querySelectorAll('[data-room-locked]').forEach(b => b.addEventListener('click', () => alert('この部屋は地下' + b.dataset.roomLocked + '階からです。まだ地下' + b.dataset.roomLocked + '階に到達していないので、参加できません（あなたの最深：' + ((hack.corridorBest | 0) ? '地下' + (hack.corridorBest | 0) + '階' : '未挑戦') + '）')));
        }
        function renderDetail() {
            const s = window.getStageById(selId);
            if (s.rush) { renderRush(s); return; }
            if (s.corridor) { renderCorr(s); return; }
            const DIFFS = window.STAGE_DATA.DIFFS;
            const eq = HW.getEquipped(hack);
            detEl.innerHTML =
                '<h3 style="margin:0 0 4px">' + s.icon + ' ' + esc(s.name) + '</h3><div style="font-size:.85rem;color:#b8c4e0">' + esc(s.desc) + '</div>' +
                '<div class="sbl-sec">出現する敵</div><div style="font-size:.85rem">' + s.enemies.map(e => e.icon + ' ' + esc(e.name)).join('　') + '</div>' +
                '<div class="sbl-sec">ボス</div><div style="font-size:.9rem">' + s.boss.icon + ' <b>' + esc(s.boss.name) + '</b></div>' +
                '<div class="sbl-sec">ドロップする武器（敵）</div><div style="font-size:.82rem">' + dropNames(s.drops) + '</div>' +
                '<div class="sbl-sec">ボス専用ドロップ（レア以上確定）</div><div style="font-size:.82rem;color:#ffd84a">' + dropNames(s.bossDrops) + '</div>' +
                '<div class="sbl-sec">難易度</div><div id="sbDiffs">' + DIFFS.map((d, i) => { const gt = diffGate(s, i), lk = (SS && !SS.canUseDiff(i)) || !!gt; return '<button class="sbl-btn' + (i === selDiff && !lk ? '' : ' gray') + '" data-diff="' + i + '" style="' + (i === selDiff && !lk ? 'background:' + d.color : '') + (lk ? ';opacity:.55' : '') + '">' + (lk ? '🔒 ' : '') + d.name + (lk && !gt ? '（' + SS.diffOpenWeek(i) + '週目〜）' : '') + '</button>'; }).join('') + '</div><div style="font-size:.78rem;color:#9fb3d9;margin-top:2px">' + esc(DIFFS[selDiff].note) + '</div>' +
                '<div class="sbl-sec">落ちる素材（グリフ工房の材料）</div><div style="font-size:.8rem;color:#c8f7a0">' + matLine(s) + '</div>' +
                '<div class="sbl-sec">装備中：<span style="color:' + HW.rarityOf(eq).color + '">' + esc(eq.name) + '</span></div>' +
                '<div><button class="sbl-btn green" id="sbSolo">ソロで出発</button><button class="sbl-btn" id="sbCreate">部屋を作って募集</button><button class="sbl-btn orange" id="sbQuick">クイック参加</button></div>' +
                '<div class="sbl-sec">募集中の部屋 <button class="sbl-btn gray" id="sbRefresh" style="padding:3px 8px;font-size:.75rem">更新</button></div>' +
                '<div id="sbRooms">' + (rooms.length ? rooms.filter(r => r.stageId === selId).map(r => '<div class="sbl-room"><span>' + esc(r.members[0] ? r.members[0].name : '?') + ' の部屋 (' + r.members.length + '/' + r.max + ')</span><button class="sbl-btn" data-room="' + r.id + '" style="margin:0">参加</button></div>').join('') || '<div style="font-size:.8rem;color:#889">このステージの募集はありません</div>' : '<div style="font-size:.8rem;color:#889">このステージの募集はありません</div>') + '</div>';
            detEl.querySelectorAll('[data-diff]').forEach(b => b.addEventListener('click', () => { const di = parseInt(b.dataset.diff, 10); const gt = diffGate(s, di); if (gt) { alert(gt); return; } if (SS && !SS.canUseDiff(di)) { alert('この難易度は、シーズン' + SS.diffOpenWeek(di) + '週目から解放されます。'); return; } selDiff = di; hack.lastDiff = selDiff; HW.save(hack); renderDetail(); }));
            detEl.querySelector('#sbSolo').addEventListener('click', () => launch('solo'));
            detEl.querySelector('#sbCreate').addEventListener('click', () => launch('create'));
            detEl.querySelector('#sbQuick').addEventListener('click', () => launch('quick'));
            detEl.querySelector('#sbRefresh').addEventListener('click', refreshRooms);
            detEl.querySelectorAll('[data-room]').forEach(b => b.addEventListener('click', () => launch('join', b.dataset.room)));
            if (window.SBProg) SBProg.decorateDetail(detEl, s);
        }
        function launch(mode, roomId) {
            const st = window.getStageById(selId);
            if (window.SBProg) { const bl = SBProg.stageBlocked(st); if (bl) { alert(bl); return; } }      // メインミッション：村長に話しかけて解放するまで、ステージには行けない
            if (!stageUnlocked(st)) { alert(st.unlock.text); return; }
            let useDiff = selDiff;
            { const gt = diffGate(st, selDiff); if (gt) { alert(gt); return; } }
            if (st.rush) { if (diffLocked(st, selRush)) { alert('エクストリームは、ディメンション・キーパーを「ナイトメア」でクリアすると挑戦できます。'); return; } useDiff = selRush; }
            if (st.corridor) useDiff = 0;
            if (st.corridor && mode === 'join') { const rm = rooms.find(x => x.id === roomId); if (rm && !corrRoomOk(rm)) { alert('この部屋は地下' + (rm.startFloor || 1) + '階からです。まだ到達していないので、参加できません。'); return; } }
            if (SS) { const chk = SS.canEnterStage(st, st.rush ? gateIdx(st, useDiff) : useDiff); if (!chk.ok) { alert(chk.reason); return; } }
            if (window.SBCost && !SBCost.guard()) return;      // コストが上限を超えていたら出撃できない
            if (typeof window.cancelStudyTimer === 'function') window.cancelStudyTimer();   // 勉強タイマー中なら0に戻す
            try { localStorage.setItem('sbStageLaunch', JSON.stringify({ stageId: selId, mode: mode, roomId: roomId || null, healer: (window.SBProg ? SBProg.healerPower() : 0), diff: (typeof useDiff === 'number' ? useDiff : selDiff), startFloor: st.corridor ? Math.max(1, Math.min(selStart, Math.max(1, hack.corridorBest | 0))) : 1, at: Date.now() })); } catch (e) {}
            location.href = 'lesson.html';
        }
        renderList(); renderDetail(); refreshRooms();
    }


    // ============================================================
    // オンラインマッチ（アクション対戦）
    //  ・敵はいない。2〜4人の乱戦で、最後まで立っていた人の勝ち（3分で時間切れ→HP割合）
    //  ・ダメージはステータスに関係なく相手の最大HPの割合。武器・スキル・特殊効果・立ち回りの勝負
    //  ・1人で出発すると、スパーリングボットとの練習になる
    // ============================================================
    // ---------- コスト制度：ステージゲートの上に、いまの装備・スキルのコストを表示 ----------
    function costBannerHtml() {
        if (!window.SBCost) return '';
        let b, p; try { p = (typeof getPlayerData === 'function') ? getPlayerData() : null; if (!p) return ''; b = SBCost.breakdown(HW.load(), SBCost.totalOf(p)); } catch (e) { return ''; }
        const col = b.over ? '#ff9a6a' : '#7aff9a';
        return '<details style="margin-bottom:6px;border:1px solid ' + col + ';border-radius:6px;padding:4px 8px"><summary style="cursor:pointer;color:' + col + ';font-size:.82rem">' + esc(SBCost.summaryText(b)) + '</summary>' +
            '<div style="font-size:.78rem;color:#cfe0ff;line-height:1.55;margin-top:3px">' + b.items.map(x => esc(x.label) + '：' + (Math.round(x.cost * 10) / 10)).join('<br>') + '</div>' +
            '<div style="font-size:.74rem;color:#9fb3d9;margin-top:3px">装備とスキルは、同じコスト上限を分け合います。上限は<b>勉強でステータス合計が増えるほど上がります</b>（いまの合計 ' + b.total.toLocaleString() + '）。</div></details>';
    }
    // ---------- ゴースト戦：自分の「分身」を預けて、ほかのプレイヤーの分身をもらう ----------
    function myGhostLoadout() {
        try {
            const w = HW.getEquipped(HW.load()); if (!w) return null;
            const p = JSON.parse(localStorage.getItem('player') || '{}');
            return { id: String(p.id || p.playerId || p.name || 'anon'), ghost: { name: p.name || 'あなた', wtype: w.type, wname: w.name, rar: w.rarity, mythicId: w.mythicId || '', title: (window.SBAch && SBAch.titleText && SBAch.titleText()) || '' } };
        } catch (e) { return null; }
    }
    function saveMyGhost() { const sk = getSock(), g = myGhostLoadout(); if (sk && g) { const go = () => sk.emit('ghost:save', g); if (sk.connected) go(); else sk.once('connect', go); } }
    function launchGhost() {      // ほかのプレイヤーの分身を取ってから出発（取れなければ、練習用のゴーストが出る）
        const sk = getSock(), me = myGhostLoadout(); let done = false;
        const go = foe => { if (done) return; done = true; try { if (foe) localStorage.setItem('sbGhostFoe', JSON.stringify(foe)); else localStorage.removeItem('sbGhostFoe'); } catch (e) {} launchPvp('solo'); };
        if (!sk || !sk.connected) { go(null); return; }
        setTimeout(() => go(null), 1500);
        try { sk.emit('ghost:get', { id: me ? me.id : '' }, foe => go(foe)); } catch (e) { go(null); }
    }
    function launchPvp(mode, roomId, stageId) {
        if (window.SBCost && !SBCost.guard()) return;      // コストが上限を超えていたら出撃できない
        if (typeof window.cancelStudyTimer === 'function') window.cancelStudyTimer();   // 勉強タイマー中なら0に戻す
        try { localStorage.setItem('sbStageLaunch', JSON.stringify({ stageId: stageId || 'pvp_arena', mode: mode, roomId: roomId || null, diff: 0, at: Date.now() })); } catch (e) {}
        location.href = 'lesson.html';
    }
    function openPvpArena() {
        saveMyGhost();      // いまの装備を「ゴースト」として預ける（ほかのプレイヤーが戦える）
        bmEvent('pvp');
        if (!window.STAGE_DATA || !window.HW) { alert('データの読み込みに失敗しました'); return; }
        let rooms = [], evRank = null;
        const sock = getSock();
        const onRooms = list => { rooms = (list || []).filter(r => String(r.stageId || '').indexOf('pvp_') === 0); draw(); };   // 乱戦・2v2・3v3 の部屋をまとめて表示
        const onRank = d => { if (SBPvpEvent && d && String(d.seasonId) === String(SBPvpEvent.seasonId())) { evRank = d; draw(); } };
        const m = modal('⚔ オンラインマッチ（アクション対戦）', () => { if (sock) { sock.off('stage:rooms', onRooms); sock.off('pvpEvent:rankingData', onRank); } });
        if (sock) { sock.on('stage:rooms', onRooms); sock.on('pvpEvent:rankingData', onRank); sock.on('connect', refresh); }
        function refresh() {
            if (sock && sock.connected) {
                sock.emit('stage:list', {});
                if (window.SBPvpEvent && SBPvpEvent.open()) { SBPvpEvent.report(sock); const p = getPlayerData(); sock.emit('pvpEvent:ranking', { seasonId: SBPvpEvent.seasonId(), id: p && p.id }); }
            }
        }
        // ---- シーズン最終週（SCHEDULE.pvpWeek）のPvPイベント ----
        function addCoinsEv(v) { const p = getPlayerData(); if (!p) return; p.coins = (p.coins || 0) + v; localStorage.setItem('player', JSON.stringify(p)); }
        function eventHtml() {
            const EV = window.SBPvpEvent; if (!EV) return '';
            const st = EV.seasonState(), W = (window.SeasonSys && SeasonSys.SCHEDULE && SeasonSys.SCHEDULE.pvpWeek) || 4;
            const box = (inner, bd) => '<div style="margin:8px 0;padding:8px 10px;border:1px solid ' + (bd || '#5a4a8a') + ';border-radius:8px;background:rgba(80,50,140,.18);font-size:.85rem;line-height:1.6">' + inner + '</div>';
            if (!st) return box('⚔ <b>PvPイベント</b>は、<b>シーズンキャラ専用</b>です。シーズンの' + W + '週目から開催されます。');
            if (!EV.open()) {
                if (st.ended) return box('⚔ <b>PvPイベント</b>：シーズンは終了しました。');
                const days = Math.max(0, Math.ceil((new Date(st.def.start).getTime() + (W - 1) * 7 * 86400000 - SeasonSys.now()) / 86400000));
                return box('⚔ <b>PvPイベント</b>：シーズン' + W + '週目から開催！（あと約 ' + days + ' 日）<br>オンラインマッチで勝つほど、豪華な報酬がもらえます。');
            }
            const r = EV.rec();
            let h = '<b style="color:#ffd36a">⚔ PvPイベント開催中！</b>　勝利 +' + EV.EP_WIN + 'EP ／ 負け +' + EV.EP_LOSE + 'EP（2人以上のオンラインマッチのみ。ゴースト戦はEPなし）<br>' +
                'あなたのEP：<b style="color:#ffd84a;font-size:1.05rem">' + r.pts + '</b>　（' + r.plays + '戦 ' + r.wins + '勝）';
            h += '<div class="sbl-sec">報酬</div>' + EV.MILESTONES.map((mm, i) => {
                const got = !!r.claimed[i], can = !got && r.pts >= mm.ep;
                return '<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;padding:2px 0;border-bottom:1px solid #2a3350"><span style="' + (got ? 'color:#778' : '') + '">' + mm.ep + 'EP：' + esc(mm.label) + '</span>' +
                    (got ? '<span style="color:#7aff9a">受取済</span>' : (can ? '<button class="sbl-btn orange" data-claim="' + i + '" style="padding:2px 8px;font-size:.75rem">受け取る</button>' : '<span style="color:#778">あと' + (mm.ep - r.pts) + 'EP</span>')) + '</div>';
            }).join('');
            h += '<div class="sbl-sec">ランキング（EP）</div>';
            if (evRank && evRank.top) {
                h += (evRank.me ? '<div>あなた：<b>' + evRank.me.rank + '位</b>（' + evRank.me.pts + 'EP）／ 参加 ' + evRank.total + '人</div>' : '<div style="color:#9fb3d9">まだランキングに載っていません（1戦すると載ります）</div>') +
                    evRank.top.slice(0, 10).map(x => '<div style="display:flex;justify-content:space-between;font-size:.8rem"><span>' + x.rank + '位　' + esc(x.name) + '</span><span>' + x.pts + 'EP（' + x.wins + '勝）</span></div>').join('');
            } else h += '<div style="color:#9fb3d9">' + (sock && sock.connected ? '読み込み中…' : 'サーバーに接続すると表示されます') + '</div>';
            return box(h, '#8a6adf');
        }
        // コスト制度：装備のコストと、勉強（ステータス合計）で決まる上限
        function costHtml(p) {
            if (!window.SBCost || !p) return '';
            let b; try { b = SBCost.breakdown(HW.load(), SBCost.totalOf(p)); } catch (e) { return ''; }
            const col = b.over ? '#ff9a6a' : '#7aff9a';
            return '<div class="sbl-card" style="border-color:' + col + ';margin:8px 0"><div style="font-weight:bold;color:' + col + '">' + esc(SBCost.summaryText(b)) + '</div>' +
                '<div style="font-size:.8rem;color:#cfe0ff;line-height:1.6;margin-top:3px">' + b.items.map(x => esc(x.label) + '：' + (Math.round(x.cost * 10) / 10)).join('<br>') + '</div>' +
                '<div style="font-size:.78rem;color:#9fb3d9;margin-top:4px">装備とスキルのコストが上限を超えると、<b>装備できず、出撃もできません</b>（ステージでも同じです）。上限は<b>勉強でステータス合計が増えるほど上がります</b>（いまの合計 ' + b.total.toLocaleString() + '）。</div></div>';
        }
        function draw() {
            const p = (typeof getPlayerData === 'function') ? getPlayerData() : null;
            m.body.innerHTML = '<div class="sbl-col" style="flex:1 1 100%">' +
                '<div style="font-size:.9rem;color:#cfe0ff;line-height:1.6">いまの武器とスキルで戦う、リアルタイムの対人戦です。<br>' +
                '・2〜4人の乱戦。<b>最後まで立っていた人の勝ち</b>（制限時間3分、切れたらHPの割合で判定）<br>' +
                '・ダメージは<b>ステータスに関係なく、相手の最大HPの割合</b>で決まります。武器の種類・スキル・特殊効果・立ち回りの勝負！<br>' +
                '・勝てばコイン+400、負けても+120。相手がいないときは「👻 ゴースト戦」で、ほかのプレイヤーの分身（武器・名前を借りたAI）と戦えます（勝てばコイン+200、負けても+60。勝利数・イベントには数えません）。</div>' +
                '<div style="margin:8px 0;font-size:.85rem;color:#ffd36a">通算勝利：' + ((p && p.pvpWins) || 0) + '勝</div>' + costHtml(p) + eventHtml() +
                '<div><button class="sbl-btn orange" id="pvQuick">ランダムマッチ</button><button class="sbl-btn" id="pvCreate">部屋を作る</button>' +
                '<button class="sbl-btn gray" id="pvCode">部屋コードで参加</button><button class="sbl-btn gray" id="pvBot">👻 ゴースト戦</button></div>' +
                '<div class="sbl-sec">チーム戦（2v2・3v3）</div>' +
                '<div style="font-size:.8rem;color:#9fb3d9;line-height:1.5;margin-bottom:4px">参加した順に 🔵青・🔴赤 へ交互に振り分けられます。味方には攻撃が当たらず、<b>相手チームを全員倒したら勝ち</b>。人数が足りなくてもホストが出発できます（1人だとボット練習）。</div>' +
                '<div><button class="sbl-btn orange" data-team="pvp_2v2:quick">2v2 ランダム</button><button class="sbl-btn" data-team="pvp_2v2:create">2v2 部屋を作る</button>' +
                '<button class="sbl-btn orange" data-team="pvp_3v3:quick">3v3 ランダム</button><button class="sbl-btn" data-team="pvp_3v3:create">3v3 部屋を作る</button></div>' +
                '<div class="sbl-sec">募集中の部屋</div>' +
                (rooms.length ? rooms.map(r => '<div class="sbl-card" style="display:flex;justify-content:space-between;align-items:center"><span>[' + ({ pvp_2v2: '2v2', pvp_3v3: '3v3' }[r.stageId] || '乱戦') + '] ' + esc(r.members.map(x => x.name).join('、')) + '　(' + r.members.length + '/' + r.max + ')</span><button class="sbl-btn" data-room="' + esc(r.id) + '" data-stage="' + esc(r.stageId) + '">参加</button></div>').join('') : '<div style="opacity:.7;font-size:.85rem">いまは募集中の部屋はありません。</div>') +
                '</div>';
            m.body.querySelectorAll('[data-claim]').forEach(b => b.addEventListener('click', () => {
                const lines = SBPvpEvent.claim(parseInt(b.dataset.claim, 10), addCoinsEv);
                if (lines) { alert('PvPイベントの報酬を受け取りました！\n\n' + lines.join('\n')); try { refreshInvInfo(); } catch (e) {} draw(); }
            }));
            m.body.querySelector('#pvQuick').addEventListener('click', () => launchPvp('quick'));
            m.body.querySelector('#pvCreate').addEventListener('click', () => launchPvp('create'));
            m.body.querySelector('#pvBot').addEventListener('click', () => launchGhost());
            m.body.querySelector('#pvCode').addEventListener('click', () => { const c = (prompt('部屋コード（4文字）を入力してください') || '').trim().toUpperCase(); if (!c) return; const r = rooms.find(x => String(x.id).toUpperCase() === c); launchPvp('join', c, r ? r.stageId : 'pvp_arena'); });   // 部屋の種類（乱戦・2v2・3v3）は一覧から調べる
            m.body.querySelectorAll('[data-team]').forEach(b => b.addEventListener('click', () => { const t = b.dataset.team.split(':'); launchPvp(t[1], null, t[0]); }));
            m.body.querySelectorAll('[data-room]').forEach(b => b.addEventListener('click', () => launchPvp('join', b.dataset.room, b.dataset.stage || 'pvp_arena')));
        }
        draw(); refresh();
    }
    window.openPvpArena = openPvpArena;

    // ============================================================
    // 大討伐戦（最大20人のレイド）
    //  ・ボス1体。ボスの強さは「不壊の悪魔」の約5倍。人数が多いほどHPも増える
    //  ・第一幕：増殖スライム インクリーズ（報酬：Legend of Increase／称号「増殖を食い止めるもの」）
    //  ・第三幕：ネクロマンスド・シャーマン／第四幕：双界の覇竜ツイン・エレメンタル（赤と青のエリア）／第五幕：機械真王・リレインバー。報酬は専用装備「Legend of Duality」と称号「双界を切り開くもの」
    // ============================================================
    const RAIDS = [
        { id: 'raid_increase', act: '第一幕', name: '増殖スライム インクリーズ', color: '#5be37a', mythic: 'legend_increase', weapon: 'Legend of Increase', title: '増殖を食い止めるもの',
          body: 'いつもはねて動く巨大なスライム。倒すと<b>2体に分裂</b>し、分裂するたびに<b style="color:#9df0a8">小さく・速く・弱く</b>なっていきます。<br>' +
              '・スライムが<b>10体</b>に増えると、逃げ回る<b style="color:#ff7a96">❤ 増殖の心臓</b>が現れる。<b>心臓に一撃</b>当てれば勝ち（スライムは全部消える）<br>' +
              '・着地のたびに衝撃波が出る。大きいうちは増殖弾もばらまく。心臓が出ると、スライムは少し速くなる<br>' +
              '・倒しすぎてもキリがない！ 心臓を出すまでは数を増やして、心臓が出たら一直線に狙おう<br>' +
              '・レベル50くらいあれば、1人でも倒せます（人数が多いほどHPも増えます）' },
        { id: 'raid_worm', act: '第二幕', name: 'ワールドワーム', color: '#c9a27a', mythic: 'legend_eater', weapon: 'Legend of Eater', title: '世界を喰らうもの',
          body: 'ステージごと世界を喰らう、巨大な蟲。3つのギミックを、みんなで力を合わせて攻略しよう。<br>' +
              '・<b style="color:#d8a85a">世界喰らい</b>：外周から足場が崩れて奈落に落ちる。落ちると倒れる！ 足場はどんどん狭くなり、攻撃で吹き飛ばされると、縁から落ちるかも<br>' +
              '・<b style="color:#9fe0ff">大釣合戦</b>：ワームが地中に潜る。足元の予兆をよけながら、各所の<b>アンカーの上に乗り続けて</b>、全員で引きずり出す。成功すると、長い体のどこを殴っても大ダメージ<br>' +
              '・<b style="color:#ff9ab0">体内潜入</b>：ステージの半分が丸呑みにされ、<b>外</b>と<b>体内</b>に分かれる。外は<b>硬い鱗</b>を壊して口を開けさせ、中は酸に耐えて<b>心臓核</b>を壊す。<b>中と外のコアを同時に壊す</b>と大ダウン<br>' +
              '・1人でも挑める（体内に1人で潜り、心臓核を壊す）。人数が多いほど体力も増える' },
        { id: 'raid_necro', act: '第三幕', name: 'ネクロマンスド・シャーマン', color: '#a070ff', mythic: 'legend_necromance', weapon: 'Legend of Necromance', title: '魂の理を断ち切るもの',
          body: '死霊を操る呪術師。<b style="color:#cdb8ff">1秒に5体</b>のペースで、死霊を呼び出し続けます。<br>' +
              '・<b style="color:#7fae6a">🧟 ゾンビ化</b>：シャーマンの軍勢に倒されると、<b>自分とそっくりのステータス</b>のゾンビが死体から生まれて、仲間を襲う！ 倒れないことが大切<br>' +
              '・死霊は雑魚。数に飲まれず、<b>本体のシャーマン</b>を狙おう（倒すと死霊もゾンビも全部消える）<br>' +
              '・本体は距離をとって、骨の弾幕・死霊の輪・魂の叩きつけを使う。HP50%以下で激しくなる<br>' +
              '・ボスの強さは不壊の悪魔の約4倍。人数が多いほどHPも増えます' },
        { id: 'raid_duality', act: '第四幕', name: '双界の覇竜 ツイン・エレメンタル', color: '#c06aff', mythic: 'legend_duality', weapon: 'Legend of Duality', title: '双界を切り開くもの',
          body: '戦場は<b style="color:#ff7a5a">赤い炎のエリア</b>と<b style="color:#6ad4ff">青い氷のエリア</b>に割れています。色の通りに動けば生き残れる！<br>' +
              '・赤に長くいると「熱狂」（攻撃UP・持続ダメージ）、青に長くいると「悪寒」（移動DOWN・被ダメージUP）。ときどき反対の色へ移ろう<br>' +
              '・赤いバリアは<b>青エリア</b>から、青いバリアは<b>赤エリア</b>から攻撃すると大ダメージ。全員で声を掛け合って大移動！<br>' +
              '・「カタストロフ・レイン」は、印の色と反対のエリアへ逃げると相殺できる<br>' +
              '・HP50%以下で「紫炎の崩壊」。「双界終焉」は赤と青のクリスタルを全員で同時に壊せ！<br>' +
              '・ボスの強さは不壊の悪魔の約5倍。人数が多いほどHPも増えます（推奨：ステータス合計 10万以上）' },
        { id: 'raid_machine', act: '第五幕', name: '機械真王・リレインバー', color: '#7fd8ff', mythic: 'legend_relainbar', weapon: 'Legend of Relainbar', title: '機械をも支配するもの',
          body: '空を飛ぶ、機械の王。<b style="color:#ffb04a">燃料</b>が切れるまでの耐久戦です。<br>' +
              '・⛽ <b>燃料</b>は何もしなくても減り、約<b>20分</b>で切れる。切れると墜落して、近接でも殴れる（大ダメージのチャンス）<br>' +
              '・🛡 攻撃を当てると<b style="color:#7fd8ff">自動でバリア</b>が出て、燃料を少し使う。バリア中はダメージが通らない<br>' +
              '・基本は空にいる。<b>遠距離武器</b>は地上から当たる。<b>近接武器</b>は、フィールドの<b style="color:#d8f6ff">⬆ 上昇気流</b>に乗って空へ飛べば届く<br>' +
              '・レーザーの掃射と、大量のミサイルに注意！ ミサイルは着弾の予告が出る<br>' +
              '・ボスの強さは不壊の悪魔の約6倍。人数が多いほどHPも増えます' },
        { id: 'raid_velzark', act: '第六幕', name: '魔装合体ヴェルスザーク', color: '#ffd86a', mythic: 'legend_fusion', weapon: 'Legend of Fusion', title: '融合を切り裂くもの',
          body: '最初は、<b style="color:#bfe6ff">天使「ヴェルス」</b>と<b style="color:#ff4a5a">悪魔「ザーク」</b>の2体が相手です。<br>' +
              '・😇 <b>ヴェルス</b>：不壊の悪魔のような、ビームの雨。距離をとって撃ってくる<br>' +
              '・😈 <b>ザーク</b>：ボスの中でも初めての<b>超インファイト</b>。猛スピードで近づいて、殴る・叩きつける・突進・跳ぶ<br>' +
              '・⚠ <b>どちらかが倒れると、2体が合体</b>して「魔装合体ヴェルスザーク」になる。<b>合体後はHPが満タン</b>から！<br>' +
              '・⚡ 合体後は<b style="color:#ffe27a">瞬間移動</b>で、一瞬で近くに詰めてくる。<b>遠くにいる</b>とヴェルスの技か瞬間移動、<b>近くにいる</b>とザークの技。どの技も大幅に強化されている<br>' +
              '・ボスの強さは不壊の悪魔の約7倍。人数が多いほどHPも増えます' }
    ];
    let RAID_ID = RAIDS[0].id;
    function launchRaid(mode, roomId) {
        if (window.SBCost && !SBCost.guard()) return;      // コストが上限を超えていたら出撃できない
        if (typeof window.cancelStudyTimer === 'function') window.cancelStudyTimer();   // 勉強タイマー中なら0に戻す
        try { localStorage.setItem('sbStageLaunch', JSON.stringify({ stageId: RAID_ID, mode: mode, roomId: roomId || null, diff: 0, at: Date.now() })); } catch (e) {}
        location.href = 'lesson.html';
    }
    function openRaidLobby() {
        if (!window.STAGE_DATA || !window.HW) { alert('データの読み込みに失敗しました'); return; }
        let rooms = [], cur = RAIDS.find(r => r.id === RAID_ID) || RAIDS[0];
        const sock = getSock();
        const onRooms = list => { rooms = (list || []).filter(r => r.stageId === RAID_ID); draw(); };
        const m = modal('🐉 大討伐戦（最大20人）', () => { if (sock) sock.off('stage:rooms', onRooms); });
        if (sock) { sock.on('stage:rooms', onRooms); sock.on('connect', refresh); }
        function refresh() { if (sock && sock.connected) sock.emit('stage:list', { stageId: RAID_ID }); }
        function owned() { if (!cur.mythic) return false; try { return HW.load().weapons.some(w => w && w.mythicId === cur.mythic); } catch (e) { return false; } }
        function draw() {
            m.body.innerHTML = '<div class="sbl-col" style="flex:1 1 100%">' +
                '<div style="margin-bottom:6px">' + RAIDS.map(r => '<button type="button" class="sbl-btn ' + (r.id === cur.id ? '' : 'gray') + '" data-act="' + r.id + '" style="margin:0 4px 4px 0">' + r.act + '　' + esc(r.name.split(' ')[0]) + '</button>').join('') + '</div>' +
                '<div class="sbl-card" style="border-color:' + cur.color + '"><div style="font-size:1.1rem;font-weight:bold">' + cur.act + '　' + esc(cur.name) + '</div>' +
                '<div style="font-size:.85rem;line-height:1.6;margin-top:4px;color:#e4d4ff">' + cur.body + '</div>' +
                '<div style="margin-top:6px;font-size:.85rem;color:#ffd36a">' + (cur.weapon ? '報酬：専用の神話装備「' + cur.weapon + '」' + (owned() ? '（入手済み）' : '') + '／称号「' + cur.title + '」' : '報酬：通常の大討伐戦の報酬（専用装備・称号は準備中）') + '</div></div>' +
                '<div style="margin-top:8px"><button class="sbl-btn orange" id="rdQuick">ランダム参加</button><button class="sbl-btn" id="rdCreate">部屋を作る</button>' +
                '<button class="sbl-btn gray" id="rdCode">部屋コードで参加</button><button class="sbl-btn gray" id="rdSolo">1人で挑む</button></div>' +
                '<div class="sbl-sec">募集中の部屋</div>' +
                (rooms.length ? rooms.map(r => '<div class="sbl-card" style="display:flex;justify-content:space-between;align-items:center"><span>' + esc(r.members.map(x => x.name).join('、')) + '　(' + r.members.length + '/' + r.max + ')　[' + esc(r.id) + ']</span><button class="sbl-btn" data-room="' + esc(r.id) + '">参加</button></div>').join('') : '<div style="opacity:.7;font-size:.85rem">いま募集中の部屋はありません。「部屋を作る」か「1人で挑む」から始めよう</div>') +
                '</div>';
            m.body.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', () => { cur = RAIDS.find(r => r.id === b.dataset.act) || cur; RAID_ID = cur.id; rooms = []; draw(); refresh(); }));
            m.body.querySelector('#rdQuick').addEventListener('click', () => launchRaid('quick'));
            m.body.querySelector('#rdCreate').addEventListener('click', () => launchRaid('create'));
            m.body.querySelector('#rdSolo').addEventListener('click', () => launchRaid('solo'));
            m.body.querySelector('#rdCode').addEventListener('click', () => { const c = (prompt('部屋コード（4文字）を入力してください') || '').trim().toUpperCase(); if (c) launchRaid('join', c); });
            m.body.querySelectorAll('[data-room]').forEach(b => b.addEventListener('click', () => launchRaid('join', b.dataset.room)));
        }
        draw(); refresh();
    }
    window.openRaidLobby = openRaidLobby;

    // ============================================================
    // 襲撃ステージ：ステージをクリアしたあと、確率で30分だけ出現する（抽選は practice.js の finish()。出現した期限は、武器庫のデータ ambush.until に残る）
    //  ・出現中は、画面の右上に「⚔ 襲撃ステージ 残り○:○○」が出る。タップすると入り口が開く。王を倒すと閉じる（負けたときは期限まで何度でも挑める）
    // ============================================================
    let ambUntil = 0, ambRead = 0;
    function ambushLeft(force) {
        const now = Date.now();
        if (force || now - ambRead > 8000) { ambRead = now; try { const a = HW.load().ambush; ambUntil = (a && a.until) || 0; } catch (e) { ambUntil = 0; } }
        return Math.max(0, ambUntil - now);
    }
    function ambFmt(ms) { const t = Math.ceil(ms / 1000); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); }
    function launchAmbush(mode, roomId) {
        if (!ambushLeft(true)) { alert('いまは、襲撃は起きていません。（ステージをクリアすると、確率で現れます）'); return; }
        if (window.SBCost && !SBCost.guard()) return;      // コストが上限を超えていたら出撃できない
        if (typeof window.cancelStudyTimer === 'function') window.cancelStudyTimer();
        try { localStorage.setItem('sbStageLaunch', JSON.stringify({ stageId: 'ambush', mode: mode, roomId: roomId || null, diff: 0, at: Date.now() })); } catch (e) {}
        location.href = 'lesson.html';
    }
    function openAmbushLobby() {
        if (!window.STAGE_DATA || !window.HW) { alert('データの読み込みに失敗しました'); return; }
        if (!ambushLeft(true)) { alert('いまは、襲撃は起きていません。（ステージをクリアすると、確率で現れます）'); return; }
        let rooms = [], tm = null;
        const sock = getSock();
        const onRooms = list => { rooms = (list || []).filter(r => r.stageId === 'ambush'); draw(); };
        const m = modal('⚔ 襲撃ステージ', () => { if (tm) clearInterval(tm); if (sock) sock.off('stage:rooms', onRooms); });
        if (sock) { sock.on('stage:rooms', onRooms); sock.on('connect', refresh); }
        function refresh() { if (sock && sock.connected) sock.emit('stage:list', { stageId: 'ambush' }); }
        function draw() {
            m.body.innerHTML = '<div class="sbl-col" style="flex:1 1 100%">' +
                '<div class="sbl-card" style="border-color:#c0394d"><div style="font-size:1.1rem;font-weight:bold">⚔ ニンゲンの襲来　<span id="amLeft" style="color:#ffd36a">残り ' + ambFmt(ambushLeft()) + '</span></div>' +
                '<div style="font-size:.85rem;line-height:1.6;margin-top:4px;color:#ffd9d9">邪悪な「ニンゲン」が、<b>あらゆる方向</b>から襲ってきます。<br>' +
                '・6つの波。進むほど、来る方向も数も種類も増える<br>' +
                '・ニンゲンにも、いろいろな奴らがいる：暴徒・槍兵・弓兵・盾兵・爆弾魔・衛生兵（仲間を治す）・魔術師・狂戦士・忍者（背後に回る）・狙撃手・火炎兵・指揮官（増援を呼ぶ）<br>' +
                '・波のあとに、最後のボス<b style="color:#ffcf6a">👑ニンゲンの王</b>が現れる。特別な動きをする<br>' +
                '・王を倒すと、特別な報酬（レジェンダリー確定の装備など）と称号。倒すと、この襲撃は閉じます（負けたときは、期限まで何度でも挑めます）</div></div>' +
                '<div style="margin-top:8px"><button class="sbl-btn orange" id="amQuick">ランダム参加</button><button class="sbl-btn" id="amCreate">部屋を作る</button>' +
                '<button class="sbl-btn gray" id="amCode">部屋コードで参加</button><button class="sbl-btn gray" id="amSolo">1人で挑む</button></div>' +
                '<div class="sbl-sec">募集中の部屋</div>' +
                (rooms.length ? rooms.map(r => '<div class="sbl-card" style="display:flex;justify-content:space-between;align-items:center"><span>' + esc(r.members.map(x => x.name).join('、')) + '　(' + r.members.length + '/' + r.max + ')　[' + esc(r.id) + ']</span><button class="sbl-btn" data-room="' + esc(r.id) + '">参加</button></div>').join('') : '<div style="color:#9fb3d9;font-size:.85rem">いまは、募集中の部屋はありません。</div>') +
                '</div>';
            m.body.querySelector('#amQuick').addEventListener('click', () => launchAmbush('quick'));
            m.body.querySelector('#amCreate').addEventListener('click', () => launchAmbush('create'));
            m.body.querySelector('#amSolo').addEventListener('click', () => launchAmbush('solo'));
            m.body.querySelector('#amCode').addEventListener('click', () => { const c = (prompt('部屋コード（4文字）を入力してください') || '').trim().toUpperCase(); if (c) launchAmbush('join', c); });
            m.body.querySelectorAll('[data-room]').forEach(b => b.addEventListener('click', () => launchAmbush('join', b.dataset.room)));
        }
        tm = setInterval(() => { const el = m.body.querySelector('#amLeft'); if (el) el.textContent = '残り ' + ambFmt(ambushLeft()); }, 1000);
        draw(); refresh();
    }
    window.openAmbushLobby = openAmbushLobby;
    (function ambushPill() {      // 出現中だけ、町の画面の右上に出る入り口
        if (!/index\.html$|\/$/.test(location.pathname) && !document.getElementById('raidBtn')) return;
        const pill = document.createElement('div');
        pill.id = 'ambushPill';
        pill.style.cssText = 'position:fixed;top:calc(max(8px,env(safe-area-inset-top)) + 44px);right:8px;z-index:60;display:none;cursor:pointer;background:#7a1d2a;color:#fff;border:2px solid #ffcf6a;border-radius:18px;padding:5px 12px;font-weight:bold;font-size:.82rem;box-shadow:0 0 12px rgba(255,80,80,.6);animation:ambPulse 1.2s infinite alternate';
        const st = document.createElement('style'); st.textContent = '@keyframes ambPulse{from{transform:scale(1)}to{transform:scale(1.07)}}'; document.head.appendChild(st);
        pill.addEventListener('click', openAmbushLobby);
        const add = () => { if (!pill.parentNode && document.body) document.body.appendChild(pill); };
        setInterval(() => { add(); const l = ambushLeft(); pill.style.display = l > 0 ? 'block' : 'none'; if (l > 0) pill.textContent = '⚔ 襲撃ステージ　残り ' + ambFmt(l); }, 1000);
    })();
    window.SBLobbyUI = { modal: modal, esc: esc };      // オリジナル武器の画面（orig-weapon-ui.js）が、同じ見た目の窓を使えるように
    document.addEventListener('click', function (e) {
        const b = e.target && e.target.closest && e.target.closest('#raidBtn');
        if (!b) return;
        e.preventDefault(); e.stopImmediatePropagation();
        openRaidLobby();
    }, true);

    // これまでのオンラインマッチのボタン（ランダム／ルーム作成／ルーム参加／ボット戦）は、アクション対戦につなぎ直す
    document.addEventListener('click', function (e) {
        const b = e.target && e.target.closest && e.target.closest('#randomMatch, #createRoom, #joinRoom, #botMatch, #practiceBotMatch, #pvpBtn');
        if (!b) return;
        e.preventDefault(); e.stopImmediatePropagation();
        if (b.id === 'randomMatch') launchPvp('quick');
        else if (b.id === 'createRoom') launchPvp('create');
        else if (b.id === 'joinRoom') { const c = (prompt('部屋コード（4文字）を入力してください') || '').trim().toUpperCase(); if (c) launchPvp('join', c); }
        else if (b.id === 'botMatch' || b.id === 'practiceBotMatch') launchGhost();
        else openPvpArena();
    }, true);

    // ============================================================
    // 武器庫（装備・ソケット・売却）
    // ============================================================
    // ---------- 特殊アイテム（無限回廊の宝箱・ボス部屋で手に入る）の使用パネル ----------
    //  武器：スロット拡張／レア度上昇／効果リロール　防具：効果リロール
    function itemPanelHtml(hack, kinds, target, isWeapon) {
        const can = { slot: isWeapon && HW.canAddSocket(target), rarity: isWeapon && HW.canUseCrystal(target), reroll: !!(target && target.effects && target.effects.length) };
        const legend = isWeapon && target && target.rarity === 'legendary';
        const why = { slot: '最大スロットです', rarity: legend ? 'すでに最大（+' + HW.PLUS_MAX + '）です' : 'すでに最高レア度です', reroll: '追加効果がありません' };
        const descOf = fx => { try { return isWeapon ? HW.describeEffect(fx) : SBArmor.describeEffect(fx); } catch (e) { return fx.id; } };
        return '<div class="sbl-sec">特殊アイテム（無限回廊で入手）</div>' + kinds.map(k => {
            const it = HW.SPECIAL_ITEMS[k], n = HW.itemCount(hack, k), ok = can[k] && n > 0;
            let label = it.icon + ' ' + it.name + '×' + n, text = can[k] ? it.desc : why[k];
            if (k === 'rarity' && legend && can.rarity) { const pl = target.plus | 0; label = '🔶 ＋' + (pl + 1) + ' に強化 ×' + n; text = '「＋N」のアップグレード：攻撃の%が少し上がる（いま＋' + pl + '／最大＋' + HW.PLUS_MAX + '）'; }
            let html = '<div style="display:flex;gap:6px;align-items:center;margin:3px 0"><button class="sbl-btn" data-item="' + k + '" style="margin:0;' + (ok ? 'background:' + it.color + ';color:#000' : 'opacity:.5') + '"' + (ok ? '' : ' disabled') + '>' + label + '</button><span style="font-size:.74rem;color:#9fb3d9">' + esc(text) + '</span></div>';
            if (k === 'reroll' && can.reroll) {      // どの効果を引き直すかを選べる（いくつでも）。リスキーな効果は赤で表示
                html += '<div style="margin:2px 0 6px 8px;padding:6px;border:1px solid #3a4a78;border-radius:8px;background:rgba(40,60,110,.25)"><div style="font-size:.74rem;color:#9fb3d9;margin-bottom:3px">引き直す効果にチェック（いくつでも選べます。チェックしたものだけが変わります）</div>' +
                    target.effects.map((fx, i) => '<label style="display:flex;gap:6px;align-items:flex-start;font-size:.8rem;padding:2px 0;cursor:pointer"><input type="checkbox" data-fx="' + i + '" style="margin-top:3px"><span style="color:' + (/^(rk_|ar_rk_)/.test(fx.id) ? '#ff9a9a' : '#e8eefc') + '">' + esc(descOf(fx)) + '</span></label>').join('') +
                    '<div style="margin-top:3px"><button class="sbl-btn gray" data-fxall style="padding:2px 8px;font-size:.72rem;margin:0">すべて選ぶ</button> <button class="sbl-btn gray" data-fxnone style="padding:2px 8px;font-size:.72rem;margin:0">選択を外す</button></div></div>';
            }
            return html;
        }).join('');
    }
    // 効果のチェック欄（data-fx）で選ばれた番号を集める
    function pickedFx(root) { return Array.from(root.querySelectorAll('input[data-fx]:checked')).map(x => parseInt(x.dataset.fx, 10)); }
    function bindFxPick(root) {
        const all = root.querySelector('[data-fxall]'), none = root.querySelector('[data-fxnone]');
        if (all) all.addEventListener('click', () => root.querySelectorAll('input[data-fx]').forEach(x => { x.checked = true; }));
        if (none) none.addEventListener('click', () => root.querySelectorAll('input[data-fx]').forEach(x => { x.checked = false; }));
    }
    function applyItem(hack, kind, target, isWeapon, idxs) {
        if (HW.itemCount(hack, kind) < 1) return false;
        if (kind === 'rarity' && isWeapon && window.SBCost && hack.equipped === target.id) {      // 装備中の武器のコストが上がって、上限を超えるなら使えない
            const nr = HW.RARITY_ORDER[HW.RARITY_ORDER.indexOf(target.rarity) + 1], patch = nr ? { rarity: nr } : { plus: (target.plus | 0) + 1 }, r = SBCost.canEquip(hack, { patchWeapon: target, patch: patch });
            if (!r.ok) { alert(r.msg + '\n（装備中の武器は、コストが上がるため強化できません。いったん外すか、上限を上げてください）'); return false; }
        }
        let ok = false;
        if (kind === 'slot') ok = isWeapon && HW.addSocket(target);
        else if (kind === 'rarity') ok = isWeapon && HW.upgradeRarity(target);
        else if (kind === 'reroll') ok = isWeapon ? HW.rerollWeaponEffects(target, idxs) : (window.SBArmor && SBArmor.rerollEffects(target, idxs));
        if (ok) HW.takeItem(hack, kind);
        return !!ok;
    }
    function orbLabel(o) {
        let name = o.tier || 'orb';
        try { if (typeof getOrbDisplayName === 'function') name = getOrbDisplayName(o); } catch (e) {}
        return String(name);
    }
    function openArmory() {
        bmEvent('armory');
        if (!window.HW) return;
        let hack = HW.load();
        try { HW.syncLegacy(hack, true); } catch (e) {}
        let selId = hack.equipped;
        let filter = 'all';
        const m = modal('🗡 武器庫（装備・オーブ・売却）', () => { try { if (typeof renderOrbInventory === 'function') renderOrbInventory(); if (typeof updateStatus === 'function') updateStatus(getPlayerData()); } catch (e) {} });
        m.body.innerHTML = '<div class="sbl-col sbl-left" id="sbWl"></div><div class="sbl-col sbl-right" id="sbWd"></div>';
        const wl = m.body.querySelector('#sbWl'), wd = m.body.querySelector('#sbWd');
        const coins = () => { const p = getPlayerData(); return p ? (p.coins || 0) : 0; };

        function sorted() {
            const arr = hack.weapons.filter(w => filter === 'all' || w.type === filter || (filter === 'eq' && w.id === hack.equipped));
            return arr.sort((a, b) => HW.rIdx(b.rarity) - HW.rIdx(a.rarity) || b.ilvl - a.ilvl || b.dmg - a.dmg);
        }
        function renderList() {
            const types = {}; hack.weapons.forEach(w => { types[w.type] = 1; });
            wl.innerHTML = '<div class="sbl-sec">所持武器 ' + hack.weapons.length + ' 本（コイン ' + coins() + '）</div>' +
                '<select id="sbFilter" style="margin-bottom:6px;padding:4px"><option value="all">すべて</option><option value="eq">装備中</option>' + Object.keys(types).map(t => '<option value="' + t + '"' + (filter === t ? ' selected' : '') + '>' + esc((HW.TYPES[t] || {}).label || t) + '</option>').join('') + '</select> ' +
                '<button class="sbl-btn gray" id="sbBulk" style="padding:4px 8px;font-size:.75rem">🗑 一括売却</button>' +
                '<button class="sbl-btn orange" id="sbForge" style="padding:4px 8px;font-size:.75rem">🔨 オリジナル武器キット</button>' +
                '<button class="sbl-btn green" id="sbArmorBtn" style="padding:4px 8px;font-size:.75rem">🛡 防具（頭・胴・脚）</button>' +
                '<button class="sbl-btn orange" id="sbAccBtn" style="padding:4px 8px;font-size:.75rem">✨ アクセサリー（スキル）</button>' +
                sorted().map(w => '<div class="sbl-wl' + (w.id === selId ? ' sel' : '') + (w.id === hack.equipped ? ' eq' : '') + '" data-id="' + w.id + '"><span style="color:' + HW.rarityOf(w).color + '">' + (w.id === hack.equipped ? '【装備中】' : '') + esc(w.name) + (w.elems && w.elems.length && window.SBElem ? ' ' + SBElem.ELEMS[w.elems[0]].icon + (w.elems.length > 1 ? SBElem.ELEMS[w.elems[1]].icon : '') : '') + '</span><span style="color:#9fb3d9">' + (w.locked ? '🔒 ' : '') + '攻' + HW.pctLabel(w) + ' 穴' + w.sockets + '</span></div>').join('');
            wl.querySelector('#sbFilter').value = filter;
            wl.querySelector('#sbFilter').addEventListener('change', (e) => { filter = e.target.value; renderList(); });
            wl.querySelectorAll('.sbl-wl').forEach(r => r.addEventListener('click', () => { selId = r.dataset.id; renderList(); renderDetail(); }));
            wl.querySelector('#sbBulk').addEventListener('click', openBulk);
            wl.querySelector('#sbForge').addEventListener('click', () => { if (window.SBOrigUI) SBOrigUI.openKits(hack, () => { try { refreshInvInfo(); } catch (e) {} selId = hack.equipped; renderList(); renderDetail(); }); else openForge(); });
            const ab = wl.querySelector('#sbArmorBtn'); if (ab) ab.addEventListener('click', openArmor);
            const ac = wl.querySelector('#sbAccBtn'); if (ac) ac.addEventListener('click', openAccessory);
        }
        function addCoins(v) { const p = getPlayerData(); if (!p) return; p.coins = (p.coins || 0) + v; localStorage.setItem('player', JSON.stringify(p)); }

        function renderDetail() {
            const w = hack.weapons.find(x => x.id === selId);
            if (!w) { wd.innerHTML = '<div style="color:#889">武器を選んでください</div>'; return; }
            const R = HW.rarityOf(w), T = HW.TYPES[w.type] || {};
            const ag = HW.aggregate(w);
            const slots = []; for (let i = 0; i < w.sockets; i++) slots.push('<span class="sbl-slot' + (w.orbs[i] ? ' full' : '') + '" data-slot="' + i + '" title="' + (w.orbs[i] ? esc(orbLabel(w.orbs[i])) : '空きソケット') + '">' + (w.orbs[i] ? '💎' : '＋') + '</span>');
            wd.innerHTML =
                '<h3 style="margin:0;color:' + R.color + '">' + esc(w.name) + '</h3>' +
                '<div style="font-size:.82rem;color:#9fb3d9">[' + R.label + '] ' + esc(T.label || w.type) + '　Lv' + w.ilvl + '　攻撃力 ' + HW.pctLabel(w) + (w.custom ? '　★オリジナル' + (w.v2 || w.exp != null ? '（成長 ' + Math.round(HW.growFrac(w) * 100) + '%）' : '') : '') + '</div>' +
                (T.sup ? '<div style="font-size:.78rem;color:#9fe0a0">🩹 支援武器：' + ({ all: '攻撃すると、自分と近くの味方を回復＆鼓舞（攻撃・防御アップ）し、当てた敵を弱体化・減速させて受けるダメージを増やす' }[T.sup] || '') + '</div>' : '') +
                (w.elems && w.elems.length && window.SBElem ? '<div class="sbl-sec">属性</div><div style="font-size:.82rem">' + SBElem.labels(w.elems) + '</div><div style="font-size:.76rem">' + SBElem.styleHtml(w.elems) + '</div>' : '<div style="font-size:.76rem;color:#778">無属性</div>') +
                '<div class="sbl-sec">特殊効果</div>' + (w.effects.length ? w.effects.map(f => '<div class="sbl-fx">◆ ' + esc(HW.describeEffect(f)) + '</div>').join('') : '<div class="sbl-fx" style="color:#778">なし</div>') +
                '<div class="sbl-sec">ソケット（オーブをはめ込む）</div><div>' + slots.join('') + '</div>' +
                (w.orbs.some(Boolean) ? '<div class="sbl-sec">オーブの効果</div>' + w.orbs.map(o => o ? HW.orbToEffects(o).lines.map(l => '<div class="sbl-fx" style="color:#9fe0ff">💎 ' + esc(l) + '</div>').join('') : '').join('') : '') +
                '<div style="margin-top:8px"><button class="sbl-btn green" id="sbEq"' + (w.id === hack.equipped ? ' disabled' : '') + '>装備する</button>' +
                '<button class="sbl-btn red" id="sbSell"' + (w.id === hack.equipped || w.locked ? ' disabled' : '') + '>売却 (' + HW.sellValue(w) + ')</button>' +
                '<button class="sbl-btn gray" id="sbLock">' + (w.locked ? '🔓 ロック解除' : '🔒 ロック') + '</button></div>' +
                '<div class="sbl-note" style="font-size:.74rem;color:#8a97b8;margin-top:3px">ロックした武器は、一括売却の対象になりません。</div>' +
                (window.SBCost && hack.equipped !== w.id ? (function () { const r = SBCost.canEquip(hack, { weapon: w }); return '<div style="margin-top:6px;font-size:.8rem;color:' + (r.ok ? '#7aff9a' : '#ff9a6a') + '">⚖ 装備すると コスト ' + r.after.cost + ' / 上限 ' + r.after.cap + (r.ok ? '' : '　⚠ 装備できません') + '</div>'; })() : '') +
                (w.custom && window.SBOrigUI ? '<div style="margin-top:6px"><button class="sbl-btn orange" id="sbWork">⚒ 工房（成長・見た目・レア度アップ）</button></div>' : '') +
                (w.custom ? '<div class="sbl-sec">名前を変更（オリジナル武器は、いつでも無料で変えられます）</div><div style="display:flex;gap:4px"><input id="sbRnName" type="text" maxlength="' + HW.FORGE_NAME_MAX + '" value="' + esc(w.name) + '" style="flex:1;min-width:0;padding:5px;box-sizing:border-box"><button class="sbl-btn orange" id="sbRnGo">変更</button></div><div id="sbRnMsg" style="font-size:.8rem;color:#ff9a9a;margin-top:3px"></div>' +
                    '<div class="sbl-sec">武器種を変更（作成費用の1/4：' + HW.typeChangeCost(w).toLocaleString() + ' コイン）</div><div style="display:flex;gap:4px"><select id="sbTyType" style="flex:1;min-width:0;padding:5px">' + HW.availableTypes(hack).map(t => '<option value="' + t + '"' + (t === w.type ? ' selected' : '') + '>' + esc(HW.TYPES[t].label) + '</option>').join('') + '</select><button class="sbl-btn orange" id="sbTyGo">変更する</button></div><div id="sbTyMsg" style="font-size:.8rem;color:#ff9a9a;margin-top:3px"></div>' : '') +
                itemPanelHtml(hack, ['slot', 'rarity', 'reroll'], w, true) +
                '<div id="sbOrbPick"></div>';
            bindFxPick(wd);
            wd.querySelectorAll('[data-item]').forEach(b => b.addEventListener('click', () => {
                const k = b.dataset.item, it = HW.SPECIAL_ITEMS[k];
                let idxs;
                if (k === 'reroll') { idxs = pickedFx(wd); if (!idxs.length) { alert('引き直す効果にチェックを入れてください。'); return; } if (!confirm('「' + w.name + '」の効果のうち、選んだ ' + idxs.length + ' 個を引き直します。いまの効果は失われます。よろしいですか？')) return; }
                if (k === 'rarity') { if (w.rarity === 'legendary') { if (!confirm('「' + w.name + '」を ＋' + ((w.plus | 0) + 1) + ' に強化します（攻撃の%が少し上がります）。よろしいですか？')) return; } else if (!confirm('「' + w.name + '」のレア度を1段階上げます。よろしいですか？')) return; }
                if (applyItem(hack, k, w, true, idxs)) { HW.save(hack); refreshInvInfo(); renderList(); renderDetail(); } else alert(it.name + 'は、この武器には使えません。');
            }));
            if (w.custom) wd.querySelector('#sbTyGo').addEventListener('click', () => {
                const msg = wd.querySelector('#sbTyMsg'), nt = wd.querySelector('#sbTyType').value;
                if (!nt || !HW.TYPES[nt]) { msg.textContent = '武器種を選んでください。'; return; }
                if (nt === w.type) { msg.textContent = 'いまと同じ武器種です。'; return; }
                const cost = HW.typeChangeCost(w);
                if (coins() < cost) { msg.textContent = 'コインが足りません。'; return; }
                if (!confirm(HW.TYPES[w.type].label + ' → ' + HW.TYPES[nt].label + ' に変更します（' + cost.toLocaleString() + ' コイン）。よろしいですか？')) return;
                if (!HW.changeType(hack, w, nt)) { msg.textContent = 'この武器種には変更できません。'; return; }
                addCoins(-cost); HW.save(hack); refreshInvInfo(); renderList(); renderDetail();
            });
            if (w.custom) wd.querySelector('#sbRnGo').addEventListener('click', () => {
                const msg = wd.querySelector('#sbRnMsg'), clean = HW.cleanName(wd.querySelector('#sbRnName').value);
                if (!clean) { msg.textContent = '名前を入力してください。'; return; }
                const v = (typeof validateName === 'function') ? validateName(clean) : { valid: true };
                if (!v.valid) { msg.textContent = v.reason; return; }
                w.name = clean; w.baseName = clean; HW.save(hack); renderList(); renderDetail();
            });
            const wk = wd.querySelector('#sbWork'); if (wk) wk.addEventListener('click', () => SBOrigUI.openWorkshop(hack, w, () => { try { refreshInvInfo(); } catch (e) {} renderList(); renderDetail(); }));
            wd.querySelector('#sbLock').addEventListener('click', () => { w.locked = !w.locked; HW.save(hack); renderList(); renderDetail(); });
            wd.querySelector('#sbEq').addEventListener('click', () => { if (window.ClassSys && !ClassSys.canUseWeaponType(w.type)) { alert('この武器は、選んでいる職業では使えません。（近距離の職業は近接武器、遠距離の職業は弾・魔法の武器）'); return; } if (window.SBCost) { const r = SBCost.canEquip(hack, { weapon: w }); if (!r.ok) { alert(r.msg); return; } } hack.equipped = w.id; HW.save(hack); refreshInvInfo(); renderList(); renderDetail(); });
            wd.querySelector('#sbSell').addEventListener('click', () => {
                if (!confirm(w.name + ' を売却しますか？（はめたオーブは戻ります）')) return;
                const v = HW.sellWeapon(hack, w.id); if (v > 0) { addCoins(v); HW.save(hack); selId = hack.equipped; renderList(); renderDetail(); }
            });
            wd.querySelectorAll('.sbl-slot').forEach(s => s.addEventListener('click', () => openOrbPicker(w, parseInt(s.dataset.slot, 10))));
        }
        function openOrbPicker(w, slot) {
            const box = wd.querySelector('#sbOrbPick');
            const p = getPlayerData(); const orbs = (p && p.orbs) || [];
            let h = '<div class="sbl-sec">ソケット' + (slot + 1) + 'にはめるオーブ（所持 ' + orbs.length + '）</div>';
            if (w.orbs[slot]) h += '<button class="sbl-btn gray" id="sbUn">いまのオーブを外す</button>';
            h += orbs.map((o, i) => '<div class="sbl-orb" data-i="' + i + '">💎 ' + esc(orbLabel(o)) + '<br><small style="color:#9fe0ff">' + esc(HW.orbToEffects(o).lines.join(' / ')) + '</small></div>').join('') || '<div style="color:#889;font-size:.8rem">オーブがありません（ステージの敵・ボスや勉強で入手）</div>';
            box.innerHTML = h;
            const un = box.querySelector('#sbUn'); if (un) un.addEventListener('click', () => { HW.unsocketOrb(w, slot); HW.save(hack); renderDetail(); });
            box.querySelectorAll('.sbl-orb').forEach(el => el.addEventListener('click', () => { const o = orbs[parseInt(el.dataset.i, 10)]; if (o && HW.socketOrb(w, slot, o.id)) { HW.save(hack); renderDetail(); } }));
        }

        // ---------- 一括売却 ----------
        function openBulk() {
            const pick = { normal: true, magic: true, rare: false, epic: false, legendary: false };
            let inclSock = false, inclCustom = false;
            function draw() {
                const rarities = HW.RARITY_ORDER.filter(k => pick[k]);
                const targets = HW.bulkTargets(hack, { rarities: rarities, includeSocketed: inclSock, includeCustom: inclCustom });
                const total = targets.reduce((a, w) => a + HW.sellValue(w), 0);
                const count = k => hack.weapons.filter(w => w.rarity === k && w.id !== hack.equipped && !w.locked).length;
                wd.innerHTML = '<h3 style="margin:0">🗑 一括売却</h3><div style="font-size:.82rem;color:#9fb3d9">売りたいレア度にチェックを入れてください。装備中・ロック中の武器は売られません。</div>' +
                    '<div class="sbl-sec">売るレア度</div>' +
                    HW.RARITY_ORDER.map(k => '<label style="display:block;margin:2px 0;color:' + HW.RARITIES[k].color + '"><input type="checkbox" data-r="' + k + '"' + (pick[k] ? ' checked' : '') + '> ' + HW.RARITIES[k].label + '（' + count(k) + '本）</label>').join('') +
                    '<div class="sbl-sec">オプション</div>' +
                    '<label style="display:block;margin:2px 0"><input type="checkbox" id="sbIncSock"' + (inclSock ? ' checked' : '') + '> オーブをはめた武器も売る（オーブは戻ります）</label>' +
                    '<label style="display:block;margin:2px 0"><input type="checkbox" id="sbIncCustom"' + (inclCustom ? ' checked' : '') + '> オリジナル武器も売る</label>' +
                    '<div style="margin:10px 0;font-size:1rem"><b>' + targets.length + '本</b> を売却 → <b style="color:#ffd84a">' + total + ' コイン</b></div>' +
                    '<button class="sbl-btn red" id="sbBulkGo"' + (targets.length ? '' : ' disabled') + '>売却する</button><button class="sbl-btn gray" id="sbBulkCancel">やめる</button>';
                wd.querySelectorAll('[data-r]').forEach(c => c.addEventListener('change', () => { pick[c.dataset.r] = c.checked; draw(); }));
                wd.querySelector('#sbIncSock').addEventListener('change', e => { inclSock = e.target.checked; draw(); });
                wd.querySelector('#sbIncCustom').addEventListener('change', e => { inclCustom = e.target.checked; draw(); });
                wd.querySelector('#sbBulkCancel').addEventListener('click', () => renderDetail());
                wd.querySelector('#sbBulkGo').addEventListener('click', () => {
                    const hi = targets.filter(w => w.rarity === 'epic' || w.rarity === 'legendary').length;
                    if (!confirm(targets.length + '本を売却して ' + total + ' コインを得ます。' + (hi ? '\n※エピック／レジェンドが ' + hi + '本 含まれています！' : '') + '\nよろしいですか？')) return;
                    const r = HW.bulkSell(hack, { rarities: rarities, includeSocketed: inclSock, includeCustom: inclCustom });
                    addCoins(r.coins); HW.save(hack); selId = hack.equipped;
                    renderList(); renderDetail();
                });
            }
            draw();
        }

        // ---------- オリジナル武器（コイン鍛冶）----------
        function openForge() {
            const types = HW.availableTypes(hack);
            let type = types.indexOf('sword') >= 0 ? 'sword' : types[0], rarity = 'normal', name = '', els = [];
            function draw() {
                const have = coins();
                const rars = HW.RARITY_ORDER.map(k => { const R = HW.RARITIES[k]; const c = HW.forgeCost(k, els.length); return { k: k, R: R, c: c, ok: have >= c }; });
                wd.innerHTML = '<h3 style="margin:0">🔨 オリジナル武器を作る</h3>' +
                    '<div style="font-size:.82rem;color:#9fb3d9">コインを多く使うほどレア度が上がります。名前は自由に決められます。攻撃力の上昇％はレア度で決まり、特殊効果とソケットはランダムです。</div>' +
                    '<div class="sbl-sec">所持コイン：' + have.toLocaleString() + '</div>' +
                    '<div class="sbl-sec">武器の種類</div><select id="sbFgType" style="padding:4px;max-width:100%">' + types.map(t => '<option value="' + t + '"' + (t === type ? ' selected' : '') + '>' + esc(HW.TYPES[t].label) + '</option>').join('') + '</select>' +
                    '<div class="sbl-sec">名前（' + HW.FORGE_NAME_MAX + '文字まで）</div><input id="sbFgName" type="text" maxlength="' + HW.FORGE_NAME_MAX + '" placeholder="例：勇者の剣" value="' + esc(name) + '" style="width:100%;box-sizing:border-box;padding:6px;border-radius:6px;border:1px solid #445;background:#0f1530;color:#fff">' +
                    '<div class="sbl-sec">属性（任意・最大2つ。1つで+25%、2つで+70%のコイン）</div><div id="sbFgEl" style="display:flex;flex-wrap:wrap;gap:4px">' + (window.SBElem ? SBElem.ORDER.map(id => { const m = SBElem.ELEMS[id], on = els.indexOf(id) >= 0; return '<button type="button" data-el="' + id + '" style="padding:3px 7px;border-radius:12px;border:1px solid ' + (on ? m.color : '#3a4670') + ';background:' + (on ? '#26335f' : '#171f3e') + ';color:' + m.color + ';font-size:.78rem;cursor:pointer">' + m.icon + m.name + '</button>'; }).join('') : '') + '</div>' + (els.length && window.SBElem ? '<div style="font-size:.76rem;margin-top:3px">' + SBElem.styleHtml(els) + '</div>' : '') +
                    '<div class="sbl-sec">レア度（使うコイン）</div>' +
                    rars.map(r => '<label style="display:block;margin:3px 0;padding:4px 6px;border-radius:6px;background:' + (r.k === rarity ? '#26335f' : '#171f3e') + ';opacity:' + (r.ok ? 1 : .5) + ';color:' + r.R.color + '"><input type="radio" name="sbFgR" value="' + r.k + '"' + (r.k === rarity ? ' checked' : '') + (r.ok ? '' : ' disabled') + '> ' + r.R.label + '　<b>' + r.c.toLocaleString() + ' コイン</b>　<small style="color:#9fb3d9">攻撃力 約＋' + Math.round(r.R.orig * 100) + '%・ソケット' + r.R.sockets[0] + '〜' + r.R.sockets[1] + '・効果' + r.R.fx[0] + '〜' + r.R.fx[1] + '</small></label>').join('') +
                    '<div style="margin-top:8px"><button class="sbl-btn orange" id="sbFgGo">' + HW.RARITIES[rarity].label + 'で作る（' + HW.forgeCost(rarity, els.length).toLocaleString() + ' コイン）</button><button class="sbl-btn gray" id="sbFgCancel">やめる</button></div>' +
                    '<div id="sbFgMsg" style="font-size:.82rem;color:#ff9a9a;margin-top:4px"></div>';
                wd.querySelector('#sbFgType').addEventListener('change', e => { type = e.target.value; name = wd.querySelector('#sbFgName').value; draw(); });
                wd.querySelector('#sbFgName').addEventListener('input', e => { name = e.target.value; });
                wd.querySelectorAll('[name=sbFgR]').forEach(r => r.addEventListener('change', () => { name = wd.querySelector('#sbFgName').value; rarity = r.value; draw(); }));
                wd.querySelectorAll('#sbFgEl [data-el]').forEach(b => b.addEventListener('click', () => {
                    name = wd.querySelector('#sbFgName').value; const id = b.dataset.el, i = els.indexOf(id);
                    if (i >= 0) els.splice(i, 1); else if (els.length < 2) els.push(id); else { els.shift(); els.push(id); }
                    draw();
                }));
                wd.querySelector('#sbFgCancel').addEventListener('click', () => renderDetail());
                wd.querySelector('#sbFgGo').addEventListener('click', () => {
                    const msg = wd.querySelector('#sbFgMsg'); name = wd.querySelector('#sbFgName').value;
                    const clean = HW.cleanName(name);
                    if (clean) { const v = (typeof validateName === 'function') ? validateName(clean) : { valid: true }; if (!v.valid) { msg.textContent = v.reason; return; } }
                    const cost = HW.forgeCost(rarity, els.length);
                    if (coins() < cost) { msg.textContent = 'コインが足りません。'; return; }
                    if (hack.weapons.length >= HW.STORAGE_LIMIT) { msg.textContent = '武器庫がいっぱいです。不要な武器を売却してください。'; return; }
                    if (!confirm((clean || 'オリジナル' + HW.TYPES[type].label) + '（' + HW.RARITIES[rarity].label + (els.length && window.SBElem ? '・' + SBElem.labels(els) : '') + '）を ' + cost.toLocaleString() + ' コインで作ります。よろしいですか？')) return;
                    const w = HW.forgeOriginal(hack, { type: type, rarity: rarity, name: clean, elems: els.slice() });
                    if (!w) { msg.textContent = 'この武器種は、まだ作れません。'; return; }
                    addCoins(-cost);
                    hack.weapons.push(w); HW.save(hack); selId = w.id;
                    renderList(); renderDetail();
                });
            }
            draw();
        }
        renderList(); renderDetail();
    }

    // ---------- 第二世界の解放通知（町に戻ったとき1回だけ）----------
    // ============================================================
    // アクセサリー（装備すると、特殊なスキルが自動で使えるようになる。ステータスは上がらない）
    // ============================================================
    function openAccessory() {
        if (!window.HW || !window.SBAcc) return;
        const hack = HW.load(); SBAcc.ensure(hack);
        let selId = null;
        const m = modal('✨ アクセサリー（装備するとスキルが使える）', () => { try { refreshInvInfo(); if (typeof updateStatus === 'function') updateStatus(getPlayerData()); } catch (e) {} });
        m.body.innerHTML = '<div class="sbl-col sbl-left" id="acL"></div><div class="sbl-col sbl-right" id="acR"></div>';
        const L = m.body.querySelector('#acL'), R = m.body.querySelector('#acR');
        const addCoins = v => { const p = getPlayerData(); if (!p) return; p.coins = (p.coins || 0) + v; localStorage.setItem('player', JSON.stringify(p)); };
        const isEq = a => hack.accEq.indexOf(a.id) >= 0;
        function renderList() {
            const eq = SBAcc.equippedList(hack);
            const arr = hack.accs.slice().sort((a, b) => HW.RARITY_ORDER.indexOf(b.rarity) - HW.RARITY_ORDER.indexOf(a.rarity) || b.ilvl - a.ilvl);
            L.innerHTML = '<div class="sbl-sec">装備中（' + SBAcc.SLOTS + '枠）</div>' +
                eq.map((a, i) => '<div style="font-size:.82rem;padding:3px 0">' + (i + 1) + '. ' + (a ? '<span style="color:' + HW.rarityOf(a).color + '">' + SBAcc.baseOf(a).icon + ' ' + esc(a.name) + '</span> <button class="sbl-btn gray" data-off="' + a.id + '" style="padding:1px 6px;font-size:.7rem;margin:0">はずす</button>' : '<span style="color:#778">（空き）</span>') + '</div>').join('') +
                '<div class="sbl-sec">所持アクセサリー ' + hack.accs.length + ' 個 <button class="sbl-btn gray" id="acBulk" style="padding:3px 8px;font-size:.75rem;margin-left:6px">🗑 一括売却</button></div>' +
                (arr.length ? arr.map(a => '<div class="sbl-wl' + (a.id === selId ? ' sel' : '') + (isEq(a) ? ' eq' : '') + '" data-id="' + a.id + '"><span style="color:' + HW.rarityOf(a).color + '">' + (isEq(a) ? '【装備中】' : '') + SBAcc.baseOf(a).icon + ' ' + esc(a.name) + '</span><span style="font-size:.72rem;color:#9fb3d9">Lv' + a.ilvl + (a.locked ? ' 🔒' : '') + '</span></div>').join('') : '<div style="color:#889;font-size:.85rem;padding:6px 0">まだアクセサリーを持っていません。ボスを倒す・ボスラッシュ・無限回廊の宝箱で手に入ります。</div>');
            L.querySelectorAll('[data-off]').forEach(b => b.addEventListener('click', () => { SBAcc.unequip(hack, b.dataset.off); HW.save(hack); renderList(); renderDetail(); }));
            L.querySelector('#acBulk').addEventListener('click', bulk);
            L.querySelectorAll('.sbl-wl').forEach(r => r.addEventListener('click', () => { selId = r.dataset.id; renderList(); renderDetail(); }));
        }
        function renderDetail() {
            const a = hack.accs.find(x => x.id === selId);
            if (!a) { R.innerHTML = '<div class="sbl-sec">アクセサリーとは</div><div class="sbl-fx">◆ 装備しても、ステータスは上がりません</div><div class="sbl-fx">◆ かわりに、特殊なスキルが<b>自動で</b>発動します（範囲攻撃が中心）</div><div class="sbl-fx">◆ 3つまで同時に装備できます。発動条件が違うものを組み合わせると強力です</div><div class="sbl-fx">◆ 対人戦では使えません</div><div style="color:#889;margin-top:8px">左のリストから選んでください</div>'; return; }
            const Rr = HW.rarityOf(a), b = SBAcc.baseOf(a);
            R.innerHTML = '<h3 style="margin:0;color:' + Rr.color + '">' + b.icon + ' ' + esc(a.name) + '</h3>' +
                '<div style="font-size:.82rem;color:#9fb3d9">[' + Rr.label + ']　Lv' + a.ilvl + '</div>' +
                '<div class="sbl-sec">スキル</div>' + SBAcc.describe(a).map(l => '<div class="sbl-fx">◆ ' + esc(l) + '</div>').join('') +
                '<div style="margin-top:8px"><button class="sbl-btn green" id="acEq"' + (!isEq(a) && hack.accEq.indexOf(null) < 0 ? ' disabled' : '') + '>' + (isEq(a) ? '外す' : (hack.accEq.indexOf(null) < 0 ? '装備枠がいっぱい' : '装備する')) + '</button>' +
                '<button class="sbl-btn red" id="acSell"' + (isEq(a) || a.locked ? ' disabled' : '') + '>売却 (' + SBAcc.sellValue(a) + ')</button>' +
                '<button class="sbl-btn gray" id="acLock">' + (a.locked ? '🔓 ロック解除' : '🔒 ロック') + '</button></div>';
            R.querySelector('#acEq').addEventListener('click', () => { if (isEq(a)) SBAcc.unequip(hack, a.id); else SBAcc.equip(hack, a.id); HW.save(hack); renderList(); renderDetail(); });
            R.querySelector('#acLock').addEventListener('click', () => { a.locked = !a.locked; HW.save(hack); renderList(); renderDetail(); });
            R.querySelector('#acSell').addEventListener('click', () => { if (!confirm(a.name + ' を売却しますか？')) return; const v = SBAcc.sell(hack, a.id); if (v > 0) { addCoins(v); HW.save(hack); selId = null; renderList(); renderDetail(); } });
        }
        function bulk() {   // ノーマル・マジックで、ロックも装備もしていないものをまとめて売る
            const t = hack.accs.filter(a => (a.rarity === 'normal' || a.rarity === 'magic') && !a.locked && !isEq(a));
            if (!t.length) { alert('売却できるアクセサリー（ノーマル・マジックで、ロック・装備していないもの）がありません。'); return; }
            const total = t.reduce((n, a) => n + SBAcc.sellValue(a), 0);
            if (!confirm('ノーマル・マジックのアクセサリー ' + t.length + ' 個を売却します（+' + total + ' コイン）。よろしいですか？')) return;
            t.forEach(a => SBAcc.sell(hack, a.id)); addCoins(total); HW.save(hack); selId = null; renderList(); renderDetail();
        }
        renderList(); renderDetail();
    }

    // ============================================================
    // 防具（頭・胴・脚）
    // ============================================================
    function openArmor() {
        if (!window.HW || !window.SBArmor) return;
        const hack = HW.load(); SBArmor.ensure(hack);
        let selId = null, slotF = 'all';
        const m = modal('🛡 防具（頭・胴・脚）', () => { try { refreshInvInfo(); if (typeof updateStatus === 'function') updateStatus(getPlayerData()); } catch (e) {} });
        m.body.innerHTML = '<div class="sbl-col sbl-left" id="arL"></div><div class="sbl-col sbl-right" id="arR"></div>';
        const L = m.body.querySelector('#arL'), R = m.body.querySelector('#arR');
        const addCoins = v => { const p = getPlayerData(); if (!p) return; p.coins = (p.coins || 0) + v; localStorage.setItem('player', JSON.stringify(p)); };
        const eqId = a => hack.armorEq[a.slot] === a.id;
        function renderList() {
            const eq = SBArmor.equipped(hack);
            const arr = hack.armors.filter(a => slotF === 'all' || a.slot === slotF).sort((a, b) => HW.RARITY_ORDER.indexOf(b.rarity) - HW.RARITY_ORDER.indexOf(a.rarity) || b.ilvl - a.ilvl);
            L.innerHTML = '<div class="sbl-sec">装備中</div>' + SBArmor.SLOT_ORDER.map(sl => { const a = eq[sl]; return '<div style="font-size:.8rem;padding:2px 0">' + SBArmor.SLOTS[sl].icon + ' ' + SBArmor.SLOTS[sl].label + '：' + (a ? '<span style="color:' + HW.rarityOf(a).color + '">' + esc(a.name) + '</span>' : '<span style="color:#778">なし</span>') + '</div>'; }).join('') +
                '<div class="sbl-sec">所持防具 ' + hack.armors.length + ' 個 <button class="sbl-btn gray" id="arBulk" style="padding:3px 8px;font-size:.75rem;margin-left:6px">🗑 一括売却</button></div>' +
                '<select id="arF" style="margin-bottom:6px;padding:4px"><option value="all">すべて</option>' + SBArmor.SLOT_ORDER.map(sl => '<option value="' + sl + '"' + (slotF === sl ? ' selected' : '') + '>' + SBArmor.SLOTS[sl].label + '</option>').join('') + '</select>' +
                (arr.length ? arr.map(a => '<div class="sbl-wl' + (a.id === selId ? ' sel' : '') + (eqId(a) ? ' eq' : '') + '" data-id="' + a.id + '"><span style="color:' + HW.rarityOf(a).color + '">' + (eqId(a) ? '【装備中】' : '') + SBArmor.SLOTS[a.slot].icon + ' ' + esc(a.name) + '</span><span style="color:#9fb3d9">Lv' + a.ilvl + (a.locked ? ' 🔒' : '') + '</span></div>').join('') : '<div style="color:#889;font-size:.8rem">防具はステージの敵・ボスがドロップします</div>');
            L.querySelector('#arF').addEventListener('change', e => { slotF = e.target.value; renderList(); });
            L.querySelector('#arBulk').addEventListener('click', openArmorBulk);
            L.querySelectorAll('.sbl-wl').forEach(r => r.addEventListener('click', () => { selId = r.dataset.id; renderList(); renderDetail(); }));
        }
        function renderDetail() {
            const a = hack.armors.find(x => x.id === selId);
            if (!a) { const t = SBArmor.summaryLines(hack); R.innerHTML = '<div class="sbl-sec">装備による効果の合計</div>' + (t.length ? t.map(l => '<div class="sbl-fx">◆ ' + esc(l) + '</div>').join('') : '<div style="color:#889">防具を選んでください</div>'); return; }
            const Rr = HW.rarityOf(a);
            R.innerHTML = '<h3 style="margin:0;color:' + Rr.color + '">' + esc(a.name) + '</h3>' +
                '<div style="font-size:.82rem;color:#9fb3d9">[' + Rr.label + '] ' + SBArmor.SLOTS[a.slot].label + '　Lv' + a.ilvl + '</div>' +
                '<div class="sbl-sec">基本性能</div>' + SBArmor.statLines(a).filter(Boolean).map(l => '<div class="sbl-fx">◆ ' + esc(l) + '</div>').join('') +
                '<div class="sbl-sec">特殊効果</div>' + (a.effects.length ? a.effects.map(f => '<div class="sbl-fx">◆ ' + esc(SBArmor.describeEffect(f)) + '</div>').join('') : '<div class="sbl-fx" style="color:#778">なし</div>') +
                itemPanelHtml(hack, ['reroll'], a, false) +
                '<div style="margin-top:8px"><button class="sbl-btn green" id="arEq">' + (eqId(a) ? '外す' : '装備する') + '</button>' +
                '<button class="sbl-btn red" id="arSell"' + (eqId(a) || a.locked ? ' disabled' : '') + '>売却 (' + SBArmor.sellValue(a) + ')</button>' +
                '<button class="sbl-btn gray" id="arLock">' + (a.locked ? '🔓 ロック解除' : '🔒 ロック') + '</button></div>';
            bindFxPick(R);
            R.querySelectorAll('[data-item]').forEach(b => b.addEventListener('click', () => {
                const idxs = pickedFx(R); if (!idxs.length) { alert('引き直す効果にチェックを入れてください。'); return; }
                if (!confirm('「' + a.name + '」の効果のうち、選んだ ' + idxs.length + ' 個を引き直します。いまの効果は失われます。よろしいですか？')) return;
                if (applyItem(hack, 'reroll', a, false, idxs)) { HW.save(hack); renderList(); renderDetail(); } else alert('この防具には使えません。');
            }));
            R.querySelector('#arEq').addEventListener('click', () => { if (eqId(a)) SBArmor.unequip(hack, a.slot); else { if (window.SBCost) { const r = SBCost.canEquip(hack, { armor: a }); if (!r.ok) { alert(r.msg); return; } } SBArmor.equip(hack, a.id); } HW.save(hack); renderList(); renderDetail(); });
            R.querySelector('#arLock').addEventListener('click', () => { a.locked = !a.locked; HW.save(hack); renderList(); renderDetail(); });
            R.querySelector('#arSell').addEventListener('click', () => {
                if (!confirm(a.name + ' を売却しますか？')) return;
                const v = SBArmor.sell(hack, a.id); if (v > 0) { addCoins(v); HW.save(hack); selId = null; renderList(); renderDetail(); }
            });
        }
        // ---------- 防具の一括売却 ----------
        function openArmorBulk() {
            const pick = { normal: true, magic: true, rare: false, epic: false, legendary: false };
            const slotPick = { head: true, body: true, legs: true };
            function draw() {
                const o = { rarities: HW.RARITY_ORDER.filter(k => pick[k]), slots: SBArmor.SLOT_ORDER.filter(s => slotPick[s]) };
                const targets = SBArmor.bulkTargets(hack, o), total = targets.reduce((a, x) => a + SBArmor.sellValue(x), 0);
                const count = k => hack.armors.filter(a => a.rarity === k && slotPick[a.slot] && !a.locked && hack.armorEq[a.slot] !== a.id).length;
                R.innerHTML = '<h3 style="margin:0">🗑 防具の一括売却</h3><div style="font-size:.82rem;color:#9fb3d9">売りたいレア度と部位にチェックを入れてください。装備中・ロック中の防具は売られません。</div>' +
                    '<div class="sbl-sec">売るレア度</div>' + HW.RARITY_ORDER.map(k => '<label style="display:block;margin:2px 0;color:' + HW.RARITIES[k].color + '"><input type="checkbox" data-r="' + k + '"' + (pick[k] ? ' checked' : '') + '> ' + HW.RARITIES[k].label + '（' + count(k) + '個）</label>').join('') +
                    '<div class="sbl-sec">売る部位</div>' + SBArmor.SLOT_ORDER.map(s => '<label style="margin-right:10px"><input type="checkbox" data-s="' + s + '"' + (slotPick[s] ? ' checked' : '') + '> ' + SBArmor.SLOTS[s].icon + SBArmor.SLOTS[s].label + '</label>').join('') +
                    '<div style="margin:10px 0;font-size:1rem"><b>' + targets.length + '個</b> を売却 → <b style="color:#ffd84a">' + total + ' コイン</b></div>' +
                    '<button class="sbl-btn red" id="arBulkGo"' + (targets.length ? '' : ' disabled') + '>売却する</button><button class="sbl-btn gray" id="arBulkCancel">やめる</button>';
                R.querySelectorAll('[data-r]').forEach(c => c.addEventListener('change', () => { pick[c.dataset.r] = c.checked; draw(); }));
                R.querySelectorAll('[data-s]').forEach(c => c.addEventListener('change', () => { slotPick[c.dataset.s] = c.checked; draw(); }));
                R.querySelector('#arBulkCancel').addEventListener('click', () => renderDetail());
                R.querySelector('#arBulkGo').addEventListener('click', () => {
                    const hi = targets.filter(x => x.rarity === 'epic' || x.rarity === 'legendary').length;
                    if (!confirm(targets.length + '個を売却して ' + total + ' コインを得ます。' + (hi ? '\n※エピック／レジェンドが ' + hi + '個 含まれています！' : '') + '\nよろしいですか？')) return;
                    const r = SBArmor.bulkSell(hack, o);
                    addCoins(r.coins); HW.save(hack); selId = null; renderList(); renderDetail();
                });
            }
            draw();
        }
        renderList(); renderDetail();
    }

    function checkWorldNotice() {
        try {
            if (!window.HW) return;
            const h = HW.load();
            const wn = h.worldNotice;
            if (!wn || !wn.t) return;
            h.worldNotice = null; HW.save(h);
            const n = document.createElement('div');
            n.style.cssText = 'position:fixed;top:18%;left:50%;transform:translateX(-50%);z-index:100002;background:rgba(40,16,80,.92);color:#f0e0ff;border:2px solid #ffc84a;border-radius:12px;padding:12px 20px;font-weight:bold;text-align:center;max-width:90vw;box-shadow:0 0 24px rgba(255,200,74,.55);transition:opacity 1s;opacity:0';
            const t = document.createElement('div'); t.textContent = '🚪 ' + wn.t;
            const sub = document.createElement('div'); sub.style.cssText = 'font-size:.85em;font-weight:normal;margin-top:4px'; sub.textContent = wn.s || '';
            n.appendChild(t); n.appendChild(sub);
            document.body.appendChild(n);
            setTimeout(() => { n.style.opacity = '1'; }, 800);
            setTimeout(() => { n.style.opacity = '0'; }, 7500);
            setTimeout(() => { n.remove(); }, 8600);
        } catch (e) { /* 通知は無くても進行に影響しない */ }
    }

    // ---------- インベントリ画面（旧ショップ画面）からの導線 ----------
    function refreshInvInfo() {
        const el = document.getElementById('invEquipped');
        if (!el || !window.HW) return;
        const w = HW.getEquipped(HW.load());
        if (w) { el.textContent = w.name + '（' + HW.rarityOf(w).label + '・攻撃' + HW.pctLabel(w) + '）'; el.style.color = HW.rarityOf(w).color; }
    }
    function bindInventory() {
        const a = document.getElementById('openArmoryFromInv'), g = document.getElementById('openStageGateFromInv');
        if (a) a.addEventListener('click', openArmory);
        if (g) g.addEventListener('click', openStageGate);
        const sec = document.getElementById('section-shop');
        if (sec && window.MutationObserver) new MutationObserver(refreshInvInfo).observe(sec, { attributes: true, attributeFilter: ['class'] });
        refreshInvInfo();
        checkWorldNotice();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bindInventory); else bindInventory();

    window.openStageGate = openStageGate;
    window.openArmory = openArmory;
})();
