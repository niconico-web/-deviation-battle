// ============================================================
// ステージ・エンジン (stage.js)
//  ・町(ロビー)から飛んできて「ダンジョン1つ＋ボス1体」を約5分で攻略する
//  ・敵に触れても画面遷移はしない。フィールド上でそのまま攻撃して戦う
//  ・最大4人の協力プレイ（ホストが敵を動かし、他の人は同期された状態を見る）
//  ・装備は hw-weapons.js のハクスラ武器（オーブをはめ込んで強化）
//  ・クイズに正解するとエネルギーが溜まり、Qキーでバースト（全周囲攻撃＋回復）
// ============================================================
(function () {
    'use strict';

    // 画面の向き：スマホは横画面で遊ぶ（縦のときは「横にしてね」案内を出して一時停止する）
    if (window.SBOrientation) SBOrientation.guard();

    // ---------- 起動パラメータ ----------
    let launch = null;
    try { launch = JSON.parse(localStorage.getItem('sbStageLaunch') || 'null'); } catch (e) { launch = null; }
    const stage = launch && window.getStageById ? window.getStageById(launch.stageId) : null;
    try { localStorage.removeItem('studyTimerState'); } catch (e) {}   // ステージに入ったら勉強タイマーは0に戻る（保険）
    const pdata = (typeof getPlayerData === 'function') ? getPlayerData() : null;
    if (!stage || !pdata) {
        alert('ステージ情報かキャラクターデータが見つかりません。町に戻ります。');
        location.href = 'index.html';
        return;
    }
    const hack = HW.load();
    const weapon = HW.getEquipped(hack);
    const MYPC = (weapon && weapon.pix && window.SBPix && SBPix.prepCustom) ? SBPix.prepCustom(HW.cleanPix(weapon.pix)) : null;      // 自分で描いた武器のドット絵
    const MYATK = (weapon && weapon.custom && weapon.rarity === 'mythic' && HW.cleanMotion) ? ((HW.cleanMotion(weapon.motion) || {}).atk || null) : null;      // 配置で作った通常攻撃
    const MY_TEXRAW = (MYATK && MYATK.tex && MYATK.tex.some(Boolean)) ? MYATK.tex : null;      // 自分で描いた弾の絵（味方にも送る）
    const MY_TEX = (MYATK && window.SBPix && SBPix.prepTex) ? (MYATK.tex || []).map(t => t ? SBPix.prepTex(HW.cleanPix(t)) : null) : [];
    let MYPC_SENT = null;      // 味方へ最後に全部送った絵の目印（絵が大きいので、変わったときと、ときどきだけ全部送る）
    const FXCOL = (weapon && weapon.fxColor && HW.cleanColor(weapon.fxColor)) || null;                                              // 自分で決めた攻撃エフェクトの色
    const agg = HW.aggregate(weapon);
    try { if (window.SBArmor) SBArmor.merge(agg, hack); } catch (e) { /* 防具が読めなくても戦える */ }
    // コスト制度：装備とスキルのコストが、ステータス合計で決まる上限を超えていたら、武器・防具の効果とスキルの威力をまとめて弱める（cost.js）
    const COSTCHK = window.SBCost ? (function () { try { return SBCost.breakdown(hack, SBCost.totalOf(pdata)); } catch (e) { return null; } })() : null;
    if (COSTCHK && COSTCHK.over) SBCost.scaleAgg(agg, COSTCHK.ratio);
    try { if (window.ClassSys) ClassSys.mergeInto(agg); } catch (e) { /* 職業の強化が読めなくても戦える */ }
    const A = k => agg.stats[k] || 0;
    const AB = k => !!(agg.flags && agg.flags[k]);     // Tier4オーブの固有能力のうち、特別な処理が要るもの（hw-weapons.js の ORB_ABILITY_MAP）
    const T = HW.TYPES[weapon.type] || HW.TYPES.sword;

    // ---------- 定数 ----------
    const PVP = !!stage.pvp;                                  // オンラインマッチ（アクション対戦）
    const DBG = (launch && launch.debug && typeof launch.debug === 'object') ? launch.debug : null;   // デバッグ戦闘（debug.js）：報酬・クリア記録なし。god=無敵 / energy=エネルギー無限 / hp=ボスHP倍率 / cores=核の数
    const RUSH_ON = !!stage.rush;                              // ボスラッシュ（フェーズ制のボス連戦）
    const CORR_ON = !!stage.corridor;                          // 無限回廊（迷路のダンジョン）
    const AMB_ON = !!stage.ambush;                             // 襲撃ステージ（クリア後に30分だけ出現する、ニンゲンの襲撃）
    const RAID = !!stage.raid;                                 // 大討伐戦（最大20人のレイド）
    // 大討伐戦のボスの強さ：無限回廊の「不壊の悪魔」と同じ式（パーティの平均ステータス合計 × 階層の倍率 × ボスの倍率1.9 × 1.35）の、RAID_MUL 倍。
    //  ・不壊の悪魔が出るのは地下40階あたりから（RAID_REF_FLOOR）。ステージ側の stage.raidMul で、ボスごとに倍率を変えられる（この世界の最強種たちを、順に強くしていける）
    //  ・不壊の悪魔は5つのステータスをランダムに割り振るが、大討伐戦のボスは毎回同じ（割り振りは全部1.0）。人数が多いほどHPが増える（partyScale）
    const RAID_MUL = 5, RAID_REF_FLOOR = 40, RAID_TIME_MIN = 30;
    const TEAM = stage.pvpTeam || 0;                          // チーム戦（2v2 / 3v3）なら1チームの人数。0＝乱戦
    let teamMap = {};                                         // 選手ID → チーム(0=青 / 1=赤)。出発の瞬間に、部屋の参加順で交互に決める
    const sameTeam = (id) => !!TEAM && teamMap[id] !== undefined && teamMap[id] === teamMap[myId];
    let WORLD_W = PVP ? 1500 : (RAID ? (stage.id === 'raid_worm' ? 4000 : 2800) : (RUSH_ON ? 1700 : 2400)), WORLD_H = PVP ? 1000 : (RAID ? 1800 : (RUSH_ON ? 1100 : 1600));   // ボスラッシュは弾幕が避けやすい広さに。無限回廊は階層ごとに変わる
    const MAX_PARTY = 4;
    const TIME_LIMIT = PVP ? 180 : (RAID ? RAID_TIME_MIN * 60 : (CORR_ON ? Infinity : (RUSH_ON ? 99 * 60 : (AMB_ON ? 14 * 60 : (stage.standardOnly ? 25 * 60 : 9 * 60)))));   // 大討伐戦は RAID_TIME_MIN 分。ボスラッシュは全体ではなく「1フェーズごと」の制限時間（難易度で決まる）。無限回廊は無制限   // 時間切れ（スタンダードワールドは長丁場）
    const KILLS_BASE = 75;               // ボス出現に必要な討伐数（1人）。敵が弱く数が多いぶん、以前（45）より多め
    const ENEMY_CAP_BASE = 50;           // 同時に出る敵の数の上限（以前は30）
    const MOB_HP_MUL = 0.6, MOB_DMG_MUL = 0.85, MOB_GROUP_MUL = 1.5;   // 雑魚の体力・攻撃は下げ、1グループの数を増やす（爽快感のため。精鋭とボスは変えない）
    // 通常攻撃もエネルギーを使う：1秒ぶん連打したときの消費量（武器の攻撃間隔に比例。重い武器ほど1振りが高い）
    const ATK_ENERGY_PER_SEC = 4;
    // 溜め（詠唱）：この形のスキルは、ボタンを押してから発動までこの秒数のあいだ動けない（攻撃・ダッシュ・ほかのスキルもできない）。スタンされると中断
    const CHARGE_SEC = { laser: 0.8, barrage: 1.2, domain: 1.5, summon: 1.2 };
    const CHARGE_NAME = { laser: 'レーザー', barrage: '包囲弾幕', domain: '結界（領域）', summon: 'ミニオン召喚' };
    // 守りの溜め：ボタンを押し続けて GUARD_CHARGE 秒溜めると、GUARD_SEC 秒のあいだ相手の攻撃を完全に防ぐバリアが張れる（そのあいだ動ける）。使ったあとは GUARD_CD 秒使えない
    const GUARD_CHARGE = 3, GUARD_SEC = 3, GUARD_CD = 15;
// ジャストパリィ：敵の攻撃が当たる直前（PARRY_WINDOW秒以内）にバリアボタンを押す（長押しでなく、ポンと押す）と、受けるダメージが1になる。押したあと PARRY_CD 秒は次のパリィが効かない（連打でごまかせない）
const PARRY_WINDOW = 0.22, PARRY_CD = 1.0;
    const START_ENERGY = 40;       // 開始時のエネルギー（0だと最初の攻撃ができないため）
    let ENERGY_MAX = 100;          // 特殊ステータスで上限が増える（下の P を作った直後に決める）
    // 状態は受信側で補間するため、毎秒12回で十分な滑らかさを保てる。
    // 送信量を抑えて、操作やPing応答が状態同期の待ち行列に埋もれるのを防ぐ。
    const SNAP_HZ = 12;
    // ボスの技（boss-moves.js）とスタン
    const BM = window.BOSS_MOVES || null;
    const STUN_SEC = (BM && BM.STUN_SECONDS) || 3.0;     // スタンの長さ（動けない・攻撃も回避もできない）
    const STUN_IMM = (BM && BM.STUN_IMMUNE) || 3.5;      // スタンから復帰したあとの耐性時間（連続スタン防止）
    const PVP_STUN_MAX = 0.6;                            // 対人戦：プレイヤーへのスタンの長さの上限（秒）。ステージ（最終問題）では STUN_SEC のまま
    const PVP_STUN_IMM = 1.2;                            // 対人戦：スタンから復帰したあとの耐性時間（秒）
    let PW = stage.power || { hp: 1, dmg: 1, spd: 1 };  // 第二世界など、ステージごとの敵の強化倍率

    // ---------- 乱数・ユーティリティ ----------
    const rnd = (a, b) => a + Math.random() * (b - a);
    const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
    const dist = (a, b, c, d) => Math.hypot(a - c, b - d);
    function seeded(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
    function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

    // ---------- 難易度 ----------
    const CORR_DIFF = { name: '無限回廊', hp: 1.0, dmg: 1.0, spd: 1.0, elite: 0.22, luck: 0.9, healRed: 0 };
    const DIFFS = RUSH_ON ? window.STAGE_DATA.RUSH_DIFFS : (CORR_ON ? [CORR_DIFF] : window.STAGE_DATA.DIFFS);
    let DIFF = DIFFS[Math.max(0, Math.min(DIFFS.length - 1, parseInt(launch.diff, 10) || 0))];

    // ---------- プレイヤーの戦闘ステータス ----------
    let base = { maxHp: 50, atk: 70, def: 50, speed: 30, special: 50 };
    try { const s = getStatsFromPlayer(pdata, true); if (s) base = Object.assign(base, s); } catch (e) { /* 既定値のまま */ }
    const P = {
        maxHp: Math.max(10, Math.round((100 + base.maxHp * 2) * Math.max(0.2, 1 + A('hpPct')) * (A('hpHalf') > 0 ? 0.5 : 1))),      // 脆き砲台：最大HPの上限が50%で固定
        atkMul: (0.6 + base.atk / 150) * Math.max(0.2, 1 + A('atkPct')),
        def: base.def * (1 + A('defPct')),
        move: 235 * (1 + Math.min(base.speed, 300) / 700) * Math.max(0.35, 1 + A('moveSpd')),
        special: base.special,
        cd: T.cd / Math.max(0.3, 1 + A('aspd')),
        range: (T.range || 0) * (1 + A('rangePct')),
        radius: (T.radius || 0) * (1 + A('rangePct')),
        crit: 0.05 + A('critRate') + (T.crit || 0),
        critMul: 1.5 + A('critDmg'),
        dashCd: 1.6 * (1 - Math.min(0.6, A('dashCdr'))),
        energyMul: Math.max(0.2, 1 + A('energyUp'))
    };
    // スキルの与ダメージにかかる倍率（スキルは火力ではなく特殊な攻撃手段。特殊ステータスは以前の1/3の効き方。定義は action-skills.js の skillDamageMul / skillPowerFor）
    function SKILL_MUL() { return (window.ActionSkills && ActionSkills.skillDamageMul) ? ActionSkills.skillDamageMul(A('skillPct')) * ActionSkills.skillPowerFor(P.special) : 0.45 * (1 + P.special / 900); }
    // 状況で変わる攻撃力の倍率：狂戦士（HPが半分を超えると-25%／以下で+）・孤高（仲間がいると-30%／ソロで+）
    function atkDyn() {
        let m = 1; const b = A('berserk'), lw = A('loneWolf');
        if (b > 0) m *= (me.hp / me.maxHp <= 0.5 ? 1 + b : 0.75);
        if (lw > 0) m *= (partyCount() > 1 ? 0.7 : 1 + lw);
        return m;
    }
    // 特殊ステータスが高いほど、エネルギーの上限が増える（特殊50で100、倍になるごとに+30）。上限が大きいぶん溜まる量も少し増やす
    ENERGY_MAX = Math.round(100 + 30 * Math.log2(Math.max(1, base.special / 50)));
    P.energyMul *= Math.sqrt(ENERGY_MAX / 100);

    // ---------- 属性（elements.js）----------
    //  命中ダメージ × 属性倍率 が「属性ダメージ」として上乗せされる。弱点×1.6／耐性×0.5。属性ごとに命中時の効果（バトルスタイル）が違う
    const SE = window.SBElem || null;
    const WEL = SE ? (weapon.elems || []).filter(id => SE.ELEMS[id]) : [];     // 装備中の武器の属性
    const ELPTS = SE ? SE.getPts(hack) : {};
    function elemStyle(e, dmg, id, o) {
        const st = o.st || (o.st = {}), a = Math.atan2(e.y - me.y, e.x - me.x), ch = p => Math.random() < p;
        const chain = (n, mul, rad) => { let c = 0; enemies.forEach(x => { if (x !== e && x.hp > 0 && !x.pvp && c < n && dist(x.x, x.y, e.x, e.y) < rad) { c++; fx.push({ k: 'line', x: e.x, y: e.y, x2: x.x, y2: x.y, t: 0.2, life: 0.2, c: SE.ELEMS[id].color }); dealHit(x, dmg * mul, { el: [] }); } }); };
        const splash = (mul, rad) => { fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: rad, t: 0.3, life: 0.3, c: SE.ELEMS[id].color, fill: true }); enemies.forEach(x => { if (x !== e && x.hp > 0 && !x.pvp && dist(x.x, x.y, e.x, e.y) < rad) dealHit(x, dmg * mul, { el: [] }); }); };
        const push = k => { o.kx = (o.kx || 0) + Math.cos(a) * k; o.ky = (o.ky || 0) + Math.sin(a) * k; };
        switch (id) {
            case 'fire': if (ch(0.35)) st.burn = Math.max(st.burn || 0, dmg * 0.3); break;
            case 'water': if (ch(0.5)) st.slow = 1; break;
            case 'wind': push(90); if (ch(0.2)) me.haste = Math.max(me.haste || 0, 1.2); break;
            case 'earth': if (ch(0.1)) st.stun = 1; break;
            case 'thunder': if (ch(0.3)) chain(2, 0.5, 190); break;
            case 'steam': if (ch(0.35)) st.weaken = 1; break;
            case 'blast': if (ch(0.25)) splash(0.4, 100); break;
            case 'lava': if (ch(0.3)) { st.burn = Math.max(st.burn || 0, dmg * 0.3); st.curse = 1; } break;
            case 'plasma': if (ch(0.2)) { o.add = (o.add || 0) + dmg * 0.6; fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: 40, t: 0.25, life: 0.25, c: '#ff7aff', fill: true }); } break;
            case 'ice': if (ch(0.5)) st.slow = 1; if (ch(0.12)) st.stun = 1; break;
            case 'venom': if (ch(0.5)) st.poison = Math.max(st.poison || 0, dmg * 0.22); break;
            case 'sand': if (ch(0.4)) st.blind = 1; push(60); break;
            case 'storm': if (ch(0.25)) { chain(1, 0.5, 190); me.haste = Math.max(me.haste || 0, 1.2); } break;
            case 'discharge': if (ch(0.25)) splash(0.35, 150); break;
            case 'magnet': if (ch(0.35)) { push(-130); chain(1, 0.4, 190); } break;
        }
    }
    // 属性ダメージ（追加分）を返す。副作用として、命中時の効果を o に足す
    function elemHit(e, dmg, els, o) {
        const wk = SE.weakOf(e.def && e.def.name);
        let extra = 0, col = null;
        els.forEach(id => {
            const m = SE.ELEMS[id]; if (!m) return;
            const r = SE.ratio(id, ELPTS, P.special) * (1 + (A('elAtk:' + id) || 0) + (A('elAtkAll') || 0));
            const mul = wk.weak === id ? 1.6 : (wk.resist === id ? 0.5 : 1);
            extra += dmg * r * mul / els.length;
            col = col || m.color;
            elemStyle(e, dmg, id, o);
        });
        o.elc = col;
        return extra + (o.add || 0);
    }
    // 敵の強さの基準は「ステージのレベルだけ」で決まる固定値。プレイヤーの今のステータス・装備には合わせない。
    //  ・FIX_HP  : 敵の攻撃力の基準にする体力（敵のダメージ = 攻撃割合 × この値。防御・軽減は従来どおりプレイヤー側で効く）
    //  ・FIX_DPS : 敵のHPの基準にする火力（ステージの想定火力ぶんの秒数でHPが決まる）
    // 数字を変えたいときはこの2行だけ触ればよい。
    //  ステージごとの「推奨ステータス合計」(stage.req) に合わせて敵が強くなる（stage-data.js の STAT_REQ）。
    //  G_DMG: 敵HPの倍率（その合計の人の火力に合わせる） / G_HP: 敵の攻撃力の基準HPの倍率（その合計の人のHPに合わせる）
    //  最初のステージは従来どおり（倍率1）。最終ステージは推奨ステータス合計30万。武器は＋％なので、強さの主役はステータス合計。
    let G_DMG = stage.gDmg || 1, G_HP = stage.gHp || 1, G_MOB = stage.gMob || G_DMG;
    let FIX_HP = (250 + 40) * G_HP;
    let FIX_DPS = 28 * 1.18 * G_DMG;
    let REF_HP = FIX_HP;
    // ボスラッシュ（フェーズごと）・無限回廊（階層ごと／自分のステータスに合わせる）では、ステージの途中で敵の強さの基準が変わる。
    //  req : 推奨ステータス合計（敵の強さの基準）／ ilvl : 敵の足の速さなどに効くレベル／ pw : HP・攻撃・速さの倍率
    const SC = { ilvl: stage.ilvl, hpMul: stage.hpMul || 1, dmgMul: 1 };
    function applyScale(req, ilvl, pw) {
        const sc = window.STAGE_DATA.scaleOf(Math.max(250, req));
        G_DMG = sc.gDmg; G_HP = sc.gHp; G_MOB = sc.gMob;
        FIX_HP = (250 + 40) * G_HP; FIX_DPS = 28 * 1.18 * G_DMG; REF_HP = FIX_HP;
        SC.ilvl = ilvl; PW = pw || { hp: 1, dmg: 1, spd: 1 };
    }
    const RUSHD = window.STAGE_DATA.RUSH, CD = window.STAGE_DATA.CORRIDOR, RUSHD_EXTREME = window.STAGE_DATA.RUSH_DIFFS.length - 1;
    const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const RS = { ph: 0, st: 0, t: 0, limit: 0, inter: 0 };      // ボスラッシュの進行：ph=フェーズ(1〜6)、st=0待機/1戦闘中/2幕間、t=フェーズ開始からの秒、limit=制限秒、inter=幕間の残り秒
    const TILE = 22, CELL_T = 14;                                  // 無限回廊：1タイルの大きさ(px)／1区画の幅（タイル数。区画の中に部屋を1つ作り、区画どうしを通路でつなぐ＝トルネコの大冒険のような構造）
    const CF = { on: false, inBoss: false, floor: 1, seed: 0, cols: 0, rows: 0, tw: 0, th: 0, solid: null, open: null, rects: [], props: [], start: null, seen: null, flow: null, flowFor: -1, flows: null, gateT: 0, reqT: 0, rc: null, bend: null, big: null, mini: null, miniCtx: null, saved: null, exit: null, fade: 0, st: { chests: 0, mimics: 0, bosses: 0 } };
    // 戦利品の文脈：ボスラッシュ・無限回廊では、倒した敵ごとに「どのレベル・どの表から」ドロップを引くかが変わる（null ならステージ本来のもの）
    let LT = null;
    const L = () => LT || stage;
    // 撃破の報酬は、武器庫のデータを毎回読み書きすると重い（全武器の読み込み＋保存＋旧システムへの同期）。
    // 1回の撃破で10回近く保存していたのがボスラッシュのフリーズの原因だったので、撃破イベントの間はメモリ上の1つを使い回し、最後に1回だけ保存する
    let TX = null;
    const hwLoad = () => TX || HW.load();
    const hwSave = d => { if (!TX) HW.save(d); };
    // 無限回廊の「袋」：手に入れた武器・防具・素材・オーブ・特殊アイテムは、脱出ゲートから脱出するまで保存されない（死んだら全部失う）
    const BAG = { weapons: [], armors: [], accs: [], items: {}, mats: {}, orbs: [] };
    const myId = String(pdata.id || ('p' + Math.random().toString(36).slice(2, 8)));
    const myName = pdata.name || 'あなた';

    // ---------- キャンバス ----------
    const canvas = document.getElementById('practiceCanvas');
    const ctx = canvas.getContext('2d');
    let VW = 960, VH = 540, DPR = 1;
    function fit() {
        DPR = (window.SBPix && SBPix.lite) ? 1 : Math.min(2, window.devicePixelRatio || 1);      // 軽量モードのときは、等倍の解像度で描く（高解像度の画面でも重くならないように）
        VW = window.innerWidth; VH = window.innerHeight;
        canvas.width = Math.round(VW * DPR); canvas.height = Math.round(VH * DPR);
        canvas.style.width = VW + 'px'; canvas.style.height = VH + 'px';
    }
    window.addEventListener('resize', fit); fit();

    // ---------- フィールド（障害物の岩）----------
    const rocks = [];
    (function genRocks() {
        if (RUSH_ON || CORR_ON || stage.id === 'raid_worm' || stage.id === 'raid_machine') return;      // ボスラッシュは広い平地、無限回廊は迷路の壁だけ
        const r = seeded(hashStr(stage.id));
        for (let i = 0; i < 18; i++) {
            const x = 150 + r() * (WORLD_W - 300), y = 150 + r() * (WORLD_H - 300);
            if (dist(x, y, WORLD_W / 2, WORLD_H / 2) < 260 || dist(x, y, 220, WORLD_H / 2) < 200) continue;
            rocks.push({ x: x, y: y, r: 26 + r() * 38 });
        }
    })();
    // 移動を小さな歩幅（6px以下）に刻んで、1歩ごとに壁・岩から押し出す。
    // 1フレームで大きく動いたとき（ダッシュ・ノックバック・処理落ち）に、薄い壁の向こうへ一気に抜けてしまうのを防ぐ
    function moveSolid(o, dx, dy, rad) {
        const n = Math.max(1, Math.ceil(Math.hypot(dx, dy) / 6)), sx = dx / n, sy = dy / n;
        for (let i = 0; i < n; i++) { o.x += sx; o.y += sy; pushOutOfRocks(o, rad); }
    }
    function pushOutOfRocks(o, rad) {
        for (const k of rocks) {
            const d = dist(o.x, o.y, k.x, k.y), m = k.r + rad;
            if (d < m && d > 0.01) { o.x = k.x + (o.x - k.x) / d * m; o.y = k.y + (o.y - k.y) / d * m; }
        }
        if (CORR_ON) corrPushOut(o, rad);
        o.x = clamp(o.x, rad, WORLD_W - rad); o.y = clamp(o.y, rad, WORLD_H - rad);
    }

    // ---------- 状態 ----------
    const me = { id: myId, name: myName, x: (stage.id === 'raid_worm' ? 1400 - 280 : 220) + rnd(-30, 30), y: WORLD_H / 2 + rnd(-60, 60), r: 15, hp: P.maxHp, maxHp: P.maxHp,
        ang: 0, atkCd: 0, dashCd: 0, dashT: 0, dashVX: 0, dashVY: 0, inv: 0, cast: null, gch: 0, ult: 0, ultT: 0, guardT: 0, guardCd: 0, gMsgT: 0, energy: START_ENERGY, shield: false, haste: 0, dead: false, reviveT: 0, lungeT: 0, combo: 0, stunT: 0, stunImm: 0, invHard: 0 };
    const allies = {};           // id -> {id,name,x,y,tx,ty,hp,maxHp,dead,ang,rar}
    let enemies = [];            // ホスト: 実体 / クライアント: スナップショットの描画用
    let eBullets = [];
    let telegraphs = [];
    let myShots = [];
    let myBlades = [], ghostBlades = [];   // 神話のオリジナル武器：分身の剣（自分のものは当たり判定あり／仲間のものは見た目だけ）            // 自分の弾（命中判定は自分側でやる）
    let pvpProj = false;      // 対人戦：いま「飛び道具」のダメージを与えている最中（相手の魔断ち・反射の構えが効くかの目印）
    let ghostShots = [];         // 他のプレイヤーが撃った弾（見た目だけ。命中判定は撃った本人の画面でやる）
    let fx = [];                 // 見た目の演出
    let minions = [];            // スキル「ミニオン召喚」の自分のミニオン。{ id, x, y, r, t, max, sid, idx, atkT, cc, base, hasDmg, eff, fx, c, ... }
    let remoteMinions = {};      // 他のプレイヤーのミニオン（見た目だけ）。{ プレイヤーID: { l: [[x,y,r,残り秒]...], c, at } }
    let minionSendT = 0, hadMinions = false, auraT = 0, minionSeq = 0;
    // ---------- 対人戦のサドンデス ----------
    //  開始から SD.start 秒までは通常。そのあと SD.full 秒にかけて、攻撃力は 1→(1+SD.atk)倍まで上がり続け（時間切れまで止まらない）、
    //  防御力（ダメージ軽減）と回復系の効果は 0 に向かって下がっていく。時間切れは「総合ダメージ量」が多い方の勝ち
    const SD = { start: 40, full: 160, atk: 0.03 /* 1秒ごとの攻撃力の上昇 */, healMin: 0.1 /* 回復の効きの下限（サドンデス最終盤でも1割は残る） */ };
    function sdOn() { return PVP && run.phase === 'run'; }
    function sdProg() { return sdOn() ? clamp((run.time - SD.start) / (SD.full - SD.start), 0, 1) : 0; }       // 0〜1（防御・回復の低下の進み具合）
    function sdAtkMul() { return sdOn() ? 1 + SD.atk * Math.max(0, run.time - SD.start) : 1; }                  // 攻撃力の倍率（上限なし）
    function sdDefMul() { return 1 - sdProg(); }                                                                // 防御力（ダメージ軽減）の効き目
    // 回復系の効果の倍率：難易度（ナイトメア50%・エクストリーム75%低下）と、対人戦のサドンデスの両方がかかる
    function healMul() { if (A('noHeal') > 0 || (window.ClassPerks && ClassPerks.healBlock())) return 0; return Math.max(0, 1 - (DIFF.healRed || 0) - A('healDown')) * (sdOn() ? Math.max(SD.healMin, 1 - sdProg()) : 1); }      // 渇望：回復不可／血鎧：回復-50%
    function addHp(v) { v = v * healMul(); if (v <= 0 || me.dead) return 0; const before = me.hp; me.hp = Math.min(me.maxHp, me.hp + v); return me.hp - before; }
    let domains = [];            // スキル「領域」。{ id, x, y, r, t, max, own, fx(味方に効く自己強化), ... }
    let popups = [];
    let nextId = 1;
    if (window.SBSound) SBSound.bgm(PVP ? 'battle' : (RAID ? 'raid' : (RUSH_ON ? 'rush' : (CORR_ON ? 'dungeon' : 'stage'))), stage.id);      // ステージごとに、違う曲（同じステージでは同じ曲）
    const run = { phase: 'wait', time: 0, kills: 0, need: KILLS_BASE, bossSpawned: false, bossDead: false, ended: false,
        stats: { kills: 0, dmg: 0, loot: [], coins: 0, orbs: 0, mats: {} } };
    let isHost = true, room = null, socket = null;
    let spawnT = 1.5, snapT = 0, posT = 0, posSeq = 0, snapSeq = 0, lastSnapQ = -1, lastSnapAt = 0, snapAge = 0;
    let lastHt = null, WS = null, ZN = null;      // WS：ワールドワームの進行（ホストだけ）／ZN：敵のAIが動いている間だけ、その敵と同じ側（外／体内）のプレイヤーに絞る      // 直前のスナップショットのホスト側の時刻（ms）
    let snapBytes = 0, netPing = -1, netPingT = 0, netPingBusy = false;      // 直近のスナップショットの大きさ／通信の遅れ（ms）
    const posLast = { x: 0, y: 0, t: performance.now() };

    // ---------- 敵の強さをプレイヤーに合わせる ----------
    //  ステージの想定（stage.req＝推奨ステータス合計）よりパーティのステータス合計が高いとき、
    //  敵のHP・攻撃・速さと敵レベル（ilvl）をその強さに引き上げる。
    //  ボスHPが固定値のステージ（スタンダードワールド）と、強さが別途決まる
    //  ボスラッシュ・無限回廊・対人戦は対象外。
    if (!PVP && !RUSH_ON && !CORR_ON && !RAID && !stage.bossHp && typeof window.STAGE_DATA.ilvlForReq === 'function') {
        const pt = corrPartyTotal();
        if (pt > (stage.req || 0)) {
            applyScale(pt, window.STAGE_DATA.ilvlForReq(pt), PW);
            // ここは起動の途中で、画面の部品（el）がまだ使えない。少しあとに知らせる（直前の版では、ここでエラーになってステージが始まらなかった）
            setTimeout(() => { try { announce('⚔ 強い気配を感じる…　このステージの敵が強くなった！', 2200); } catch (e) { /* お知らせが出せなくても、ステージは続ける */ } }, 700);
        }
    }

    // ---------- ネットワーク ----------
    function netSend(t, d) {
        if (!socket || !room) return;
        const packet = { t: t, d: d };
        // 位置・状態同期は次の更新で必ず置き換わる。一時的に回線が詰まった際、
        // 古い状態をため込むと操作・Ping応答まで遅れるため、最新分だけを送る。
        const hot = t === 'pos' || t === 'snap' || t === 'mn';
        const sender = hot && socket.volatile ? socket.volatile : socket;
        sender.emit('stage:relay', packet);
    }
    // ゲストのヒット通知：ヒットのたびに1通ずつ送ると、連続ヒットのスキル（旋回・領域・ミニオン…）で通信が詰まって画面が重くなる。
    // 0.06秒ぶんをまとめて1通（'hits'）で送る。ホストは受け取ったら1つずつ処理する
    let hitQ = [], hitFlushT = 0;
    function flushHits() {
        if (!hitQ.length) return;
        const l = hitQ; hitQ = [];
        if (l.length === 1) netSend('hit', l[0]); else netSend('hits', { l: l });
    }
    function queueHit(d) { hitQ.push(d); if (hitQ.length >= 24) flushHits(); }
    function partyCount() { return 1 + Object.keys(allies).length; }
    function partyScale() { return 1 + 0.65 * (partyCount() - 1); }

    function setupNet() {
        if (typeof io !== 'function') return false;
        socket = io({ transports: ['websocket', 'polling'], reconnectionDelay: 500, reconnectionDelayMax: 3000 });      // 最初から WebSocket で接続する（既定の polling 始まりだと、回線によっては切り替わらず重いままになる）
        socket.on('connect', () => {
            netPingT = 0;
            const best = Math.max(1, hack.corridorBest | 0 || 1), payload = { player: { id: myId, name: myName, wname: weapon.name, rar: weapon.rarity, best: hack.corridorBest | 0, lv: (pdata.level || (typeof calcLevel === 'function' ? calcLevel(pdata.xp || 0) : 1)) }, stageId: stage.id, diff: parseInt(launch.diff, 10) || 0, startFloor: stage.corridor ? Math.max(1, Math.min(launch.startFloor | 0 || 1, best)) : 1 };      // 無限回廊：部屋のスタート階層と、自分の最深の階層を伝える
            if (launch.mode === 'create') socket.emit('stage:create', payload);
            else if (launch.mode === 'join') socket.emit('stage:join', Object.assign({ roomId: launch.roomId }, payload));
            else socket.emit('stage:quick', payload);
        });
        socket.on('stage:room', onRoom);
        socket.on('stage:error', (m) => { showWaitMsg((m && m.message) || 'ルームに入れませんでした'); setTimeout(() => { location.href = 'index.html'; }, 1800); });
        socket.on('stage:started', () => { if (run.phase === 'wait') beginRun(); });
        socket.on('stage:msg', onMsg);
        return true;
    }

    // ホストが抜けたとき：最後に受け取った敵の状態を引き継いで、自分が敵を動かす側になる
    function adoptEnemies() {
        enemies = enemies.map(e => {
            const def = e.boss ? { name: stage.boss.name, icon: stage.boss.icon, color: stage.boss.color, arch: 'chaser' }
                : (CORR_ON ? (CD.mobs.find(d => d.name === e.def.name) || (e.def.name === CD.mimic.name ? CD.mimic : CD.mobs[0])) : (stage.enemies.find(d => d.name === e.def.name) || stage.enemies[0]));
            const st = enemyStats(def, e.boss, e.elite);
            return { id: e.id, def: def, arch: def.arch, boss: e.boss, elite: !!e.elite, x: e.x, y: e.y, hp: e.hp, maxHp: e.maxHp, dmg: st.dmg, spd: st.spd, r: e.r,
                t: 0, state: 0, st: { burn: 0, burnT: 0, poison: 0, poisonT: 0, slowT: 0, stunT: 0, bleed: 0, bleedT: 0, curseT: 0, weakenT: 0, blindT: 0 }, kx: 0, ky: 0, aim: 0, fuse: 0, patIdx: 0, enraged: e.hp / e.maxHp < 0.5, air: 0, mv: null };
        });
        telegraphs = [];   // 受け取った予告範囲は威力を持たないので、ホスト交代時は破棄する
        eBullets.forEach(b => { b.vx = 0; b.vy = 0; b.life = 0; });
        nextId = 100000 + Math.floor(Math.random() * 100000);
        announce('ホストが交代しました', 1600);
    }

    function onRoom(r) {
        room = r;
        DIFF = DIFFS[Math.max(0, Math.min(DIFFS.length - 1, r.diff | 0))];
        el('stageName').textContent = stage.icon + ' ' + stage.name + ' [' + DIFF.name + ']';
        const wasHost = isHost;
        isHost = r.hostId === myId;
        if (!wasHost && isHost && run.phase === 'run') adoptEnemies();
        const ids = r.members.map(m => m.id);
        r.members.forEach(m => { if (m.id !== myId && !allies[m.id]) allies[m.id] = { id: m.id, name: m.name, x: (stage.id === 'raid_worm' ? 1120 : 220), y: WORLD_H / 2, tx: (stage.id === 'raid_worm' ? 1120 : 220), ty: WORLD_H / 2, hp: 100, maxHp: 100, dead: false, ang: 0, rar: m.rar || 'normal', r: 15 }; });
        Object.keys(allies).forEach(id => { if (ids.indexOf(id) < 0) delete allies[id]; });
        if (run.phase === 'wait') renderWait();
        if (r.state === 'playing' && run.phase === 'wait') beginRun();
    }

    function onMsg(m) {
        if (!m || !m.t) return;
        const d = m.d || {};
        const a = allies[m.from];
        switch (m.t) {
            case 'pos':
                if (a && !(d.q < a.pq)) { a.pq = d.q; a.vx = clamp(+d.vx || 0, -900, 900); a.vy = clamp(+d.vy || 0, -900, 900); a.pt = performance.now(); if (d.tp) { a.x = d.x; a.y = d.y; a.vx = 0; a.vy = 0; } }
                if (a) { a.tx = d.x; a.ty = d.y; a.ang = d.a; a.hp = d.hp; a.maxHp = d.mh; a.dead = !!d.dead || !!a.esc; a.stun = !!d.st; a.g = !!d.g; if (d.tt > 0) a.tt = d.tt; if (typeof d.wt === 'string' && window.SBPix && SBPix.hasWeapon(d.wt)) a.wt = d.wt; if (typeof d.ws === 'number') a.wsz = (window.HW && HW.cleanSize) ? HW.cleanSize(d.ws) : 1;
        if (d.wp === 0) a.wpc = null;
        else if (d.wp && typeof d.wp === 'object' && d.wp.k && !d.wp.rows) { /* 絵は変わっていない（目印だけ届いた）。持っている絵をそのまま使う */ }
        else if (d.wp && typeof d.wp === 'object') { const cp = HW.cleanPix(d.wp); if (cp && window.SBPix && SBPix.customKey) { const ck = SBPix.customKey(cp); if (!a.wpc || a.wpc.key !== ck) a.wpc = SBPix.prepCustom(cp); } }      // 仲間が自分で描いた武器のドット絵（形式と大きさを確認してから使う）
        if (Array.isArray(d.wx) && window.SBPix && SBPix.prepTex) a.txc = d.wx.slice(0, 10).map(t => { const c = t && HW.cleanPix(t); return c && c.w <= 16 && c.h <= 16 ? SBPix.prepTex(c) : null; });      // 仲間が自分で描いた弾の絵
        if (typeof d.wm === 'string') a.wm = (d.wm && window.SBPix && SBPix.hasMythic(d.wm)) ? d.wm : null;
        if (typeof d.av === 'string' && d.av.length < 80 && window.SBPix && SBPix.cleanAvatar) a.av = SBPix.cleanAvatar(d.av);
        if (d.ti !== undefined) a.ti = (window.SBAch && SBAch.isTitleText(d.ti)) ? d.ti : ''; }
                break;
            case 'esc':     // 無限回廊：仲間が脱出した（倒れた扱いにして、敵に狙われないようにする）
                if (a) { a.esc = true; a.dead = true; popups.push({ x: a.x, y: a.y - 30, t: 1.6, text: '脱出！', c: '#9fe8ff', big: true }); }
                break;
            case 'creq':    // 無限回廊：クライアントからの「階段に着いた／ボス部屋の入口に入った／出口に着いた」
                if (CORR_ON && isHost && run.phase === 'run' && d) corrAsk(String(d.k), d.i | 0);
                break;
            case 'cuse':    // 無限回廊：仲間が回復の泉を使った
                if (CORR_ON && d) { const q = corrProp(d.i | 0); if (q && q.k === 'spring') q.k = 'spring_done'; }
                break;
            case 'cho':     // 無限回廊：仲間が宝箱を開けた（中身は開けた人のもの）
                if (CORR_ON && d) { const q = corrProp(d.i | 0); if (q && q.k === 'chest') { q.k = 'open'; fx.push({ k: 'ring', x: q.x, y: q.y, r: 0, max: 60, t: 0.4, life: 0.4, c: '#ffd84a' }); } }
                break;
            case 'cmim':    // 無限回廊：宝箱がミミックだった（ホストが敵として出す）
                if (CORR_ON && d) { const q = corrProp(d.i | 0); if (q) { CF.props = CF.props.filter(x => x !== q); popups.push({ x: q.x, y: q.y - 30, t: 1.4, text: 'ミミックだ！', c: '#ff6a5a', big: true }); } }
                break;
            case 'atk':
                if (a && d && d.k === 'blades') { ghostBladesFrom(d, a); break; }      // 仲間の分身の剣：見た目だけ
                if (a) { spawnAtkFx(d); a.swingAt = performance.now(); a.swingDir = d.dir || 1; a.swingFin = d.fin; a.swingKind = d.k === 'line' ? 'line' : (d.k === 'proj' ? 'proj' : ((d.k === 'smash' || d.k === 'ring') ? 'smash' : 'cone')); }
                break;
            case 'shot':   // 他のプレイヤーの弾：見た目だけを出す（ダメージは撃った人の画面で計算される）
                if (a && d && Array.isArray(d.s)) d.s.slice(0, 12).forEach(q => {
                    const num = v => (typeof v === 'number' && isFinite(v)) ? v : 0;
                    ghostShots.push({ x: num(q.x), y: num(q.y), vx: clamp(num(q.vx), -1500, 1500), vy: clamp(num(q.vy), -1500, 1500), r: clamp(num(q.r) || 8, 2, 40), kd: q.kd ? 1 : 0,
                        life: clamp(num(q.life) || 0.8, 0.05, 3), c: typeof q.c === 'string' && q.c.length <= 9 ? q.c : '#ffffff', pierce: clamp(Math.round(num(q.pierce)), 0, 9), aoe: clamp(num(q.aoe), 0, 200),
                        tp: (a.txc && typeof q.t === 'number' && a.txc[q.t | 0]) || null, ts: clamp(Math.round(num(q.ts)) || 2, 1, 4) });
                });
                break;
            case 'hit':
                if (isHost) applyHit(d);
                break;
            case 'hits':      // ゲストがまとめて送ったヒット
                if (isHost && Array.isArray(d.l)) d.l.slice(0, 40).forEach(h => { if (h) applyHit(h); });
                break;
            case 'bhit':
                if (isHost) eBullets = eBullets.filter(b => b.id !== d.id);
                break;
            case 'pbar':      // 職業パーク「ガーディアン・スピリット」：味方の盾が自分に跳ね返ってきた → 3秒間、あらゆるダメージを無効化
                if (d && d.to === myId && !me.dead) { const sec = Math.min(5, Number(d.t) || 3); me.invHard = Math.max(me.invHard || 0, sec); me.inv = Math.max(me.inv, sec); popups.push({ x: me.x, y: me.y - 40, t: 1.2, text: '🛡 聖なるバリア', c: '#fff3b0', big: true }); }
                break;
            case 'mn':      // 他のプレイヤーのミニオン（位置・向き・攻撃の動作）。対人戦では、相手チームのものは赤く表示する
                if (a && d && Array.isArray(d.l)) {
                    const nowMs = performance.now(), prev = remoteMinions[m.from], list = d.l.slice(0, 12);
                    if (prev && d.q != null && prev.q != null && d.q <= prev.q && d.q > prev.q - 50) break;      // 古い・順番が入れ替わった更新は捨てる
                    const dtM = prev ? clamp((nowMs - prev.at) / 1000, 0.03, 0.5) : 0.1;
                    remoteMinions[m.from] = {
                        q: d.q, at: nowMs, c: String(d.c || '#9df0ff').slice(0, 9),
                        l: list.map((q, k) => {
                            const tx = clamp(Number(q[0]) || 0, 0, WORLD_W), ty = clamp(Number(q[1]) || 0, 0, WORLD_H), o = prev && prev.l[k];      // 番号 k が同じものを同じミニオンとみなす
                            let vx = 0, vy = 0, x = tx, y = ty;
                            if (o) { x = o.x; y = o.y; vx = clamp((tx - o.tx) / dtM, -700, 700); vy = clamp((ty - o.ty) / dtM, -700, 700); if (Math.hypot(tx - o.tx, ty - o.ty) > 260) { x = tx; y = ty; vx = vy = 0; } }
                            return { x: x, y: y, tx: tx, ty: ty, vx: vx, vy: vy, r: clamp(Number(q[2]) || 14, 6, 40), t: Number(q[3]) || 0, face: Number(q[4]) || 0, lunge: Number(q[5]) ? 0.15 : (o ? Math.max(0, o.lunge - dtM) : 0) };
                        })
                    };
                }
                break;
            case 'cf':      // 他のプレイヤーの職業スキルの動き（設置物・召喚・剣など）を、見た目だけで再現する。ダメージは撃った人の画面で決まる
                if (d && d.from !== myId && typeof d.k === 'string' && window.ClassForms && ClassForms.castRemote && (cfRate[d.from] = (cfRate[d.from] || 0) + 1) <= 8) ClassForms.castRemote(d.from, d.k.slice(0, 24), { ang: clamp(Number(d.a) || 0, -7, 7), p: { element: typeof d.e === 'string' ? d.e.slice(0, 12) : undefined } });
                break;
            case 'dom':     // 他のプレイヤーのスキル「領域」：自分の画面にも領域を描く。味方のものは中にいる間だけ回復・バフが効く（対人戦の相手チームのものは、赤い見た目だけ）
                if (d && d.from !== myId && domains.length < 16) {
                    const foe = !!(PVP && run.pvpMode && !sameTeam(d.from));
                    const dr = clamp(Number(d.r) || 0, 0, 900), dt0 = clamp(Number(d.t) || 6, 0, 20);
                    const o = { id: String(d.id), x: Number(d.x) || 0, y: Number(d.y) || 0, r: dr, t: dt0, max: dt0, own: false, foe: foe, fx: foe ? [] : (Array.isArray(d.fx) ? d.fx : []).filter(k => SELF_FX.indexOf(k) >= 0), c: foe ? '#ff5a5a' : String(d.c || '#7aff9a').slice(0, 9) };
                    domains = domains.filter(x => x.id !== o.id);     // 同じ領域の重複を防ぐ
                    spawnDomain(o);
                }
                break;
            case 'sup':     // 味方の支援武器（回復・鼓舞）：範囲内にいる自分に効く
                if (d && d.from !== myId && (!(PVP && run.pvpMode) || sameTeam(d.from)) && dist(me.x, me.y, Number(d.x) || 0, Number(d.y) || 0) <= clamp(Number(d.r) || 0, 0, 320)) applySupport(d, false);   // 対人戦では、味方チームの回復・鼓舞だけが効く
                break;
            case 'refl':    // 他の人がスキルを発動：その人の周りの放射弾を跳ね返す（ホストが処理）
                if (isHost && GMK === 'dimension') hostReflect(Number(d.x) || 0, Number(d.y) || 0);
                break;
            case 'gm':
                if (!isHost) onGm(d); else if (d && d.k === 'corpse' && GMK === 'necro') hostCorpse(d);      // 仲間がシャーマンに倒された：その場にゾンビを生む
                break;
            case 'snap':
                if (!isHost && !PVP) applySnap(d);
                break;
            case 'pvph':
                if (PVP && d.to === myId) hurtPvp(d.f, d.kx, d.ky, d.st, m.from, d.pj);
                break;
            case 'pvpd':   // 誰かが誰かに与えた実ダメージ（最大HPに対する%）：時間切れの勝敗に使う
                if (PVP && d && d.by) tallyDmg(String(d.by).slice(0, 60), clamp(Number(d.p) || 0, 0, 100000));
                break;
            case 'kill':
                if (!isHost) onKillEvent(d);
                break;
            case 'boom':
                if (!isHost) onBoom(d);
                break;
            case 'announce':
                if (!isHost) announce(d.text, d.ms);
                break;
            case 'end':
                if (!isHost) finish(TEAM && d.winnerTeam !== undefined ? (d.winnerTeam >= 0 && d.winnerTeam === teamMap[myId]) : (PVP && d.winner !== undefined ? d.winner === myId : d.win), d);
                break;
            case 'sk':
                if (a) skillFx(d, a);
                break;
        }
    }

    // ---------- 入力 ----------
    const keys = {};
    const input = { mx: 0, my: 0, aimX: 0, aimY: 0, aimOn: false, mouseDown: false, touchAim: null, stick: { id: null, ox: 0, oy: 0, x: 0, y: 0 }, aimStick: { id: null, ox: 0, oy: 0, x: 0, y: 0 } };
    const isTouch = matchMedia('(pointer: coarse)').matches;
    window.addEventListener('keydown', (e) => {
        if (e.repeat && ['Space'].indexOf(e.code) >= 0) return;
        keys[e.code] = true;
        if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') doDash();
        const sk = { KeyZ: 0, KeyX: 1, KeyC: 2, KeyV: 3 }[e.code]; if (sk !== undefined) castSkill(sk);
        if (e.code === 'Tab') { e.preventDefault(); toggleQuiz(); }
        if (e.code === 'KeyB' && !e.repeat) startGuard();
        if (e.code === 'KeyR' && !e.repeat) castUlt();
        if (e.code === 'KeyO' && !e.repeat && window.SBPix) { SBPix.lite = !SBPix.lite; liteManual = true; fit(); announce(SBPix.lite ? '⚡ 軽量モード ON（エフェクトを減らします）' : '✨ 軽量モード OFF', 1400); }
        if (e.code === 'KeyP' && !e.repeat && window.SBPix) { SBPix.setOn(!SBPix.on()); announce(SBPix.on() ? '🎨 ドット絵表示 ON' : '🎨 ドット絵表示 OFF（従来の表示）', 1400); }
        if (e.code === 'KeyG') { autoAim = !autoAim; try { localStorage.setItem('sbAutoAim', autoAim ? '1' : '0'); } catch (er) {} announce(autoAim ? '🎯 オートエイム ON（近くの敵を自動で狙う）' : '🎯 オートエイム OFF（マウスで狙う）', 1500); }
        if (/^Digit[1-4]$/.test(e.code)) quizPick(parseInt(e.code.slice(5), 10) - 1);
        if (e.code.indexOf('Arrow') === 0 || e.code === 'Space') e.preventDefault();
    });
    window.addEventListener('keyup', (e) => { keys[e.code] = false; if (e.code === 'KeyB') cancelGuard(); });
    canvas.addEventListener('mousemove', (e) => { input.aimX = e.clientX; input.aimY = e.clientY; input.aimOn = true; });
    canvas.addEventListener('mousedown', (e) => { if (e.button === 2) { doDash(); return; } input.mouseDown = true; input.aimX = e.clientX; input.aimY = e.clientY; input.aimOn = true; });
    window.addEventListener('mouseup', () => { input.mouseDown = false; });
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    // タッチ：左半分=移動スティック / 右半分=エイム＆攻撃スティック
    canvas.addEventListener('pointerdown', (e) => {
        if (e.pointerType === 'mouse') return;
        const left = e.clientX < VW / 2;
        const st = left ? input.stick : input.aimStick;
        if (st.id !== null) return;
        st.id = e.pointerId; st.ox = e.clientX; st.oy = e.clientY; st.x = 0; st.y = 0;
        canvas.setPointerCapture(e.pointerId);
    });
    canvas.addEventListener('pointermove', (e) => {
        [input.stick, input.aimStick].forEach(st => {
            if (st.id !== e.pointerId) return;
            let dx = e.clientX - st.ox, dy = e.clientY - st.oy;
            const l = Math.hypot(dx, dy), m = 56;
            if (l > m) { dx = dx / l * m; dy = dy / l * m; }
            st.x = dx / m; st.y = dy / m;
        });
    });
    const endPtr = (e) => { [input.stick, input.aimStick].forEach(st => { if (st.id === e.pointerId) { st.id = null; st.x = 0; st.y = 0; } }); };
    canvas.addEventListener('pointerup', endPtr); canvas.addEventListener('pointercancel', endPtr);
    document.getElementById('btnDash').addEventListener('pointerdown', (e) => { e.preventDefault(); doDash(); });
    const btnU = document.getElementById('btnUlt');
    if (btnU) btnU.addEventListener('pointerdown', (e) => { e.preventDefault(); castUlt(); });
    const btnG = document.getElementById('btnGuard');
    if (btnG) { btnG.addEventListener('pointerdown', (e) => { e.preventDefault(); startGuard(); }); ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => btnG.addEventListener(ev, cancelGuard)); }

    // ---------- 敵生成（ホスト）----------
    // 敵の攻撃力は「基準HPに対する割合」で持つ（各プレイヤーが自分のHPに換算して受けるので、協力でも公平）
    function ed(e) { return (e.dmg || 0) * (e.dmgMul || 1) * (e.rage || 1); }
    function foeDmg(arch, isBoss, elite, noArch) {
        const a = noArch ? { atk: 1 } : (window.STAGE_DATA.ARCH[arch] || window.STAGE_DATA.ARCH.chaser);
        return Math.min(0.22, 0.075 + 0.0045 * SC.ilvl) * DIFF.dmg * a.atk * (isBoss ? 0.9 : 1) * (elite ? 1.4 : 1) * PW.dmg;
    }
    // S が渡されたとき（無限回廊）：この敵の「合計ステータス」S から、体力・攻撃を求める（S の割り当ては spawnEnemy が乱数で決める）。
    //  S が渡されないとき：従来どおり、ステージ全体の基準（G_*）から決める
    function enemyStats(def, isBoss, elite, S) {
        const ilvl = SC.ilvl;
        const a = window.STAGE_DATA.ARCH[def.arch] || window.STAGE_DATA.ARCH.chaser;
        const ps = partyScale();
        const sc = S ? window.STAGE_DATA.scaleOf(Math.max(250, S)) : null;
        const gMob = sc ? sc.gMob : G_MOB, gDmg = sc ? sc.gDmg : G_DMG, fixDps = sc ? 28 * 1.18 * sc.gDmg : FIX_DPS;
        const stageHp = 70 * 1.7 * gDmg, mobHp = 70 * 1.7 * gMob;
        let hp;
        if (isBoss) hp = Math.max(stageHp * 24, fixDps * 45) * SC.hpMul * DIFF.hp * ps * PW.hp;                 // 想定火力で最低45秒ぶん（固定）
        else hp = Math.max(mobHp, 28 * 1.18 * gMob * 1.8) * DIFF.hp * (sc ? 1 : a.hp) * ps * (elite ? 4.5 : (CORR_ON ? 1 : MOB_HP_MUL)) * PW.hp * (PW.mobHp || 1); // 雑魚も最低約2秒ぶん（固定）
        const refRatio = sc ? sc.gHp / G_HP : 1;      // 攻撃力は「基準HPに対する割合」なので、この敵の合計ステータスぶんの基準HPに換算する
        return {
            maxHp: Math.round(hp),
            dmg: foeDmg(def.arch, isBoss, elite, !!sc) * (isBoss || elite || CORR_ON ? 1 : MOB_DMG_MUL) * (isBoss ? SC.dmgMul : 1) * refRatio,
            spd: 118 * (sc ? 1 : a.spd) * (1 + ilvl * 0.015) * DIFF.spd * (elite ? 1.05 : 1) * PW.spd,
            r: (isBoss ? 46 : a.r) * (elite ? 1.3 : 1)
        };
    }
    // 無限回廊：敵の合計ステータス＝プレイヤー（パーティ平均）の合計 × 階層の倍率 × 敵の種類の倍率。それを5つのステータス（体力・攻撃・防御・速さ・特殊）にランダムに割り振る
    const CTYPE_MUL = { chaser: 1.25, swarm: 0.9, tank: 1.7, ranged: 1.1, bomber: 1.0, charger: 1.4 };      // 敵の種類ごとの倍率
    function corrTypeMul(def, isBoss, elite) { return isBoss ? 1 : (CTYPE_MUL[def.arch] || 1.2) * (elite ? 1.25 : 1); }
    function corrEnemyTotal(def, isBoss, elite, bossMul) { return corrPartyTotal() * corrMul(CF.floor) * corrTypeMul(def, isBoss, elite) * (bossMul || 1); }
    function corrShares() {      // 合計を5つに分けたときの、平均を1とした割合：[体力, 攻撃, 防御, 速さ, 特殊]
        const w = [0, 1, 2, 3, 4].map(() => 0.35 + Math.random() * 1.3), sum = w.reduce((x, y) => x + y, 0);
        return w.map(x => x / sum * 5);
    }
    function applyShares(e, sh) {
        e.sh = sh.map(v => Math.round(v * 100) / 100);
        const c = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
        e.maxHp = e.hp = Math.max(1, Math.round(e.maxHp * c(sh[0], 0.35, 2.2)));          // 体力
        e.dmg *= c(sh[1], 0.4, 2.0);                                                       // 攻撃（接触・弾・技の基本の強さ）
        e.takeMul = 1 / (0.55 + 0.45 * c(sh[2], 0.2, 2.6));                                // 防御：高いほど受けるダメージが減る
        e.spd *= 0.8 + 0.2 * c(sh[3], 0.2, 2.5);                                           // 速さ
        e.dmgMul = 0.75 + 0.25 * c(sh[4], 0.2, 2.5);                                       // 特殊（遠距離の弾・ボスの技の強さ）
    }

    function spawnEnemy(def, x, y, isBoss, elite, S) {
        const st = enemyStats(def, isBoss, elite, S);
        const e = { id: nextId++, def: def, arch: def.arch, boss: !!isBoss, elite: !!elite, x: x, y: y, hp: st.maxHp, maxHp: st.maxHp, dmg: st.dmg, spd: st.spd, r: st.r,
            t: rnd(0, 2), state: 0, st: { burn: 0, burnT: 0, poison: 0, poisonT: 0, slowT: 0, stunT: 0, bleed: 0, bleedT: 0, curseT: 0, weakenT: 0, blindT: 0 },
            kx: 0, ky: 0, aim: 0, fuse: 0, patIdx: 0, enraged: false, air: 0, mv: null };
        if (S) applyShares(e, corrShares());
        enemies.push(e);
        return e;
    }

    // 通常ステージの「魔改造」敵：精鋭（elite）に低確率で一般モブにも付き、
    // 倒し方・戦い方が少し変わる変種になる。無限回廊は専用のCAFFIXがあるので対象外。
    const STAGE_AFFIX = [
        { id: 'explosive', n: '爆発型', icon: '💥' },
        { id: 'split',     n: '分裂型', icon: '🧫' },
        { id: 'venom',     n: '毒牙',   icon: '☠️' },
        { id: 'frenzy',    n: '狂暴',   icon: '😡' },
        { id: 'swift',     n: '疾走',   icon: '💨' },
        { id: 'giant',     n: '巨漢',   icon: '🗿' },
        { id: 'thick',     n: '鉄壁',   icon: '🛡️' }
    ];
    function applyStageAffix(e, loud) {
        const a = STAGE_AFFIX[Math.floor(Math.random() * STAGE_AFFIX.length)];
        e.affix = a.id;
        if (a.id === 'frenzy') { e.dmg *= 1.25; e.spd *= 1.1; }
        else if (a.id === 'swift') e.spd *= 1.35;
        else if (a.id === 'giant') { e.hp = e.maxHp = Math.round(e.maxHp * 1.4); e.r *= 1.2; e.dmg *= 1.15; }
        else if (a.id === 'thick') e.takeMul = (e.takeMul || 1) * 0.6;
        else if (a.id === 'explosive') e.dmg *= 1.1;
        if (loud) netAnnounce(a.icon + ' ' + a.n + 'の敵が出現！', 1300);
    }

    function spawnGroup() {
        const alive = alivePlayersPos();
        const c = alive[Math.floor(Math.random() * alive.length)] || { x: WORLD_W / 2, y: WORLD_H / 2 };
        const def = stage.enemies[Math.floor(Math.random() * stage.enemies.length)];
        const eliteAlive = enemies.filter(e => e.elite && e.hp > 0).length;
        const elite = def.arch !== 'swarm' && eliteAlive < 3 && Math.random() < DIFF.elite;
        const n = elite ? 1 : Math.round((def.arch === 'swarm' ? Math.floor(rnd(5, 9)) : (def.arch === 'tank' ? Math.floor(rnd(1, 3)) : Math.floor(rnd(3, 6)))) * MOB_GROUP_MUL);
        const ang = rnd(0, Math.PI * 2), d = rnd(480, 660);
        if (elite) announce('⚔ 精鋭が出現！', 1100);
        for (let i = 0; i < n; i++) {
            const x = clamp(c.x + Math.cos(ang) * d + rnd(-60, 60), 40, WORLD_W - 40), y = clamp(c.y + Math.sin(ang) * d + rnd(-60, 60), 40, WORLD_H - 40);
            const e = spawnEnemy(def, x, y, false, elite);
            if (!CORR_ON && (elite || Math.random() < 0.05)) applyStageAffix(e, elite);
            pushOutOfRocks(e, e.r);
        }
        ZN = null;
    }

    function alivePlayersPos() {
        const out = [];
        if (!me.dead) out.push({ x: me.x, y: me.y, id: me.id });
        Object.keys(allies).forEach(id => { const a = allies[id]; if (!a.dead) out.push({ x: a.x, y: a.y, id: id }); });
        return ZN == null ? out : out.filter(q => wmZone(q.x) === ZN);
    }
    function nearestPlayer(x, y) {
        let best = null, bd = 1e9;
        alivePlayersPos().forEach(p => { const d = dist(x, y, p.x, p.y); if (d < bd) { bd = d; best = p; } });
        return best;
    }

    function bullet(x, y, ang, spd, dmg, r, life, color, kd) {   // kd: 1 = 剣（ゲートキーパーの射出物）
        if (eBullets.length > 420) eBullets.splice(0, 60);      // 弾が増えすぎると処理が重くなり、画面が固まって見える。古い弾から消す
        eBullets.push({ id: nextId++, x: x, y: y, vx: Math.cos(ang) * spd, vy: Math.sin(ang) * spd, dmg: dmg, r: r || 7, life: life || 3.2, c: color || '#ff6a5a', kd: kd || 0 });
    }
    // 予告範囲。o で形を指定できる：{ sh:'cone'|'line'|'donut', a:向き, arc:角度, ri:内半径, w:幅, stun:スタン付き, rep/gap:持続ヒット }
    function telegraph(x, y, r, t, dmg, c, o) {
        const tg = { id: nextId++, x: x, y: y, r: r, t: t, max: t, dmg: dmg, c: c || '#ff5a5a' };
        if (o) Object.keys(o).forEach(k => { if (o[k] != null && o[k] !== false) tg[k] = o[k]; });
        telegraphs.push(tg);
    }

    // ---------- 敵AI（ホストだけが動かす）----------
    function updateEnemies(dt) {
        for (const e of enemies) {
            const s = e.st;
            if (e.arch === 'wseg' || e.arch === 'wscale' || e.arch === 'wcore') continue;      // ワールドワームの体・鱗・核は、自分では動かない
            ZN = GMK === 'worm' ? wmZone(e.x) : null;
            if (CORR_ON && CF.on && !e.boss && !e.act && !corrWake(e)) continue;      // 無限回廊：近づくまで眠っている敵
            // 状態異常
            let dot = 0;
            if (s.burnT > 0) { s.burnT -= dt; dot += s.burn; }
            if (s.poisonT > 0) { s.poisonT -= dt; dot += s.poison; }
            if (s.bleedT > 0) { s.bleedT -= dt; dot += s.bleed; }
            if (s.curseT > 0) s.curseT -= dt;
            if (s.weakenT > 0) s.weakenT -= dt;
            if (s.blindT > 0) s.blindT -= dt;
            e.dmgMul = s.blindT > 0 ? 0.5 : (s.weakenT > 0 ? 0.65 : 1);
            if (dot > 0 && !e.inv) { e.hp -= dot * dt; if (e.hp <= 0) { killEnemy(e, null); continue; } }
            if (s.stunT > 0) { s.stunT -= dt; if (e.ma === 1) { e.ma = 0; e.mt = 0; e.mcd = 0.8; } continue; }      // 溜めている最中にスタンしたら、攻撃は中断
            const slow = s.slowT > 0 ? 0.45 : 1; if (s.slowT > 0) s.slowT -= dt;
            e.t += dt;
            // ノックバック
            if (Math.abs(e.kx) + Math.abs(e.ky) > 1) { e.x += e.kx * dt; e.y += e.ky * dt; e.kx *= Math.pow(0.02, dt); e.ky *= Math.pow(0.02, dt); }
            const tgt = nearestPlayer(e.x, e.y);
            if (!tgt) continue;
            const dx = tgt.x - e.x, dy = tgt.y - e.y, d = Math.hypot(dx, dy) || 1, ang = Math.atan2(dy, dx);
            const sp = e.spd * slow;
            let mvx = dx / d, mvy = dy / d, los = true;
            if (CORR_ON && CF.on && !e.boss) { const w = corrWaypoint(e, tgt), wd = Math.hypot(w.x - e.x, w.y - e.y) || 1; mvx = (w.x - e.x) / wd; mvy = (w.y - e.y) / wd; los = corrLOS(e.x, e.y, tgt.x, tgt.y); }
            if (e.boss) { updateBoss(e, dt, tgt, d, ang, slow); }
            else if (e.arch === 'chaser' || e.arch === 'swarm' || e.arch === 'tank') { if (!meleeUpdate(e, dt, d, ang, sp, mvx, mvy, los)) { e.x += mvx * sp * dt; e.y += mvy * sp * dt; } }      // 近づいたら、接触ではなく「攻撃モーション」で攻撃する
            else if (e.arch === 'ranged') {
                const want = (d > 320 || !los) ? 1 : (d < 200 ? -0.8 : 0);
                e.x += mvx * sp * dt * want;
                e.y += mvy * sp * dt * want;
                if (e.t > 1.5 && d < 640 && los) { e.t = rnd(0, 0.4); bullet(e.x, e.y, ang, 300, ed(e), 7, 3.4, e.def.color); if (e.elite) { bullet(e.x, e.y, ang + 0.22, 300, ed(e), 7, 3.4, e.def.color); bullet(e.x, e.y, ang - 0.22, 300, ed(e), 7, 3.4, e.def.color); } }
            } else if (e.arch === 'charger') {
                if (e.state === 0) { e.x += mvx * sp * dt; e.y += mvy * sp * dt; if (d < 340 && e.t > 1.4 && los) { e.state = 1; e.t = 0; e.aim = ang; } }
                else if (e.state === 1) { if (e.t > 0.7) { e.state = 2; e.t = 0; } }
                else { e.x += Math.cos(e.aim) * 540 * slow * dt; e.y += Math.sin(e.aim) * 540 * slow * dt; if (e.t > 0.55) { e.state = 0; e.t = -0.6; } }
            } else if (e.arch === 'bomber') {
                if (e.fuse > 0) { e.fuse -= dt; if (e.fuse <= 0) { boomAt(e.x, e.y, 85, ed(e) * 1.3, e.def.color); e.hp = 0; removeDead(e); } }
                else { e.x += mvx * sp * dt; e.y += mvy * sp * dt; if (d < 60 && los) e.fuse = 0.6; }
            }
            pushOutOfRocks(e, e.r);
        }
        enemies = enemies.filter(e => e.hp > 0);
    }
    function removeDead(e) { /* enemies配列のhp<=0は次のfilterで消える */ }

    // ボス：パターンを順番に使う
    // ================= 大討伐戦 第一幕：増殖スライム インクリーズ =================
    //  ・常にはねながら動く。着地すると衝撃波。倒すと2体に分裂し、世代が進むほど小さく・速く・弱くなる
    //  ・分裂したスライムが INC_HEART_AT 体になると「増殖の心臓」が現れる。心臓に1発当てれば勝ち（スライムは全部消える）
    //  ・スライムも心臓も、ボス（boss:true）として動く。最後に残った「心臓」を倒したときだけクリア（killEnemy の last 判定）
    const INC_HEART_AT = 10, INC_SPLIT = { hp: 0.62, dmg: 0.88, spd: 1.1, r: 0.8 };
    const INC_COLS = ['#5be37a', '#7de85b', '#a6ea4c', '#d4e84a', '#f0d84a', '#f2b43a'];
    function incAlive() { return enemies.filter(o => o.arch === 'slime' && !o.dead && o.hp > 0); }
    function spawnSlime(par, gen, x, y) {
        const bd = par.bd, c = spawnEnemy({ name: bd.name, icon: bd.icon, arch: 'slime', color: INC_COLS[Math.min(5, gen)] }, x, y, true);
        c.bd = bd; c.gen = gen; c.hopT = rnd(0, 0.3); c.sh = par.sh ? par.sh.slice() : [1, 1, 1, 1, 1]; c.takeMul = 1; c.dmgMul = 1;
        c.maxHp = c.hp = Math.max(1, Math.round(par.maxHp * INC_SPLIT.hp)); c.dmg = par.dmg * INC_SPLIT.dmg; c.spd = par.spd * INC_SPLIT.spd; c.r = Math.max(18, par.r * INC_SPLIT.r);
        pushOutOfRocks(c, c.r);
        return c;
    }
    function spawnHeart(from) {
        let best = null, bd = -1;
        for (let i = 0; i < 8; i++) { const x = rnd(240, WORLD_W - 240), y = rnd(240, WORLD_H - 240), n = nearestPlayer(x, y), dd = n ? dist(x, y, n.x, n.y) : 0; if (dd > bd) { bd = dd; best = { x: x, y: y }; } }
        const h = spawnEnemy({ name: '増殖の心臓', icon: '❤️', arch: 'heart', color: '#ff4d6d' }, best.x, best.y, true);
        h.bd = from.bd; h.heart = true; h.maxHp = h.hp = 1; h.dmg = from.dmg * 1.6; h.r = 26; h.spd = 150; h.sh = from.sh ? from.sh.slice() : [1, 1, 1, 1, 1]; h.takeMul = 1; h.dmgMul = 1; h.beatT = 2.2;
        G.heart = 1; incAlive().forEach(s => { s.spd *= 1.15; });
        netAnnounce('❤ 増殖の心臓が現れた！　一撃を当てれば勝ち！', 3200);
        fx.push({ k: 'ring', x: h.x, y: h.y, r: 0, max: 200, t: 0.8, life: 0.8, c: '#ff4d6d' });
    }
    function incOnDeath(e) {      // スライムが倒された：2体に分裂（心臓が出たあとは、もう増えない）
        if (G.heart) return;
        const g = (e.gen | 0) + 1;
        for (let i = 0; i < 2; i++) { const a = rnd(0, Math.PI * 2); spawnSlime(e, g, clamp(e.x + Math.cos(a) * e.r * 0.7, 40, WORLD_W - 40), clamp(e.y + Math.sin(a) * e.r * 0.7, 40, WORLD_H - 40)); }
        fx.push({ k: 'puff', x: e.x, y: e.y, t: 0.4, life: 0.4, c: e.def.color || '#5be37a' });
        const n = incAlive().length; G.n = n;
        if (n >= INC_HEART_AT) spawnHeart(e); else netAnnounce('🟢 分裂した！　スライム ' + n + ' / ' + INC_HEART_AT + ' 体', 1100);
    }
    function incHeartDown(e) {      // 心臓が砕けた：スライムは全部消える（このあと killEnemy が「最後のボス」として報酬を出す）
        enemies.forEach(o => { if (o.arch === 'slime' && !o.dead) { o.hp = 0; o.dead = true; fx.push({ k: 'puff', x: o.x, y: o.y, t: 0.5, life: 0.5, c: o.def.color || '#5be37a' }); } });
        netAnnounce('💥 心臓が砕けた！　増殖が止まった！', 2600);
    }
    function incHost(dt) { G.n = incAlive().length; }
    function updateSlime(e, dt, tgt, d, ang, slow) {      // 常にはねながら移動する。着地すると衝撃波
        const g = e.gen | 0, hopDur = (0.62 - Math.min(0.16, g * 0.03)) / slow, wait = (0.34 - Math.min(0.22, g * 0.045)) / slow, len = clamp(e.spd * 2.4, 140, 420);
        e.hopT = (e.hopT || 0) + dt;
        if (!e.hopping) {
            e.air = 0;
            if (e.hopT >= wait) { e.hopping = true; e.hopT = 0; const dd = Math.max(1, d), step = d < e.r * 0.8 ? 0 : Math.min(len, dd - e.r * 0.3); e.hx0 = e.x; e.hy0 = e.y; e.hx1 = e.x + Math.cos(ang) * step + rnd(-30, 30); e.hy1 = e.y + Math.sin(ang) * step + rnd(-30, 30); }
        } else {
            const k = Math.min(1, e.hopT / hopDur);
            e.x = e.hx0 + (e.hx1 - e.hx0) * k; e.y = e.hy0 + (e.hy1 - e.hy0) * k; e.air = Math.sin(k * Math.PI) * e.r * 1.5;
            if (k >= 1) { e.hopping = false; e.hopT = 0; e.air = 0; telegraph(e.x, e.y, e.r * 1.6 + 36, 0.42, ed(e) * 1.1, e.def.color); fx.push({ k: 'puff', x: e.x, y: e.y + e.r * 0.6, t: 0.25, life: 0.25, c: '#cfe' }); }
        }
        if (g <= 1) {      // 大きいうちは、ときどき増殖弾をばらまく
            e.sprayT = (e.sprayT == null ? rnd(2.5, 4) : e.sprayT) - dt;
            if (e.sprayT <= 0 && !e.hopping) { e.sprayT = g === 0 ? 5 : 7; const n = g === 0 ? 9 : 5; for (let i = 0; i < n; i++) bullet(e.x, e.y, ang + (i - (n - 1) / 2) * 0.2, 240, ed(e) * 0.7, 8, 3.4, e.def.color); }
        }
    }
    function updateHeart(e, dt, tgt, d, ang, slow) {      // 心臓：プレイヤーから逃げ回りながら、ときどき鼓動で衝撃波を出す
        const want = d < 520 ? -1 : 0, sp = e.spd * slow;
        e.x = clamp(e.x + Math.cos(ang) * sp * want * dt + Math.cos(e.t * 1.7) * 40 * dt, 60, WORLD_W - 60); e.y = clamp(e.y + Math.sin(ang) * sp * want * dt + Math.sin(e.t * 1.3) * 40 * dt, 60, WORLD_H - 60);
        e.beatT -= dt;
        if (e.beatT <= 0) { e.beatT = 3.2; telegraph(e.x, e.y, 230, 0.9, ed(e) * 1.2, '#ff4d6d'); for (let i = 0; i < 10; i++) bullet(e.x, e.y, i * Math.PI * 2 / 10 + e.t, 210, ed(e) * 0.6, 8, 3.2, '#ff7a96'); }
    }
    // ================= 大討伐戦 第二幕：ワールドワーム =================
    //  ① 世界喰らい：外周から足場（円盤）が崩れて奈落に落ちる。落ちると倒れる（足場の縁に倒れて、仲間に起こしてもらえる）
    //  ② 大釣合戦：ワームが地中へ潜り、足元から狙ってくる。ステージ各所のアンカーに乗り続けて、全員で引きずり出す → 長い体がどこも弱点の大チャンス
    //  ③ 体内潜入：ステージの半分のプレイヤーが体内（別の部屋）に丸呑みにされる。外は「硬い鱗」を壊して口の核を、中は「心臓核」を、同じ頃に壊す → 大ダウン
    //  ホスト：wormHost（進行）／全員：wormLocal（落下・酸）。G は全員に配られる見た目用の状態（pr＝足場の半径・wm＝今のモード など）
    // <worm-start>
    const WM = { cx: 1400, cy: 900, R0: 820, RMIN: 380, N: 24, BITE: 80, IN: { x0: 2800, y0: 300, x1: 3700, y1: 1500 }, SEG: 10, GAP: 62 };
    const WM_TAU = Math.PI * 2;
    function wmZone(x) { return x >= WM.IN.x0 - 150 ? 1 : 0; }      // 0＝外（足場）／1＝体内。位置だけで決まる（体内の部屋は、足場から遠く離れている）
    function wmHidden(x) { return GMK === 'worm' && wmZone(x) !== wmZone(me.x); }
    function wmRa(a) { const pr = G.pr; if (!pr || pr.length !== WM.N) return WM.R0; const k = (((a % WM_TAU) + WM_TAU) % WM_TAU) / WM_TAU * WM.N, i0 = Math.floor(k) % WM.N, i1 = (i0 + 1) % WM.N, f = k - Math.floor(k); return pr[i0] * (1 - f) + pr[i1] * f; }
    function wmR(x, y) { return wmRa(Math.atan2(y - WM.cy, x - WM.cx)); }
    function wmOn(x, y, pad) { return Math.hypot(x - WM.cx, y - WM.cy) <= wmR(x, y) + (pad || 0); }
    function wormInit(b) {
        WS = { mode: 'A', t: 0, biteT: 24, q: [], bT: 62, cN: 0, trail: [], segs: [], an: [], anT: 0, swT: 0, cT: 0, acT: 0, dT: 0, lay: null, open: false, inner: null, outer: null, scales: [] };
        G.pr = new Array(WM.N).fill(WM.R0); G.wm = 'A'; G.hid = 0; G.sc = 0; G.cr = []; G.an = []; G.at = 0; G.ct = 0;
        for (let j = Math.ceil(WM.SEG * WM.GAP / 8); j >= 0; j--) WS.trail.push({ x: b.x, y: b.y + j * 8 });      // 体は、最初は頭の下（南）に伸びている
        for (let k = 0; k < WM.SEG; k++) {
            const s = spawnEnemy({ name: 'ワールドワームの体', icon: '🟤', arch: 'wseg', color: '#b08a5a' }, b.x, b.y + (k + 1) * WM.GAP, false);
            s.bd = b.bd; s.maxHp = s.hp = 1e9; s.dmg = b.dmg * 0.5; s.r = Math.max(32, 62 - k * 3); s.spd = 0; s.takeMul = 1; s.dmgMul = 1; WS.segs.push(s);
        }
    }
    function wormSegments(b) {      // 体：頭の通った道に沿って、GAP ずつ離して並ぶ（引きずり出された間は、横たわる）
        if (WS.lay) { WS.segs.forEach((s, k) => { s.x = WS.lay.pts[k].x; s.y = WS.lay.pts[k].y; }); return; }
        const L = WS.trail, last = L[L.length - 1];
        if (!last || Math.hypot(b.x - last.x, b.y - last.y) > 8) { L.push({ x: b.x, y: b.y }); if (L.length > 500) L.shift(); }
        let need = WM.GAP, k = 0, px = b.x, py = b.y;
        for (let i = L.length - 1; i >= 0 && k < WS.segs.length; i--) {
            const q = L[i]; let d = Math.hypot(q.x - px, q.y - py);
            while (d >= need && k < WS.segs.length) { const f = need / d; px += (q.x - px) * f; py += (q.y - py) * f; const s = WS.segs[k++]; s.x = px; s.y = py; d = Math.hypot(q.x - px, q.y - py); need = WM.GAP; }
            need -= d; px = q.x; py = q.y;
        }
        while (k < WS.segs.length) { const s = WS.segs[k++]; s.x = px; s.y = py + 1; }
    }
    function wormLay() {      // 横たわった体：頭を左に、体を右へ（足場がいちばん狭くなっても収まる）
        const span = Math.min.apply(null, G.pr) - 80, step = Math.min(WM.GAP, span * 2 / (WM.SEG + 1)), hx = WM.cx - span, pts = [];
        for (let k = 0; k < WM.SEG; k++) pts.push({ x: hx + (k + 1) * step, y: WM.cy + Math.sin(k * 0.9) * 50 });
        return { head: { x: hx, y: WM.cy }, pts: pts };
    }
    function wormHost(dt) {
        const b = gmBoss(); if (!b || !WS) return;
        WS.t += dt; G.wm = WS.mode;
        const hide = WS.mode === 'B' || WS.mode === 'C'; WS.segs.forEach(s => { s.inv = hide; });      // 潜っている間・口を開けている間は、体を狙えない
        wormSegments(b);
        if (WS.mode === 'A') wormA(b, dt); else if (WS.mode === 'B') wormB(b, dt); else if (WS.mode === 'C') wormC(b, dt); else if (WS.mode === 'D') wormD(b, dt);
        if (WS.mode === 'A' || WS.mode === 'D') wormBites(dt);
        G.cr = WS.q.filter(it => !it.done).map(it => it.i);
    }
    // ---- ① 世界喰らい：足場の崩壊 ----
    function wormBites(dt) {
        WS.biteT -= dt;
        if (WS.biteT <= 0 && !WS.q.length) {
            const s0 = Math.floor(Math.random() * WM.N); for (let k = 0; k < 6; k++) WS.q.push({ i: (s0 + k) % WM.N, t: 1.5 + k * 0.28, done: false, d: 0 });
            WS.biteT = Math.max(16, 30 - WS.t / 40); netAnnounce('🌋 世界喰らい！　足場が崩れる！　外周から離れろ！', 1900);
        }
        WS.q.forEach(it => { if (!it.done) { it.t -= dt; if (it.t <= 0) { it.done = true; it.d = 0.6; G.pr[it.i] = Math.max(WM.RMIN, G.pr[it.i] - WM.BITE); } } else it.d -= dt; });
        WS.q = WS.q.filter(it => !it.done || it.d > 0);
    }
    // ---- 地上戦（技は boss-moves の raid_worm）----
    function wormA(b, dt) {
        b.inv = false;
        if (!wmOn(b.x, b.y, -90)) { const a = Math.atan2(WM.cy - b.y, WM.cx - b.x); b.x += Math.cos(a) * 240 * dt; b.y += Math.sin(a) * 240 * dt; }      // 足場の外に出ないように
        const TH = [0.7, 0.4, 0.15];
        if (WS.cN < 3 && b.hp / b.maxHp <= TH[WS.cN]) { wormStartC(b); return; }
        WS.bT -= dt; if (WS.bT <= 0 && !WS.q.length) wormStartB(b);
    }
    // ---- ② 大釣合戦 ----
    function wormStartB(b) {
        WS.mode = 'B'; WS.bT = 70; WS.q = []; b.inv = true; b.st.stunT = 999; b.mv = null; G.hid = 1; eBullets = []; telegraphs = [];
        const ps = alivePlayersPos().filter(q => wmZone(q.x) === 0), n = clamp(ps.length, 1, 5), rho = Math.min.apply(null, G.pr) * 0.62, off = Math.random() * WM_TAU;
        WS.an = []; for (let i = 0; i < n; i++) { const a = off + i * WM_TAU / n; WS.an.push({ x: WM.cx + Math.cos(a) * rho, y: WM.cy + Math.sin(a) * rho, p: 0 }); }
        WS.anT = 34; WS.swT = 1.2; G.at = 34; G.an = WS.an.map(a => ({ x: Math.round(a.x), y: Math.round(a.y), p: 0 }));
        netAnnounce('🪝 ワームが地中へ潜った！　足元の予兆をよけて、アンカーに乗り続けろ！', 3200);
    }
    function wormB(b, dt) {
        WS.anT -= dt; WS.swT -= dt;
        const ps = alivePlayersPos().filter(q => wmZone(q.x) === 0);
        WS.an.forEach(a => { const occ = ps.some(q => dist(q.x, q.y, a.x, a.y) < 74); a.p = occ ? Math.min(100, a.p + 28 * dt) : Math.max(0, a.p - 10 * dt); });
        if (WS.swT <= 0) {      // 地中から狙う：足元の予兆（1.5秒後に突き上げ）
            WS.swT = 2.4; const v = ps.length ? ps[Math.floor(Math.random() * ps.length)] : null;
            if (v) telegraph(v.x, v.y, 120, 1.5, ed(b) * 2.2, '#c9a27a');
            for (let i = 0; i < 2; i++) { const a = Math.random() * WM_TAU, r = Math.random() * Math.min.apply(null, G.pr) * 0.8; telegraph(WM.cx + Math.cos(a) * r, WM.cy + Math.sin(a) * r, 110, 1.5, ed(b) * 2.0, '#c9a27a'); }
        }
        G.an = WS.an.map(a => ({ x: Math.round(a.x), y: Math.round(a.y), p: Math.round(a.p) })); G.at = Math.max(0, Math.ceil(WS.anT));
        if (WS.an.every(a => a.p >= 100)) wormYank(b);
        else if (WS.anT <= 0) {      // 失敗：ワームが暴れて地上に出る。すぐに地盤沈下
            WS.an = []; G.an = []; G.hid = 0; b.inv = false; b.st.stunT = 0; b.x = WM.cx; b.y = WM.cy; WS.mode = 'A'; WS.bT = 45; WS.biteT = 1.0;
            telegraph(WM.cx, WM.cy, 900, 2.2, ed(b) * 2.0, '#c9a27a', { sh: 'donut', ri: 220 });
            netAnnounce('💢 引きずり出せなかった！　ワームが暴れる！', 2400);
        }
    }
    function wormYank(b) {
        WS.mode = 'D'; WS.an = []; G.an = []; G.hid = 0; b.inv = false; b.st.stunT = 14; b.vuln = 99; WS.dT = 14; WS.lay = wormLay(); b.x = WS.lay.head.x; b.y = WS.lay.head.y;
        netAnnounce('💥 ワームを引きずり出した！　長い体のどこを殴っても大ダメージ！', 3000);
    }
    function wormD(b, dt) {
        WS.dT -= dt;
        if (WS.dT <= 0) { WS.mode = 'A'; WS.lay = null; b.st.stunT = 0; b.vuln = 0; WS.bT = 55; WS.trail = []; for (let j = Math.ceil(WM.SEG * WM.GAP / 8); j >= 0; j--) WS.trail.push({ x: b.x, y: b.y + j * 8 }); netAnnounce('ワームが起き上がった！', 1600); }
    }
    // ---- ③ 体内潜入 ----
    function wormCoreInit(c, b, shielded) { c.bd = b.bd; c.maxHp = c.hp = Math.max(1, Math.round(b.maxHp * 0.04)); c.dmg = 0; c.r = 40; c.spd = 0; c.takeMul = 1; c.dmgMul = 1; c.inv = !!shielded; c.broken = null; c.sh = b.sh ? b.sh.slice() : [1, 1, 1, 1, 1]; }
    function wormStartC(b) {
        WS.cN++; WS.mode = 'C'; WS.q = []; b.inv = true; b.st.stunT = 999; b.mv = null; eBullets = []; telegraphs = [];
        const all = alivePlayersPos(), n = all.length;
        const th = Math.random() * WM_TAU, cs = Math.cos(th), sn = Math.sin(th), k = n >= 2 ? Math.floor(n / 2) : 1;      // ランダムな向きで、いちばん端にいる半分が丸呑みにされる（1人のときは、その1人）
        const ids = all.map(q => ({ id: q.id, v: q.x * cs + q.y * sn })).sort((a, c) => c.v - a.v).slice(0, k).map(o => o.id);
        netSend('gm', { k: 'swal', ids: ids }); if (ids.indexOf(me.id) >= 0) wormEnterInner();
        const outside = n - ids.length, icx = (WM.IN.x0 + WM.IN.x1) / 2, icy = (WM.IN.y0 + WM.IN.y1) / 2;
        const ic = spawnEnemy({ name: '心臓核', icon: '❤️', arch: 'wcore', color: '#ff4d8a' }, icx, icy, false); wormCoreInit(ic, b, outside > 0); WS.inner = ic; WS.outer = null; WS.open = false; WS.scales = [];
        if (outside > 0) {
            const m = clamp(Math.ceil(outside * 1.5), 3, 8);
            for (let i = 0; i < m; i++) { const a = i / m * WM_TAU, r = 170 + 60 * (i % 2), sc = spawnEnemy({ name: '硬い鱗', icon: '🛡', arch: 'wscale', color: '#8fa0b8' }, b.x + Math.cos(a) * r, b.y + Math.sin(a) * r, false); sc.bd = b.bd; sc.maxHp = sc.hp = Math.max(1, Math.round(b.maxHp * 0.012)); sc.dmg = 0; sc.r = 30; sc.spd = 0; sc.takeMul = 1; sc.dmgMul = 1; WS.scales.push(sc); }
        }
        WS.cT = 85; WS.acT = 1.5; G.ct = 85; G.sc = WS.scales.length;
        netAnnounce('🍽 ワームがステージの半分を丸呑みにした！　外：鱗を砕け／体内：心臓核を狙え！', 3600);
    }
    function wormC(b, dt) {
        WS.cT -= dt; G.ct = Math.max(0, Math.ceil(WS.cT));
        const ps = alivePlayersPos(), outN = ps.filter(q => wmZone(q.x) === 0).length;
        WS.acT -= dt; if (WS.acT <= 0) { WS.acT = 2.6; for (let i = 0; i < 3; i++) telegraph(rnd(WM.IN.x0 + 90, WM.IN.x1 - 90), rnd(WM.IN.y0 + 90, WM.IN.y1 - 90), 120, 1.6, ed(b) * 0.9, '#9bd84a'); }      // 体内の酸の池
        if (outN === 0) WS.scales.forEach(s => { if (!s.dead) { s.hp = 0; s.dead = true; } });      // 外に誰もいなければ、鱗は無いものとする
        const left = WS.scales.filter(s => !s.dead && s.hp > 0).length; G.sc = left;
        if (!WS.open && left === 0) {
            WS.open = true; WS.inner.inv = false;
            if (outN > 0) { const oc = spawnEnemy({ name: '口の核', icon: '🟡', arch: 'wcore', color: '#ffd84a' }, b.x, b.y - 130, false); wormCoreInit(oc, b, false); oc.outer = true; WS.outer = oc; }
            netAnnounce('✨ 鱗が砕けた！　口の核と心臓核を、すぐに続けて壊せ！', 3000);
        }
        const cores = [WS.inner, WS.outer].filter(Boolean);
        cores.forEach(c => { if (c.broken != null && WS.t - c.broken > 8) { c.broken = null; c.inv = false; c.hp = c.maxHp; netAnnounce('核が再生した！　もう一度！', 1500); } });
        if (WS.open && cores.every(c => c.broken != null)) { wormCSuccess(b); return; }
        if (WS.cT <= 0) wormCFail(b);
    }
    function wormCoreBreak(e) {      // killEnemy から：核は死なずに「砕けた状態」で待つ。もう一方が8秒以内に砕ければ成功
        e.hp = 1; e.inv = true; e.broken = WS ? WS.t : 0; fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: 120, t: 0.5, life: 0.5, c: e.def.color || '#fff', fill: true });
        const other = WS && [WS.inner, WS.outer].filter(Boolean).length > 1;
        netAnnounce(e.outer ? '口の核が砕けた！' + (other ? '　体内の心臓核も、すぐに！' : '') : '心臓核が砕けた！' + (other ? '　外の口の核も、すぐに！' : ''), 2200);
    }
    function wormCleanup(withSegs) { if (!WS) return; (withSegs ? WS.segs : []).concat(WS.scales, [WS.inner, WS.outer]).forEach(o => { if (o && !o.dead) { o.hp = 0; o.dead = true; } }); }      // withSegs：ボスが倒れたとき、体もすべて消す
    function wormCSuccess(b) {
        wormCleanup(false); netSend('gm', { k: 'eject' }); wormEjectMe();
        b.hp = Math.max(1, b.hp - b.maxHp * 0.05); WS.mode = 'D'; b.inv = false; b.st.stunT = 16; b.vuln = 99; WS.dT = 16; WS.lay = wormLay(); b.x = WS.lay.head.x; b.y = WS.lay.head.y; G.hid = 0; G.sc = 0; G.ct = 0;
        netAnnounce('💥 中と外のコアが同時に砕けた！　ワームが大ダウン！', 3200);
    }
    function wormCFail(b) {
        wormCleanup(false); netSend('gm', { k: 'eject' }); wormEjectMe();
        b.inv = false; b.st.stunT = 0; b.rage = Math.max(b.rage || 1, 1.12); WS.mode = 'A'; WS.bT = 45; WS.biteT = 1.0; G.sc = 0; G.ct = 0;
        telegraph(WM.cx, WM.cy, 900, 2.2, ed(b) * 2.0, '#9bd84a', { sh: 'donut', ri: 220 });
        netAnnounce('💢 コアを壊しきれなかった！　全員が吐き出される！', 2600);
    }
    // </worm-end-host>
    function wormEnterInner() {      // 丸呑みにされる：体内の部屋へ
        me.x = (WM.IN.x0 + WM.IN.x1) / 2 + rnd(-220, 220); me.y = (WM.IN.y0 + WM.IN.y1) / 2 + rnd(150, 380); me.inv = Math.max(me.inv || 0, 1.2); me.fallT = 0;
        popups.push({ x: me.x, y: me.y - 30, t: 1.6, text: '🍽 丸呑みにされた！', c: '#ff9ab0', big: true });
    }
    function wormEjectMe() {      // 吐き出される：足場の中央あたりへ
        if (wmZone(me.x) !== 1) return;
        const a = Math.random() * WM_TAU, r = 120 + Math.random() * 180; me.x = WM.cx + Math.cos(a) * r; me.y = WM.cy + Math.sin(a) * r; me.inv = Math.max(me.inv || 0, 1.2);
        popups.push({ x: me.x, y: me.y - 30, t: 1.4, text: '吐き出された！', c: '#9fe0ff', big: true });
    }
    // <worm-end>
    let WL = { pr: null };
    function wormSafePos() {      // いまの向きのまま、足場の半分の位置（崩れにくい内側）へ
        const a = Math.atan2(me.y - WM.cy, me.x - WM.cx), R = Math.max(120, wmR(me.x, me.y) * 0.5);
        me.x = WM.cx + Math.cos(a) * R; me.y = WM.cy + Math.sin(a) * R;
    }
    function wormFall() {      // 奈落に落ちた：足場の縁に倒れる（仲間が近くに来れば復活できる）
        me.fallT = 0; wormSafePos();      // 落ちたら、足場の内側（縁から離れた所）に倒れる。縁だと、起き上がってもまた崖っぷち
        popups.push({ x: me.x, y: me.y - 30, t: 1.6, text: '🕳 奈落に落ちた！', c: '#ff7a7a', big: true });
        me.hp = 0; me.dead = true; me.reviveT = 0; me.stunT = 0; me.orb = null; if (window.SBSound) SBSound.sfx('defeat'); announce('奈落に落ちた！　仲間が近くに来れば復活できます', 2200);
    }
    function wormShove() {
        const b = gmBoss(); if (!b || wmZone(me.x) === 1 || G.hid) return;
        const d = Math.hypot(me.x - b.x, me.y - b.y); if (d > 520) return;
        const a = Math.atan2(me.y - b.y, me.x - b.x); me.x += Math.cos(a) * 120; me.y += Math.sin(a) * 120;
    }
    function wormLocal(dt) {      // 全員：足場の崩れる演出・落下の判定・体内の酸
        if (G.pr) {
            if (WL.pr) for (let i = 0; i < WM.N; i++) if (G.pr[i] < WL.pr[i] - 1) { const a = (i + 0.5) * WM_TAU / WM.N; if (!wmHidden(WM.cx)) { fx.push({ k: 'puff', x: WM.cx + Math.cos(a) * WL.pr[i], y: WM.cy + Math.sin(a) * WL.pr[i], t: 0.5, life: 0.5, c: '#8a6a40' }); addShake(5, 0.25); } }
            WL.pr = G.pr.slice();
        }
        if (me.dead) { if (wmZone(me.x) === 0 && !wmOn(me.x, me.y, -40)) wormSafePos(); return; }      // 倒れている間に足場が崩れても、起こしてもらったときに崖っぷちにならないように
        if (run.phase !== 'run') return;
        if (wmZone(me.x) === 1) {
            me.x = clamp(me.x, WM.IN.x0 + me.r, WM.IN.x1 - me.r); me.y = clamp(me.y, WM.IN.y0 + me.r, WM.IN.y1 - me.r);
            if (G.wm === 'C') { me.acidT = (me.acidT || 0) + dt; if (me.acidT >= 1.5) { me.acidT = 0; const bb = gmBoss(); hurtMe((bb ? ed(bb) : 0.1) * 0.28); popups.push({ x: me.x, y: me.y - 20, t: 0.6, text: '酸！', c: '#9bd84a' }); } }
        } else if (!wmOn(me.x, me.y, 16)) { me.fallT = (me.fallT || 0) + dt; if (me.fallT > 0.45) wormFall(); }
        else me.fallT = 0;
    }
    function updateBoss(e, dt, tgt, d, ang, slow) {
        if (e.arch === 'slime') { updateSlime(e, dt, tgt, d, ang, slow); return; }
        if (e.arch === 'heart') { updateHeart(e, dt, tgt, d, ang, slow); return; }
        if (e.arch === 'necro') { updateNecro(e, dt, tgt, d, ang, slow); return; }
        if (e.arch === 'machine') { updateMachine(e, dt, tgt, d, ang, slow); return; }
        if (e.arch === 'ningen') { updateNingen(e, dt, tgt, d, ang, slow); return; }
        const hpR = e.hp / e.maxHp;
        if (!e.enraged && hpR < 0.5) { e.enraged = true; netAnnounce('ボスが激昂した！', 1800); }
        const pats = bdef(e).patterns, SET = setOf(e);
        // 歩行
        if (e.state === 0 && !bdef(e).stand) { const sp = e.spd * slow * (e.enraged ? 1.3 : 0.8); if (d > 150) { e.x += Math.cos(ang) * sp * dt; e.y += Math.sin(ang) * sp * dt; } }
        // 技セット(boss-moves.js)があるボスは技の合間を短めにして、技そのものの見せ場を増やす
        const cdMax = (SET ? (e.enraged ? 0.7 : 1.2) * (SET.cdMul || 1) : (e.enraged ? 1.1 : 1.9)) / (DIFF.dmg > 1.5 ? 1.15 : 1);      // SET.cdMul：大討伐戦ボスは技の合間が短い
        if (e.state === 0 && e.t > cdMax) {
            if (SET) { const md = pickMove(e); if (md) { startMove(e, md, ang); return; } }
            const pat = pats[e.patIdx % pats.length]; e.patIdx++; e.t = 0;
            const k = ed(e) * (e.enraged ? 1.15 : 1);
            if (pat === 'radial') { const n = e.enraged ? 26 : 18, off = rnd(0, 6.28); for (let i = 0; i < n; i++) bullet(e.x, e.y, off + i * Math.PI * 2 / n, 250, k, 8, 4, bdef(e).color); }
            else if (pat === 'volley') { const n = e.enraged ? 11 : 7; for (let i = 0; i < n; i++) bullet(e.x, e.y, ang + (i - (n - 1) / 2) * 0.17, 360, k, 8, 3.2, bdef(e).color); }
            else if (pat === 'slam') { const alive = alivePlayersPos(); alive.forEach(p => telegraph(p.x, p.y, 120, 1.2, k * 1.6, bdef(e).color)); telegraph(e.x, e.y, 150, 1.2, k * 1.4, bdef(e).color); }
            else if (pat === 'charge') { e.state = 1; e.aim = ang; e.t = 0; }
            else if (pat === 'summon') { const def = stage.enemies[0]; for (let i = 0; i < (e.enraged ? 6 : 4); i++) { const m = spawnEnemy(def, e.x + rnd(-120, 120), e.y + rnd(-120, 120), false); m.hp = m.maxHp = Math.round(m.maxHp * 0.7); } }
            else if (pat === 'spiral') { e.state = 3; e.t = 0; e.spin = 0; }
        } else if (e.state >= 10 && e.mv) { // 技の実行中
            runMove(e, dt);
        } else if (e.state === 1) { // 突進（予告0.6秒→突進0.7秒）
            if (e.t < 0.6) { /* 予告中：その場で構える */ } else if (e.t < 1.3) { e.x += Math.cos(e.aim) * 620 * dt; e.y += Math.sin(e.aim) * 620 * dt; } else { e.state = 0; e.t = 0; }
        } else if (e.state === 3) { // 渦巻き弾
            e.spin += dt * 9; if (Math.floor(e.t * 14) !== Math.floor((e.t - dt) * 14)) { bullet(e.x, e.y, e.spin, 240, ed(e) * 0.8, 7, 4, bdef(e).color); bullet(e.x, e.y, e.spin + Math.PI, 240, ed(e) * 0.8, 7, 4, bdef(e).color); }
            if (e.t > 2.2) { e.state = 0; e.t = 0; }
        }
    }

    // ---------- ボスの技エンジン（技の中身は boss-moves.js）----------
    // 技は「時刻つきステップ」の並び。ホストだけが実行し、範囲攻撃は予告(telegraph)→着弾(boom)で全員に伝わる。
    const BOSS_SET = (BM && BM.SETS && BM.SETS[stage.id]) || null;

    // ---------- ギミックボス（stage.boss.gimmick）----------
    //  stigma    : 死神。10秒ごとに全員へスティグマ。13個で死亡（HP75/50/25%を切るたびに4個浄化）
    //  pressure  : 炉心の巨人。25秒ごとに圧力が溜まり、安全弁を全部壊さないと大爆発
    //  gravity   : 重力喰らい。技「pull」で全員を中心へ引き寄せる
    //  twin      : ゼウス＆プロメテウス。片方を倒すと、15秒後に残った方が蘇らせる
    //  dimension : ディメンション・キーパー。6つの核（放射弾をスキルで跳ね返して破壊）→ 強化ゲートキーパー（歴代ラスボス召喚）
    const GMK = (stage.boss && stage.boss.gimmick) || null;
    let G = {};                      // ギミックの共有状態。ホストが管理し、スナップショットで全員へ配る
    let pullFx = null;               // 引き寄せ中 { x, y, t, f }
    let stgLastS = 0, stgLastC = 0;
    const STIGMA_MAX = 13, STIGMA_EVERY = 10, REFL_R = 210;
    const DK_ECHO = [['abyssal_rift', 0.80], ['rift_throne', 0.62], ['god_throne', 0.45], ['mech_throne', 0.30], ['void_throne', 0.15]];   // 歴代ラスボス（HPがこの割合を切るたびに1体ずつ）
    function bdef(e) { return (e && e.bd) || stage.boss; }
    function setOf(e) { return (e && e.bset) || BOSS_SET; }
    function pickMove(e) {
        if (e.vz === 'f') return vzPick(e);      // 魔装合体ヴェルスザーク：距離で技を選ぶ
        const BOSS_SET = setOf(e);
        e.mvCount = (e.mvCount || 0) + 1;
        const every = e.enraged ? 3 : 4;                        // 4回に1回（激昂中は3回に1回）はスタン技
        // 大技：HPが ultAt の割合を切るたびに1回ずつ。激昂中は7回に1回も出す
        const ult = BOSS_SET.ult && BM.MOVES[BOSS_SET.ult];
        if (ult) {
            e.ultN = e.ultN || 0;
            if (e.ultN < BOSS_SET.ultAt.length && e.hp / e.maxHp < BOSS_SET.ultAt[e.ultN]) { e.ultN++; return ult; }
            if (e.enraged && e.mvCount % 7 === 0) return ult;
        }
        if (e.mvCount % every === 0 && BM.MOVES[BOSS_SET.stun]) return BM.MOVES[BOSS_SET.stun];
        const list = BOSS_SET.moves; e.mvIdx = e.mvIdx || 0;
        if (BOSS_SET.rnd && list.length > 1) {                  // 大討伐戦ボス：技の順番はランダム（直前と同じ技は続けない）
            let k, tries = 0; do { k = Math.floor(Math.random() * list.length); } while (k === e.mvLast && ++tries < 8);
            e.mvLast = k; return BM.MOVES[list[k]] || null;
        }
        const m = BM.MOVES[list[e.mvIdx % list.length]]; e.mvIdx++;
        return m || null;
    }
    function startMove(e, def, ang) {
        e.state = 10; e.t = 0;
        e.mv = { def: def, t: 0, i: 0, ang: ang, act: null, wAng: null };
        if (def.ult) netAnnounce('💥 大技「' + def.name + '」', 2600);
        else netAnnounce((def.stun ? '⚡ ' : '⚔ ') + def.name + (def.stun ? '！　当たるとスタン' : ''), def.stun ? 1500 : 1000);
    }
    function endMove(e) {
        const rec = e.mv ? e.mv.def.rec : 0.5;
        e.mv = null; e.state = 0; e.air = 0; e.t = -rec;
    }
    function runMove(e, dt) {
        const m = e.mv;
        m.t += dt;
        const a = m.act;
        if (a) {
            a.el += dt;
            if (a.k === 'dash') {
                e.state = 11;
                e.x += Math.cos(a.ang) * a.spd * dt; e.y += Math.sin(a.ang) * a.spd * dt;
                e.x = clamp(e.x, 50, WORLD_W - 50); e.y = clamp(e.y, 50, WORLD_H - 50);
                if (a.el >= a.dur) { m.act = null; e.state = 10; }
            } else if (a.k === 'leap') {
                e.state = 12;
                const p = Math.min(1, a.el / a.dur);
                e.x = a.sx + (a.tx - a.sx) * p; e.y = a.sy + (a.ty - a.sy) * p;
                e.air = Math.sin(p * Math.PI) * 130;
                if (p >= 1) { m.act = null; e.air = 0; e.state = 10; }
            } else if (a.k === 'spiral') {
                a.spin += dt * 9; a.acc += dt;
                while (a.acc >= 1 / 14) {
                    a.acc -= 1 / 14;
                    for (let i = 0; i < a.arms; i++) bullet(e.x, e.y, a.spin + i * Math.PI * 2 / a.arms, a.spd, a.dmg, 7, 4, a.c || bdef(e).color);
                }
                if (a.el >= a.dur) m.act = null;
            }
        }
        const steps = m.def.steps;
        while (m.i < steps.length && steps[m.i].t <= m.t) { execStep(e, m, steps[m.i]); m.i++; }
        if (m.i >= steps.length && !m.act && m.t >= m.def.dur) endMove(e);
    }
    function execStep(e, m, s) {
        const en = e.enraged;
        const k = ed(e) * (en ? 1.15 : 1);
        const dmg = k * (s.dm || 0);
        const tm = en ? 0.85 : 1;                                   // 激昂中は予告が少し短い
        const c = s.stun ? '#ffd84a' : (s.c || bdef(e).color);
        const aimNow = () => { const p = nearestPlayer(e.x, e.y); return p ? Math.atan2(p.y - e.y, p.x - e.x) : m.ang; };
        const ang = (s.aim === 'l' ? m.ang : aimNow()) + (s.off || 0) * Math.PI / 180;
        const shape = { stun: s.stun, rep: s.rep, gap: s.gap };
        switch (s.k) {
            case 'tp': {        // 瞬間移動：いちばん近いプレイヤーの近くへ一瞬で詰める（魔装合体ヴェルスザーク）
                const p = nearestPlayer(e.x, e.y); if (!p) break;
                const a0 = Math.random() * Math.PI * 2, gp = s.gap || 120;
                fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: 150, t: 0.4, life: 0.4, c: '#ffe9a0', fill: true });
                e.x = clamp(p.x + Math.cos(a0) * gp, 50, WORLD_W - 50); e.y = clamp(p.y + Math.sin(a0) * gp, 50, WORLD_H - 50);
                fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: 200, t: 0.45, life: 0.45, c: '#ff5a6a', fill: true });
                addShake(6, 0.2); m.ang = Math.atan2(p.y - e.y, p.x - e.x);
                break;
            }
            case 'beamfan': {   // ボスから扇状に、細いビームを何本も撃つ
                const n = Math.max(1, s.n | 0);
                for (let i = 0; i < n; i++) telegraph(e.x, e.y, s.r, s.tele * tm, dmg, c, Object.assign({ sh: 'line', a: ang + (n > 1 ? (i - (n - 1) / 2) * (s.sp || 0) / (n - 1) : 0), w: s.w }, shape));
                break;
            }
            case 'beamAt': {    // アリーナ上の決まった位置（割合 fx,fy）から撃つビーム。track なら撃つ向きを標的に合わせる
                const x = s.fx * WORLD_W, y = s.fy * WORLD_H; let a = s.a;
                if (s.track) { const p = nearestPlayer(x, y); if (p) a = Math.atan2(p.y - y, p.x - x); }
                telegraph(x, y, s.r, s.tele * tm, dmg, c, Object.assign({ sh: 'line', a: a, w: s.w }, shape));
                break;
            }
            case 'blast': {     // 標的の周りに砲口を並べ、標的へ向けて撃つ（ガスターブラスター風）
                const al = alivePlayersPos(); if (!al.length) break;
                const tg = al[Math.floor(Math.random() * al.length)], n = Math.round(s.n * (en ? 1.15 : 1)), R = s.R || 440, off = rnd(0, 6.28);
                for (let i = 0; i < n; i++) {
                    const a0 = off + i * Math.PI * 2 / n, x = clamp(tg.x + Math.cos(a0) * R, 40, WORLD_W - 40), y = clamp(tg.y + Math.sin(a0) * R, 40, WORLD_H - 40);
                    telegraph(x, y, 40, s.tele * tm, 0, '#ffd36a', { sh: 'portal' });
                    telegraph(x, y, s.r, s.tele * tm, dmg, c, Object.assign({ sh: 'line', a: Math.atan2(tg.y - y, tg.x - x), w: s.w }, shape));
                }
                break;
            }
            case 'wall': {      // 画面を横切る弾の壁。隙間が1か所だけある
                const al = alivePlayersPos(); const tg = al.length ? al[Math.floor(Math.random() * al.length)] : { x: WORLD_W / 2, y: WORLD_H / 2 };
                const horiz = s.dir === 'h' || (s.dir === 'rand' && Math.random() < 0.5), gapW = (s.gapW || 190) * (en ? 0.92 : 1), sp = s.spd || 320, step = 30;
                if (horiz) {
                    const gx = clamp(tg.x + rnd(-260, 260), gapW, WORLD_W - gapW), fromTop = Math.random() < 0.5;
                    for (let x = 14; x < WORLD_W; x += step) if (Math.abs(x - gx) > gapW / 2) bullet(x, fromTop ? -10 : WORLD_H + 10, fromTop ? Math.PI / 2 : -Math.PI / 2, sp, dmg, 10, WORLD_H / sp + 0.8, c);
                } else {
                    const gy = clamp(tg.y + rnd(-200, 200), gapW, WORLD_H - gapW), fromLeft = Math.random() < 0.5;
                    for (let y = 14; y < WORLD_H; y += step) if (Math.abs(y - gy) > gapW / 2) bullet(fromLeft ? -10 : WORLD_W + 10, y, fromLeft ? 0 : Math.PI, sp, dmg, 10, WORLD_W / sp + 0.8, c);
                }
                break;
            }
            case 'cone': telegraph(e.x, e.y, s.r, s.tele * tm, dmg, c, Object.assign({ sh: 'cone', a: ang, arc: s.arc }, shape)); break;
            case 'line': telegraph(e.x, e.y, s.r, s.tele * tm, dmg, c, Object.assign({ sh: 'line', a: ang, w: s.w }, shape)); break;
            case 'warn': m.wAng = ang; telegraph(e.x, e.y, s.r, s.tele * tm, 0, '#ff9a5a', { sh: 'line', a: ang, w: s.w }); break;
            case 'ring': telegraph(e.x, e.y, s.r, s.tele * tm, dmg, c, shape); break;
            case 'donut': telegraph(e.x, e.y, s.r, s.tele * tm, dmg, c, Object.assign({ sh: 'donut', ri: s.ri }, shape)); break;
            case 'at': {
                const al = alivePlayersPos(); if (!al.length) break;
                const list = s.who === 'rand' ? [al[Math.floor(Math.random() * al.length)]] : al;
                list.forEach(p => telegraph(p.x, p.y, s.r, s.tele * tm, dmg, c, shape));
                break;
            }
            case 'rain': {
                const al = alivePlayersPos(); if (!al.length) break;
                const n = Math.round(s.n * (en ? 1.25 : 1));
                for (let i = 0; i < n; i++) {
                    const b = al[Math.floor(Math.random() * al.length)];
                    const x = i === 0 ? b.x : clamp(b.x + rnd(-380, 380), 40, WORLD_W - 40), y = i === 0 ? b.y : clamp(b.y + rnd(-300, 300), 40, WORLD_H - 40);
                    telegraph(x, y, s.r, s.tele * tm + i * (s.gap || 0.15), dmg, c, shape);
                }
                break;
            }
            case 'dash': {
                const da = (s.aim === 'l' ? m.ang : (m.wAng != null ? m.wAng : aimNow())) + (s.off || 0) * Math.PI / 180;
                m.act = { k: 'dash', el: 0, dur: s.dur, spd: s.spd, ang: da };
                break;
            }
            case 'leap': {
                const p = nearestPlayer(e.x, e.y); const tx = clamp(p ? p.x : e.x, 60, WORLD_W - 60), ty = clamp(p ? p.y : e.y, 60, WORLD_H - 60);
                telegraph(tx, ty, s.r, s.dur, dmg, c, shape);                 // 着地点を予告（着地の瞬間に爆発）
                m.act = { k: 'leap', el: 0, dur: s.dur, sx: e.x, sy: e.y, tx: tx, ty: ty };
                break;
            }
            case 'pull': {    // 全員を、ボスの足元へ引き寄せる（重力）
                gmPullStart(e.x, e.y, s.dur, s.force);
                netSend('gm', { k: 'pull', x: Math.round(e.x), y: Math.round(e.y), dur: s.dur, f: s.force });
                break;
            }
            case 'ports': {   // ゲートキーパー：標的の周りに「門」を開く
                const al = alivePlayersPos(); if (!al.length) break;
                const tg = al[Math.floor(Math.random() * al.length)];
                const n = Math.round(s.n * (en ? 1.2 : 1)), R = s.R || 420, list = [];
                const cl = (v, hi) => clamp(v, 40, hi - 40);
                if (s.mode === 'around') { const off = rnd(0, 6.28); for (let i = 0; i < n; i++) { const a0 = off + i * Math.PI * 2 / n, x = cl(tg.x + Math.cos(a0) * R, WORLD_W), y = cl(tg.y + Math.sin(a0) * R, WORLD_H); list.push({ x: x, y: y, a: Math.atan2(tg.y - y, tg.x - x) }); } }
                else if (s.mode === 'sky') { for (let i = 0; i < n; i++) list.push({ x: cl(tg.x + (i - (n - 1) / 2) * (s.gapX || 140) + rnd(-20, 20), WORLD_W), y: cl(tg.y - R, WORLD_H), a: Math.PI / 2 }); }
                else if (s.mode === 'side') { for (let i = 0; i < n; i++) { const left = i % 2 === 0; list.push({ x: cl(tg.x + (left ? -R : R), WORLD_W), y: cl(tg.y + (i - (n - 1) / 2) * (s.gapY || 170), WORLD_H), a: left ? 0 : Math.PI }); } }
                else if (s.mode === 'diag') { for (let i = 0; i < n; i++) { const a0 = (45 + 90 * i) * Math.PI / 180, x = cl(tg.x + Math.cos(a0) * R, WORLD_W), y = cl(tg.y + Math.sin(a0) * R, WORLD_H); list.push({ x: x, y: y, a: Math.atan2(tg.y - y, tg.x - x) }); } }
                list.forEach(p => telegraph(p.x, p.y, 46, s.life, 0, '#ffd36a', { sh: 'portal' }));
                m.ports = list;
                break;
            }
            case 'swords': {  // 開いている門から剣を撃つ
                const list = m.ports || [], al = alivePlayersPos();
                list.forEach(p => {
                    if (s.frac < 1 && Math.random() > s.frac) return;
                    let a = p.a;
                    if (s.track && al.length) { let best = al[0], bd = 1e9; al.forEach(q => { const dd = dist(p.x, p.y, q.x, q.y); if (dd < bd) { bd = dd; best = q; } }); a = Math.atan2(best.y - p.y, best.x - p.x); }
                    const per = s.per || 1;
                    for (let k = 0; k < per; k++) bullet(p.x, p.y, a + (per > 1 ? (k - (per - 1) / 2) * (s.sp || 0.12) : 0) + rnd(-0.03, 0.03), s.spd, dmg, 10, 3.8, '#ffe9a0', 1);
                });
                break;
            }
            case 'beams': {   // 開いている門からビームを撃つ（予告線→発射）
                const list = m.ports || [], al = alivePlayersPos();
                list.forEach(p => {
                    if (s.frac < 1 && Math.random() > s.frac) return;
                    let a = p.a;
                    if (s.track && al.length) { let best = al[0], bd = 1e9; al.forEach(q => { const dd = dist(p.x, p.y, q.x, q.y); if (dd < bd) { bd = dd; best = q; } }); a = Math.atan2(best.y - p.y, best.x - p.x); }
                    telegraph(p.x, p.y, s.r, s.tele * tm, dmg, '#fff2a0', Object.assign({ sh: 'line', a: a, w: s.w }, shape));
                });
                break;
            }
            case 'fan': { const n = Math.round(s.n * (en ? 1.3 : 1)); for (let i = 0; i < n; i++) bullet(e.x, e.y, ang + (i - (n - 1) / 2) * s.sp, s.spd, dmg, 8, 3.4, s.c || bdef(e).color); break; }
            case 'rad': { const n = Math.round(s.n * (en ? 1.3 : 1)), off = rnd(0, 6.28); for (let i = 0; i < n; i++) bullet(e.x, e.y, off + i * Math.PI * 2 / n, s.spd, dmg, 8, 4, s.c || bdef(e).color); break; }
            case 'spiral': m.act = { k: 'spiral', el: 0, dur: s.dur, spd: s.spd, arms: s.arms || 2, acc: 0, spin: rnd(0, 6.28), dmg: dmg, c: s.c || null }; break;
            case 'summon': {
                const def = stage.enemies[0], n = Math.round(s.n * (en ? 1.4 : 1));
                for (let i = 0; i < n; i++) { const mm = spawnEnemy(def, e.x + rnd(-120, 120), e.y + rnd(-120, 120), false); mm.hp = mm.maxHp = Math.round(mm.maxHp * 0.7); }
                break;
            }
        }
    }

    function boomAt(x, y, r, dmg, c, o) {
        const d = { x: x, y: y, r: r, dmg: dmg, c: c };
        if (o) Object.keys(o).forEach(k => { if (o[k] != null && o[k] !== false) d[k] = o[k]; });
        onBoom(d);
        if (isHost) netSend('boom', d);
    }
    // 範囲攻撃の当たり判定（円／扇／直線／ドーナツ）
    function inShape(d, px, py, pr) {
        const dd = dist(px, py, d.x, d.y);
        if (d.sh === 'cone') {
            if (dd > d.r + pr) return false;
            if (dd < pr + 22) return true;
            let da = Math.atan2(py - d.y, px - d.x) - d.a; da = Math.atan2(Math.sin(da), Math.cos(da));
            return Math.abs(da) <= d.arc / 2;
        }
        if (d.sh === 'line') return distSeg(px, py, d.x, d.y, d.x + Math.cos(d.a) * d.r, d.y + Math.sin(d.a) * d.r) < (d.w || 60) / 2 + pr;
        if (d.sh === 'donut') return dd < d.r + pr && dd > (d.ri || 0) - pr;
        return dd < d.r + pr;
    }
    function onBoom(d) {
        if (d.sh === 'portal') return;   // 門は見た目だけ（ダメージ・爆発演出なし）
        const col = d.c || '#ff9a3a';
        if (d.sh === 'cone') fx.push({ k: 'arc', x: d.x, y: d.y, a: d.a, rng: d.r, arc: d.arc, t: 0.28, life: 0.28, c: col });
        else if (d.sh === 'line') fx.push({ k: 'line', x: d.x, y: d.y, x2: d.x + Math.cos(d.a) * d.r, y2: d.y + Math.sin(d.a) * d.r, t: 0.25, life: 0.25, c: col, w: d.w || 60 });
        else fx.push({ k: 'ring', x: d.x, y: d.y, r: 0, max: d.r, t: 0.35, life: 0.35, c: col, fill: true });
        if (!me.dead && d.dmg > 0 && inShape(d, me.x, me.y, me.r)) hurtMe(d.dmg, { stun: !!d.stun });
    }

    function netAnnounce(text, ms) { announce(text, ms); if (isHost) netSend('announce', { text: text, ms: ms }); }

    // ---------- ダメージ処理 ----------
    // 自分の攻撃が敵に当たったとき：ホストなら直接、そうでなければホストへ送る
    // ---------- オンラインマッチ（アクション対戦）----------
    //  ・相手は自分の画面では「敵」として扱う（pvp ダミー）ので、武器・スキル・特殊効果は今までの攻撃がそのまま使える
    //  ・ダメージはステータスに関係なく「相手の最大HPの割合」。基準の一撃（自分の素のステータスでの武器1振り）= 4.5%
    //    → 武器の％・種類・クリティカル・スキル・特殊効果の勝負になる（ステータス差で圧倒されない）
    const PVP_BASE = 0.045, PVP_REF = HW.HIT_BASE * (0.6 + base.atk / 150);
    const pvpDummies = {};
    function syncPvpDummies() {
        const list = [];
        Object.keys(allies).forEach(id => {
            const a = allies[id]; if (a.dead) return;
            if (sameTeam(id)) return;      // チーム戦：味方には攻撃が当たらない
            let d = pvpDummies[id];
            if (!d) d = pvpDummies[id] = { id: 'pv:' + id, pvp: true, pid: id, def: { name: a.name, icon: '🧑', color: '#fff' }, arch: 'chaser', boss: false, elite: false, r: 16, maxHp: 100, hp: 100, flash: 0, kx: 0, ky: 0, state: 0, air: 0,
                st: { burn: 0, burnT: 0, poison: 0, poisonT: 0, slowT: 0, stunT: 0, bleed: 0, bleedT: 0, curseT: 0, weakenT: 0, blindT: 0 } };
            d.x = a.x; d.y = a.y; d.hp = Math.max(1, (a.maxHp ? a.hp / a.maxHp : 1) * 100);
            list.push(d);
        });
        enemies = list;
    }
    function dealPvp(e, dmg, o) {
        if (e.ghost) { ghostHurt(e, dmg, o); return; }      // ゴースト戦：通信せず、その場で当てる
        // 1発のダメージ（相手の最大HPに対する割合）。上限はなし（通信の異常値だけ弾く）。サドンデスで時間とともに攻撃力が上がる
        let f = PVP_BASE * dmg / PVP_REF * sdAtkMul(); if (!isFinite(f) || f < 0) f = 0; f = Math.min(f, 100);
        popups.push({ x: e.x + rnd(-8, 8), y: e.y - e.r - 6, t: 0.7, text: (f * 100).toFixed(1) + '%', c: o.crit ? '#ffd84a' : '#fff', big: !!o.crit });
        run.stats.dmg += f * 100; e.flash = 0.1;
        const st = o.st && o.st.stun ? { stun: Math.min(PVP_STUN_MAX, typeof o.st.stun === 'number' ? o.st.stun : 1) } : null;
        netSend('pvph', { to: e.pid, f: +f.toFixed(4), kx: Math.round(o.kx || 0), ky: Math.round(o.ky || 0), st: st, pj: pvpProj ? 1 : 0 });
    }
    // 相手の攻撃を受けたとき（ダメージは自分の最大HPの割合）
    function hurtPvp(f, kx, ky, st, by, pj) {
        if (me.dead || me.invHard > 0 || run.phase !== 'run' || me.inv > 0) return;
        if (pj && window.ClassForms && ClassForms.pvpBlock && ClassForms.pvpBlock(f, by)) return;      // 職業：魔断ち・反射の構え・スペル・イーターが、相手の飛び道具を消す
        if (me.guardT > 0) { guardBlock(); return; }
        if (Math.random() < Math.min(0.5, A('dodge'))) { popups.push({ x: me.x, y: me.y - 24, t: 0.6, text: 'MISS', c: '#9fe0ff' }); me.inv = 0.1; return; }
        if (me.shield) { me.shield = false; popups.push({ x: me.x, y: me.y - 24, t: 0.7, text: 'BARRIER', c: '#9fe0ff' }); me.inv = 0.4; return; }
        let dmg = Math.max(1, Math.round(f * me.maxHp * (1 - Math.min(0.75, Math.max(-0.5, A('dr'))) * sdDefMul()) * (1 + A('dmgTaken')) * (me.stunT > 0 ? 1 - 0.4 * sdDefMul() : 1) * (me.cutT > 0 ? (me.cutMul || 0.5) : 1)));   // サドンデスで、ダメージ軽減（防御）の効き目が下がっていく
        if (me.barrierHp > 0) { const ab = Math.min(dmg, me.barrierHp); me.barrierHp -= ab; dmg -= ab; popups.push({ x: me.x, y: me.y - 30, t: 0.7, text: 'BARRIER-' + Math.round(ab), c: '#7fc8ff' }); if (dmg <= 0) { me.inv = 0.1; return; } }
        const lost = Math.min(me.hp, dmg);
        me.hp -= dmg; me.inv = 0.06; me.flash = 0.2;
        popups.push({ x: me.x, y: me.y - 24, t: 0.8, text: '-' + dmg, c: '#ff7b7b', big: true });
        if (by) { const pct = +(lost / me.maxHp * 100).toFixed(2); tallyDmg(by, pct); netSend('pvpd', { by: by, p: pct }); }   // 実際に減った分を「与ダメージ」として、全員の画面で記録する
        if (kx || ky) { moveSolid(me, clamp(kx, -400, 400) * 0.05, clamp(ky, -400, 400) * 0.05, me.r); }
        if (me.hp <= 0 && AB('guts') && !(me.gutsT > 0)) { me.hp = 1; me.gutsT = 45; me.inv = Math.max(me.inv, 1.0); popups.push({ x: me.x, y: me.y - 40, t: 1.3, text: '根性！ HP1で耐えた', c: '#ffd84a', big: true }); }
        if (me.hp <= 0) { me.hp = 0; me.dead = true; me.stunT = 0; me.orb = null; announce('倒れた…　決着を見届けよう', 2400); }
        else if (st && st.stun) stunMe(st.stun);
    }
    // 総合ダメージ量（相手の最大HPに対する%の合計）。time-up のときに多い方が勝つ
    function tallyDmg(id, pct) { run.pvpDmg = run.pvpDmg || {}; run.pvpDmg[id] = (run.pvpDmg[id] || 0) + pct; }
    function dmgOf(id) { return (run.pvpDmg && run.pvpDmg[id]) || 0; }
    function pvpHostCheck() {
        if (run.ended || run.phase !== 'run') return;
        if (TEAM) {           // チーム戦：片方のチームが全滅したら決着。時間切れは、チームの残りHP割合の合計で判定
            const sum = [0, 0], cnt = [0, 0];
            const add = (id, f) => { const t = teamMap[id]; if (t === 0 || t === 1) { sum[t] += f; cnt[t]++; } };
            if (!me.dead) add(myId, me.hp / me.maxHp);
            Object.keys(allies).forEach(id => { const a = allies[id]; if (!a.dead) add(id, a.maxHp ? a.hp / a.maxHp : 1); });
            if (run.time > 4 && (cnt[0] === 0 || cnt[1] === 0)) endPvpTeam(cnt[0] > 0 ? 0 : (cnt[1] > 0 ? 1 : -1), 'last');
            else if (run.time > TIME_LIMIT) {     // 時間切れ：チーム全員の総合ダメージ量が多い方の勝ち（同じなら引き分け）
                const dsum = [0, 0]; const addD = id => { const t = teamMap[id]; if (t === 0 || t === 1) dsum[t] += dmgOf(id); };
                addD(myId); Object.keys(allies).forEach(addD);
                endPvpTeam(dsum[0] > dsum[1] ? 0 : (dsum[1] > dsum[0] ? 1 : -1), 'time');
            }
            return;
        }
        const alive = [];
        if (!me.dead) alive.push({ id: myId, f: me.hp / me.maxHp });
        Object.keys(allies).forEach(id => { const a = allies[id]; if (!a.dead) alive.push({ id: id, f: a.maxHp ? a.hp / a.maxHp : 1 }); });
        if (run.time > 4 && alive.length <= 1) endPvp(alive[0] ? alive[0].id : null, 'last');
        else if (run.time > TIME_LIMIT) {      // 時間切れ：生き残っている人のうち、総合ダメージ量がいちばん多い人の勝ち（同じなら残りHPが多い方）
            alive.sort((x, y) => (dmgOf(y.id) - dmgOf(x.id)) || (y.f - x.f));
            endPvp(alive[0] ? alive[0].id : null, 'time');
        }
    }
    function endPvpTeam(team, reason) {      // team: 0/1＝勝ったチーム、-1＝引き分け
        if (run.ended) return;
        run.ended = true;
        const d = { winnerTeam: team, reason: reason, dmg: run.pvpDmg || {} };
        netSend('end', d);
        finish(team >= 0 && team === teamMap[myId], d);
    }
    function endPvp(winnerId, reason) {
        if (run.ended) return;
        run.ended = true;
        const d = { winner: winnerId, reason: reason, dmg: run.pvpDmg || {} };
        netSend('end', d);
        finish(winnerId === myId, d);
    }

    function dealHit(e, dmg, o) {
        o = o || {};
        if (e.pvp) { dealPvp(e, dmg, o); return; }
        if (e.arch === 'machine' && !G.crash) {      // 機械真王：バリア中は無効／空にいる間は、近づいて殴る攻撃は上昇気流に乗っていないと届かない
            if (G.bar > 0) { if ((e.invAt || 0) < Date.now() - 600) { e.invAt = Date.now(); popups.push({ x: e.x, y: e.y - e.r - 8, t: 0.8, text: 'バリア！', c: '#7fd8ff' }); } e.flash = 0.05; return; }
            if (G.mfl && !pvpProj && !(me.udT > 0) && dist(me.x, me.y, e.x, e.y) < 260) { if ((e.invAt || 0) < Date.now() - 700) { e.invAt = Date.now(); popups.push({ x: me.x, y: me.y - 30, t: 0.9, text: '届かない！上昇気流へ', c: '#ffe08a' }); } return; }
        }
        if (e.inv) {   // ギミックで守られている間はダメージが通らない
            if ((e.invAt || 0) < Date.now() - 700) { e.invAt = Date.now(); popups.push({ x: e.x, y: e.y - e.r - 8, t: 0.8, text: 'ガード中', c: '#7fffd4' }); }
            e.flash = 0.05; return;
        }
        if (window.ClassPerks && dmg > 0) dmg = ClassPerks.dealMul(e, dmg);              // 職業パーク：与ダメージの補正
        const els = SE ? (o.el !== undefined ? o.el : WEL) : [];
        if (els && els.length && dmg > 0) dmg += elemHit(e, dmg, els, o);
        const d = { eid: e.id, dmg: dmg, st: o.st || null, kx: o.kx || 0, ky: o.ky || 0, by: myId, crit: !!o.crit };
        if (dmg > 0) {
            run.stats.dmg += dmg;
            popups.push({ x: e.x + rnd(-8, 8), y: e.y - e.r - 6, t: 0.7, text: String(Math.round(dmg)), c: o.crit ? '#ffd84a' : (o.elc || '#fff'), big: !!o.crit });
        }
        e.flash = 0.1;
        if (window.SBSound && dmg > 0) SBSound.sfx(o.crit ? 'crit' : 'hit');
        if (isHost) applyHit(d); else { queueHit(d); e.hp = Math.max(0, e.hp - dmg * (e.takeMul || 1)); }
        if (dmg > 0 && window.ClassPerks) ClassPerks.afterDeal(e, dmg);
        if (dmg > 0 && !accBusy) accEvent('hit');
    }
    function applyHit(d) {
        let e = enemies.find(x => x.id === d.eid);
        if (e && e.arch === 'wseg') { const bb = gmBoss(); if (!bb) return; d = Object.assign({}, d, { dmg: d.dmg * (G.wm === 'D' ? 3 : 0.35) }); e = bb; }      // ワールドワームの長い体：どこを叩いても、ワーム本体のダメージ（普段は小さく、引きずり出した間は大きく）
        if (!e || e.hp <= 0 || e.inv) return;
        if (e.arch === 'machine' && !machineHit(e)) return;      // 攻撃を受けると自動でバリア（燃料を消費）
        const duM = GMK === 'duality' ? duHitMul(e, d) : 1; if (duM <= 0) return;      // 大討伐戦：バリア・クリスタルの色の判定
        const amp = (e.st.curseT > 0 ? 1.2 : 1) * (e.vuln > 0 ? 1.3 : 1) * duM;
        e.hp -= d.dmg * amp * (e.takeMul || 1);      // 防御（無限回廊の敵）
        e.kx += d.kx; e.ky += d.ky;
        const s = d.st;
        if (s) {
            if (s.burn) { e.st.burn = Math.max(e.st.burn, s.burn); e.st.burnT = 3; }
            if (s.poison) { e.st.poison = Math.max(e.st.poison, s.poison); e.st.poisonT = 5; }
            if (s.bleed) { e.st.bleed = Math.max(e.st.bleed, s.bleed); e.st.bleedT = 4; }
            if (s.slow) e.st.slowT = 2.5;
            if (s.stun && !e.boss) e.st.stunT = Math.max(e.st.stunT, typeof s.stun === 'number' ? s.stun : 1);
            if (s.weaken) e.st.weakenT = 3;
            if (s.blind) e.st.blindT = 2.5;
            if (s.curse) e.st.curseT = 6;
        }
        if (e.hp <= 0) killEnemy(e, d.by);
    }

    function killEnemy(e, by) {
        if (e.dead) return;
        if (e.arch === 'wcore' && WS) { wormCoreBreak(e); return; }      // 核は、すぐには壊れない（中と外が同時に壊したときだけ）
        e.dead = true; e.hp = 0;
        run.kills++;
        if (e.boss && GMK === 'worm') wormCleanup(true);
        if (e.boss && GMK === 'necro') necroCleanup();
        if (e.boss && GMK === 'machine') G.lz = null;
        if (e.arch === 'slime') incOnDeath(e); else if (e.arch === 'heart') incHeartDown(e);      // 増殖スライム：分裂／心臓を砕いたら勝ち
        if (window.ClassFx) ClassFx.onKill(e);                                  // 職業：魂喰らい・調合・聖なる加護
        // 魔改造の死に際効果（ホスト側で実行。telegraphは状態同期されるので観戦側にも見える）
        // 無限回廊のexplosiveは下のCORR_ON側で別途処理済みなので、ここでは通常ステージのみ
        if (!CORR_ON && e.affix === 'explosive') telegraph(e.x, e.y, 150, 0.9, e.dmg * 1.6, '#ff7a3a');
        else if (!CORR_ON && e.affix === 'split') {
            for (let i = 0; i < 2; i++) {
                const m = spawnEnemy(e.def, e.x + rnd(-50, 50), e.y + rnd(-50, 50), false, false);
                m.hp = m.maxHp = Math.round(m.maxHp * 0.4); m.noLoot = true; m.affix = null;
            }
        }
        const main = e.boss && !e.echo;                                                    // 召喚された歴代ボス(echo)は本体ではない
        const others = main && enemies.some(o => o !== e && o.boss && !o.echo && !o.dead && o.hp > 0);
        const last = main && !others && !(GMK === 'velzark' && !G.vzF);                    // 最後の1体を倒したときだけクリア＆ボスドロップ（ヴェルスザークは、合体するまでは「最後」ではない）
        if (window.SBSound) { SBSound.sfx(last ? 'bossdie' : (e.boss ? 'bossdie' : 'die')); if (last) SBSound.bgm('victory', stage.id); }      // 倒した：勝利の曲（結果画面へ）
        const ev = { id: e.id, x: e.x, y: e.y, boss: last, part: (main && !last && !RUSH_ON) || !!e.noLoot, echo: !!e.echo, elite: !!e.elite, by: by, ilvl: SC.ilvl, ico: e.def.icon, col: e.def.color || '#fff', r: e.r };
        if (RUSH_ON && main) {      // ボスラッシュ：1体ごとに報酬（rb=1）、フェーズの最後の1体は豪華（rb=2）
            const pd = RUSHD.phases[Math.max(0, RS.ph - 1)] || RUSHD.phases[0];
            ev.rb = last ? 2 : 1; ev.ph = RS.ph; ev.fin = !!pd.final; ev.lw = pd.lootWorld; ev.ilvl = pd.ilvl; ev.src = e.rushSrc || '';
        }
        if (CORR_ON) { ev.fl = CF.floor; ev.cm = e.mimic ? 1 : 0; ev.cb = e.cboss || 0; if (e.affix === 'explosive') telegraph(e.x, e.y, 150, 0.9, e.dmg * 1.2, '#ff7a3a'); }
        onKillEvent(ev);
        netSend('kill', ev);
        if (main && others && GMK === 'twin') twinOnDeath(e);
        if (main && GMK === 'velzark' && !G.vzF) vzFuse(e);      // ヴェルスかザークのどちらかが倒れた：合体する
        if (last) {
            if (RUSH_ON && !ev.fin) rushPhaseClear();
            else if (CORR_ON) corrBossDown();
            else run.bossDead = true;
            eBullets.length = 0; telegraphs.length = 0;      // 勝利の演出中に、敵の攻撃は当たらない
            G.rv = null; enemies.forEach(o => { if (o !== e && (o.echo || o.valve)) { o.hp = 0; o.dead = true; } });
        }
    }

    // 全員が受け取る撃破イベント：各自が自分用のドロップを抽選する（ハクスラ式の個人ドロップ）
    // 第一世界の最終ステージ「深淵の裂け目」を攻略（どの難易度でもよい）すると、第二世界への道が開く
    // 世界をまたぐ流れ：①前の世界の最終ステージを攻略（ノーマルでもよい） → ②「門」が現れる → ③ゲートキーパーを倒す → ④次の世界が解放
    function worldOpenedByThisStage() {      // このステージの攻略で「門」が現れる世界（gateFlag）
        return (window.STAGE_DATA.WORLDS || []).find(w => w.unlock && stage.id === w.unlock.stageId && DIFFS.indexOf(DIFF) >= ((window.SeasonSys && w.unlock.diff != null) ? window.SeasonSys.gateDiffReq(w.unlock.diff) : w.unlock.diff)) || null;
    }
    function worldOpenedByGate() {           // このステージ（ゲート）のゲートキーパーを倒すと解放される世界（flag）
        return (window.STAGE_DATA.WORLDS || []).find(w => w.unlock && stage.id === w.unlock.gateId) || null;
    }
    // ---------- 撃破の演出（爽快感）----------
    //  光の輪・飛び散る火花・コンボ表示・画面の揺れ。精鋭とボスはさらに派手に。多くの敵を一度に倒しても重くならないよう、演出の数に上限をかける
    let shakeT = 0, shakeA = 0, comboN = 0, comboT = 0;
    function addShake(a, t) { if (a > shakeA || shakeT <= 0) { shakeA = a; } shakeT = Math.max(shakeT, t); }
    // ---------- ボスを倒したときの演出（マスターデュエルの「破壊」のような）----------
    //  ①倒した人からボスへ向かって衝撃波が走る ②ボスが固まって、ひびが入る（スローモーション・ボスへズーム）
    //  ③砕け散る：白い閃光・光の筋・飛び散る破片・広がる光の輪・画面の揺れ。スローモーションはひとりで遊ぶときだけ（マルチでは、全員の動きを止めてしまうので映像だけ）
    const CINE = { used: false, motes: [], fired: [], on: false, t: 0, x: 0, y: 0, kx: 0, ky: 0, ang: 0, col: '#ffd86a', r: 60, ico: '', ghost: null, cracks: [], shards: [], shat: false, pn: 0 };
    const CINE_END = 4.4, CINE_SHATTER = 0.7;      // 演出の長さ（秒）／砕ける瞬間（それまでは、固まってひびが入る）
    //  破壊は3段階の連鎖：①砕け散る ②もう一度、内側から爆ぜる ③最後に、特大の破壊。at=砕けた瞬間からの秒
    const CINE_WAVES = [
        { at: 0,   rings: [[420, 18, '#ffffff'], [280, 10, null]], rays: 16, flash: 0.95, shake: 12, shards: 34, zoom: 0.05 },
        { at: 0.8, rings: [[320, 14, '#ffffff'], [200, 8, null]],  rays: 10, flash: 0.5,  shake: 8,  shards: 22, zoom: 0.04 },
        { at: 1.6, rings: [[600, 24, '#ffffff'], [400, 12, null], [230, 8, '#ffffff']], rays: 24, flash: 0.9, shake: 15, shards: 38, zoom: 0.08 }
    ];
    function cineSolo() { return partyCount() === 1 && !PVP; }
    function cineScale() {      // 時間の流れる速さ：一瞬でスローに→破壊が終わるまでゆっくり→元に戻る
        if (!CINE.on || !cineSolo()) return 1;
        const t = CINE.t;
        return t < 0.12 ? 1 - 0.88 * (t / 0.12) : (t < 3.0 ? 0.12 : (t < 3.9 ? 0.12 + 0.88 * ((t - 3.0) / 0.9) : 1));
    }
    function cineFocus() {      // 0〜1：カメラがボスへ移っている度合い（最初にすっと寄り、演出の終わりにゆっくり戻る）
        if (!CINE.on) return 0;
        const t = CINE.t, a = Math.min(1, t / 0.45), s = a * a * (3 - 2 * a), r = Math.max(0, Math.min(1, (CINE_END - t) / 0.9));
        return s * (r * r * (3 - 2 * r));
    }
    function cineZoom() {      // ボスへ寄っていき、砕けるたびにドンと寄って、ゆっくり戻る
        if (!CINE.on) return 1;
        const t = CINE.t;
        if (t < CINE_SHATTER) return 1 + 0.12 * (t / CINE_SHATTER) * (t / CINE_SHATTER);
        let z = 1 + 0.12 * Math.pow(Math.max(0, 1 - (t - CINE_SHATTER) / 3.0), 2);
        CINE_WAVES.forEach(w => { const kw = t - CINE_SHATTER - w.at; if (kw >= 0) z += w.zoom * Math.exp(-kw * 7); });
        return z;
    }
    function cineStart(ev) {
        if (CINE.on) return;
        let kx = me.x, ky = me.y;
        if (ev.by && ev.by !== myId && allies[ev.by]) { kx = allies[ev.by].x; ky = allies[ev.by].y; }      // 倒した仲間の位置から
        const src = enemies.find(x => x.id === ev.id);
        const g = src ? Object.assign({}, src) : null; if (g) { g.dead = false; g.hp = g.maxHp || 1; g.flash = 0; }
        Object.assign(CINE, { on: true, t: 0, x: ev.x, y: ev.y, kx: kx, ky: ky, ang: Math.atan2(ev.y - ky, ev.x - kx), col: ev.col || '#ffd86a', r: Math.max(40, ev.r || 70), ico: ev.ico || '👑', ghost: g, shat: false, shards: [], motes: [], fired: [], used: true, pn: performance.now() });
        CINE.cracks = []; for (let i = 0; i < 9; i++) CINE.cracks.push({ a: Math.random() * 6.2832, len: 0.5 + Math.random() * 0.9, w: 1.5 + Math.random() * 2 });
    }
    function cineDraw() {      // 世界座標で描く（ボスへのズームの中）
        if (!CINE.on) return;
        const now = performance.now(), dtv = Math.min(0.05, (now - CINE.pn) / 1000); CINE.pn = now;
        const t = CINE.t, x = CINE.x, y = CINE.y, R = CINE.r, lite = LITE();
        // ① 倒した人から、ボスに向かって走る衝撃波
        if (t < 0.5) {
            const k = Math.min(1, t / 0.4), e = 1 - Math.pow(1 - k, 3), D = Math.hypot(x - CINE.kx, y - CINE.ky), fade = t < 0.4 ? 1 : (0.5 - t) / 0.1;
            for (let i = 0; i < 4; i++) {
                const kk = e - i * 0.07; if (kk <= 0) continue;
                const px = CINE.kx + Math.cos(CINE.ang) * D * kk, py = CINE.ky + Math.sin(CINE.ang) * D * kk;
                ctx.save(); ctx.globalAlpha = Math.max(0, (1 - i * 0.22) * fade); ctx.strokeStyle = i === 0 ? '#ffffff' : CINE.col; ctx.lineWidth = 12 - i * 2.5; ctx.lineCap = 'round';
                ctx.beginPath(); ctx.arc(px, py, 60 + 30 * kk, CINE.ang - 0.95, CINE.ang + 0.95); ctx.stroke(); ctx.restore();
            }
        }
        // ② 砕ける前：ボスが固まって震え、ひびが入る
        if (t < CINE_SHATTER) {
            const k = t / CINE_SHATTER, sh = (1 - k * 0.4) * 4 * Math.sin(t * 90);
            if (CINE.ghost) { CINE.ghost.x = x + sh; CINE.ghost.y = y; try { drawEnemy(CINE.ghost); } catch (er) { CINE.ghost = null; } }
            if (!CINE.ghost) { ctx.save(); ctx.font = Math.round(R * 2) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(CINE.ico, x + sh, y); ctx.restore(); }
            ctx.save(); const gr = ctx.createRadialGradient(x, y, 0, x, y, R * 1.3); gr.addColorStop(0, 'rgba(255,255,255,' + (0.15 + 0.5 * k * (0.6 + 0.4 * Math.sin(t * 60))) + ')'); gr.addColorStop(1, 'rgba(255,255,255,0)');
            ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, R * 1.3, 0, 7); ctx.fill();
            ctx.strokeStyle = '#ffffff'; ctx.lineCap = 'round';
            CINE.cracks.forEach(c => { const L = R * c.len * Math.min(1, k * 1.6); ctx.lineWidth = c.w; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(c.a) * L, y + Math.sin(c.a) * L); ctx.stroke(); });
            ctx.restore();
        }
        // ③ 砕け散る（3段階の連鎖）
        if (t >= CINE_SHATTER) {
            const k = t - CINE_SHATTER, col = CINE.col;
            CINE_WAVES.forEach((w, wi) => {
                if (k >= w.at && !CINE.fired[wi]) {      // その段階の破壊が起きる
                    CINE.fired[wi] = true; addShake(w.shake, 0.5 + wi * 0.15);
                    fx.push({ k: 'ring', x: x, y: y, r: 0, max: w.rings[0][0] * 0.9, t: 0.7, life: 0.7, c: '#ffffff', fill: wi !== 1 });
                    const n = Math.round((lite ? 0.4 : 1) * w.shards);
                    for (let i = 0; i < n; i++) { const a = Math.random() * 6.2832, v = (200 + Math.random() * 650) * (1 + wi * 0.18); CINE.shards.push({ x: x + Math.cos(a) * R * 0.3, y: y + Math.sin(a) * R * 0.3, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 60, rot: Math.random() * 6.2832, vr: (Math.random() - 0.5) * 14, s: 8 + Math.random() * (14 + wi * 6), w: Math.random() < 0.5 ? 1 : 0, age: 0, life: 1.5 + Math.random() * 1.1 }); }
                }
                const kw = k - w.at; if (kw < 0 || kw > 1.0) return;
                const ra = Math.max(0, 1 - kw / 0.45);      // 光の筋
                if (ra > 0) { ctx.save(); ctx.globalAlpha = ra; ctx.strokeStyle = '#ffffff'; ctx.lineCap = 'round'; for (let i = 0; i < w.rays; i++) { const a = i * 6.2832 / w.rays + 0.2 + wi * 0.3, L0 = 40 + kw * 1000, L1 = L0 + 120 + (i % 3) * 60; ctx.lineWidth = 3 + (i % 2) * 3; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * L0, y + Math.sin(a) * L0); ctx.lineTo(x + Math.cos(a) * L1, y + Math.sin(a) * L1); ctx.stroke(); } ctx.restore(); }
                w.rings.forEach(rg => { const kk = Math.min(1, kw / 0.8); if (kk >= 1) return; ctx.save(); ctx.globalAlpha = 1 - kk; ctx.strokeStyle = rg[2] || col; ctx.lineWidth = rg[1] * (1 - kk * 0.6); ctx.beginPath(); ctx.arc(x, y, rg[0] * (1 - Math.pow(1 - kk, 3)), 0, 7); ctx.stroke(); ctx.restore(); });      // 広がる光の輪
            });
            // 破片：ゆっくり飛び散って、舞いながら消えていく
            const slowK = 0.5;      // 破片の動きは、スローの間はさらにゆっくり見せる
            CINE.shards = CINE.shards.filter(s => (s.age += dtv) < s.life);
            CINE.shards.forEach(s => {
                const dmp = Math.pow(0.16, dtv), dd = dtv * slowK; s.x += s.vx * dd; s.y += s.vy * dd; s.vx *= dmp; s.vy = s.vy * dmp + 90 * dd; s.rot += s.vr * dd;
                ctx.save(); ctx.globalAlpha = Math.max(0, 1 - s.age / s.life); ctx.translate(s.x, s.y); ctx.rotate(s.rot); ctx.fillStyle = s.w ? '#ffffff' : col;
                ctx.beginPath(); ctx.moveTo(-s.s * 0.5, s.s * 0.4); ctx.lineTo(s.s * 0.7, 0); ctx.lineTo(-s.s * 0.2, -s.s * 0.5); ctx.closePath(); ctx.fill(); ctx.restore();
            });
            // 光の粒：ボスのいた場所から、ゆっくり立ちのぼる（消えていく余韻）
            if (k < 2.8 && CINE.motes.length < (lite ? 40 : 110)) for (let i = 0; i < (lite ? 1 : 3); i++) { const a = Math.random() * 6.2832, d = Math.random() * R; CINE.motes.push({ x: x + Math.cos(a) * d, y: y + Math.sin(a) * d * 0.7, vx: (Math.random() - 0.5) * 30, vy: -(30 + Math.random() * 70), s: 2 + Math.random() * 4, age: 0, life: 1.2 + Math.random() * 1.2, w: Math.random() < 0.6 }); }
            CINE.motes = CINE.motes.filter(m => (m.age += dtv) < m.life);
            CINE.motes.forEach(m => { m.x += m.vx * dtv; m.y += m.vy * dtv; ctx.save(); ctx.globalAlpha = Math.max(0, 1 - m.age / m.life) * 0.9; ctx.fillStyle = m.w ? '#ffffff' : col; ctx.fillRect(Math.round(m.x), Math.round(m.y), m.s, m.s); ctx.restore(); });
        }
    }
    function cineFlash() {      // 画面全体（周りを少し暗くして集中させ、砕けるたびに白く光る。最後に「撃破」の文字）
        if (!CINE.on) return;
        const t = CINE.t;
        if (t < CINE_SHATTER) { ctx.fillStyle = 'rgba(0,0,0,' + (0.3 * (t / CINE_SHATTER)).toFixed(3) + ')'; ctx.fillRect(0, 0, VW, VH); return; }
        let fa = 0; CINE_WAVES.forEach(w => { const kw = t - CINE_SHATTER - w.at; if (kw >= 0 && kw < 0.4) fa = Math.max(fa, w.flash * (1 - kw / 0.4)); });
        if (fa > 0) { ctx.fillStyle = 'rgba(255,255,255,' + fa.toFixed(3) + ')'; ctx.fillRect(0, 0, VW, VH); }
        // 「撃破」の文字は出さない（演出だけで十分）
    }
    function killFx(ev) {
        if (ev.boss && !PVP) cineStart(ev);      // ボスを倒した：撃破の演出
        const col = ev.col || '#fff', big = ev.boss ? 3 : (ev.elite ? 2 : 1), r0 = ev.r || 14;
        fx.push({ k: 'puff', x: ev.x, y: ev.y, t: 0.35, life: 0.35, c: '#fff' });
        fx.push({ k: 'ring', x: ev.x, y: ev.y, r: 0, max: 34 + r0 * 1.4 * big, t: 0.38, life: 0.38, c: col });
        if (fx.length > 420) return;
        const n = ev.boss ? 46 : (ev.elite ? 26 : 11);
        for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, v = (120 + Math.random() * 360) * (0.8 + big * 0.25); fx.push({ k: 'spark', x: ev.x, y: ev.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, sz: 2.5 + Math.random() * 3.5 * (big > 1 ? 1.4 : 1), t: 0.35 + Math.random() * 0.3, life: 0.65, c: Math.random() < 0.4 ? '#fff' : col }); }
        if (big >= 2) { fx.push({ k: 'ring', x: ev.x, y: ev.y, r: 0, max: 120 + 30 * big, t: 0.5, life: 0.5, c: '#fff' }); addShake(big === 3 ? 9 : 4, big === 3 ? 0.5 : 0.22); }
        if (ev.by === myId) {      // 自分が倒したときだけコンボを数える
            comboT = 2.4; comboN++;
            if (comboN >= 5 && comboN % 5 === 0) {
                const hype = comboN >= 100 ? '殲滅！' : (comboN >= 50 ? '無双！' : (comboN >= 25 ? '圧倒！' : (comboN >= 10 ? '連鎖！' : '')));
                popups.push({ x: me.x, y: me.y - 64, t: 1.1, text: (hype ? hype + ' ' : '') + comboN + ' COMBO', c: comboN >= 50 ? '#ff7bd5' : (comboN >= 25 ? '#ffb347' : '#ffe08a'), big: true });
                if (comboN % 25 === 0) { fx.push({ k: 'ring', x: me.x, y: me.y, r: 0, max: 220, t: 0.5, life: 0.5, c: '#ffe08a', fill: true }); addShake(3, 0.2); }
            }
        }
    }
    // 戦利品の文脈：ボスラッシュは「そのフェーズの世界」の表、無限回廊は「その階層のレベル」の表から引く
    function lootCtx(ev) {
        if (RUSH_ON && ev.lw) {
            const lp = RUSHD.lootPool(ev.lw), src = ev.src && window.getStageById(ev.src), dk = window.getStageById('dimension_end');
            return { ilvl: ev.ilvl || stage.ilvl, id: 'boss_rush', mats: (src && src.mats) || (dk && dk.mats) || { mob: [], elite: [], boss: [] }, drops: lp.drops, bossDrops: lp.bossDrops };
        }
        if (CORR_ON) { const pool = corrPool(ev.ilvl || 10); return { ilvl: ev.ilvl || 10, id: 'infinite_corridor', mats: stage.mats, drops: pool, bossDrops: pool }; }
        return null;
    }
    function onKillEvent(ev) {
        LT = lootCtx(ev);
        const own = !TX && !CORR_ON; if (own) TX = HW.load();
        try { onKillEvent0(ev); } finally { LT = null; if (own) { const d = TX; TX = null; HW.save(d); } }
    }
    function onKillEvent0(ev) {
        killFx(ev);
        if (stage.pvp || DBG) return;   // アリーナのボットとデバッグ戦闘は戦利品なし
        if (ev.part || ev.echo) {   // 双子の片方・召喚されたボス・安全弁：コインだけ
            run.stats.kills++; run.stats.coins += Math.round((1 + (ev.ilvl || stage.ilvl) * 0.8) * (ev.echo ? 6 : 3) * (1 + A('goldPct')));
            return;
        }
        if (AMB_ON && !ev.boss) {      // 襲撃のニンゲン：少しのコインだけ（王を倒したときだけ、専用の報酬）
            run.stats.kills++; run.stats.coins += Math.round((1 + 30 * 0.8) * 1.2 * (1 + A('goldPct')));
            return;
        }
        if (RAID && !ev.boss) {      // 大討伐戦の子分（眷属）：専用装備もボス報酬も出ない。少しのコインだけ（ボスを倒したときだけ raidKillReward）
            run.stats.kills++; run.stats.coins += Math.round((1 + 46 * 0.8) * 1.5 * (1 + A('goldPct')));
            return;
        }
        if (ev.boss) {
            const wo = worldOpenedByThisStage(), wg = worldOpenedByGate(), hh = HW.load();
            if (wo && !hh[wo.unlock.gateFlag]) setTimeout(() => announce(wo.unlock.openText, 5200), 700);
            if (wg) setTimeout(() => announce(wg.unlock.clearText, 5200), 700);
        }
        run.stats.kills++;
        try { if (window.SBAch && !DBG) SBAch.report('kill', ev.boss ? 1 : 0, weapon.type); } catch (e) { /* 実績の記録に失敗してもゲームは続ける */ }
        if (ev.rb) { rushKillReward(ev); return; }          // ボスラッシュ：専用の報酬
        { const al = A('rarePct') + DIFF.luck;      // アクセサリー：ボス・精鋭・雑魚の順に出にくい
          if (ev.boss && Math.random() < 0.45 + 0.1 * al) rollAcc(al, 'magic', ev.x + 14, ev.y); else if (ev.elite && Math.random() < 0.05 * (1 + al)) rollAcc(al, 'normal', ev.x, ev.y); else if (!ev.part && !ev.boss && Math.random() < 0.004 * (1 + al)) rollAcc(al, 'normal', ev.x, ev.y); }
        if (CORR_ON) { corrKillReward(ev); return; }        // 無限回廊：専用の報酬
        if (AMB_ON) { ambKillReward(ev); return; }          // 襲撃ステージ：専用の報酬
        if (RAID) { raidKillReward(ev); return; }           // 大討伐戦：専用の報酬
        const coin = Math.round((1 + stage.ilvl * 0.8) * (ev.boss ? 25 : 1) * (1 + A('goldPct')));
        run.stats.coins += coin;
        const luck = A('dropPct');
        const rareBonus = A('rarePct') + DIFF.luck + (ev.boss ? 0.8 : 0) + (ev.elite ? 0.5 : 0);
        rollMats(ev.boss ? 'boss' : (ev.elite ? 'elite' : 'mob'), ev.x, ev.y);
        if (ev.boss) {
            // ボス専用ドロップ：レア以上確定を2本＋通常ドロップ1本
            rollLoot(stage.bossDrops, rareBonus, 'rare', ev.x, ev.y, 'boss');
            rollLoot(stage.bossDrops, rareBonus, 'rare', ev.x + 22, ev.y, 'boss');
            rollLoot(stage.drops, rareBonus, 'magic', ev.x - 22, ev.y, 'boss');
            rollArmor(rareBonus, 'rare', ev.x, ev.y - 20, 'boss'); if (Math.random() < 0.5) rollArmor(rareBonus, 'magic', ev.x + 18, ev.y - 24, 'boss');
            if (Math.random() < 0.8) giveOrb(true);
            if (stage.emergency) emgBossBonus(ev);      // 緊急ステージ（ニグス）：専用の追加報酬
        } else if (ev.elite) {
            // 精鋭：高確率で武器（マジック以上）、オーブも出やすい
            if (Math.random() < 0.55 * (1 + luck)) rollLoot(stage.drops, rareBonus, 'magic', ev.x, ev.y, 'elite');
            if (Math.random() < 0.22 * (1 + luck)) rollArmor(rareBonus, 'magic', ev.x, ev.y - 16, 'elite');
            if (Math.random() < 0.22 * (1 + A('orbPct'))) giveOrb(false);
        } else {
            if (Math.random() < 0.07 * (1 + luck)) rollLoot(stage.drops, rareBonus, 'normal', ev.x, ev.y, 'mob');
            if (Math.random() < 0.025 * (1 + luck)) rollArmor(rareBonus, 'normal', ev.x, ev.y - 12, 'mob');
            if (Math.random() < 0.035 * (1 + A('orbPct'))) giveOrb(false);
        }
        if (ev.by === myId) {
            onMyKill();
            // 回復の宝珠：倒した本人が拾う（被弾が増えたぶんの救済）
            if (!me.dead && Math.random() < (ev.elite || ev.boss ? 0.5 : 0.09)) {
                addHp(me.maxHp * (ev.elite ? 0.2 : 0.1));
                popups.push({ x: me.x, y: me.y - 34, t: 0.9, text: '+HP', c: '#7aff9a' });
            }
        }
    }

    function rollArmor(luck, minR, x, y, src) {
        if (!window.SBArmor) return;
        const a = SBArmor.roll({ ilvl: L().ilvl, luck: luck, minRarity: minR, source: L().id + ':' + src });
        if (CORR_ON) BAG.armors.push(a); else { const d = hwLoad(); SBArmor.add(d, a); hwSave(d); }
        run.stats.loot.push(a);
        popups.push({ x: x, y: y - 14, t: 1.6, text: '🛡 ' + a.name, c: HW.rarityOf(a).color, big: true });
        fx.push({ k: 'ring', x: x, y: y, r: 0, max: 50, t: 0.5, life: 0.5, c: HW.rarityOf(a).color });
        refreshLootLog();
    }
    // 不壊の悪魔（無限回廊の最強ボス）を倒した報酬：専用の神話武器「Legend of Unbreakable」（1本だけ。持っていたら出ない）
    function giveUnbreakable(x, y) {
        const hasIt = (arr) => (arr || []).some(w => w && w.mythicId === 'legend_unbreakable');
        if (hasIt(hwLoad().weapons) || (CORR_ON && hasIt(BAG.weapons))) { popups.push({ x: x, y: y - 20, t: 1.6, text: '不壊の悪魔の力は、すでにあなたの中に', c: '#ff9aa8' }); return; }
        const w = HW.makeMythic('legend_unbreakable'); if (!w) return;
        if (CORR_ON) BAG.weapons.push(w); else { const d = hwLoad(); d.weapons.push(w); hwSave(d); }
        run.stats.loot.push(w);
        popups.push({ x: x, y: y - 24, t: 2.4, text: '✦ ' + w.name, c: '#ff2a4a', big: true });
        fx.push({ k: 'ring', x: x, y: y, r: 0, max: 120, t: 0.8, life: 0.8, c: '#ff2a4a' }); announce('🏆 神話の武器「' + w.name + '」を手に入れた！', 3200);
        refreshLootLog();
    }
    // 双界の覇竜ツイン・エレメンタルを倒した報酬：専用の神話装備「Legend of Duality」（1本だけ。持っていたら出ない）
    function giveDuality(x, y) {
        const hasIt = (arr) => (arr || []).some(w => w && w.mythicId === 'legend_duality');
        if (hasIt(hwLoad().weapons)) { popups.push({ x: x, y: y - 20, t: 1.6, text: '双界の力は、すでにあなたの中に', c: '#d9a0ff' }); return; }
        const w = HW.makeMythic('legend_duality'); if (!w) return;
        const d = hwLoad(); d.weapons.push(w); hwSave(d);      // ドロップの保存と同じ経路（まとめ保存の途中で上書きされないように）
        run.stats.loot.push(w);
        popups.push({ x: x, y: y - 24, t: 2.4, text: '✦ ' + w.name, c: '#c06aff', big: true });
        fx.push({ k: 'ring', x: x, y: y, r: 0, max: 140, t: 0.8, life: 0.8, c: '#ff5a3a' }); fx.push({ k: 'ring', x: x, y: y, r: 0, max: 100, t: 0.8, life: 0.8, c: '#4ac8ff' });
        announce('🏆 神話の武器「' + w.name + '」を手に入れた！', 3400);
        refreshLootLog();
    }
    // ワールドワームを倒した報酬：専用の神話装備「Legend of Eater」（1本だけ。持っていたら出ない）
    function giveEater(x, y) {
        const hasIt = (arr) => (arr || []).some(w => w && w.mythicId === 'legend_eater');
        if (hasIt(hwLoad().weapons)) { popups.push({ x: x, y: y - 20, t: 1.6, text: '世界を喰らう力は、すでにあなたの中に', c: '#e8c48a' }); return; }
        const w = HW.makeMythic('legend_eater'); if (!w) return;
        const d = hwLoad(); d.weapons.push(w); hwSave(d);
        run.stats.loot.push(w);
        popups.push({ x: x, y: y - 24, t: 2.4, text: '✦ ' + w.name, c: '#d8a85a', big: true });
        fx.push({ k: 'ring', x: x, y: y, r: 0, max: 140, t: 0.8, life: 0.8, c: '#d8a85a' }); fx.push({ k: 'ring', x: x, y: y, r: 0, max: 100, t: 0.8, life: 0.8, c: '#9bd84a' });
        announce('🏆 神話の武器「' + w.name + '」を手に入れた！', 3400);
        refreshLootLog();
    }
    // 増殖スライム インクリーズを倒した報酬：専用の神話装備「Legend of Increase」（1本だけ。持っていたら出ない）
    function giveIncrease(x, y) {
        const hasIt = (arr) => (arr || []).some(w => w && w.mythicId === 'legend_increase');
        if (hasIt(hwLoad().weapons)) { popups.push({ x: x, y: y - 20, t: 1.6, text: '増殖の力は、すでにあなたの中に', c: '#9df0a8' }); return; }
        const w = HW.makeMythic('legend_increase'); if (!w) return;
        const d = hwLoad(); d.weapons.push(w); hwSave(d);
        run.stats.loot.push(w);
        popups.push({ x: x, y: y - 24, t: 2.4, text: '✦ ' + w.name, c: '#5be37a', big: true });
        fx.push({ k: 'ring', x: x, y: y, r: 0, max: 140, t: 0.8, life: 0.8, c: '#5be37a' }); fx.push({ k: 'ring', x: x, y: y, r: 0, max: 100, t: 0.8, life: 0.8, c: '#ff4d6d' });
        announce('🏆 神話の武器「' + w.name + '」を手に入れた！', 3400);
        refreshLootLog();
    }
    function giveMythicFor(id, soulText, col1, col2, hasText) {
        const hasIt = (arr) => (arr || []).some(w => w && w.mythicId === id);
        return function (x, y) {
            if (hasIt(hwLoad().weapons)) { popups.push({ x: x, y: y - 20, t: 1.6, text: hasText, c: col1 }); return; }
            const w = HW.makeMythic(id); if (!w) return;
            const d = hwLoad(); d.weapons.push(w); hwSave(d);
            run.stats.loot.push(w);
            popups.push({ x: x, y: y - 24, t: 2.4, text: '✦ ' + w.name, c: col1, big: true });
            fx.push({ k: 'ring', x: x, y: y, r: 0, max: 140, t: 0.8, life: 0.8, c: col1 }); fx.push({ k: 'ring', x: x, y: y, r: 0, max: 100, t: 0.8, life: 0.8, c: col2 });
            announce('🏆 神話の武器「' + w.name + '」を手に入れた！', 3400);
            refreshLootLog();
        };
    }
    const giveNecromance = giveMythicFor('legend_necromance', '', '#a070ff', '#7fae6a', '魂の理は、すでにあなたの中に');
    const giveRelainbar = giveMythicFor('legend_relainbar', '', '#7fd8ff', '#ff9a3a', '機械の王の力は、すでにあなたの中に');
    const giveFusion = giveMythicFor('legend_fusion', '', '#ffd86a', '#ff3a52', '融合の力は、すでにあなたの中に');
    // 大討伐戦のボスを倒した報酬（全員が自分の分を受け取る）
    function raidKillReward(ev) {
        const rb = A('rarePct') + DIFF.luck;
        run.stats.coins += Math.round((1 + 46 * 0.8) * 60 * (1 + A('goldPct')));
        rollMats('boss', ev.x, ev.y); rollMats('boss', ev.x + 20, ev.y);
        const pool = (window.STAGE_DATA.RUSH && window.STAGE_DATA.RUSH.lootPool) ? window.STAGE_DATA.RUSH.lootPool(5).bossDrops : [];
        if (pool.length) { rollLoot(pool, rb + 1.2, 'epic', ev.x, ev.y, 'raid'); rollLoot(pool, rb + 1.6, 'epic', ev.x + 24, ev.y, 'raid'); }
        rollArmor(rb + 1.2, 'epic', ev.x, ev.y - 22, 'raid'); rollAcc(rb + 1.4, 'epic', ev.x - 30, ev.y + 30);
        if (stage.id === 'raid_increase') giveIncrease(ev.x, ev.y); else if (stage.id === 'raid_worm') giveEater(ev.x, ev.y); else if (stage.id === 'raid_necro') giveNecromance(ev.x, ev.y); else if (stage.id === 'raid_machine') giveRelainbar(ev.x, ev.y); else if (stage.id === 'raid_velzark') giveFusion(ev.x, ev.y); else giveDuality(ev.x, ev.y);
        try { if (window.SBAch && !DBG) SBAch.report('raid', 1, stage.id); } catch (e) { /* 実績の記録に失敗してもゲームは続ける */ }
    }
    function rollLoot(pool, luck, minR, x, y, src) {
        const w = HW.roll({ ilvl: L().ilvl, baseIds: pool, luck: luck, minRarity: minR, source: L().id + ':' + src });
        if (CORR_ON) BAG.weapons.push(w); else { const d = hwLoad(); d.weapons.push(w); hwSave(d); }
        run.stats.loot.push(w);
        popups.push({ x: x, y: y - 14, t: 1.6, text: '✦ ' + w.name, c: HW.rarityOf(w).color, big: true });
        fx.push({ k: 'ring', x: x, y: y, r: 0, max: 50, t: 0.5, life: 0.5, c: HW.rarityOf(w).color });
        refreshLootLog();
    }
    // ---------- モンスター素材（グリフ工房の材料）----------
    // 抽選表は stage-data.js の MATS。雑魚は控えめ、精鋭はそのまま、ボスの確定枠は2〜3個。
    function matName(id) { return (typeof MATERIAL_DATA !== 'undefined' && MATERIAL_DATA[id]) ? MATERIAL_DATA[id].name : id; }
    function rollMats(kind, x, y) {
        const list = L().mats && L().mats[kind];
        if (!list || !list.length) return;
        const kindMul = kind === 'mob' ? 0.6 : 1;
        const luck = (1 + A('dropPct') * 0.5) * (1 + DIFF.luck * 0.25);
        const got = {};
        list.forEach(row => {
            const id = row[0], ch = row[1];
            if (Math.random() < Math.min(1, ch * kindMul * luck) * 0.05) got[id]   /* 素材ドロップは以前の 1/20 */  = (got[id] || 0) + ((kind === 'boss' && ch >= 1) ? 2 + Math.floor(Math.random() * 2) : 1);
        });
        giveMaterials(got, x, y);
    }
    function giveMaterials(got, x, y) {
        const ids = Object.keys(got);
        if (!ids.length) return;
        const p = CORR_ON ? {} : getPlayerData(); if (!p) return;
        if (!p.materials || Array.isArray(p.materials)) p.materials = {};
        ids.forEach((id, i) => {
            if (CORR_ON) BAG.mats[id] = (BAG.mats[id] || 0) + got[id]; else p.materials[id] = (p.materials[id] || 0) + got[id];
            run.stats.mats[id] = (run.stats.mats[id] || 0) + got[id];
            popups.push({ x: x + (i - (ids.length - 1) / 2) * 6, y: y - 10 - i * 14, t: 1.1, text: '🧪 ' + matName(id) + (got[id] > 1 ? '×' + got[id] : ''), c: '#c8f7a0' });
        });
        if (!CORR_ON) { try { localStorage.setItem('player', JSON.stringify(p)); } catch (e) {} }
    }
    function giveOrb(isBoss) {
        if (typeof createOrb !== 'function') return;
        const il = L().ilvl;
        let tier = 'tier1';
        const r = Math.random();
        if (il >= 12 && r < (isBoss ? 0.15 : 0.03)) tier = 'tier4';
        else if (il >= 7 && r < (isBoss ? 0.45 : 0.18)) tier = 'tier3';
        else if (il >= 3 && r < (isBoss ? 0.7 : 0.4)) tier = 'tier2';
        const orb = createOrb(tier);
        if (!orb) return;
        if (CORR_ON) BAG.orbs.push(orb);
        else {
            const p = getPlayerData(); if (!p) return;
            if (!Array.isArray(p.orbs)) p.orbs = [];
            p.orbs.push(orb);
            try { localStorage.setItem('player', JSON.stringify(p)); } catch (e) {}
        }
        run.stats.orbs++;
        popups.push({ x: me.x, y: me.y - 40, t: 1.4, text: '💎 オーブ入手 (' + (orb.tier || tier) + ')', c: '#9fe0ff', big: true });
    }

    // 自分が倒したとき（撃破時効果）
    function onMyKill() {
        accEvent('kills');
        agg.procs.filter(p => p.on === 'kill').forEach(p => {
            if (Math.random() >= p.v && p.key !== 'killHeal') return;
            if (p.key === 'killHeal') addHp(me.maxHp * Math.min(0.2, p.v));
            else if (p.key === 'killBoom') boomMine(me.x, me.y, 110);
            else if (p.key === 'killHaste') me.haste = 3;
            else if (p.key === 'killEnergy') addEnergy(8);
            else if (p.key === 'killNova') boomMine(me.x, me.y, 230);
            else if (p.key === 'killGuard') me.shield = true;
        });
    }

    // 自分が敵に与える範囲爆発（味方には当たらない）
    function boomMine(x, y, r) {
        r *= (1 + A('aoePct'));
        fx.push({ k: 'ring', x: x, y: y, r: 0, max: r, t: 0.3, life: 0.3, c: '#ffb04a', fill: true });
        netSend('sk', { f: 'nova', x: Math.round(x), y: Math.round(y), r: Math.round(r) });
        const dm = weapon.dmg * P.atkMul * 0.9;
        enemies.forEach(e => { if (e.hp > 0 && dist(e.x, e.y, x, y) < r + e.r) dealHit(e, dm, {}); });
    }

    // ---------- 守りの溜め（バリア）----------
    function startGuard() {
        if (!me.dead && me.stunT <= 0 && run.phase === 'run' && !(me.parryCd > 0)) {      // ジャストパリィの受付（攻撃が当たる直前に押せたら成功）
            me.parryT = PARRY_WINDOW; me.parryCd = PARRY_CD;
            fx.push({ k: 'ring', x: me.x, y: me.y, r: 60, max: 22, t: PARRY_WINDOW, life: PARRY_WINDOW, c: '#ffe08a' });
        }
        if (me.dead || me.stunT > 0 || run.phase !== 'run' || me.cast || me.gch > 0 || me.ultT > 0 || me.guardT > 0) return;
        if (me.guardCd > 0) { popups.push({ x: me.x, y: me.y - 30, t: 0.8, text: 'バリアはあと' + Math.ceil(me.guardCd) + '秒', c: '#ff9a9a' }); return; }
        me.gch = 0.001; me.dashT = 0;
    }
    function cancelGuard() { if (me.gch > 0) { const long = me.gch > 0.5; me.gch = 0; if (long) popups.push({ x: me.x, y: me.y - 30, t: 0.7, text: '溜め中断', c: '#ff9a9a' }); } }      // ポンと押しただけ（パリィ）のときは出さない
    // 溜め・バリアの時間を進める（updateMe の頭で毎フレーム呼ぶ）
    function tickCharge(dt) {
        if (me.gMsgT > 0) me.gMsgT -= dt;
        if (me.guardCd > 0) me.guardCd -= dt;
        if (me.parryT > 0) me.parryT -= dt; if (me.parryCd > 0) me.parryCd -= dt;
        if (me.dead || run.phase !== 'run') { me.cast = null; me.gch = 0; me.guardT = 0; me.ultT = 0; return; }
        if (me.guardT > 0) me.guardT -= dt;
        if (me.cutT > 0) me.cutT -= dt;
        if (me.ultT > 0) me.ultT -= dt;
        if (ultFlashT > 0) ultFlashT -= dt;
        if (me.stunT > 0) {
            if (me.cast) { const sl = skillSlots[me.cast.slot]; if (sl) { me.energy = Math.min(ENERGY_MAX, me.energy + sl.cost); updateEnergyUI(); } me.cast = null; popups.push({ x: me.x, y: me.y - 30, t: 0.9, text: '溜め中断！', c: '#ff9a9a' }); }
            me.gch = 0; return;
        }
        if (me.cast) {
            me.cast.t -= dt;
            if (me.cast.t <= 0) { const sl = me.cast.slot; me.cast = null; castSkill(sl, true); }
        }
        if (me.gch > 0) {
            me.gch += dt;
            if (me.gch >= GUARD_CHARGE) {
                me.gch = 0; me.guardT = GUARD_SEC; me.guardCd = GUARD_CD;
                popups.push({ x: me.x, y: me.y - 40, t: 1.1, text: '🛡 バリア展開！', c: '#8fe8ff', big: true });
                fx.push({ k: 'ring', x: me.x, y: me.y, r: 0, max: 90, t: 0.4, life: 0.4, c: '#8fe8ff' });
            }
        }
    }
    function guardBlock() {      // バリア中は攻撃を完全に防ぐ（連続で当たるときは、表示を出しすぎない）
        if (me.gMsgT <= 0) { me.gMsgT = 0.35; popups.push({ x: me.x, y: me.y - 28, t: 0.6, text: 'BLOCK', c: '#8fe8ff' }); fx.push({ k: 'ring', x: me.x, y: me.y, r: 20, max: 44, t: 0.2, life: 0.2, c: '#8fe8ff' }); }
    }

    function parryFx() {      // ジャストパリィ成功の演出：金色の光の輪・火花・ヒットストップ
        popups.push({ x: me.x, y: me.y - 44, t: 1.0, text: '⚔ ジャストパリィ！', c: '#ffe08a', big: true });
        fx.push({ k: 'ring', x: me.x, y: me.y, r: 10, max: 120, t: 0.3, life: 0.3, c: '#ffe08a', fill: true }); fx.push({ k: 'ring', x: me.x, y: me.y, r: 0, max: 70, t: 0.22, life: 0.22, c: '#ffffff' });
        if (fx.length < 420) for (let i = 0; i < 14; i++) { const a = Math.random() * Math.PI * 2, v = 160 + Math.random() * 360; fx.push({ k: 'spark', x: me.x, y: me.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, sz: 2.5 + Math.random() * 3, t: 0.3 + Math.random() * 0.2, life: 0.5, c: Math.random() < 0.5 ? '#ffe08a' : '#ffffff' }); }
        addShake(4, 0.2); hitStop(0.09);
        if (window.SBSound) SBSound.sfx('guard');
    }
    // ---------- 被ダメージ ----------
    function hurtMe(raw, opt) {
        if (me.dead || me.invHard > 0 || run.phase !== 'run') return;
        if (me.guardT > 0) { guardBlock(); return; }
        if (me.inv > 0 && !(opt && opt.stun)) return;   // 被弾直後の無敵はスタン攻撃には効かない（小弾に隠されて不発になるのを防ぐ）
        let parried = false;
        if (me.parryT > 0) { me.parryT = 0; parried = true; parryFx(); }      // ジャストパリィ成功：ダメージは1になる（回避・シールドは使わずに取っておく）
        if (!parried && Math.random() < Math.min(0.5, A('dodge'))) { popups.push({ x: me.x, y: me.y - 24, t: 0.6, text: 'MISS', c: '#9fe0ff' }); me.inv = 0.25; return; }
        if (!parried && me.shield) { me.shield = false; popups.push({ x: me.x, y: me.y - 24, t: 0.7, text: 'BARRIER', c: '#9fe0ff' }); me.inv = 0.5; return; }
        run.hitTaken = true;      // 被弾した（無限回廊の「一度も被弾せず脱出」の判定に使う）
        if (me.stunT > 0) raw *= 0.6;   // スタン中は被ダメージを少し軽減（スタンロックで一方的に倒されないように）
        // raw は「基準HPに対する割合」。防御は最大55%まで軽減
        const defNow = P.def * (me.fortifyT > 0 ? 1.4 : 1);
        const red = Math.min(0.55, defNow / (defNow + 250));
        let dmg = raw * REF_HP * (1 - red) * (1 - Math.min(0.75, Math.max(-0.5, A('dr') + (me.hp / me.maxHp <= 0.3 ? A('lowHpDr') : 0)))) * (1 + A('dmgTaken'));
        if (AB('re_miserable')) dmg *= 0.8;                                    // リ・ミゼラブル：敵の攻撃0.8倍
        if (window.ClassFx) dmg *= ClassFx.incomingMul();                       // 職業：不動の城
        if (me.cutT > 0) dmg *= (me.cutMul || 0.5);                             // 職業：ジャガーノートの突進中は、受けるダメージを50%カット
        if (GMK === 'duality' && me.chill > 0) dmg *= 1 + Math.min(0.5, me.chill * 0.05);      // 悪寒：防御DOWN
        dmg = Math.max(1, Math.round(dmg));
        if (parried) dmg = 1;      // ジャストパリィ：1ダメージに抑える
        if (me.barrierHp > 0) { const ab = Math.min(dmg, me.barrierHp); me.barrierHp -= ab; dmg -= ab; popups.push({ x: me.x, y: me.y - 30, t: 0.7, text: 'BARRIER-' + Math.round(ab), c: '#7fc8ff' }); me.inv = 0.3; if (dmg <= 0) return; }
        me.hp -= dmg; me.inv = 0.6 + A('iframe'); me.flash = 0.2;
        if (GMK === 'worm') wormShove();      // ワーム：攻撃を受けると、ワームから離れる向きに吹き飛ぶ（縁の近くでは、落ちる危険）
        if (opt && opt.poison && !parried) { me.poisonT = 4; me.poisonDps = Math.max(me.poisonDps || 0, dmg * 0.35); popups.push({ x: me.x, y: me.y - 34, t: 0.9, text: '毒！', c: '#8fd45a' }); }
        if (window.SBSound) SBSound.sfx('hurt');
        accEvent('hurt');
        if (window.ClassFx) ClassFx.onHurt(dmg);                                // 職業：怒りゲージ・剣気
        popups.push({ x: me.x, y: me.y - 24, t: 0.8, text: '-' + dmg, c: '#ff7b7b', big: true });
        // 被弾時効果
        if (A('thorns') > 0) { const n = nearestEnemy(me.x, me.y, 140); if (n) dealHit(n, weapon.dmg * P.atkMul * A('thorns'), {}); }
        if (AB('thorn_armor')) { const n = nearestEnemy(me.x, me.y, 170); if (n) dealHit(n, weapon.dmg * P.atkMul * Math.min(6, 0.15 * 40 * (dmg / me.maxHp)), {}); }   // 棘の鎧：受けたダメージの15%ぶんを反射
        if (me.hp <= 0 && window.ClassPerks && ClassPerks.fatal()) { /* 職業パーク：身代わりの術で、致命傷を回避した */ }
        if (me.hp <= 0 && AB('guts') && !(me.gutsT > 0)) {                       // 根性：致死ダメージをHP1で耐える（45秒に1回）
            me.hp = 1; me.gutsT = 45; me.inv = Math.max(me.inv, 1.0);
            popups.push({ x: me.x, y: me.y - 40, t: 1.3, text: '根性！ HP1で耐えた', c: '#ffd84a', big: true });
        }
        agg.procs.filter(p => p.on === 'hurt').forEach(p => {
            if (Math.random() >= p.v) return;
            if (p.key === 'hurtShield') me.shield = true;
            if (p.key === 'hurtHeal') addHp(me.maxHp * 0.03);
            if (p.key === 'hurtHaste') me.haste = Math.max(me.haste || 0, 2);
            if (p.key === 'hurtFrost') { fx.push({ k: 'ring', x: me.x, y: me.y, r: 0, max: 190, t: 0.35, life: 0.35, c: '#9fe0ff' }); enemies.forEach(e => { if (e.hp > 0 && !e.pvp && dist(e.x, e.y, me.x, me.y) < 190) dealHit(e, weapon.dmg * P.atkMul * 0.05, { st: { slow: 1 } }); }); }
            if (p.key === 'hurtNova') { fx.push({ k: 'ring', x: me.x, y: me.y, r: 0, max: 160, t: 0.35, life: 0.35, c: '#ffe08a' }); enemies.forEach(e => { if (dist(e.x, e.y, me.x, me.y) < 170) { const a = Math.atan2(e.y - me.y, e.x - me.x); dealHit(e, weapon.dmg * P.atkMul * 0.8, { kx: Math.cos(a) * 300, ky: Math.sin(a) * 300 }); } }); }
        });
        if (me.hp <= 0) { me.hp = 0; me.dead = true; me.reviveT = 0; me.stunT = 0; me.orb = null; if (window.SBSound) SBSound.sfx('defeat'); announce('倒れた！ 仲間が近くに来れば復活できます', 2200); if (GMK === 'necro') necroCorpse(); if (CORR_ON) { try { if (window.SBAch) SBAch.report('corrDeath'); } catch (e) { /* 記録に失敗してもゲームは続ける */ } } }
        else if (opt && opt.stun && !parried) stunMe(STUN_SEC);      // パリィしたときは、スタンも受けない
    }
    // スタン：約3秒、移動・攻撃・ダッシュ・スキルがすべて使えない（クイズの回答だけは可能）
    function stunMe(sec) {
        if (me.dead || me.stunT > 0 || me.stunImm > 0) return;
        if (me.guardT > 0) { guardBlock(); return; }
        if (AB('iron_will') && Math.random() < 0.5) { popups.push({ x: me.x, y: me.y - 40, t: 1.0, text: '耐性！', c: '#9fe0ff', big: true }); return; }   // 不動の心：状態異常を50%無効化
        if (PVP) sec = Math.min(sec, PVP_STUN_MAX);      // 対人戦のスタンは短く
        me.stunT = sec; me.dashT = 0; me.dashBlast = 0;
        popups.push({ x: me.x, y: me.y - 40, t: 1.3, text: '💫 スタン！', c: '#ffe14a', big: true });
        fx.push({ k: 'ring', x: me.x, y: me.y, r: 0, max: 60, t: 0.4, life: 0.4, c: '#ffe14a' });
    }

    function nearestEnemy(x, y, maxD) {
        let best = null, bd = maxD || 1e9;
        enemies.forEach(e => { if (e.hp <= 0) return; const d = dist(x, y, e.x, e.y) - e.r; if (d < bd) { bd = d; best = e; } });
        return best;
    }

    // ---------- 攻撃 ----------
    // オートエイム：スマホと同じく、いちばん近い敵へ自動で狙いを合わせる（PCはGキーでオン/オフ）
    let autoAim = true; try { autoAim = localStorage.getItem('sbAutoAim') !== '0'; } catch (e) {}
    function aimAngle() {
        if (input.aimStick.id !== null && Math.hypot(input.aimStick.x, input.aimStick.y) > 0.2) return Math.atan2(input.aimStick.y, input.aimStick.x);
        if (isTouch || autoAim) { const n = nearestEnemy(me.x, me.y, 520); if (n) return Math.atan2(n.y - me.y, n.x - me.x); }
        return me.ang;   // マウス操作時は updateMe が毎フレーム me.ang を更新している
    }
    function wantsAttack() {
        if (keys['Space'] || input.mouseDown) return true;
        if (input.aimStick.id !== null) return true;
        return false;
    }

    function calcHit(e, mult) {
        let dmg = weapon.dmg * (T.mult || 1) * P.atkMul * atkDyn() * (mult || 1) * rnd(0.93, 1.07);
        if (e.pvp) { /* 対人戦ではボス・雑魚用の補正は無し */ } else if (e.boss) dmg *= 1 + A('dmgBoss'); else dmg *= 1 + A('dmgMob');
        if (e.hp / e.maxHp < 0.3) dmg *= 1 + A('dmgLow');
        if (e.hp >= e.maxHp) dmg *= 1 + A('dmgFull');
        if (me.hp / me.maxHp < 0.5) dmg *= 1 + A('rageAtk');
        if (me.empowerT > 0) dmg *= 1.15;
        if (!e.pvp) {
            if (AB('re_miserable')) dmg *= 1.25;                              // リ・ミゼラブル：敵のHP0.8倍と同じ
            if (AB('penetration') && (e.boss || e.elite)) dmg *= 1.15;        // 貫通：防御を半分無視
        }
        if (AB('guts') && me.hp <= 1.5) dmg *= 3;                             // 根性：HP1の間は攻撃力3倍
        let crit = Math.random() < P.crit;
        if (AB('first_strike') && !run.firstStrike && run.phase === 'run') { crit = true; run.firstStrike = true; }   // 会心の初撃
        if (crit) dmg *= P.critMul; else if (A('nonCritDown') > 0) dmg *= 1 - Math.min(0.9, A('nonCritDown'));      // 諸刃：クリティカルでないとダメージが減る
        return { dmg: dmg, crit: crit };
    }

    // 命中時の効果（状態異常・連鎖雷・隕石など）
    function onHitProcs(e, h) {
        const st = {};
        let extra = false;
        const base = weapon.dmg * P.atkMul;
        agg.procs.forEach(p => {
            if (p.on === 'crit') { if (h.crit && Math.random() < p.v) { if (p.key === 'critHeal') addHp(me.maxHp * 0.02); else boomMine(e.x, e.y, 100); } return; }
            if (p.on !== 'hit') return;
            if (Math.random() >= p.v) return;
            switch (p.key) {
                case 'burn': st.burn = base * 0.35; break;
                case 'poison': st.poison = base * 0.22; break;
                case 'bleed': st.bleed = base * 0.3; break;
                case 'freeze': st.slow = 1; break;
                case 'stun': st.stun = 1; break;
                case 'curse': st.curse = 1; break;
                case 'double': extra = true; break;
                case 'splash': boomMine(e.x, e.y, 70); break;
                case 'echo': setTimeout(() => { if (!run.ended && e.hp > 0) dealHit(e, base * 0.55, {}); }, 220); break;
                case 'toxcloud': enemies.forEach(o => { if (o !== e && o.hp > 0 && dist(o.x, o.y, e.x, e.y) < 140) dealHit(o, base * 0.05, { st: { poison: base * 0.22 } }); }); fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: 140, t: 0.35, life: 0.35, c: '#7fd13b' }); st.poison = base * 0.22; break;
                case 'ignite2': st.burn = base * 0.35; st.bleed = base * 0.3; break;
                case 'vacuum': enemies.forEach(o => { if (o !== e && !o.boss && o.hp > 0 && !o.pvp) { const d0 = dist(o.x, o.y, e.x, e.y); if (d0 < 220 && d0 > 1) { const k = Math.min(60, d0 * 0.4) / d0; o.x += (e.x - o.x) * k; o.y += (e.y - o.y) * k; } } }); fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: 100, t: 0.3, life: 0.3, c: '#b49aff' }); break;
                case 'leech': addHp(me.maxHp * 0.01); break;
                case 'shock': {
                    let c = 0; fx.push({ k: 'bolt', x: e.x, y: e.y, t: 0.25, life: 0.25, pts: [] });
                    enemies.forEach(o => { if (o !== e && o.hp > 0 && c < 3 && dist(o.x, o.y, e.x, e.y) < 190) { c++; fx.push({ k: 'line', x: e.x, y: e.y, x2: o.x, y2: o.y, t: 0.2, life: 0.2, c: '#ffe84a' }); dealHit(o, base * 0.6, {}); } });
                    break;
                }
                case 'meteor': {
                    const mx = e.x, my = e.y;
                    fx.push({ k: 'warn', x: mx, y: my, r: 70, t: 0.6, life: 0.6, c: '#ff8a3a' });
                    setTimeout(() => { if (!run.ended) boomMine(mx, my, 90); }, 600);
                    break;
                }
            }
        });
        if (A('lifesteal') > 0) addHp(Math.min(h.dmg * A('lifesteal'), me.maxHp * 0.06));   // 1回の命中で回復するのは最大HPの6%まで
        return { st: Object.keys(st).length ? st : null, extra: extra };
    }

    // 支援武器：自分と近くの味方を回復／鼓舞する（回復量は最大HPの割合。特殊ステータスが高いほど増える）
    function supportPulse(Tt) {
        const r = P.radius || Tt.radius || 150;
        const sp = Math.min(1, P.special / 3000);
        if (Tt.sup === 'heal' || Tt.sup === 'all') {
            const v = (Tt.sup === 'all' ? 0.03 : 0.04) + 0.05 * sp;
            applySupport({ k: 'heal', v: v, t: 2 }, true);
            netSend('sup', { k: 'heal', x: Math.round(me.x), y: Math.round(me.y), r: Math.round(r), v: +v.toFixed(3), t: 2, from: myId });
        }
        if (Tt.sup === 'buff' || Tt.sup === 'all') {
            applySupport({ k: 'buff', t: 4 + 3 * sp }, true);
            netSend('sup', { k: 'buff', x: Math.round(me.x), y: Math.round(me.y), r: Math.round(r), t: +(4 + 3 * sp).toFixed(1), from: myId });
        }
        fx.push({ k: 'ring', x: me.x, y: me.y, r: 0, max: r, t: 0.4, life: 0.4, c: Tt.sup === 'buff' ? '#ffd84a' : '#7aff9a' });
    }
    function applySupport(d, self) {
        if (me.dead) return;
        if (d.k === 'heal') {
            addHp(me.maxHp * clamp(Number(d.v) || 0, 0, 0.12)); me.regenT = Math.max(me.regenT || 0, clamp(Number(d.t) || 0, 0, 3));
            popups.push({ x: me.x, y: me.y - 30, t: 0.8, text: '+HP', c: '#7aff9a' });
        } else if (d.k === 'buff') {
            const t = clamp(Number(d.t) || 0, 0, 8);
            me.empowerT = Math.max(me.empowerT || 0, t); me.fortifyT = Math.max(me.fortifyT || 0, t);
            popups.push({ x: me.x, y: me.y - 30, t: 0.8, text: '鼓舞！', c: '#ffd84a' });
        }
    }


    // ================= 必殺技（ゲージ制）=================
    //  攻撃を当てるとゲージが溜まり、満タンで R キー（スマホは ⚡ ボタン）で、持っている武器に合った必殺技が出る。
    //  ゲージが溜まる量は「1振りにつき1回」（大勢に当てても増えすぎない）。フィニッシャーは多く溜まる。対人戦では使えない。
    const ULT_MAX = 100;
    const ULT_TYPES = {      // st: slash=連続斬り / quake=衝撃波 / lance=突進して貫く / volley=矢や弾の雨 / storm=雷の雨 / nova=魔法陣の大爆発
        sword:      { name: '剣聖の連斬', st: 'slash', n: 7, gap: 90, mult: 1.15, range: 1.35, arc: 1.9 },
        katana:     { name: '居合・千本桜', st: 'slash', n: 9, gap: 75, mult: 1.0, range: 1.3, arc: 1.3, blink: 70 },
        dagger:     { name: '影縫い乱舞', st: 'slash', n: 15, gap: 55, mult: 0.55, range: 1.0, arc: 2.2, blink: 40 },
        fist:       { name: '百裂拳', st: 'slash', n: 18, gap: 50, mult: 0.5, range: 0.95, arc: 1.8 },
        boots:      { name: '流星蹴り', st: 'slash', n: 10, gap: 80, mult: 0.75, range: 1.2, arc: 2.6, blink: 60 },
        twinblade:  { name: '双舞・嵐刃', st: 'slash', n: 12, gap: 65, mult: 0.65, range: 1.3, arc: 2.2 },
        scythe:     { name: '死神の刈り取り', st: 'slash', n: 4, gap: 160, mult: 1.7, range: 1.5, arc: 4.2 },
        halberd:    { name: '龍尾・大薙ぎ', st: 'slash', n: 3, gap: 180, mult: 2.0, range: 1.5, arc: 4.4 },
        greatsword: { name: '断罪の大地割り', st: 'quake', waves: 3, gap: 170, radius: 170, mult: 2.8, kn: 380 },
        axe:        { name: '狂戦士の旋風', st: 'quake', waves: 6, gap: 110, radius: 125, mult: 1.3, kn: 160 },
        hammer:     { name: '天槌・大震撃', st: 'quake', waves: 2, gap: 260, radius: 240, mult: 3.8, kn: 460 },
        spear:      { name: '貫穿の一閃', st: 'lance', len: 380, width: 56, fan: 1, rep: 3, gap: 130, mult: 2.4 },
        whip:       { name: '千条の鞭', st: 'lance', len: 340, width: 40, fan: 5, rep: 2, gap: 220, mult: 1.2 },
        kusarigama: { name: '鎖の嵐', st: 'lance', len: 320, width: 46, fan: 3, rep: 3, gap: 170, mult: 1.3 },
        bow:        { name: '星降りの矢雨', st: 'volley', n: 18, gap: 70, mult: 0.95, sky: true },
        crossbow:   { name: '破城の連弩', st: 'volley', n: 10, gap: 110, mult: 1.7, sky: false },
        pistol:     { name: '早撃ち乱射', st: 'volley', n: 26, gap: 45, mult: 0.55, sky: false },
        shotgun:    { name: '散弾の嵐', st: 'volley', n: 12, gap: 90, mult: 1.1, sky: false },
        chakram:    { name: '円月・千輪', st: 'volley', n: 9, gap: 100, mult: 1.2, sky: true },
        cannon:     { name: '魔導砲・全力射', st: 'nova', radius: 250, mult: 6.5, waves: 1, wind: 600 },
        wand:       { name: '天雷の魔法陣', st: 'storm', n: 8, gap: 130, mult: 2.2, wind: 500 },
        tome:       { name: '禁書・大解放', st: 'nova', radius: 215, mult: 3.6, waves: 2, wind: 500 },
        esper:      { name: '念動の大崩壊', st: 'nova', radius: 300, mult: 3.4, waves: 2, wind: 400 }
    };
    function ultDef() {
        if (weapon.mythicId && MYTHIC_ULT[weapon.mythicId]) return MYTHIC_ULT[weapon.mythicId];
        if (weapon.custom && weapon.rarity === 'mythic' && HW.motionUlt) { const mu = HW.motionUlt(weapon); if (mu) return mu; }      // 自分で作った必殺技
        const u = ULT_TYPES[weapon.type]; if (u) return u;
        const k = T.kind;
        if (k === 'line') return { name: '貫穿の一閃', st: 'lance', len: 360, width: 52, fan: 1, rep: 3, gap: 130, mult: 2.2 };
        if (k === 'smash') return { name: '大震撃', st: 'quake', waves: 3, gap: 180, radius: 200, mult: 2.8, kn: 320 };
        if (k === 'proj') return { name: '一斉掃射', st: 'volley', n: 16, gap: 70, mult: 0.9, sky: false };
        if (k === 'ring') return { name: '大崩壊', st: 'nova', radius: 280, mult: 3.2, waves: 2, wind: 450 };
        return { name: '連斬', st: 'slash', n: 7, gap: 90, mult: 1.1, range: 1.3, arc: 1.9 };
    }

    // ================= 神話の武器：固有の必殺技 =================
    //  通常の必殺技（ULT_TYPES）と同じ型（slash/quake/lance/volley/storm/nova）で、回数・威力が大きく、さらに次の効果が付く：
    //   heal=終わりに最大HPの割合を回復 / guard=終わりに結界（秒）/ exec=HP30%以下のザコを即座に倒す級の大ダメージ / lastMult=最後の一撃の倍率 / finale=最後の大爆発 {radius,mult}
    const MYTHIC_ULT = {
        legend_eater: { name: '世界喰らい・大顎', st: 'seq', phases: [{ st: 'quake', waves: 5, gap: 170, radius: 260, kn: 360, mult: 1.8 }, { st: 'bladedance', n: 8, dur: 2.8, mult: 0.3 }, { st: 'nova', radius: 340, waves: 2, wind: 450, mult: 2.2 }], finale: { radius: 460, mult: 8 }, heal: 0.25 },      // 地割れ→剣舞→大崩壊、最後に大爆発
        legend_necromance: { name: '魂の理・断絶', st: 'seq', phases: [{ st: 'quake', waves: 4, gap: 190, radius: 250, kn: 300, mult: 1.6 }, { st: 'bladedance', n: 10, dur: 3.0, mult: 0.3 }, { st: 'nova', radius: 330, waves: 2, wind: 450, mult: 2.0 }], finale: { radius: 440, mult: 7.5 }, heal: 0.2 },      // 地割れ→魂の刃の舞→大崩壊、最後に大爆発
        legend_relainbar: { name: '機神の裁き・全弾発射', st: 'seq', phases: [{ st: 'bladedance', n: 14, dur: 3.2, mult: 0.3 }, { st: 'nova', radius: 340, waves: 3, wind: 450, mult: 1.6 }], finale: { radius: 440, mult: 7.5 }, guard: 3 },      // 機兵の群れ→ミサイルの雨、最後に大爆発（終わりに結界）
        legend_fusion: { name: '天魔融合・断罪の双翼', st: 'seq', phases: [{ st: 'bladedance', n: 12, dur: 2.6, mult: 0.32 }, { st: 'quake', waves: 4, gap: 190, radius: 260, kn: 300, mult: 1.6 }, { st: 'nova', radius: 360, waves: 2, wind: 450, mult: 2.0 }], finale: { radius: 460, mult: 8 } },      // 光と魔の刃の舞→地割れ→大崩壊、最後に大爆発（天使と悪魔の融合）
        legend_increase: { name: '増殖の宴・無限分裂', st: 'seq', phases: [{ st: 'bladedance', n: 12, dur: 3.6, mult: 0.3 }, { st: 'nova', radius: 320, waves: 3, wind: 450, mult: 1.5 }], finale: { radius: 420, mult: 7 }, heal: 0.15 },      // 剣が増えて舞い、最後に大きな爆発
        legend_duality: { name: '双界終焉・紅蓮と氷獄', st: 'duality', R: 520, w: 70, n: 16, gap: 150, step: 0.30, mult: 1.25, finale: { radius: 440, mult: 7 } },      // 赤と青の光刃が逆向きに全周を薙ぎ払い、最後に紫の大爆発（ツイン・エレメンタルの大技を、自分のまわりに）
        legend_unbreakable: { name: '不壊の怒り・全方位照射', st: 'unbreak', R: 620, w: 54, n: 22, step: 0.37, gap: 120, mult: 0.8 },      // 不壊の悪魔の大技（壁から大量のビームを撃ち切り、逆回転でもう一度）を、自分のまわりの広い範囲に放つ
        eternal_serenity: { name: '万象開門・千剣', st: 'keeper', swordMult: 1.5, beamMult: 2.8, R: 430 },      // ゲートキーパーの大技（g1_ult）をプレイヤー側で再現
        twin_sirius:      { name: '次元の咆哮・瞬影連牙', st: 'slash', n: 30, gap: 36, mult: 0.9, range: 1.2, arc: 2.4, blink: 140, lastMult: 4, finale: { radius: 420, mult: 5 } },      // フェンリルの「瞬影突進」で切り抜け、「次元の咆哮」で薙ぎ払う
        orbit:            { name: '聖星墜天・流星群', st: 'meteor', n: 34, gap: 70, mult: 2.2, radius: 95, wind: 800, heal: 0.2, finale: { radius: 420, mult: 7, at: 'target' } },      // 星砕きの巨神の「流星群」を、神聖な力で降らせる
        grandia:          { name: '突撃の号令・覇王の進軍', st: 'quake', waves: 6, gap: 150, radius: 260, mult: 4.2, kn: 520, finale: { radius: 420, mult: 6 } },
        muMyou_katana:    { name: '鮮血の十字斬・血の渦', st: 'cross', n: 14, gap: 95, mult: 1.7, len: 560, width: 46, exec: true, finale: { radius: 380, mult: 5 } },      // 血の伯爵の「鮮血の十字斬」と「血の渦」
        brionac:          { name: '雷光の急降下・落雷の連鎖', st: 'lance', len: 620, width: 70, fan: 3, rep: 5, gap: 120, mult: 3.2, finale: { storm: 8, mult: 2.6 } },
        freikugel:        { name: 'ガトリング・魔弾掃射', st: 'volley', n: 48, gap: 28, mult: 0.85, sky: false, lastMult: 4 },
        asura_fist:       { name: '火花の連打・千手観音', st: 'slash', n: 44, gap: 28, mult: 0.7, range: 1.1, arc: 2.4, lastMult: 7, heal: 0.2 },
        thanatos:         { name: '廻転断ち・死神の三連鎌', st: 'slash', n: 5, gap: 200, mult: 3.4, range: 1.7, arc: 6.28, lastMult: 3, exec: true, heal: 0.3 },
        artemis:          { name: '星珠の舞・星々の裁き', st: 'volley', n: 40, gap: 40, mult: 1.3, sky: true, finale: { radius: 330, mult: 6 } },
        yggdrasil:        { name: '若木の呼び声・世界樹の根', st: 'storm', style: 'roots', n: 22, gap: 65, mult: 3.0, wind: 500, heal: 0.3, finale: { radius: 300, mult: 5 } }      // 嘆きの樹母の根が、敵の足もとから突き上がる
    };
    let curUlt = null;
    const MOTION_COMBO = (weapon.custom && weapon.rarity === 'mythic' && HW.motionCombo) ? HW.motionCombo(weapon) : null;      // 神話のオリジナル武器：自分で作った通常攻撃
    let ultFlashT = 0;
    function ultGain(n) { if (me.ultT > 0 || PVP) return; const was = me.ult || 0; me.ult = Math.min(ULT_MAX, was + n * ((weapon.mythicId || weapon.rarity === 'mythic') ? 1.6 : 1));      // 神話の武器は、ゲージが1.6倍の速さで溜まる
         if (was < ULT_MAX && me.ult >= ULT_MAX) { popups.push({ x: me.x, y: me.y - 46, t: 1.4, text: '⚡ 必殺技 準備完了！', c: '#ffd84a', big: true }); fx.push({ k: 'pring', x: me.x, y: me.y, r: 0, max: 70, t: 0.35, life: 0.35, c: '#ffd84a' }); } }
    function ultTargets(maxD) { return enemies.filter(e => e.hp > 0 && e.act !== false && dist(me.x, me.y, e.x, e.y) - e.r < maxD); }
    function ultLater(ms, fn) { setTimeout(() => { if (run.phase !== 'run' || me.dead) return; fn(); }, ms); }
    function ultFx(d) { spawnAtkFx(d); netSend('atk', d); mySwing(d); }
    function mySwing(d) { me.swingAt = performance.now(); me.swingDir = d.dir || 1; me.swingFin = d.fin; me.swingKind = d.k === 'line' ? 'line' : (d.k === 'proj' ? 'proj' : ((d.k === 'smash' || d.k === 'ring') ? 'smash' : 'cone')); }      // 見た目は仲間にも送る
    function ultHit(e, mult, kb, fin) { if (curUlt && curUlt.exec && !e.boss && e.maxHp && e.hp / e.maxHp < 0.3) mult *= 3; const h = strike(e, mult, kb || 0); hitFeel(e, { fin: !!fin, i: 1, ult: true }, h); return h; }
    function ultDur(U) {
        if (U.st === 'seq') return U.phases.reduce((a, Q) => a + ultDur(Q), 0) - 0.15 * (U.phases.length - 1);
        return U.st === 'bladedance' ? (U.dur || 3.2) + 0.5 : U.st === 'duality' ? 0.9 + U.n * U.gap / 1000 + 1.4 : U.st === 'unbreak' ? 7.0 : U.st === 'keeper' ? 5.0 : U.st === 'meteor' ? (U.wind + U.n * U.gap) / 1000 + 1.0 : U.st === 'cross' ? U.n * U.gap / 1000 + 0.5 : U.st === 'slash' ? U.n * U.gap / 1000 + 0.3 : U.st === 'quake' ? U.waves * U.gap / 1000 + 0.4 : U.st === 'lance' ? U.rep * U.gap / 1000 + 0.4 : U.st === 'volley' ? U.n * U.gap / 1000 + 0.3 : (U.wind || 400) / 1000 + (U.n ? U.n * U.gap / 1000 : U.waves * 0.25) + 0.3;
    }
    function ultBody(U, ang0, col, dur) {
        if (U.st === 'slash') {
            const range = (P.range || 80) * U.range;
            for (let i = 0; i < U.n; i++) ultLater(i * U.gap, () => {
                const last = i === U.n - 1, tg = nearestEnemy(me.x, me.y, 340);
                const ang = tg ? Math.atan2(tg.y - me.y, tg.x - me.x) : ang0 + (Math.random() - 0.5) * 1.2;
                if (tg && U.blink) { const L = blinkLimit(me.x, me.y, ang, Math.min(U.blink, Math.max(0, dist(me.x, me.y, tg.x, tg.y) - tg.r - 20)), me.r); me.x += Math.cos(ang) * L; me.y += Math.sin(ang) * L; pushOutOfRocks(me, me.r); }
                me.ang = ang; const arc = U.arc * (last ? 1.3 : 1), rg = range * (last ? 1.35 : 1);
                ultFx({ k: 'cone', x: me.x, y: me.y, a: ang, rng: rg, arc: arc, dir: i % 2 ? -1 : 1, fin: last ? 1 : 0, c: col });
                enemies.forEach(e => { if (e.hp <= 0 || e.act === false) return; const dd = dist(me.x, me.y, e.x, e.y); if (dd > rg + e.r) return; let da = Math.atan2(e.y - me.y, e.x - me.x) - ang; da = Math.atan2(Math.sin(da), Math.cos(da)); if (Math.abs(da) <= arc / 2 || dd < e.r + 18) ultHit(e, U.mult * (last ? (U.lastMult || 2.4) : 1), last ? 260 : 30, last); });
                if (last) { addShake(5, 0.2); hitStop(0.08); }
            });
        } else if (U.st === 'bladedance') {      // 剣舞：剣が分身して、あたり一面を舞い、敵を次々に切り刻む
            addMyBlades({ mode: 'dance', n: U.n, hits: 1, sz: U.sz || 1, bm: U.mult, a: ang0, x: me.x, y: me.y, life: U.dur || 3.2 });
            popups.push({ x: me.x, y: me.y - 44, t: 1.0, text: '🗡 剣舞！', c: col, big: true });
        } else if (U.st === 'quake') {
            for (let k = 0; k < U.waves; k++) ultLater(k * U.gap, () => {
                const r = U.radius * (1 + 0.3 * k), last = k === U.waves - 1, cx = me.x + Math.cos(ang0) * 40 * (U.waves > 2 ? 0 : 1), cy = me.y + Math.sin(ang0) * 40 * (U.waves > 2 ? 0 : 1);
                fx.push({ k: 'pring', x: cx, y: cy, r: 0, max: r, t: 0.35, life: 0.35, c: col, fill: true }); netSend('atk', { k: 'ring', x: cx, y: cy, a: 0, rad: r, c: col, fin: 1 });
                enemies.forEach(e => { if (e.hp > 0 && e.act !== false && dist(cx, cy, e.x, e.y) < r + e.r) { const a2 = Math.atan2(e.y - cy, e.x - cx); const h = strike(e, U.mult * (last ? 1.5 : 1), U.kn); hitFeel(e, { fin: last, i: 1, ult: true }, h); } });
                addShake(3 + k, 0.18); if (k === 0) hitStop(0.06);
            });
        } else if (U.st === 'lance') {
            for (let r = 0; r < U.rep; r++) ultLater(r * U.gap, () => {
                const tg = nearestEnemy(me.x, me.y, 420), base = tg ? Math.atan2(tg.y - me.y, tg.x - me.x) : ang0, last = r === U.rep - 1, ox = me.x, oy = me.y;
                me.ang = base;
                const sp = U.fan > 1 ? 1.5 / (U.fan - 1) : 0;
                for (let f = 0; f < U.fan; f++) {
                    const a = base + (U.fan > 1 ? (f - (U.fan - 1) / 2) * sp : 0), len = U.len * (last ? 1.2 : 1), x2 = ox + Math.cos(a) * len, y2 = oy + Math.sin(a) * len;
                    ultFx({ k: 'line', x: ox, y: oy, a: a, rng: len, w: U.width * (last ? 1.5 : 1), fin: last ? 1 : 0, c: col });
                    enemies.forEach(e => { if (e.hp > 0 && e.act !== false && distSeg(e.x, e.y, ox, oy, x2, y2) < U.width / 2 + e.r) ultHit(e, U.mult * (last ? 1.8 : 1) / Math.sqrt(U.fan), 120, last); });
                }
                if (U.fan === 1) { me.dashVX = Math.cos(base) * 900; me.dashVY = Math.sin(base) * 900; me.dashT = 0.12; }
                if (last) { addShake(4, 0.18); hitStop(0.07); }
            });
        } else if (U.st === 'volley') {
            for (let i = 0; i < U.n; i++) ultLater(i * U.gap, () => {
                const ts = ultTargets(560), e = ts.length ? ts[Math.floor(Math.random() * ts.length)] : null, last = i === U.n - 1;
                if (!e) { const a = ang0 + (Math.random() - 0.5) * 0.8; ultFx({ k: 'line', x: me.x, y: me.y, a: a, rng: 260, w: 10, fin: 0, c: col }); return; }
                if (U.sky) ultFx({ k: 'line', x: e.x, y: e.y - 240, a: Math.PI / 2, rng: 240, w: 12, fin: last ? 1 : 0, c: col });
                else { const a = Math.atan2(e.y - me.y, e.x - me.x); me.ang = a; ultFx({ k: 'line', x: me.x, y: me.y, a: a, rng: dist(me.x, me.y, e.x, e.y), w: 12, fin: last ? 1 : 0, c: col }); }
                ultHit(e, U.mult * (last ? (U.lastMult || 2) : 1), 40, last); if (last) { addShake(3, 0.15); hitStop(0.05); }
            });
        } else if (U.st === 'storm') {
            fx.push({ k: 'pring', x: me.x, y: me.y, r: 0, max: 150, t: (U.wind || 400) / 1000, life: (U.wind || 400) / 1000, c: col }); netSend('atk', { k: 'ring', x: me.x, y: me.y, a: 0, rad: 150, c: col, fin: 0 });
            for (let i = 0; i < U.n; i++) ultLater((U.wind || 400) + i * U.gap, () => {
                const ts = ultTargets(620), e = ts.length ? ts[Math.floor(Math.random() * ts.length)] : null, last = i === U.n - 1; if (!e) return;
                if (U.style === 'roots') ultFx({ k: 'line', x: e.x, y: e.y + 70, a: -Math.PI / 2, rng: 190, w: 26, fin: 1, c: '#8aff7a' });      // 根が足もとから突き上がる
                else ultFx({ k: 'line', x: e.x, y: e.y - 280, a: Math.PI / 2, rng: 280, w: 22, fin: 1, c: '#fff6a8' });
                fx.push({ k: 'pring', x: e.x, y: e.y, r: 0, max: 70, t: 0.22, life: 0.22, c: U.style === 'roots' ? '#8aff7a' : col });
                enemies.forEach(q => { if (q.hp > 0 && q.act !== false && dist(e.x, e.y, q.x, q.y) < 70 + q.r) ultHit(q, U.mult * (last ? (U.lastMult || 1.8) : 1), 60, last); });
                addShake(1.5, 0.08);
            });
        } else if (U.st === 'meteor') {      // 聖星墜天・流星群：頭上に光輪を広げ、天から無数の隕石を敵に降らせる
            const wind = U.wind || 800;
            fx.push({ k: 'pring', x: me.x, y: me.y, r: 0, max: 170, t: wind / 1000, life: wind / 1000, c: '#ffe9a0', fill: true }); netSend('atk', { k: 'ring', x: me.x, y: me.y, a: 0, rad: 170, c: '#ffe9a0', fin: 1 });
            fx.push({ k: 'pring', x: me.x, y: me.y, r: 0, max: 110, t: wind / 1000 * 0.8, life: wind / 1000 * 0.8, c: '#ffffff' });
            for (let i = 0; i < U.n; i++) ultLater(wind + i * U.gap, () => {
                const ts = ultTargets(780), e = ts.length ? ts[Math.floor(Math.random() * ts.length)] : null;
                const tx = e ? e.x + (Math.random() - 0.5) * 50 : me.x + (Math.random() - 0.5) * 700, ty = e ? e.y + (Math.random() - 0.5) * 50 : me.y + (Math.random() - 0.5) * 500, R = U.radius || 95, fall = 0.4;
                fx.push({ k: 'meteor', sx: tx + 170 + Math.random() * 80, sy: ty - 520, x: tx, y: ty, r: R, t: fall, life: fall });
                ultLater(fall * 1000, () => {
                    fx.push({ k: 'pring', x: tx, y: ty, r: 0, max: R, t: 0.28, life: 0.28, c: '#ffd36a', fill: true }); netSend('atk', { k: 'ring', x: tx, y: ty, a: 0, rad: R, c: '#ffd36a', fin: 0 });
                    enemies.forEach(q => { if (q.hp > 0 && q.act !== false && dist(tx, ty, q.x, q.y) < R + q.r) ultHit(q, U.mult, 160, false); });
                    if (i % 3 === 0) addShake(2, 0.08);
                });
            });
        } else if (U.st === 'cross') {      // 鮮血の十字斬：敵ひとりひとりに、十字の斬撃を刻む
            for (let i = 0; i < U.n; i++) ultLater(i * U.gap, () => {
                const ts = ultTargets(680), e = ts.length ? ts[Math.floor(Math.random() * ts.length)] : null, last = i === U.n - 1;
                const cx = e ? e.x : me.x + (Math.random() - 0.5) * 300, cy = e ? e.y : me.y + (Math.random() - 0.5) * 300, base = i * 0.55 + Math.random() * 0.3, len = U.len * (last ? 1.4 : 1), w = U.width * (last ? 1.5 : 1);
                if (e) { const an = Math.atan2(e.y - me.y, e.x - me.x), L = blinkLimit(me.x, me.y, an, Math.max(0, dist(me.x, me.y, e.x, e.y) - e.r - 40), me.r); me.x += Math.cos(an) * L; me.y += Math.sin(an) * L; pushOutOfRocks(me, me.r); me.ang = an; }
                const lines = [base, base + Math.PI / 2].map(a => ({ a: a, x1: cx - Math.cos(a) * len / 2, y1: cy - Math.sin(a) * len / 2, x2: cx + Math.cos(a) * len / 2, y2: cy + Math.sin(a) * len / 2 }));
                lines.forEach(l => ultFx({ k: 'line', x: l.x1, y: l.y1, a: l.a, rng: len, w: w, fin: 1, c: '#ff4a4a' }));
                enemies.forEach(q => { if (q.hp <= 0 || q.act === false) return; if (lines.some(l => distSeg(q.x, q.y, l.x1, l.y1, l.x2, l.y2) < w / 2 + q.r)) ultHit(q, U.mult * (last ? 2.2 : 1), 120, last); });
                if (last) { addShake(5, 0.2); hitStop(0.07); }
            });
        } else if (U.st === 'unbreak') {      // 不壊の怒り：自分のまわりに砲門がぐるりと並び、中心へ向けて大量のビームを撃つ。撃ち切ったら、逆回転でもう一度
            const cx = me.x, cy = me.y, R = U.R, W = U.w, per = U.n, step = U.step, off = Math.random() * 6.28;
            const beam = (theta, atMs) => ultLater(atMs, () => {
                const gx = clamp(cx + Math.cos(theta) * R, 40, WORLD_W - 40), gy = clamp(cy + Math.sin(theta) * R, 40, WORLD_H - 40);
                const a = Math.atan2(cy - gy, cx - gx), len = R * 1.9, x2 = gx + Math.cos(a) * len, y2 = gy + Math.sin(a) * len;
                fx.push({ k: 'line', x: gx, y: gy, x2: x2, y2: y2, t: 0.28, life: 0.28, c: '#ff8a9a', w: 3 });      // 細い予告線
                ultLater(280, () => {
                    ultFx({ k: 'line', x: gx, y: gy, a: a, rng: len, w: W, fin: 1, c: col });
                    enemies.forEach(e => { if (e.hp > 0 && e.act !== false && distSeg(e.x, e.y, gx, gy, x2, y2) < W / 2 + e.r) ultHit(e, U.mult, 120, false); });
                });
            });
            fx.push({ k: 'pring', x: cx, y: cy, r: 0, max: R, t: 0.6, life: 0.6, c: col }); netSend('atk', { k: 'ring', x: cx, y: cy, a: 0, rad: R, c: col, fin: 0 });
            const t0 = 500, t1 = t0 + per * U.gap + 450;
            for (let k = 0; k < per; k++) beam(off + k * step, t0 + k * U.gap);                        // 順回転
            for (let k = 0; k < per; k++) beam(off + (per - 1 - k) * step + 0.18, t1 + k * U.gap);     // 逆回転でもう一度
        } else if (U.st === 'duality') {      // 双界終焉：赤い光刃は時計回り、青い光刃は反時計回りに、自分を中心にぐるりと全周を薙ぎ払う。最後に2色が混ざった紫の大爆発
            const cx = me.x, cy = me.y, R = U.R, W = U.w, N = U.n, off = Math.random() * 6.28, RED = '#ff5a3a', BLUE = '#4ac8ff';
            fx.push({ k: 'pring', x: cx, y: cy, r: 0, max: R, t: 0.8, life: 0.8, c: RED }); fx.push({ k: 'pring', x: cx, y: cy, r: 0, max: R * 0.7, t: 0.8, life: 0.8, c: BLUE });
            netSend('atk', { k: 'ring', x: cx, y: cy, a: 0, rad: R, c: '#c06aff', fin: 0 });
            const blade = (theta, col, atMs) => ultLater(atMs, () => {
                const x2 = cx + Math.cos(theta) * R, y2 = cy + Math.sin(theta) * R;
                ultFx({ k: 'line', x: cx, y: cy, a: theta, rng: R, w: W, fin: 1, c: col });
                enemies.forEach(e => { if (e.hp > 0 && e.act !== false && distSeg(e.x, e.y, cx, cy, x2, y2) < W / 2 + e.r) ultHit(e, U.mult, 140, false); });
            });
            const t0 = 700;
            for (let k = 0; k < N; k++) { blade(off + k * U.step, RED, t0 + k * U.gap); blade(off + Math.PI - k * U.step, BLUE, t0 + k * U.gap); }
            const tEnd = t0 + N * U.gap + 350;
            ultLater(tEnd, () => {
                const F = U.finale; addShake(7, 0.3); hitStop(0.09);
                fx.push({ k: 'pring', x: cx, y: cy, r: 0, max: F.radius, t: 0.5, life: 0.5, c: '#c06aff', fill: true }); fx.push({ k: 'pring', x: cx, y: cy, r: 0, max: F.radius * 0.6, t: 0.4, life: 0.4, c: '#ffffff', fill: true });
                netSend('atk', { k: 'ring', x: cx, y: cy, a: 0, rad: F.radius, c: '#c06aff', fin: 1 });
                enemies.forEach(e => { if (e.hp > 0 && e.act !== false && dist(cx, cy, e.x, e.y) < F.radius + e.r) ultHit(e, F.mult, 360, true); });
            });
        } else if (U.st === 'keeper') {      // ゲートキーパーの大技：周囲に12の門を開き、剣の雨とビームを降らせる（時間の流れは boss-moves.js の g1_ult と同じ）
            const cx = me.x, cy = me.y, R = U.R || 430, gates = [], off = Math.random() * 6.28;
            const aimAt = (gx, gy) => { const ts = ultTargets(900); let best = null, bd = 1e9; ts.forEach(e => { const dd = dist(gx, gy, e.x, e.y); if (dd < bd) { bd = dd; best = e; } }); return best ? Math.atan2(best.y - gy, best.x - gx) : Math.atan2(cy - gy, cx - gx); };
            for (let i = 0; i < 12; i++) { const an = off + i * Math.PI * 2 / 12, gx = clamp(cx + Math.cos(an) * R, 40, WORLD_W - 40), gy = clamp(cy + Math.sin(an) * R, 40, WORLD_H - 40); gates.push({ x: gx, y: gy }); fx.push({ k: 'gate', x: gx, y: gy, t: 5.0, life: 5.0 }); }
            const volley = (at, frac, track, spd) => ultLater(at * 1000, () => {
                const sent = []; gates.forEach(g => { if (frac < 1 && Math.random() > frac) return; const a = (track ? aimAt(g.x, g.y) : Math.atan2(cy - g.y, cx - g.x)) + (Math.random() - 0.5) * 0.06; sent.push(fireKeeperSword(g.x, g.y, a, U.swordMult || 1.5, { spd: spd || 560, life: 2.2, pierce: 4, fin: false })); });
                if (sent.length) netSend('shot', { s: sent }); addShake(1.5, 0.08);
            });
            const beams = (at, list, frac, w, tele) => ultLater(at * 1000, () => {
                list.forEach(g => {
                    if (frac < 1 && Math.random() > frac) return; const a = g.a != null ? g.a : aimAt(g.x, g.y), len = 1500, x2 = g.x + Math.cos(a) * len, y2 = g.y + Math.sin(a) * len;
                    fx.push({ k: 'line', x: g.x, y: g.y, x2: x2, y2: y2, t: tele, life: tele, c: '#fff2a0', w: 3 });      // 細い予告線
                    ultLater(tele * 1000, () => { ultFx({ k: 'line', x: g.x, y: g.y, a: a, rng: len, w: w, fin: 1, c: '#fff2a0' }); enemies.forEach(e => { if (e.hp > 0 && e.act !== false && distSeg(e.x, e.y, g.x, g.y, x2, y2) < w / 2 + e.r) ultHit(e, U.beamMult || 2.8, 80, true); }); addShake(3, 0.12); });
                });
            });
            volley(1.0, 1, false, 540); volley(1.5, 0.7, true); volley(1.9, 0.7, true); volley(2.3, 0.7, true);
            beams(2.4, gates, 0.4, 56, 0.45);
            volley(3.0, 0.6, true, 600); volley(3.4, 0.6, true, 600);
            ultLater(3.4 * 1000, () => {      // 左右に6つの門（横から射るビーム用）
                const side = []; for (let i = 0; i < 6; i++) { const left = i % 2 === 0, gx = clamp(cx + (left ? -600 : 600), 40, WORLD_W - 40), gy = clamp(cy + (i - 2.5) * 150, 40, WORLD_H - 40); side.push({ x: gx, y: gy, a: left ? 0 : Math.PI }); fx.push({ k: 'gate', x: gx, y: gy, t: 2.6, life: 2.6 }); }
                beams(0.9, side, 1, 60, 0.5);
            });
        } else {      // nova：魔法陣を広げて、そのあと大爆発
            const tg = nearestEnemy(me.x, me.y, 700), cx = tg ? tg.x : me.x + Math.cos(ang0) * 240, cy = tg ? tg.y : me.y + Math.sin(ang0) * 240;
            const wind = U.wind || 450;
            fx.push({ k: 'pring', x: cx, y: cy, r: 0, max: U.radius, t: wind / 1000, life: wind / 1000, c: col }); netSend('atk', { k: 'ring', x: cx, y: cy, a: 0, rad: U.radius, c: col, fin: 0 });
            for (let k = 0; k < U.waves; k++) ultLater(wind + k * 260, () => {
                const r = U.radius * (1 + 0.25 * k), last = k === U.waves - 1;
                fx.push({ k: 'pring', x: cx, y: cy, r: 0, max: r, t: 0.4, life: 0.4, c: '#ffffff', fill: true }); netSend('atk', { k: 'ring', x: cx, y: cy, a: 0, rad: r, c: col, fin: 1 });
                enemies.forEach(e => { if (e.hp > 0 && e.act !== false && dist(cx, cy, e.x, e.y) < r + e.r) ultHit(e, U.mult * (last ? 1.4 : 1), 220, last); });
                addShake(5, 0.25); hitStop(0.07);
            });
        }
    }
    function castUlt() {
        if (PVP || me.dead || me.stunT > 0 || me.cast || me.gch > 0 || me.ultT > 0 || run.phase !== 'run') return;
        if ((me.ult || 0) < ULT_MAX) { popups.push({ x: me.x, y: me.y - 34, t: 0.8, text: '必殺ゲージ ' + Math.floor(me.ult || 0) + '%', c: '#ffe08a' }); return; }
        const U = ultDef(), col = FXCOL || HW.rarityOf(weapon).color; me.ult = 0; curUlt = U;
        const dur = ultDur(U);
        const lockT = (U.st === 'keeper' || U.st === 'unbreak' || U.st === 'duality' || U.st === 'bladedance') ? 1.0 : dur, godT = U.st === 'keeper' ? 2.2 : (U.st === 'unbreak' ? 2.6 : (U.st === 'duality' ? dur : dur));      // ゲートキーパーの大技は、門が働いている間も動ける（動けないのは最初の1秒だけ）
        me.ultT = lockT; me.invHard = Math.max(me.invHard || 0, godT); me.inv = Math.max(me.inv, godT); me.dashT = 0; me.ang = aimAngle();
        ultFlashT = 0.3; addShake(4, 0.25); announce('⚡ ' + U.name, 1500);
        if (window.SBSound) SBSound.sfx('ult');
        fx.push({ k: 'pring', x: me.x, y: me.y, r: 0, max: 110, t: 0.4, life: 0.4, c: col, fill: true }); netSend('atk', { k: 'ring', x: me.x, y: me.y, a: me.ang, rad: 110, c: col, fin: 1 });
        const ang0 = me.ang;
        if (U.st === 'seq') {      // 自作の必殺技：いくつかの型を、順番につなげる
            let off = 0;
            U.phases.forEach((Q, k) => { const dq = ultDur(Q), go = () => { me.ang = aimAngle(); ultBody(Q, me.ang, col, dq); }; if (k === 0) go(); else ultLater(off, go); off += Math.max(300, dq * 1000 - 150); });
        } else ultBody(U, ang0, col, dur);
        ultFinish(U, dur, col);
    }
    // 神話の必殺技の「終わりの効果」：最後の大爆発・体力の回復・結界
    function ultFinish(U, dur, col) {
        if (!(U.finale || U.heal || U.guard)) return;
        ultLater(Math.max(150, dur * 1000 - 250), () => {
            const F = U.finale;
            if (F && F.radius) {
                const tg = F.at === 'target' ? nearestEnemy(me.x, me.y, 900) : null, fxx = tg ? tg.x : me.x, fyy = tg ? tg.y : me.y;      // at:'target' は、敵のいる場所に落とす
                fx.push({ k: 'pring', x: fxx, y: fyy, r: 0, max: F.radius, t: 0.45, life: 0.45, c: '#ffffff', fill: true }); netSend('atk', { k: 'ring', x: fxx, y: fyy, a: 0, rad: F.radius, c: col, fin: 1 });
                enemies.forEach(e => { if (e.hp > 0 && e.act !== false && dist(fxx, fyy, e.x, e.y) < F.radius + e.r) ultHit(e, F.mult, 320, true); });
                addShake(7, 0.3); hitStop(0.09);
            }
            if (F && F.storm) for (let i = 0; i < F.storm; i++) ultLater(i * 90, () => {
                const ts = ultTargets(640), e = ts.length ? ts[Math.floor(Math.random() * ts.length)] : null; if (!e) return;
                ultFx({ k: 'line', x: e.x, y: e.y - 300, a: Math.PI / 2, rng: 300, w: 26, fin: 1, c: '#fff6a8' });
                fx.push({ k: 'pring', x: e.x, y: e.y, r: 0, max: 80, t: 0.22, life: 0.22, c: col });
                enemies.forEach(q => { if (q.hp > 0 && q.act !== false && dist(e.x, e.y, q.x, q.y) < 80 + q.r) ultHit(q, F.mult, 80, true); });
                addShake(2, 0.08);
            });
            if (U.heal) { addHp(me.maxHp * U.heal); popups.push({ x: me.x, y: me.y - 40, t: 1.1, text: '💚 回復', c: '#8affb0', big: true }); }
            if (U.guard) { me.guardT = Math.max(me.guardT || 0, U.guard); popups.push({ x: me.x, y: me.y - 56, t: 1.1, text: '🛡 結界', c: '#8fe8ff', big: true }); }
        });
    }

    // ================= 通常攻撃コンボ =================
    //  連続で攻撃すると、段が進んで動きが変わる。最後の段（フィニッシャー）は大きく振り、強くふっ飛ばす。
    //  m=ダメージ倍率 / r=範囲 / a=角度 / w=幅 / cd=次の攻撃までの間 / kn=ノックバック / lunge=前に踏み込む量(px) / dir=振る向き(1か-1) / fin=フィニッシャー
    const COMBO_STYLES = {
        blade: [{ m: 1.0, dir: 1 }, { m: 1.05, r: 1.05, dir: -1, lunge: 14 }, { m: 1.9, r: 1.25, a: 1.35, cd: 1.5, kn: 1.8, lunge: 30, dir: 1, fin: true }],
        fast:  [{ m: 0.9, dir: 1 }, { m: 0.9, dir: -1 }, { m: 1.0, r: 1.05, dir: 1, lunge: 10 }, { m: 2.2, r: 1.3, a: 1.3, cd: 2.2, kn: 3, lunge: 26, dir: -1, fin: true }],
        heavy: [{ m: 1.0, dir: 1 }, { m: 1.8, r: 1.2, a: 1.1, cd: 1.3, kn: 2, dir: -1, fin: true }],
        pole:  [{ m: 1.0 }, { m: 1.05, r: 1.05, lunge: 12 }, { m: 1.9, r: 1.2, w: 1.6, cd: 1.5, kn: 2, lunge: 24, fin: true }],
        ranged: [{ m: 1.0 }, { m: 1.0 }, { m: 1.6, cd: 1.4, fin: true }]
    };
    const COMBO_BY_TYPE = { dagger: 'fast', fist: 'fast', boots: 'fast', twinblade: 'fast', greatsword: 'heavy', axe: 'heavy', hammer: 'heavy', spear: 'pole', halberd: 'pole', whip: 'pole', kusarigama: 'pole' };
    function comboStyle() { return COMBO_BY_TYPE[weapon.type] || ((T.kind === 'proj') ? 'ranged' : (T.kind === 'line' ? 'pole' : (T.kind === 'smash' ? 'heavy' : 'blade'))); }

    // ================= 神話の武器：固有の通常攻撃コンボ =================
    //  通常のコンボ（COMBO_STYLES）に加えて、神話の武器だけ次の特別な動きが付く：
    //   wave=剣気（前方の長い範囲に追撃。値は届く距離の倍率）/ quake=その場に衝撃波（値は半径）/ heal=当てるたび最大HPの割合を回復 / xs=弾が増える本数 / homing=弾が追尾
    const MYTHIC_COMBO = {
        legend_unbreakable: [{ m: 1, cd: 1 }],      // 不壊：1回の攻撃で7本のレーザー。コンボは無し
        legend_eater: [{ m: 1.1, dir: 1, r: 1.1, a: 1.3, heal: 0.008 }, { m: 1.1, dir: -1, r: 1.1, a: 1.3, lunge: 20, heal: 0.008 }, { m: 1.3, dir: 1, r: 1.15, lunge: 30, quake: 120, heal: 0.01, blades: { mode: 'spiral', n: 2, hits: 2, sz: 1, sp: 1, cap: 2 }, bm: 0.3 }, { m: 2.6, dir: -1, r: 1.4, a: 1.6, cd: 1.8, kn: 3, lunge: 36, fin: true, quake: 170, wave: 2.0, heal: 0.02, blades: { mode: 'boomerang', n: 2, hits: 2, sz: 1.2, sp: 1, cap: 2 }, bm: 0.4 }],      // 喰らう：叩きつけるたびに体力を奪い、渦を巻く牙とブーメランの顎が追撃する
        legend_necromance: [{ m: 1.0, dir: 1, a: 1.3, heal: 0.006, blades: { mode: 'orbit', n: 1, hits: 2, sz: 1, sp: 1, cap: 3 }, bm: 0.25 }, { m: 1.0, dir: -1, r: 1.05, a: 1.3, heal: 0.006, blades: { mode: 'orbit', n: 2, hits: 2, sz: 1, sp: 1, cap: 4 }, bm: 0.25 }, { m: 1.2, dir: 1, r: 1.1, lunge: 16, heal: 0.008, wave: 1.4, blades: { mode: 'spiral', n: 2, hits: 2, sz: 1, sp: 1, cap: 4 }, bm: 0.28 }, { m: 2.5, dir: -1, r: 1.35, a: 1.6, cd: 1.8, kn: 3, lunge: 34, fin: true, quake: 160, wave: 2.0, heal: 0.02, blades: { mode: 'rain', n: 4, hits: 2, sz: 1.2, sp: 1, cap: 4 }, bm: 0.3 }],      // 死霊：魂の刃が舞い、体力を吸う
        legend_relainbar: [{ m: 1.0, dir: 1, blades: { mode: 'boomerang', n: 1, hits: 2, sz: 1, sp: 1, cap: 2 }, bm: 0.3 }, { m: 1.0, dir: -1, r: 1.05, blades: { mode: 'boomerang', n: 2, hits: 2, sz: 1, sp: 1, cap: 3 }, bm: 0.3 }, { m: 1.1, dir: 1, r: 1.1, lunge: 14, wave: 1.5, blades: { mode: 'strike', n: 3, hits: 2, sz: 1, sp: 1, cap: 4 }, bm: 0.28 }, { m: 2.4, dir: -1, r: 1.3, a: 1.5, cd: 1.8, kn: 3, lunge: 30, fin: true, quake: 140, wave: 2.2, blades: { mode: 'rain', n: 5, hits: 2, sz: 1.2, sp: 1, cap: 5 }, bm: 0.3, blades2: { mode: 'orbit', n: 3, hits: 3, sz: 1, sp: 1, cap: 6 }, bm2: 0.1 }],      // 機神：機兵が飛び出して、遠くの敵まで追撃する
        legend_fusion: [{ m: 1.0, dir: 1, blades: { mode: 'strike', n: 1, hits: 2, sz: 1, sp: 1, cap: 2 }, bm: 0.3 }, { m: 1.0, dir: -1, r: 1.05, blades: { mode: 'orbit', n: 2, hits: 2, sz: 1, sp: 1, cap: 3 }, bm: 0.28 }, { m: 1.15, dir: 1, r: 1.1, lunge: 40, wave: 1.5, blades: { mode: 'strike', n: 3, hits: 2, sz: 1, sp: 1, cap: 4 }, bm: 0.28 }, { m: 2.6, dir: -1, r: 1.3, a: 1.5, cd: 1.8, kn: 3, lunge: 36, fin: true, quake: 150, wave: 2.2, blades: { mode: 'rain', n: 5, hits: 2, sz: 1.2, sp: 1, cap: 5 }, bm: 0.3, blades2: { mode: 'orbit', n: 3, hits: 3, sz: 1, sp: 1, cap: 6 }, bm2: 0.1 }],      // 融合：光と魔の刃を交互に振るい、3段目は一瞬で詰め寄り、4段目は刃の雨
        legend_increase: [{ m: 1.0, dir: 1, blades: { mode: 'strike', n: 1, hits: 2, sz: 1, sp: 1, cap: 2 }, bm: 0.25 }, { m: 1.0, dir: -1, r: 1.05, blades: { mode: 'strike', n: 2, hits: 2, sz: 1, sp: 1, cap: 2 }, bm: 0.25 }, { m: 1.1, dir: 1, r: 1.1, lunge: 14, blades: { mode: 'sweep', n: 2, hits: 2, sz: 1, sp: 1, cap: 2 }, bm: 0.28 }, { m: 2.4, r: 1.35, a: 1.5, cd: 1.8, kn: 3, lunge: 32, dir: -1, fin: true, quake: 150, blades: { mode: 'rain', n: 4, hits: 2, sz: 1.2, sp: 1, cap: 2 }, bm: 0.3, blades2: { mode: 'orbit', n: 3, hits: 3, sz: 1, sp: 1, cap: 6 }, bm2: 0.1 }],      // 増殖：斬るたびに分身の剣が増える（1本→2本→X字→剣の雨）
        legend_duality: [{ m: 1.0, dir: 1 }, { m: 1.0, dir: -1, r: 1.05 }, { m: 1.15, dir: 1, r: 1.1, lunge: 14 }, { m: 3.4, r: 1.35, a: 1.5, cd: 1.8, kn: 3, lunge: 32, dir: -1, fin: true, quake: 170, wave: 1.9 }],      // 双界：炎と氷のX字斬りを3回、4段目は紫に光る大斬撃（衝撃波つき）
        eternal_serenity: [{ m: 1.1, dir: 1, keeper: 1 }, { m: 1.1, r: 1.1, dir: -1, keeper: 1 }, { m: 1.3, r: 1.2, dir: 1, wave: 1.7, keeper: 2 }, { m: 1.3, r: 1.2, dir: -1, wave: 1.9, lunge: 20, keeper: 2 }, { m: 3.4, r: 1.6, a: 1.6, cd: 1.7, kn: 3, lunge: 40, dir: 1, fin: true, quake: 150, wave: 2.4, keeper: 5 }],      // keeper=ゲートキーパーの剣を飛ばす本数
        twin_sirius: [{ m: 0.8, dir: 1 }, { m: 0.8, dir: -1 }, { m: 0.85, dir: 1, r: 1.05 }, { m: 0.85, dir: -1, r: 1.05 }, { m: 0.9, dir: 1, r: 1.1, lunge: 16 }, { m: 2.8, r: 1.35, a: 1.4, cd: 2.0, kn: 3, lunge: 36, dir: -1, fin: true, quake: 110 }],
        orbit: [{ m: 1.2, a: 1.2, r: 1.1, dir: 1, wave: 1.7 }, { m: 1.3, a: 1.3, r: 1.15, dir: -1, wave: 1.9, quake: 110 }, { m: 3.2, a: 1.9, r: 1.4, cd: 1.7, kn: 2.5, dir: 1, fin: true, wave: 2.3, quake: 240 }],      // 光輪（quake）が広がる
        grandia: [{ m: 1.7, r: 1.1, kn: 2, dir: 1, quake: 90 }, { m: 1.9, r: 1.15, kn: 2.4, dir: -1, quake: 120 }, { m: 4.0, r: 1.4, a: 1.2, cd: 1.7, kn: 4, dir: 1, fin: true, quake: 220 }],
        muMyou_katana: [{ m: 1.0, dir: 1, lunge: 50 }, { m: 1.0, dir: -1, lunge: 50 }, { m: 1.1, dir: 1, lunge: 50 }, { m: 1.1, dir: -1, lunge: 50 }, { m: 3.2, r: 1.3, a: 1.3, cd: 1.6, kn: 2.5, dir: 1, lunge: 70, fin: true, wave: 2.2 }],
        brionac: [{ m: 1.1, r: 1.3, wave: 1.4 }, { m: 1.15, r: 1.35, wave: 1.5, lunge: 20 }, { m: 1.25, r: 1.4, wave: 1.6, lunge: 20 }, { m: 3.2, r: 1.6, w: 2.0, cd: 1.7, kn: 3, lunge: 40, fin: true, wave: 2.5 }],
        freikugel: [{ m: 1.0, xs: 1, homing: true }, { m: 1.0, xs: 1, homing: true }, { m: 1.1, xs: 2, homing: true }, { m: 2.2, xs: 4, homing: true, cd: 1.5, fin: true }],
        asura_fist: [{ m: 0.75, dir: 1 }, { m: 0.75, dir: -1 }, { m: 0.8, dir: 1 }, { m: 0.8, dir: -1 }, { m: 0.9, dir: 1, lunge: 14 }, { m: 3.0, r: 1.35, a: 1.4, cd: 2.0, kn: 4.5, lunge: 30, dir: -1, fin: true, quake: 170 }],
        thanatos: [{ m: 1.3, a: 1.3, r: 1.2, dir: 1, heal: 0.01 }, { m: 1.4, a: 1.4, r: 1.25, dir: -1, heal: 0.01 }, { m: 3.6, a: 1.9, r: 1.5, cd: 1.7, kn: 2.5, dir: 1, fin: true, heal: 0.04, wave: 1.9 }],
        artemis: [{ m: 1.0, xs: 1, homing: true }, { m: 1.0, xs: 2, homing: true }, { m: 2.0, xs: 5, homing: true, cd: 1.5, fin: true }],
        yggdrasil: [{ m: 1.0, homing: true }, { m: 1.0, xs: 1, homing: true }, { m: 2.4, xs: 3, homing: true, cd: 1.6, fin: true, quake: 180 }]
    };
    // 神話の追加効果：剣気（前方の長い範囲）・衝撃波・回復。通常の命中とは別に、全員に当たる
    // ゲートキーパーの剣：敵を追って飛ぶ金色の剣（ボスが門から撃つ剣と同じもの）。1本ごとに貫通し、威力は mult
    function fireKeeperSword(x, y, a, mult, o) {
        o = o || {}; const sp = o.spd || 620, life = o.life || 1.1, s = { x: x, y: y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, r: 11, life: life, pierce: o.pierce != null ? o.pierce : 3, hit: {}, homing: o.homing !== false, aoe: 0, c: '#ffe9a0', m: mult, fin: o.fin ? 1 : 0, cs: 1, vol: 0, kd: 1 };
        myShots.push(s); return { x: Math.round(x), y: Math.round(y), vx: Math.round(s.vx), vy: Math.round(s.vy), r: 11, life: +life.toFixed(2), pierce: s.pierce, aoe: 0, c: s.c, kd: 1 };
    }
    function fireKeeperSwords(cs, ang) {
        const n = cs.keeper | 0, sent = [];
        for (let i = 0; i < n; i++) sent.push(fireKeeperSword(me.x + Math.cos(ang) * 18, me.y + Math.sin(ang) * 18, ang + (n > 1 ? (i - (n - 1) / 2) * (cs.fin ? 0.3 : 0.18) : 0), 0.7 * cs.m, { fin: cs.fin }));
        if (sent.length) netSend('shot', { s: sent });
    }
    function mythicExtras(cs, d, ang) {
        let n = 0;
        [[cs.blades, cs.bm], [cs.blades2, cs.bm2]].forEach(q => { const B = q[0]; if (B) addMyBlades({ mode: B.mode, n: B.n, hits: B.hits, cap: B.cap, sz: B.sz, sp: B.sp, bm: q[1], a: ang, x: me.x, y: me.y, fin: cs.fin ? 1 : 0, col: cs.col }); });      // 剣が分身して攻撃する（最大2組）
        if (cs.keeper) fireKeeperSwords(cs, ang);
        if (cs.wave) {
            const len = d.rng * cs.wave, x2 = me.x + Math.cos(ang) * len, y2 = me.y + Math.sin(ang) * len;
            const wd = { k: 'line', x: me.x, y: me.y, a: ang, rng: len, w: 36 * (cs.fin ? 1.6 : 1), fin: cs.fin ? 1 : 0, c: d.c }; spawnAtkFx(wd); netSend('atk', wd);
            enemies.forEach(e => { if (e.hp > 0 && e.act !== false && distSeg(e.x, e.y, me.x, me.y, x2, y2) < 26 + e.r) { const h = strike(e, 0.7 * cs.m, 60); hitFeel(e, { fin: !!cs.fin, i: 1, ult: true }, h); n++; } });
        }
        if (cs.quake) {
            fx.push({ k: 'pring', x: me.x, y: me.y, r: 0, max: cs.quake, t: 0.28, life: 0.28, c: d.c, fill: true }); netSend('atk', { k: 'ring', x: me.x, y: me.y, a: 0, rad: cs.quake, c: d.c, fin: 1 });
            enemies.forEach(e => { if (e.hp > 0 && e.act !== false && dist(me.x, me.y, e.x, e.y) < cs.quake + e.r) { const h = strike(e, 0.6 * cs.m, 160); hitFeel(e, { fin: !!cs.fin, i: 1, ult: true }, h); n++; } });
            addShake(cs.fin ? 4 : 2, 0.12);
        }
        if (cs.heal && n > 0) addHp(me.maxHp * cs.heal);
    }
    function nextComboStep() {
        const steps = (weapon.mythicId && MYTHIC_COMBO[weapon.mythicId]) || MOTION_COMBO || COMBO_STYLES[comboStyle()], t = performance.now() / 1000;
        if (t - (me.comboAt || 0) > (me.comboWin || 0.8)) me.comboI = 0;
        const i = (me.comboI | 0) % steps.length, st = Object.assign({}, steps[i], { i: i, n: steps.length });
        me.comboI = i + 1 >= steps.length ? 0 : i + 1; me.comboAt = t; me.comboWin = P.cd * (st.cd || 1) + 0.55;
        return st;
    }
    let liteManual = false, hitStopT = 0, sparkBudget = 28, perfEma = 0.0167, perfSlow = 0;      // sparkBudget：1フレームに出せる火花の数（大勢に当てても出しすぎない）
    function hitStop(sec) { if (partyCount() === 1 && !PVP) hitStopT = Math.max(hitStopT, sec); }      // 当たった一瞬、動きを止める（ひとりで遊ぶときだけ。マルチでは全員の動きを止めてしまうので使わない）
    const SHADE_CACHE = {};
    function shade(hex, f) {      // f>0 で白に近づける／f<0 で黒に近づける
        const key = hex + f; if (SHADE_CACHE[key]) return SHADE_CACHE[key];
        const m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return hex || '#fff';
        const n = parseInt(m[1], 16); let r = n >> 16 & 255, g = n >> 8 & 255, b = n & 255;
        const t = f > 0 ? 255 : 0, k = Math.abs(f); r = Math.round(r + (t - r) * k); g = Math.round(g + (t - g) * k); b = Math.round(b + (t - b) * k);
        return (SHADE_CACHE[key] = 'rgb(' + r + ',' + g + ',' + b + ')');
    }
    function hitFeel(e, cs, h) {      // 当たった手応え：ドットの火花・画面の揺れ・ヒットストップ
        if (!cs.ult && me.comboAt !== me.ultGainAt) { me.ultGainAt = me.comboAt; ultGain(cs.fin ? 8 : 2.5); }      // 必殺ゲージ：1振りにつき1回だけ溜まる
        const base = Math.atan2(e.y - me.y, e.x - me.x), col = (h && h.crit) ? '#ffd84a' : (FXCOL || HW.rarityOf(weapon).color), n = cs.fin ? 14 : 6;
        const nn = Math.max(0, Math.min(LITE() ? Math.min(n, 3) : n, sparkBudget)); sparkBudget -= nn;
        if (fx.length < (LITE() ? 120 : 260)) for (let i = 0; i < nn; i++) { const a = base + (Math.random() - 0.5) * (cs.fin ? 2.4 : 1.6), v = 160 + Math.random() * (cs.fin ? 420 : 260); fx.push({ k: 'pspark', x: e.x, y: e.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, sz: Math.random() < 0.3 ? 8 : 4, t: 0.25 + Math.random() * 0.2, life: 0.45, c: Math.random() < 0.35 ? '#fff' : col }); }
        if (cs.fin) { addShake(3.2, 0.12); hitStop(0.06); fx.push({ k: 'pring', x: e.x, y: e.y, r: 0, max: 46, t: 0.22, life: 0.22, c: col }); }
        else { addShake(0.9, 0.05); if (cs.i >= 1) hitStop(0.025); }
    }

    function strike(e, mult, kb) {
        const h = calcHit(e, mult);
        const pr = onHitProcs(e, h);
        const a = Math.atan2(e.y - me.y, e.x - me.x);
        const k = (kb || 0) * (1 + A('knock'));
        if (T.sup === 'debuff' || T.sup === 'all') pr.st = Object.assign(pr.st || {}, { weaken: 1, slow: 1, curse: 1 });     // 呪詛の杖：弱体・減速・被ダメージ増
        dealHit(e, h.dmg, { crit: h.crit, st: pr.st, kx: Math.cos(a) * k, ky: Math.sin(a) * k });
        if (pr.extra) setTimeout(() => { if (e.hp > 0) dealHit(e, h.dmg * 0.6, { crit: false }); }, 90);
        return h;
    }

    const SHAPE_DEF = { cone: { arc: 1.6 }, line: { width: 40 }, smash: { radius: 110, reach: 70 }, ring: { radius: 150 }, proj: { speed: 720, radius: 9, range: 560 } };      // 攻撃の形を変えたときの標準の数値
    // ---------- 配置で作った通常攻撃（神話のオリジナル武器）----------
    // 置いた攻撃（近接＝扇／遠距離＝弾）が、狙った向きを基準に、置いた角度で同時に（または少しずらして）出る。
    // 威力は hw-weapons.js の atkPlan で決まる：置くほど、1個あたりは下がる。弾は、自分で描いた絵（16×16）で飛ばせる
    function placedAttack(cs, ang) {
        const col0 = FXCOL || HW.rarityOf(weapon).color, sent = [], alive = () => run.phase === 'run' && !me.dead && !(me.stunT > 0);
        let meleeSent = 0;
        if (window.SBSound) SBSound.sfx('swing');
        cs.units.forEach(u => {
            const a = ang + (u.da || 0) * Math.PI / 180;
            const fire = delayed => {
                if (!alive()) return;
                if (u.kind === 'melee') {
                    const rng = P.range * u.r, d = { k: 'cone', x: me.x, y: me.y, a: a, rng: rng, arc: u.arc, rad: 0, w: 0, c: u.col || col0, cs: 0, dir: (u.da || 0) < 0 ? -1 : 1, fin: false };
                    spawnAtkFx(d); if (meleeSent++ < 4) netSend('atk', d);      // 通信が重くならないよう、仲間に見せる斬撃は最大4つまで
                    enemies.forEach(e => {
                        if (e.hp <= 0) return;
                        const dd = dist(me.x, me.y, e.x, e.y); if (dd > rng + e.r) return;
                        let da = Math.atan2(e.y - me.y, e.x - me.x) - a; da = Math.atan2(Math.sin(da), Math.cos(da));
                        if (Math.abs(da) <= u.arc / 2) { const h = strike(e, u.m, 0); hitFeel(e, { fin: false, i: 0 }, h); }
                    });
                } else {
                    const sp = u.sp, sx = me.x + Math.cos(a) * u.d0, sy = me.y + Math.sin(a) * u.d0, r = Math.round(6 + 5 * u.sz), tx = (u.tx >= 0 && MY_TEX[u.tx]) ? u.tx : -1, ts = Math.max(1, Math.round(2 * u.sz));
                    myShots.push({ x: sx, y: sy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, r: r, life: u.rg / sp, pierce: 0, hit: {}, homing: false, aoe: 0, c: u.col || col0, m: u.m, fin: 0, cs: 0, vol: 0, ar: 0, tx: tx, ts: ts });
                    const q = { x: Math.round(sx), y: Math.round(sy), vx: Math.round(Math.cos(a) * sp), vy: Math.round(Math.sin(a) * sp), r: r, life: +(u.rg / sp).toFixed(2), pierce: 0, aoe: 0, c: u.col || col0, t: tx, ts: ts };
                    if (delayed) netSend('shot', { s: [q] }); else sent.push(q);
                }
            };
            if (u.dl > 0) setTimeout(() => fire(true), u.dl * 1000); else fire(false);
        });
        if (sent.length) netSend('shot', { s: sent.slice(0, 12) });
        const swingD = { k: cs.units.some(u => u.kind === 'melee') ? 'cone' : 'proj', dir: 1, fin: false }; mySwing(swingD);
    }
    function doAttack() {
        const atkCost = Math.max(1, Math.round(P.cd * ATK_ENERGY_PER_SEC * 10) / 10);
        if (me.energy < atkCost) { me.atkCd = 0.2; flashEnergy(); return; }   // エネルギー切れ：クイズに正解して回復
        me.energy -= atkCost; updateEnergyUI();
        const ang = aimAngle(); me.ang = ang;
        const cdv = P.cd / (me.haste > 0 ? 1.4 : 1);
        const cs = nextComboStep(); me.atkCd = cdv * (cs.cd || 1);
        if (cs.units) { placedAttack(cs, ang); return; }      // 配置で作った通常攻撃（近接と遠距離を、置いたとおりに出す）
        const TK = cs.shape || T.kind, TS = (cs.shape && cs.shape !== T.kind) ? SHAPE_DEF[cs.shape] : T;      // 自作の動きでは、段ごとに攻撃の形を変えられる（TS＝その形の標準の数値）
        const hit = (e, base) => { const h = strike(e, (base || 1) * cs.m, cs.knb ? cs.knb : (T.knock || 0) * (cs.kn || 1)); hitFeel(e, cs, h); return h; };
        const d = { k: TK, x: me.x, y: me.y, a: ang, rng: P.range * (cs.r || 1), arc: (TS.arc || 0) * (cs.a || 1), rad: ((cs.shape && cs.shape !== T.kind) ? TS.radius : (P.radius || T.radius)) * (cs.r || 1), w: (TS.width || 0) * (cs.w || 1), c: cs.col || FXCOL || HW.rarityOf(weapon).color, cs: cs.i, dir: cs.dir || 1, fin: cs.fin ? 1 : 0 };
        spawnAtkFx(d); netSend('atk', d); mySwing(d);
        if (window.SBSound) SBSound.sfx('swing');
        if (cs.wave || cs.quake || cs.heal || cs.keeper || cs.blades || cs.blades2) mythicExtras(cs, d, ang);
        if (T.sup === 'heal' || T.sup === 'buff' || T.sup === 'all') supportPulse(T);
        // デュアルウェポン：3回に1回、もう一つの武器で追撃（攻撃力70%）
        if (AB('dual_weapon') && ((me.atkN = (me.atkN || 0) + 1) % 3) === 0) {
            setTimeout(() => {
                if (run.phase !== 'run' || me.dead || me.stunT > 0) return;
                const n = nearestEnemy(me.x, me.y, Math.max(160, P.range || 0) + 80);
                if (n) { fx.push({ k: 'line', x: me.x, y: me.y, x2: n.x, y2: n.y, t: 0.2, life: 0.2, c: '#ffd0ff' }); strike(n, 0.7, 40); }
            }, 120);
        }
        const lg = cs.lunge != null ? cs.lunge : (T.lunge || 0);
        if (lg) { const L = blinkLimit(me.x, me.y, ang, lg, me.r); me.x += Math.cos(ang) * L; me.y += Math.sin(ang) * L; pushOutOfRocks(me, me.r); }

        if (TK === 'cone') {
            const range = d.rng, arc = d.arc;
            const swing = () => enemies.forEach(e => {
                if (e.hp <= 0) return;
                const dd = dist(me.x, me.y, e.x, e.y);
                if (dd > range + e.r) return;
                let da = Math.atan2(e.y - me.y, e.x - me.x) - ang; da = Math.atan2(Math.sin(da), Math.cos(da));
                if (Math.abs(da) <= arc / 2 || dd < e.r + 18) hit(e, 1);
            });
            swing();
            // 連続ヒットする武器（双刃など）：1振りで T.multi 回当たる
            for (let i = 1; i < (T.multi || 1); i++) setTimeout(() => { if (run.phase === 'run' && !me.dead && !(me.stunT > 0)) { spawnAtkFx(d); swing(); } }, i * 85);
        } else if (TK === 'line') {
            const x2 = me.x + Math.cos(ang) * d.rng, y2 = me.y + Math.sin(ang) * d.rng;
            enemies.forEach(e => { if (e.hp > 0 && distSeg(e.x, e.y, me.x, me.y, x2, y2) < (TS.width || 24) * (cs.w || 1) / 2 + e.r) hit(e, 1); });
        } else if (TK === 'ring') {
            enemies.forEach(e => { if (e.hp > 0 && dist(me.x, me.y, e.x, e.y) < d.rad + e.r) hit(e, 1); });
        } else if (TK === 'smash') {
            const cx = me.x + Math.cos(ang) * (TS.reach || 60), cy = me.y + Math.sin(ang) * (TS.reach || 60);
            fx.push({ k: 'pring', x: cx, y: cy, r: 0, max: d.rad, t: 0.3, life: 0.3, c: '#ffcf8a', fill: true });
            enemies.forEach(e => { if (e.hp > 0 && dist(cx, cy, e.x, e.y) < d.rad + e.r) hit(e, 1); });
        } else if (TK === 'duality') {
            // 双界：炎（左前）と氷（右前）の2つの扇で斬る。両方の扇に入った敵は「共鳴」して、もう一度ダメージが入る（正面で斬るほど強い）
            const range = d.rng, arc = d.arc, sp = 0.42 * (cs.dir || 1);
            const inCone = (e, a0) => { const dd = dist(me.x, me.y, e.x, e.y); if (dd > range + e.r) return false; let da = Math.atan2(e.y - me.y, e.x - me.x) - a0; da = Math.atan2(Math.sin(da), Math.cos(da)); return Math.abs(da) <= arc / 2 || dd < e.r + 18; };
            enemies.forEach(e => {
                if (e.hp <= 0) return;
                const r = inCone(e, ang - sp), b = inCone(e, ang + sp);
                if (r || b) hit(e, 1);
                if (r && b) { const h2 = strike(e, 0.5 * cs.m, 0); popups.push({ x: e.x, y: e.y - e.r - 14, t: 0.5, text: '共鳴', c: '#d9a0ff' }); if (h2 && window.SBPix) fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: 40, t: 0.2, life: 0.2, c: '#c06aff' }); }
            });
        } else if (TK === 'lasers') {
            // 不壊：自分の周りに並ぶ発射口から、7本のレーザーを近くの敵へ自動で狙って当てる（敵が少ないときは、同じ敵に重ねて当たる）
            const N = (T.count || 7) + Math.round(A('projExtra')), R = d.rng, tt = performance.now() / 1000, ls = [];
            const foes = enemies.filter(e => e.hp > 0 && e.act !== false && dist(me.x, me.y, e.x, e.y) - e.r < R).sort((p, q) => dist(me.x, me.y, p.x, p.y) - dist(me.x, me.y, q.x, q.y));
            for (let i = 0; i < N; i++) {
                const oa = tt * 1.6 + i * Math.PI * 2 / N, ex = me.x + Math.cos(oa) * 34, ey = me.y + Math.sin(oa) * 34, tg = foes.length ? foes[i % foes.length] : null;
                let tx, ty;
                if (tg) { tx = tg.x; ty = tg.y; hit(tg, 1); } else { tx = ex + Math.cos(oa) * 150; ty = ey + Math.sin(oa) * 150; }
                ls.push([Math.round(ex), Math.round(ey), Math.round(tx), Math.round(ty)]);
            }
            const ld = { k: 'lasers', ls: ls, c: d.c }; spawnAtkFx(ld); netSend('atk', ld);
        } else if (TK === 'proj') {
            const n = (T.spread || 1) + Math.round(A('projExtra')) + (cs.fin && !T.spread && !cs.xs ? 2 : 0) + (cs.xs || 0);      // フィニッシャーは弾が増える
            const spread = T.spread ? 0.16 : 0.12;
            const sentShots = [];
            setTimeout(() => { if (sentShots.length) netSend('shot', { s: sentShots }); }, 0);   // 全部の弾が出来てからまとめて送る
            for (let i = 0; i < n; i++) {
                const a = ang + (n > 1 ? (i - (n - 1) / 2) * spread : 0);
                sentShots.push({ x: Math.round(me.x), y: Math.round(me.y), vx: Math.round(Math.cos(a) * TS.speed), vy: Math.round(Math.sin(a) * TS.speed), r: TS.radius, life: +(TS.range / TS.speed).toFixed(2), pierce: (T.pierce || 0) + Math.round(A('pierce')), aoe: T.aoe || 0, c: cs.col || HW.rarityOf(weapon).color });
                myShots.push({ x: me.x, y: me.y, vx: Math.cos(a) * TS.speed, vy: Math.sin(a) * TS.speed, r: TS.radius, life: TS.range / TS.speed, pierce: (T.pierce || 0) + Math.round(A('pierce')), hit: {}, homing: !!T.homing || !!cs.homing, aoe: T.aoe || 0, c: cs.col || HW.rarityOf(weapon).color, m: cs.m, fin: cs.fin ? 1 : 0, cs: cs.i, vol: me.comboAt, ar: (weapon.type === 'bow' || weapon.type === 'crossbow') ? 1 : 0 });
            }
        }
    }
    function distSeg(px, py, x1, y1, x2, y2) {
        const dx = x2 - x1, dy = y2 - y1, l2 = dx * dx + dy * dy;
        let t = l2 ? ((px - x1) * dx + (py - y1) * dy) / l2 : 0; t = clamp(t, 0, 1);
        return dist(px, py, x1 + dx * t, y1 + dy * t);
    }
    function spawnAtkFx(d) {
        const L = d.fin ? 0.3 : 0.2;
        if (d.k === 'cone') fx.push({ k: 'pslash', x: d.x, y: d.y, a: d.a, rng: d.rng, arc: d.arc, dir: d.dir || 1, fin: !!d.fin, t: L, life: L, c: d.c });
        else if (d.k === 'line') fx.push({ k: 'pthrust', x: d.x, y: d.y, a: d.a, rng: d.rng, w: d.w || 14, fin: !!d.fin, t: L, life: L, c: d.c });
        else if (d.k === 'ring') fx.push({ k: 'pring', x: d.x, y: d.y, r: 0, max: d.rad || 100, t: 0.25, life: 0.25, c: d.c });
        else if (d.k === 'lasers' && Array.isArray(d.ls)) d.ls.slice(0, 16).forEach(q => {
            if (!Array.isArray(q) || q.length < 4) return;
            const nn = i => (typeof q[i] === 'number' && isFinite(q[i])) ? q[i] : 0, col = (typeof d.c === 'string' && d.c.length <= 9) ? d.c : '#ff5a6a';
            fx.push({ k: 'line', x: nn(0), y: nn(1), x2: nn(2), y2: nn(3), t: 0.15, life: 0.15, c: col, w: 5 });
            fx.push({ k: 'line', x: nn(0), y: nn(1), x2: nn(2), y2: nn(3), t: 0.15, life: 0.15, c: '#ffffff', w: 2 });
        });
        else if (d.k === 'duality') {      // 双界：赤い炎の斬撃と青い氷の斬撃が、X字に交差する（dir で上下が入れ替わる）
            const sp = 0.42 * (d.dir || 1), arc = d.arc || 1.15;
            fx.push({ k: 'pslash', x: d.x, y: d.y, a: d.a - sp, rng: d.rng, arc: arc, dir: 1, fin: !!d.fin, t: L, life: L, c: '#ff5a3a' });
            fx.push({ k: 'pslash', x: d.x, y: d.y, a: d.a + sp, rng: d.rng, arc: arc, dir: -1, fin: !!d.fin, t: L, life: L, c: '#4ac8ff' });
            if (d.fin) fx.push({ k: 'pring', x: d.x, y: d.y, r: 0, max: d.rng * 0.9, t: 0.3, life: 0.3, c: '#c06aff', fill: false });
        }
        else if (d.k === 'smash') fx.push({ k: 'pring', x: d.x + Math.cos(d.a) * 60, y: d.y + Math.sin(d.a) * 60, r: 0, max: d.rad || 90, t: 0.25, life: 0.25, c: d.c, fill: !!d.fin });
    }

    function doDash() {
        if (me.dead || me.stunT > 0 || me.cast || me.gch > 0 || me.ultT > 0 || me.dashCd > 0 || run.phase !== 'run') return;
        if (window.ClassPerks && !ClassPerks.dashOk()) { if (me.noDashMsg !== true) { popups.push({ x: me.x, y: me.y - 30, t: 0.8, text: 'ダッシュ不可', c: '#ff9a9a' }); me.noDashMsg = true; setTimeout(() => { me.noDashMsg = false; }, 1500); } return; }
        if (A('noDash') > 0) { if (me.noDashMsg !== true) { popups.push({ x: me.x, y: me.y - 30, t: 0.8, text: 'ダッシュ不可', c: '#ff9a9a' }); me.noDashMsg = true; setTimeout(() => { me.noDashMsg = false; }, 1500); } return; }
        let mx = input.mx, my = input.my;
        if (!mx && !my) { mx = Math.cos(me.ang); my = Math.sin(me.ang); }
        const l = Math.hypot(mx, my) || 1;
        me.dashVX = mx / l * 640; me.dashVY = my / l * 640; me.dashT = 0.18; me.dashCd = P.dashCd; me.inv = Math.max(me.inv, 0.22); me.invHard = 0.22;
        if (window.ClassPerks) ClassPerks.onDash();                                     // 職業パーク：ガンカタ
        fx.push({ k: 'puff', x: me.x, y: me.y, t: 0.25, life: 0.25, c: '#bfe6ff' });
        agg.procs.filter(p => p.on === 'dash').forEach(p => { me.dashBlast = p.v; });
        accEvent('dash');
    }

    // ---------- アクティブスキル（従来のモジュール式スキル：投射／レーザー／斬撃／衝撃波）----------
    // 形・効果・強化は action-skills.js のものをそのまま使う。Z X C V で発動。エネルギーを消費し、
    // エネルギーはクイズ正解で溜まる。威力は「装備武器の攻撃力 × スキル倍率」で決まる。
    const skillSlots = (window.ActionSkills ? ActionSkills.loadLoadout() : []).map(sk => (sk && ActionSkills.isFormUnlocked(sk.form)) ? Object.assign(ActionSkills.compute(sk), { cdLeft: 0 }) : null).map(x => { if (x && x.params && COSTCHK && COSTCHK.over) x.params.dmgMult *= COSTCHK.ratio; return x; });      // コスト超過：スキルの威力も弱まる   // 討伐で解放していない形のスキルは使えない
    while (skillSlots.length < 4) skillSlots.push(null);
    const SELF_FX = ['fortify', 'haste', 'regenerate', 'empower', 'barrier'];

    function skillFx(d, who) {
        const c = d.c || '#9df0ff';
        if (d.f === 'meteor') {   // 着弾予告（点線の輪）→ 着弾の爆発
            fx.push({ k: 'warn', x: d.x, y: d.y, r: d.r, t: d.dl, life: d.dl, c: '#ffb070' });
            setTimeout(() => { fx.push({ k: 'ring', x: d.x, y: d.y, r: 0, max: d.r, t: 0.4, life: 0.4, c: '#ffd9a0', fill: true }); }, d.dl * 1000);
            return;
        }
        if (d.f === 'orbit') { if (who && who !== me) who.orb = { t: d.dur, r: d.r, n: d.n }; return; }
        if (d.f === 'thrust') {   // 突き：細く鋭い白い線
            fx.push({ k: 'line', x: d.x, y: d.y, x2: d.x + Math.cos(d.a) * d.len, y2: d.y + Math.sin(d.a) * d.len, t: 0.22, life: 0.22, c: '#9df0ff', w: d.w || 30 });
            fx.push({ k: 'line', x: d.x, y: d.y, x2: d.x + Math.cos(d.a) * d.len, y2: d.y + Math.sin(d.a) * d.len, t: 0.22, life: 0.22, c: '#ffffff', w: Math.max(4, (d.w || 30) * 0.4) });
            return;
        }
        if (d.f === 'flash') {    // 一閃：出発点と到着点に輪、その間を光が走る
            fx.push({ k: 'line', x: d.x, y: d.y, x2: d.x2, y2: d.y2, t: 0.4, life: 0.4, c: '#fff3b0', w: d.w || 56 });
            fx.push({ k: 'line', x: d.x, y: d.y, x2: d.x2, y2: d.y2, t: 0.4, life: 0.4, c: '#ffffff', w: 8 });
            fx.push({ k: 'ring', x: d.x, y: d.y, r: 0, max: 40, t: 0.3, life: 0.3, c: '#fff3b0', fill: true });
            fx.push({ k: 'ring', x: d.x2, y: d.y2, r: 0, max: 50, t: 0.35, life: 0.35, c: '#ffffff', fill: true });
            return;
        }
        if (d.f === 'laser') fx.push({ k: 'line', x: d.x, y: d.y, x2: d.x + Math.cos(d.a) * d.len, y2: d.y + Math.sin(d.a) * d.len, t: 0.3, life: 0.3, c: '#9df0ff', w: d.w || 24 });
        else if (d.f === 'slash') fx.push({ k: 'arc', x: d.x, y: d.y, a: d.a, rng: d.r, arc: d.arc, t: 0.26, life: 0.26, c: '#c6f0ff' });
        else if (d.f === 'nova') fx.push({ k: 'ring', x: d.x, y: d.y, r: 0, max: d.r, t: 0.35, life: 0.35, c: '#ffe6a0', fill: true });
        else fx.push({ k: 'line', x: d.x, y: d.y, x2: d.x + Math.cos(d.a) * 40, y2: d.y + Math.sin(d.a) * 40, t: 0.15, life: 0.15, c: c, w: 6 });
    }

    // 命中した敵1体への処理（ダメージ＋効果）
    function skillHit(e, base, hasDmg, eff, ang) {
        let dmg = hasDmg ? base * rnd(0.95, 1.05) : 0;
        dmg *= e.pvp ? 1 : (e.boss ? 1 + A('dmgBoss') : 1 + A('dmgMob'));
        if (eff.indexOf('shatter') >= 0) dmg *= 1.15;
        if (eff.indexOf('explosion') >= 0) dmg += Math.max(2, dmg * 0.2);
        dmg = Math.round(dmg);
        const st = {};
        if (window.ClassFx) dmg = ClassFx.onHit(e, dmg, eff, st);      // 職業：奇襲・聖なる加護・専用グリフ
        const has = k => eff.indexOf(k) >= 0;
        if (has('burn')) st.burn = Math.max(1, dmg * 0.6 / 3);
        if (has('soulburn')) st.burn = Math.max(st.burn || 0, Math.max(2, dmg * 1.1 / 3));
        if (has('poison')) st.poison = Math.max(1, dmg * 0.45 / 4);
        if (has('frostbite')) { st.slow = 1; st.poison = Math.max(st.poison || 0, Math.max(1, dmg * 0.3 / 3)); }
        if (has('freeze')) st.slow = 1;
        if (has('weaken')) st.weaken = 1;
        if (has('blind')) st.blind = 1;
        if (has('stun')) st.stun = Math.max(st.stun || 0, 1.0);
        if (has('petrify')) st.stun = Math.max(st.stun || 0, 1.6);
        if (has('chronowarp')) st.stun = Math.max(st.stun || 0, 2.6);
        let knock = 40;
        if (has('knockback')) knock += 300;
        if (has('gravity')) knock -= 260 + 40;     // 負の値＝自分の方へ引き寄せる
        const a = Math.atan2(e.y - me.y, e.x - me.x), res = e.boss ? 0.4 : 1;
        if (hasDmg && dmg > 0) {
            if (has('drain')) healMe(dmg * 0.3);
            if (has('voidrend')) healMe(dmg * 0.6);
        }
        dealHit(e, dmg, { st: Object.keys(st).length ? st : null, kx: Math.cos(a) * knock * res, ky: Math.sin(a) * knock * res, el: eff.filter(k => k.indexOf('el:') === 0).map(k => k.slice(3)) });
    }
    function healMe(v) {
        v = Math.round(v); if (v <= 0 || me.dead) return;
        const got = Math.round(addHp(v)); if (got <= 0) return;      // 回復の効きは addHp が、難易度やサドンデスに応じて弱める
        popups.push({ x: me.x, y: me.y - 30, t: 0.7, text: '+' + got, c: '#7CFC9A' });
    }
    function applySelfFx(key) {
        const tag = (t, c) => popups.push({ x: me.x, y: me.y - 46, t: 0.9, text: t, c: c });
        if (key === 'fortify') { me.fortifyT = 3; tag('防御UP', '#9df0ff'); }
        else if (key === 'haste') { me.haste = Math.max(me.haste, 3); tag('速度UP', '#9df0ff'); }
        else if (key === 'empower') { me.empowerT = 3; tag('攻撃UP', '#ffb347'); }
        else if (key === 'regenerate') { me.regenT = 4; tag('再生', '#7CFC9A'); }
        else if (key === 'barrier') { me.barrierHp = (me.barrierHp || 0) + Math.max(10, Math.round(me.maxHp * 0.25)); tag('バリア', '#7fc8ff'); }
    }

    // ---------- 職業システムとの橋渡し ----------
    let classReady = false;
    function classInit() {
        if (classReady || run.phase !== 'run') return;
        classReady = true;
        if (!window.ClassSys) return;
        const stat = (e, key, sec) => { if (e && e.st) e.st[key] = Math.max(e.st[key] || 0, sec); };
        const bridge = {
            me: () => me, enemies: () => enemies, eBullets: () => eBullets, rocks: () => rocks,
            // 職業パーク用
            ghostShots: () => ghostShots, proj: v => { pvpProj = !!v; }, isPvp: () => !!(PVP && run.pvpMode),
            pvpReflect: (to, f) => netSend('pvph', { to: to, f: +Number(f).toFixed(4), kx: 0, ky: 0, st: null, pj: 0 }),
            input: () => input, getStat: k => A(k), setStat: (k, v) => { agg.stats[k] = v; }, def: () => P.def, energyMax: () => ENERGY_MAX,
            allies: () => allies, addCoins: n => { run.stats.coins = Math.max(0, (run.stats.coins || 0) + Math.round(n)); },
            stunSelf: sec => { me.stunImm = 0; stunMe(sec); },
            selfHit: raw => hurtMe(raw),
            selfDamage: hp => { if (me.dead || hp <= 0) return; me.hp = Math.max(1, me.hp - hp); popups.push({ x: me.x, y: me.y - 24, t: 0.8, text: '-' + Math.round(hp), c: '#ff7b7b', big: true }); },
            killSelf: () => { if (me.dead) return; me.inv = 0; me.invHard = 0; me.guardT = 0; me.barrierHp = 0; me.shield = false; const d0 = agg.stats.dodge; agg.stats.dodge = 0; try { hurtMe(99); } finally { agg.stats.dodge = d0; } },
            allyBarrier: (id, sec) => netSend('pbar', { to: id, t: sec }),
            world: () => ({ w: WORLD_W, h: WORLD_H }), isRun: () => run.phase === 'run',
            slots: () => skillSlots, distSeg: distSeg,
            nearestEnemy: (x, y, maxD) => nearestEnemy(x, y, maxD),
            skillHit: (e, b, hasDmg, eff, ang) => skillHit(e, b, hasDmg, eff, ang),
            dealHit: (e, dmg, o) => dealHit(e, dmg, o || {}),
            unitDmg: () => weapon.dmg * P.atkMul * atkDyn() * SKILL_MUL(),
            heal: v => healMe(v),
            barrier: v => { v = Math.round(v); if (v > 0) { me.barrierHp = Math.min(Math.round(me.maxHp * 0.4), (me.barrierHp || 0) + v); } },
            popup: (text, x, y, c) => popups.push({ x: x, y: y, t: 0.9, text: text, c: c || '#ffffff' }),
            ring: (x, y, r, c) => { const d = { f: 'nova', x: x, y: y, r: r }; skillFx(d); },
            line: (x1, y1, x2, y2) => { const a = Math.atan2(y2 - y1, x2 - x1), d = { f: 'laser', x: x1, y: y1, a: a, len: Math.hypot(x2 - x1, y2 - y1), w: 8 }; skillFx(d); },
            fxLine: (x1, y1, x2, y2, c, w) => { const a = Math.atan2(y2 - y1, x2 - x1), d = { f: 'laser', x: x1, y: y1, a: a, len: Math.hypot(x2 - x1, y2 - y1), w: w || 30 }; skillFx(d); },
            fxArc: (x, y, a, r, arc) => { const d = { f: 'slash', x: x, y: y, a: a, r: r, arc: arc }; skillFx(d); },
            setStun: (e, sec) => { if (!e || sec <= 0) return; if (e.boss) stat(e, 'slowT', sec); else stat(e, 'stunT', sec); },
            setSt: (e, o) => { if (!e) return; if (o.slow) stat(e, 'slowT', 2.5); if (o.weaken) stat(e, 'weakenT', 3); if (o.blind) stat(e, 'blindT', 2.5); if (o.curse) stat(e, 'curseT', 6); },
            moveMe: (dx, dy) => { moveSolid(me, dx, dy, me.r); },
            teleportMe: (x, y) => {
                const tx = clamp(x, 20, WORLD_W - 20), ty = clamp(y, 20, WORLD_H - 20);
                for (const k of rocks) if (dist(tx, ty, k.x, k.y) < k.r + me.r) return;
                if (CORR_ON && corrSolid(tx, ty)) return;
                me.x = tx; me.y = ty;
            }
        };
        if (window.ClassFx) ClassFx.setup(bridge);
        if (window.ClassForms) ClassForms.setBridge(bridge);
    }

    const cfRate = {};      // 他のプレイヤーの職業スキルの再現を、1秒に8回までにする（送られすぎ対策）
    setInterval(() => { for (const k in cfRate) delete cfRate[k]; }, 1000);
    function castSkill(slot, charged) {      // charged=true は、溜めが終わって実際に発動するとき
        const s = skillSlots[slot];
        if (!s || me.dead || me.stunT > 0 || me.ultT > 0 || run.phase !== 'run') return;
        if (!charged) {
            if (s.cdLeft > 0 || me.cast || me.gch > 0) return;
            classInit();
            if (window.ClassPerks && !ClassPerks.castOk(s)) return;                      // 職業パーク：使えない条件
            const pCost = s.cost * (window.ClassPerks ? ClassPerks.costMul(s) : 1), pCd = window.ClassPerks ? ClassPerks.cdMul(s) : 1;
            if (me.energy < pCost) { flashEnergy(); return; }
            me.energy -= pCost; s.cdLeft = s.cooldown * (1 + A('skillCdUp')) * pCd; updateEnergyUI();
            if (window.SBSound) SBSound.sfx('skill');
            const cs = CHARGE_SEC[s.params.form] || 0;
            if (cs > 0) {      // 溜め開始：エネルギーとクールタイムは先に使う。発動の向きと狙いは、溜め終わりの瞬間に決まる
                me.cast = { slot: slot, t: cs, max: cs, form: s.params.form }; me.dashT = 0; me.ang = aimAngle();
                popups.push({ x: me.x, y: me.y - 34, t: 0.9, text: '溜め…' + (CHARGE_NAME[s.params.form] || ''), c: '#ffe08a' });
                return;
            }
        }
        accEvent('skill');
        if (window.ClassPerks) ClassPerks.onCast(s);                                  // 職業パーク
        if (GMK === 'dimension' && G.dp === 1) { if (isHost) hostReflect(me.x, me.y); else netSend('refl', { x: Math.round(me.x), y: Math.round(me.y) }); }   // スキルのタイミングで放射弾を跳ね返す
        const p = s.params, ang = aimAngle(); me.ang = ang;
        popups.push({ x: me.x, y: me.y - 34, t: 0.9, text: s.skill.name, c: '#9df0ff' });
        if (p.form !== 'domain' && p.form !== 'summon') p.effects.forEach(k => { if (SELF_FX.indexOf(k) >= 0) applySelfFx(k); });   // 領域は中にいる間だけ、ミニオン召喚はミニオンがいる間だけ効く
        const eff = p.effects.filter(k => k !== 'damage' && SELF_FX.indexOf(k) < 0);
        if (p.element) eff.push('el:' + p.element);       // スキルの属性（skillHit が読む）
        const hasDmg = p.effects.indexOf('damage') >= 0;
        const base0 = weapon.dmg * P.atkMul * atkDyn() * p.baseMult * p.dmgMult * SKILL_MUL() * (me.empowerT > 0 ? 1.15 : 1) * (AB('guts') && me.hp <= 1.5 ? 3 : 1);      // スキルは火力ではなく特殊な攻撃手段：特殊ステータス・スキル威力%では伸びない（action-skills.js）
        const later = (sec, fn) => setTimeout(() => { if (run.phase === 'run' && !me.dead && !(me.stunT > 0)) fn(); }, sec * 1000);
        // 職業：固有効果による威力の倍率（怒りゲージ・剣気・賭け…）。専用の形は、ここから class-forms.js が動かす
        classInit();
        const base = base0 * (window.ClassFx ? ClassFx.castMul(p, s, slot) : 1);
        if (p.classForm && window.ClassForms && ClassForms.cast(p.classForm, { base: base, hasDmg: hasDmg, eff: eff, ang: ang, p: p, skill: s.skill })) { netSend('cf', { k: p.classForm, a: Math.round(ang * 1000) / 1000, e: typeof p.element === 'string' ? p.element : undefined }); return; }      // ほかのプレイヤーの画面にも、同じ動きを見た目だけで出す

        if (p.pieces) { castPieces(p, base, hasDmg, eff, ang, later, s.skill.id); return; }   // 自由配置のスキル、突き、一閃

        if (p.form === 'projectile') {
            for (let i = 0; i < p.count; i++) {
                const a = ang + (i - (p.count - 1) / 2) * p.spread;
                myShots.push({ x: me.x, y: me.y, vx: Math.cos(a) * p.speed, vy: Math.sin(a) * p.speed, r: p.radius, life: p.range / p.speed, pierce: p.pierce, hit: {}, homing: false, c: '#8fd3ff', skill: { base: base, hasDmg: hasDmg, eff: eff } });
            }
            const d = { f: 'projectile', x: me.x, y: me.y, a: ang }; skillFx(d); netSend('sk', d);
            const sk = []; for (let i = 0; i < p.count; i++) { const a = ang + (i - (p.count - 1) / 2) * p.spread; sk.push({ x: Math.round(me.x), y: Math.round(me.y), vx: Math.round(Math.cos(a) * p.speed), vy: Math.round(Math.sin(a) * p.speed), r: p.radius, life: +(p.range / p.speed).toFixed(2), pierce: p.pierce, c: '#8fd3ff' }); }
            netSend('shot', { s: sk });
        } else if (p.form === 'laser') {
            for (let i = 0; i < p.count; i++) {
                const a = ang + (i - (p.count - 1) / 2) * p.spread;
                const d = { f: 'laser', x: me.x, y: me.y, a: a, len: p.length, w: p.width }; skillFx(d); netSend('sk', d);
                const x2 = me.x + Math.cos(a) * p.length, y2 = me.y + Math.sin(a) * p.length;
                enemies.forEach(e => { if (e.hp > 0 && distSeg(e.x, e.y, me.x, me.y, x2, y2) <= p.width / 2 + e.r) skillHit(e, base, hasDmg, eff, a); });
            }
        } else if (p.form === 'slash') {
            for (let i = 0; i < p.count; i++) {
                later(i * p.delay, () => {
                    const a = aimAngle() + (i % 2 ? 0.12 : -0.12); me.ang = a;
                    const d = { f: 'slash', x: me.x, y: me.y, a: a, r: p.radius, arc: p.arc }; skillFx(d); netSend('sk', d);
                    enemies.forEach(e => {
                        if (e.hp <= 0) return;
                        const dd = dist(me.x, me.y, e.x, e.y); if (dd > p.radius + e.r) return;
                        let da = Math.atan2(e.y - me.y, e.x - me.x) - a; da = Math.atan2(Math.sin(da), Math.cos(da));
                        if (Math.abs(da) <= p.arc / 2 || dd < e.r + 18) skillHit(e, base, hasDmg, eff, a);
                    });
                });
            }
        } else if (p.form === 'nova') {
            for (let i = 0; i < p.count; i++) {
                later(i * p.delay, () => {
                    const d = { f: 'nova', x: me.x, y: me.y, r: p.radius }; skillFx(d); netSend('sk', d);
                    enemies.forEach(e => { if (e.hp > 0 && dist(me.x, me.y, e.x, e.y) <= p.radius + e.r) skillHit(e, base, hasDmg, eff, 0); });
                });
            }
        } else if (p.form === 'meteor') {
            // 狙った方向にいちばん近い敵（いなければ狙った地点）に隕石を落とす。着弾までの間に動かれると外れる
            const ax = clamp(me.x + Math.cos(ang) * 260, 30, WORLD_W - 30), ay = clamp(me.y + Math.sin(ang) * 260, 30, WORLD_H - 30);
            const tg = nearestEnemy(ax, ay, 320);
            const bx = tg ? tg.x : ax, by = tg ? tg.y : ay;
            for (let i = 0; i < p.count; i++) {
                const tx = clamp(bx + (i === 0 ? 0 : rnd(-1, 1) * p.radius * 1.1), 30, WORLD_W - 30), ty = clamp(by + (i === 0 ? 0 : rnd(-1, 1) * p.radius * 1.1), 30, WORLD_H - 30);
                const fall = p.delay + i * p.stagger;
                const d = { f: 'meteor', x: tx, y: ty, r: p.radius, dl: fall }; skillFx(d); netSend('sk', d);
                setTimeout(() => {
                    if (run.phase !== 'run') return;
                    enemies.forEach(e => { if (e.hp > 0 && dist(tx, ty, e.x, e.y) <= p.radius + e.r) skillHit(e, base, hasDmg, eff, Math.atan2(e.y - ty, e.x - tx)); });
                }, fall * 1000);
            }
        } else if (p.form === 'orbit') {
            me.orb = { t: p.duration, n: p.orbs, r: p.orbitR, tick: {}, spin: p.spin, base: base, hasDmg: hasDmg, eff: eff, ptick: p.tick };
            const d = { f: 'orbit', dur: p.duration, r: p.orbitR, n: p.orbs }; skillFx(d, me); netSend('sk', d);
        }
    }

    // 自由配置（layout）のスキルと、突き・一閃の発動。
    //   配置1つ = 出る場所（前後・左右）、向き、大きさ。位置と向きは、撃った瞬間の自分と狙った向きが基準
    function castPieces(p, base, hasDmg, eff, ang, later, skillId) {
        const rad = d => d * Math.PI / 180, c0 = Math.cos(ang), s0 = Math.sin(ang);
        const pieces = p.pieces.map(pc => ({
            x: clamp(me.x + pc.fw * c0 - pc.sd * s0, 20, WORLD_W - 20), y: clamp(me.y + pc.fw * s0 + pc.sd * c0, 20, WORLD_H - 20),
            a: ang + rad(pc.a), s: pc.s, k: 0.8 + 0.2 * pc.s     // k：大きいほど少しだけ威力も上がる
        }));
        const hitAll = (fn, k, a) => enemies.forEach(e => { if (e.hp > 0 && fn(e)) skillHit(e, base * k, hasDmg, eff, a); });
        const live = !p.custom;     // 標準配置の突き・一閃は、撃った後も狙った向きに追従する

        if (p.form === 'projectile') {
            const sk = [];
            pieces.forEach(q => {
                const vx = Math.cos(q.a) * p.speed, vy = Math.sin(q.a) * p.speed, r = p.radius * q.s, life = p.range / p.speed;
                myShots.push({ x: q.x, y: q.y, vx: vx, vy: vy, r: r, life: life, pierce: p.pierce, hit: {}, homing: false, c: '#8fd3ff', skill: { base: base * q.k, hasDmg: hasDmg, eff: eff } });
                const d = { f: 'projectile', x: q.x, y: q.y, a: q.a }; skillFx(d); netSend('sk', d);
                sk.push({ x: Math.round(q.x), y: Math.round(q.y), vx: Math.round(vx), vy: Math.round(vy), r: r, life: +life.toFixed(2), pierce: p.pierce, c: '#8fd3ff' });
            });
            netSend('shot', { s: sk });
        } else if (p.form === 'laser') {
            pieces.forEach(q => {
                const len = Math.min(900, p.length * q.s), w = p.width * Math.pow(q.s, 0.7);
                const d = { f: 'laser', x: q.x, y: q.y, a: q.a, len: len, w: w }; skillFx(d); netSend('sk', d);
                const x2 = q.x + Math.cos(q.a) * len, y2 = q.y + Math.sin(q.a) * len;
                hitAll(e => distSeg(e.x, e.y, q.x, q.y, x2, y2) <= w / 2 + e.r, q.k, q.a);
            });
        } else if (p.form === 'slash') {
            pieces.forEach((q, i) => later(i * 0.08, () => {
                const rr = p.radius * q.s;
                const d = { f: 'slash', x: q.x, y: q.y, a: q.a, r: rr, arc: p.arc }; skillFx(d); netSend('sk', d);
                hitAll(e => {
                    const dd = dist(q.x, q.y, e.x, e.y); if (dd > rr + e.r) return false;
                    let da = Math.atan2(e.y - q.y, e.x - q.x) - q.a; da = Math.atan2(Math.sin(da), Math.cos(da));
                    return Math.abs(da) <= p.arc / 2 || dd < e.r + 18;
                }, q.k, q.a);
            }));
        } else if (p.form === 'nova') {
            pieces.forEach((q, i) => later(i * 0.1, () => {
                const rr = p.radius * q.s;
                const d = { f: 'nova', x: q.x, y: q.y, r: rr }; skillFx(d); netSend('sk', d);
                hitAll(e => dist(q.x, q.y, e.x, e.y) <= rr + e.r, q.k, 0);
            }));
        } else if (p.form === 'meteor') {
            pieces.forEach((q, i) => {
                const rr = p.radius * q.s, fall = p.delay + i * 0.12;
                const d = { f: 'meteor', x: q.x, y: q.y, r: rr, dl: fall }; skillFx(d); netSend('sk', d);
                setTimeout(() => {
                    if (run.phase !== 'run') return;
                    hitAll(e => dist(q.x, q.y, e.x, e.y) <= rr + e.r, q.k, 0);
                }, fall * 1000);
            });
        } else if (p.form === 'barrage') {
            // 包囲弾幕：狙った敵（いなければ照準の先）の周りの円周に、弾を数回に分けて出し、中心へまっすぐ飛ばす（追尾なし）
            const tgt = nearestEnemy(me.x, me.y, p.range), cx = tgt ? tgt.x : clamp(me.x + Math.cos(ang) * 380, 30, WORLD_W - 30), cy = tgt ? tgt.y : clamp(me.y + Math.sin(ang) * 380, 30, WORLD_H - 30);
            const col = p.element && window.SBElem && SBElem.ELEMS[p.element] ? SBElem.ELEMS[p.element].color : '#c8a0ff';
            p.pieces.forEach((pc, i) => {
                const px = cx + pc.fw * c0 - pc.sd * s0, py = cy + pc.fw * s0 + pc.sd * c0, R = p.ringR * pc.s, per = Math.max(1, Math.round(p.bullets / p.waves)), k = 0.8 + 0.2 * pc.s;
                fx.push({ k: 'ring', x: px, y: py, r: R * 0.4, max: R, t: 0.45, life: 0.45, c: col });
                for (let w = 0; w < p.waves; w++) later(i * 0.15 + w * p.waveGap, () => {
                    const sk = [], live = tgt && tgt.hp > 0 ? { x: tgt.x + (px - cx), y: tgt.y + (py - cy) } : { x: px, y: py };
                    for (let j = 0; j < per; j++) {
                        const a = (j + w * 0.5 + i * 0.25) * Math.PI * 2 / per, bx = clamp(live.x + Math.cos(a) * R, 5, WORLD_W - 5), by = clamp(live.y + Math.sin(a) * R, 5, WORLD_H - 5);
                        const ta = Math.atan2(live.y - by, live.x - bx), vx = Math.cos(ta) * p.speed, vy = Math.sin(ta) * p.speed, r = p.bulletR * (0.8 + 0.2 * pc.s), life = (R + 120) / p.speed + 0.5;
                        myShots.push({ x: bx, y: by, vx: vx, vy: vy, r: r, life: life, pierce: 0, hit: {}, homing: false, c: col, skill: { base: base * k, hasDmg: hasDmg, eff: eff } });
                        sk.push({ x: Math.round(bx), y: Math.round(by), vx: Math.round(vx), vy: Math.round(vy), r: r, life: +life.toFixed(2), pierce: 0, c: col });
                    }
                    netSend('shot', { s: sk });
                });
            });
        } else if (p.form === 'summon') {
            // ミニオン召喚：配置ごとに1体。同じスキルをもう一度使ったら、前のミニオンは消える
            const selfFx = p.effects.filter(k => SELF_FX.indexOf(k) >= 0), col = domColor(p, selfFx);
            minions = minions.filter(m => m.sid !== skillId);
            pieces.forEach((q, i) => {
                if (minions.length >= 12) return;
                minions.push({ id: myId + '_m' + Date.now().toString(36) + i, sid: skillId, idx: i, x: q.x, y: q.y, r: 13 + 6 * q.s, t: p.duration, max: p.duration, atkT: 0.4 + i * 0.12, cc: 0, spd: p.speed, atkCd: p.atkCd,
                    base: base * q.k, hasDmg: hasDmg, eff: eff, fx: selfFx, c: col, face: 0, lunge: 0 });
                fx.push({ k: 'ring', x: q.x, y: q.y, r: 0, max: 46, t: 0.4, life: 0.4, c: col, fill: true });
            });
        } else if (p.form === 'domain') {
            // 領域：配置ごとに広い領域を展開。中の敵全員にデバフ（ダメージ）、中の味方に回復・バフ
            const selfFx = p.effects.filter(k => SELF_FX.indexOf(k) >= 0);
            pieces.forEach((q, i) => {
                const o = { id: myId + '_' + Date.now().toString(36) + i, sid: skillId + '#' + i, x: q.x, y: q.y, r: p.radius * q.s, t: p.duration, max: p.duration, own: true, tick: p.tick, tk: 0.15 + i * 0.05, cc: 0,
                    base: base * q.k, hasDmg: hasDmg, eff: eff, fx: selfFx, c: domColor(p, selfFx) };
                spawnDomain(o);
                netSend('dom', { id: o.id, x: Math.round(o.x), y: Math.round(o.y), r: Math.round(o.r), t: o.t, fx: selfFx, c: o.c, from: myId });
            });
        } else if (p.form === 'orbit') {
            const avg = pieces.reduce((a, q) => a + q.s, 0) / pieces.length, r = p.orbitR * avg;
            me.orb = { t: p.duration, n: pieces.length, r: r, tick: {}, spin: p.spin, base: base * (0.8 + 0.2 * avg), hasDmg: hasDmg, eff: eff, ptick: p.tick };
            const d = { f: 'orbit', dur: p.duration, r: r, n: pieces.length }; skillFx(d, me); netSend('sk', d);
        } else if (p.form === 'thrust') {
            pieces.forEach((q, i) => later(0.08 + i * p.delay, () => {
                const a = live ? aimAngle() : q.a, x0 = live ? me.x : q.x, y0 = live ? me.y : q.y;
                const len = p.length * q.s, w = p.width * Math.pow(q.s, 0.5);
                const x2 = x0 + Math.cos(a) * len, y2 = y0 + Math.sin(a) * len;
                const d = { f: 'thrust', x: x0, y: y0, a: a, len: len, w: w }; skillFx(d); netSend('sk', d);
                hitAll(e => distSeg(e.x, e.y, x0, y0, x2, y2) <= w / 2 + e.r, q.k, a);
                if (live) { me.ang = a; const L = blinkLimit(me.x, me.y, a, p.lunge, me.r); me.x = clamp(me.x + Math.cos(a) * L, 20, WORLD_W - 20); me.y = clamp(me.y + Math.sin(a) * L, 20, WORLD_H - 20); pushOutOfRocks(me, me.r); }
            }));
        } else if (p.form === 'flash') {
            // 一閃：その場から dist ぶん瞬間移動し、通り道の敵を斬る。複数なら連続で別の向きへ移動する（移動中は無敵）
            pieces.forEach((q, i) => later(i * p.delay, () => {
                const a = q.a, sx = me.x, sy = me.y, dd = p.dist * q.s;
                const stop = blinkLimit(sx, sy, a, dd, me.r);       // 通り道に壁・岩があれば、その手前までしか進めない
                me.x = clamp(sx + Math.cos(a) * stop, 20, WORLD_W - 20); me.y = clamp(sy + Math.sin(a) * stop, 20, WORLD_H - 20);
                pushOutOfRocks(me, me.r); me.ang = a; me.inv = Math.max(me.inv, 0.45);
                const ex = me.x, ey = me.y, w = p.width * Math.pow(q.s, 0.5);
                const d = { f: 'flash', x: sx, y: sy, x2: ex, y2: ey, w: w }; skillFx(d); netSend('sk', d);
                hitAll(e => distSeg(e.x, e.y, sx, sy, ex, ey) <= w / 2 + e.r, q.k, a);
            }));
        }
    }

    // 瞬間移動（一閃）で進める距離：出発点から角度 a の方向へ、壁タイル・岩にぶつかる手前まで（r はプレイヤーの半径）
    function blinkLimit(x, y, a, maxD, r) {
        const step = 8, n = Math.ceil(maxD / step), cx = Math.cos(a), cy = Math.sin(a);
        let ok = 0;
        for (let i = 1; i <= n; i++) {
            const d = Math.min(maxD, i * step), px = x + cx * d, py = y + cy * d;
            let hit = false;
            if (CORR_ON && CF.on) {      // 壁は、体の幅ぶん（左右・前）も見る
                if (corrSolid(px, py) || corrSolid(px + cy * r * 0.7, py - cx * r * 0.7) || corrSolid(px - cy * r * 0.7, py + cx * r * 0.7) || corrSolid(px + cx * r, py + cy * r)) hit = true;
            }
            if (!hit) for (const k of rocks) if (dist(px, py, k.x, k.y) < k.r + r * 0.6) { hit = true; break; }
            if (px < 20 || py < 20 || px > WORLD_W - 20 || py > WORLD_H - 20) hit = true;
            if (hit) break;
            ok = d;
        }
        return ok;
    }

    // ---------- スキル「領域」----------
    //  tick ごとに、中の敵へ skillHit（ダメージ＋デバフ。ただし麻痺・石化・時間凍結は2.5秒に1回だけ）。
    //  中にいる味方（自分を含む）へは、回復・バフ（自己強化系の効果）を、各自の画面で短い時間かけ続ける
    const HARD_CC = ['stun', 'petrify', 'chronowarp'];
    function domColor(p, selfFx) {
        if (p.element && window.SBElem && SBElem.ELEMS[p.element]) return SBElem.ELEMS[p.element].color;
        const debuff = p.effects.some(k => k !== 'damage' && SELF_FX.indexOf(k) < 0);
        return selfFx.length && !debuff ? '#7aff9a' : (selfFx.length ? '#ffd86a' : (debuff ? '#c070ff' : '#9df0ff'));
    }
    function spawnDomain(o) {
        if (o.own && o.sid) domains = domains.filter(d => !(d.own && d.sid === o.sid));   // 同じスキルをもう一度使ったら、前の領域は消えて置き換わる（重ねがけで二重にヒットしない）
        domains.push(o);
        fx.push({ k: 'ring', x: o.x, y: o.y, r: 0, max: o.r * 1.1, t: 0.6, life: 0.6, c: o.foe ? '#ff9a9a' : '#ffe9a0' });                 // 門が開く：金色の輪が広がる（相手の領域は赤）
        fx.push({ k: 'ring', x: o.x, y: o.y, r: 0, max: o.r * 0.6, t: 0.45, life: 0.45, c: o.foe ? '#ffd0d0' : '#fff6d0', fill: true });
    }
    function updateDomains(dt) {
        if (!domains.length) return;
        domains.forEach(d => {
            d.t -= dt;
            // 中にいる自分へ、味方の領域（自分の領域も）の回復・バフ
            if (!d.foe && d.fx && d.fx.length && !me.dead && dist(me.x, me.y, d.x, d.y) <= d.r) {
                d.bt = (d.bt || 0) - dt;
                if (d.bt <= 0) {
                    d.bt = 0.4;
                    d.fx.forEach(k => {
                        if (k === 'fortify') me.fortifyT = Math.max(me.fortifyT || 0, 1.0);
                        else if (k === 'haste') me.haste = Math.max(me.haste || 0, 1.0);
                        else if (k === 'empower') me.empowerT = Math.max(me.empowerT || 0, 1.0);
                        else if (k === 'regenerate') me.regenT = Math.max(me.regenT || 0, 1.0);
                        else if (k === 'barrier' && (me.barrierHp || 0) < me.maxHp * 0.12) me.barrierHp = Math.max(10, Math.round(me.maxHp * 0.2));
                    });
                }
            }
            // 領域の持ち主だけが、中の敵へダメージとデバフ
            if (d.own && d.t > 0) {
                d.tk -= dt;
                if (d.tk <= 0) {
                    d.tk += d.tick; d.cc -= d.tick;
                    const full = d.cc <= 0; if (full) d.cc = 2.5;
                    const eff = full ? d.eff : d.eff.filter(k => HARD_CC.indexOf(k) < 0);
                    enemies.forEach(e => { if (e.hp > 0 && !e.pvp && dist(e.x, e.y, d.x, d.y) <= d.r + e.r) skillHit(e, d.base, d.hasDmg, eff, Math.atan2(e.y - d.y, e.x - d.x)); });
                }
            }
        });
        domains = domains.filter(d => d.t > 0);
    }
    // 領域の見た目：ゲートキーパーの「門」と同じ、金色の魔法陣。開くときに広がり、閉じる直前に点滅する
    //  （外側の輪と光の粒＝門の縁／中の輪と放射線が逆回転／いちばん内側に、領域の種類の色＝属性・回復・デバフ）
    // ---------- スキル「ミニオン召喚」----------
    //  ミニオンは自分の画面で動かす。敵に近づいて、atkCd ごとに skillHit（ダメージ＋デバフ）。敵がいなければ自分の周りを回る。
    //  召喚者には、生きている間バフ・回復（自己強化系の効果）が効き続ける。他のプレイヤーには、位置だけを送って表示する
    function applyAuraFx(list) {
        list.forEach(k => {
            if (k === 'fortify') me.fortifyT = Math.max(me.fortifyT || 0, 1.0);
            else if (k === 'haste') me.haste = Math.max(me.haste || 0, 1.0);
            else if (k === 'empower') me.empowerT = Math.max(me.empowerT || 0, 1.0);
            else if (k === 'regenerate') me.regenT = Math.max(me.regenT || 0, 1.0);
            else if (k === 'barrier' && (me.barrierHp || 0) < me.maxHp * 0.12) me.barrierHp = Math.max(10, Math.round(me.maxHp * 0.2));
        });
    }
    // 治療師の同行（ロビーで「治療師を連れていく」をオンにして出発したとき）：加護の杖を持った治療師が後ろをついてきて、3秒ごとに自分のHPを回復する
    const HEALER = (launch && launch.healer > 0 && !PVP) ? { pct: Math.min(0.15, launch.healer), x: null, y: 0, t: 3 } : null;
    function updateHealer(dt) {
        if (!HEALER || me.dead || run.phase !== 'run') return;
        if (HEALER.x == null) { HEALER.x = me.x - 34; HEALER.y = me.y + 26; }
        const k = 1 - Math.exp(-dt * 5); HEALER.x += (me.x - 34 - HEALER.x) * k; HEALER.y += (me.y + 26 - HEALER.y) * k;
        HEALER.t -= dt;
        if (HEALER.t <= 0) {
            HEALER.t = 3;
            const got = me.hp < me.maxHp ? addHp(me.maxHp * HEALER.pct) : 0;
            fx.push({ k: 'ring', x: me.x, y: me.y, r: 0, max: 46, t: 0.45, life: 0.45, c: '#7aff9a' });
            if (got > 0) popups.push({ x: me.x, y: me.y - 34, t: 0.9, text: '+HP', c: '#7aff9a' });
        }
    }
    function drawHealer() {
        if (!HEALER || HEALER.x == null || me.dead) return;
        ctx.save(); ctx.font = '22px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('👩‍⚕️', HEALER.x, HEALER.y);
        ctx.font = '12px sans-serif'; ctx.fillText('🪄', HEALER.x + 14, HEALER.y - 8); ctx.restore();
    }
    function updateMinions(dt) {
        if (me.dead) minions = [];
        if (minions.length) {
            hadMinions = true;
            const tn = performance.now() / 1000;
            auraT -= dt;
            if (auraT <= 0) { auraT = 0.4; const auraFx = minions[0].fx; if (auraFx && auraFx.length) applyAuraFx(auraFx); }
            minions.forEach(m => {
                m.t -= dt; m.lunge = Math.max(0, m.lunge - dt);
                let tgt = null, bd = 650;
                enemies.forEach(e => { if (e.hp > 0) { const d = dist(m.x, m.y, e.x, e.y) - e.r; if (d < bd) { bd = d; tgt = e; } } });
                let tx, ty, stop;
                if (tgt) { tx = tgt.x; ty = tgt.y; stop = m.r + tgt.r * 0.6; }
                else { const n = Math.max(1, minions.length), an = tn * 0.9 + m.idx * Math.PI * 2 / n; tx = me.x + Math.cos(an) * 90; ty = me.y + Math.sin(an) * 90; stop = 4; }
                const dx = tx - m.x, dy = ty - m.y, d = Math.hypot(dx, dy) || 1;
                if (d > stop) { const step = Math.min(d - stop, m.spd * dt * (d > 400 && !tgt ? 2 : 1)); m.x += dx / d * step; m.y += dy / d * step; }
                m.x = clamp(m.x, 10, WORLD_W - 10); m.y = clamp(m.y, 10, WORLD_H - 10);
                m.face = Math.atan2(dy, dx);
                m.atkT -= dt;
                if (tgt && m.atkT <= 0 && dist(m.x, m.y, tgt.x, tgt.y) <= m.r + tgt.r + 26) {
                    m.atkT = m.atkCd; m.cc -= m.atkCd; m.lunge = 0.15;
                    const full = m.cc <= 0; if (full) m.cc = 2.5;     // 麻痺・石化・時間凍結は同じ敵に2.5秒に1回
                    skillHit(tgt, m.base, m.hasDmg, full ? m.eff : m.eff.filter(k => HARD_CC.indexOf(k) < 0), Math.atan2(tgt.y - m.y, tgt.x - m.x));
                    fx.push({ k: 'ring', x: tgt.x, y: tgt.y, r: 0, max: 34, t: 0.2, life: 0.2, c: m.c });
                }
            });
            minions = minions.filter(m => m.t > 0);
        }
        // 他のプレイヤーへ、位置だけを送る（0.2秒ごと。いなくなったら空を1回送る）
        minionSendT -= dt;
        if (minionSendT <= 0 && (minions.length || hadMinions)) {
            minionSendT = 1 / 15; minionSeq++;
            netSend('mn', { q: minionSeq, l: minions.slice(0, 12).map(m => [Math.round(m.x), Math.round(m.y), Math.round(m.r), Math.round(m.t * 10) / 10, +(m.face || 0).toFixed(2), m.lunge > 0 ? 1 : 0]), c: minions[0] ? minions[0].c : '#9df0ff' });
            if (!minions.length) hadMinions = false;
        }
        // 他のプレイヤーのミニオン：届いた位置へ、速度を使って先読みしながら滑らかに近づく。更新が1秒途絶えたら消す
        const nowR = performance.now(), kR = 1 - Math.exp(-dt * 18);
        Object.keys(remoteMinions).forEach(id => {
            const rm = remoteMinions[id]; if (nowR - rm.at > 1000) { delete remoteMinions[id]; return; }
            const age = Math.min(0.25, (nowR - rm.at) / 1000);
            rm.l.forEach(q => { const px = q.tx + q.vx * age, py = q.ty + q.vy * age; q.x += (px - q.x) * kR; q.y += (py - q.y) * kR; if (q.lunge > 0) q.lunge -= dt; });
        });
    }
    function drawMinionBody(x, y, r, c, face, frac, hostile, lunge) {
        const tn = performance.now() / 1000, bob = Math.sin(tn * 6 + x * 0.05) * 2;
        const ox = Math.cos(face) * (lunge ? 8 : 0), oy = Math.sin(face) * (lunge ? 8 : 0);
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(x, y + r * 0.8, r * 0.9, r * 0.35, 0, 0, 7); ctx.fill();
        const col = hostile ? '#ff6a6a' : c;
        if (window.SBPix && SBPix.on() && SBPix.drawEnemy) {      // ドット絵のミニオン（召喚した相棒）
            SBPix.drawEnemy(ctx, x + ox, y + oy, r, 'chaser', col, { left: Math.cos(face) < 0, seed: x * 0.1, now: performance.now() });
            if (frac < 1) { ctx.fillStyle = 'rgba(255,255,255,0.85)'; const n = Math.max(1, Math.round(16 * Math.max(0, frac))); for (let i = 0; i < n; i++) { const an = -Math.PI / 2 + i / 16 * Math.PI * 2; ctx.fillRect(Math.round((x + ox + Math.cos(an) * (r + 6)) / 2) * 2 - 1, Math.round((y + oy + Math.sin(an) * (r + 6)) / 2) * 2 - 1, 3, 3); } }
            return;
        }
        ctx.globalAlpha = 0.9; ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x + ox, y + oy + bob, r, 0, 7); ctx.fill();
        ctx.globalAlpha = 1; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x + ox + Math.cos(face) * r * 0.3 - r * 0.3, y + oy + bob - r * 0.15, r * 0.2, 0, 7); ctx.arc(x + ox + Math.cos(face) * r * 0.3 + r * 0.3, y + oy + bob - r * 0.15, r * 0.2, 0, 7); ctx.fill();
        ctx.fillStyle = '#10131b'; ctx.beginPath(); ctx.arc(x + ox + Math.cos(face) * r * 0.45 - r * 0.3, y + oy + bob - r * 0.15, r * 0.09, 0, 7); ctx.arc(x + ox + Math.cos(face) * r * 0.45 + r * 0.3, y + oy + bob - r * 0.15, r * 0.09, 0, 7); ctx.fill();
        if (frac < 1) { ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x + ox, y + oy + bob, r + 5, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.max(0, frac)); ctx.stroke(); }   // 残り時間
    }
    function drawMinions() {
        minions.forEach(m => drawMinionBody(m.x, m.y, m.r, m.c, m.face, m.t / m.max, false, m.lunge > 0));
        Object.keys(remoteMinions).forEach(id => {
            const rm = remoteMinions[id], hostile = PVP && run.pvpMode && !sameTeam(id);
            rm.l.forEach(q => drawMinionBody(q.x, q.y, q.r, rm.c, q.face, q.t > 0 && q.t < 99 ? 1 : 1, hostile, q.lunge > 0));
        });
    }
    const DOM_GOLD = { g0: 'rgba(255,230,140,0.0)', g1: 'rgba(255,210,100,0.26)', g2: 'rgba(255,190,60,0)', s1: 'rgba(255,226,140,0.95)', dot: '#ffe9a0', s2: '#ffd36a', s3: 'rgba(255,233,160,0.85)' };
    const DOM_FOE  = { g0: 'rgba(255,120,120,0.0)', g1: 'rgba(255,70,70,0.26)',   g2: 'rgba(255,40,40,0)',  s1: 'rgba(255,110,110,0.95)', dot: '#ff9a9a', s2: '#ff6a6a', s3: 'rgba(255,150,150,0.85)' };
    function drawDomains() {
        if (!domains.length) return;
        const now = performance.now() / 1000;
        domains.forEach(d => {
            const open = clamp((d.max - d.t) / 0.7, 0, 1), eo = 1 - Math.pow(1 - open, 3);
            let a = eo * clamp(d.t / 0.6, 0, 1);
            if (d.t < 1.4) a *= 0.7 + 0.3 * Math.sin(d.t * 30);          // 閉じる直前は点滅
            if (a <= 0.01) return;
            const R = d.r * (0.55 + 0.45 * eo), K = d.foe ? DOM_FOE : DOM_GOLD;
            ctx.save(); ctx.translate(d.x, d.y); ctx.globalAlpha = a;
            if (window.SBPix && SBPix.on()) {      // ドット絵の領域：粒の輪が回り、内側に回る星と、領域の色の輪
                const z = 4, Rq = Math.max(16, Math.round(R / 8) * 8), PADD = 14, dotsOn = (g2, rr, n, col, rot, sz, every) => { for (let i = 0; i < n; i++) { const an = i / n * Math.PI * 2 + rot; g2.fillStyle = (every && i % every === 0) ? '#ffffff' : col; g2.fillRect(Math.round(Math.cos(an) * rr / 2) * 2 - sz / 2, Math.round(Math.sin(an) * rr / 2) * 2 - sz / 2, sz, sz); } };
                // 動かない部分（薄い円盤・外側の粒の輪・領域の色の輪）：半径ごとに一度だけ描く
                const stat = fxCached('d|' + Rq + '|' + K.s2 + '|' + (d.c || ''), (Rq + PADD) * 2, (Rq + PADD) * 2, g2 => {
                    g2.translate(Rq + PADD, Rq + PADD); g2.fillStyle = K.s2; g2.globalAlpha = 0.1; for (let y = -Rq; y <= Rq; y += z) { const hw = Math.round(Math.sqrt(Math.max(0, Rq * Rq - y * y)) / z) * z; g2.fillRect(-hw, Math.round(y / z) * z, hw * 2, z); }
                    g2.globalAlpha = 1; dotsOn(g2, Rq, Math.max(24, Math.floor(Rq * 0.45)), K.s2, 0, 4, 6);
                    g2.globalAlpha = 0.5; dotsOn(g2, Rq * 0.9, Math.max(20, Math.floor(Rq * 0.4)), d.c || '#c070ff', 0, 6, 0);
                });
                ctx.globalAlpha = a; ctx.drawImage(stat, -Rq - PADD, -Rq - PADD);
                const ringDots = (rr, n, col, rot, sz, every) => dotsOn(ctx, rr, n, col, rot, sz, every);
                ctx.globalAlpha = a; ringDots(R, 24, K.dot, now * 0.5, 8, 0);      // 回る光の粒
                if (!LITE()) {
                    ctx.globalAlpha = a * 0.9; ringDots(R * 0.78, Math.max(12, Math.floor(R * 0.22)), K.s2, -now * 0.9, 4, 0);
                    for (let k2 = 0; k2 < 2; k2++) for (let i = 0; i < 3; i++) { const a1 = i * Math.PI * 2 / 3 + k2 * Math.PI / 3 + now * 0.7, a2 = (i + 1) * Math.PI * 2 / 3 + k2 * Math.PI / 3 + now * 0.7, x1 = Math.cos(a1) * R * 0.52, y1 = Math.sin(a1) * R * 0.52, x2 = Math.cos(a2) * R * 0.52, y2 = Math.sin(a2) * R * 0.52, n = Math.max(2, Math.ceil(Math.hypot(x2 - x1, y2 - y1) / 10)); ctx.globalAlpha = a * 0.85; ctx.fillStyle = K.dot; for (let j = 0; j <= n; j++) ctx.fillRect(Math.round((x1 + (x2 - x1) * j / n) / 2) * 2 - 2, Math.round((y1 + (y2 - y1) * j / n) / 2) * 2 - 2, 4, 4); }
                }
                ctx.restore(); return;
            }
            // 門の光（縁に向かって金色が濃くなる）
            const g = ctx.createRadialGradient(0, 0, R * 0.35, 0, 0, R * 1.12);
            g.addColorStop(0, K.g0); g.addColorStop(0.72, K.g1); g.addColorStop(1, K.g2);
            ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, R * 1.12, 0, 7); ctx.fill();
            // 外側の輪と、周回する光の粒
            ctx.strokeStyle = K.s1; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(0, 0, R, 0, 7); ctx.stroke();
            ctx.save(); ctx.rotate(now * 0.5); ctx.fillStyle = K.dot;
            for (let i = 0; i < 24; i++) { ctx.rotate(Math.PI / 12); ctx.beginPath(); ctx.arc(R, 0, 5, 0, 7); ctx.fill(); }
            ctx.restore();
            // 中の輪（逆回転）と放射線
            ctx.save(); ctx.rotate(-now * 0.9); ctx.strokeStyle = K.s2; ctx.lineWidth = 2.5;
            ctx.beginPath(); ctx.arc(0, 0, R * 0.78, 0, 7); ctx.stroke();
            for (let i = 0; i < 12; i++) { ctx.rotate(Math.PI / 6); ctx.beginPath(); ctx.moveTo(R * 0.78, 0); ctx.lineTo(R * 0.94, 0); ctx.stroke(); }
            ctx.restore();
            // さらに内側：星形（二重の三角）が回る
            ctx.save(); ctx.rotate(now * 0.7); ctx.strokeStyle = K.s3; ctx.lineWidth = 2;
            for (let k = 0; k < 2; k++) { ctx.beginPath(); for (let i = 0; i < 3; i++) { const an = i * Math.PI * 2 / 3 + k * Math.PI / 3; const x = Math.cos(an) * R * 0.52, y = Math.sin(an) * R * 0.52; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); } ctx.closePath(); ctx.stroke(); }
            ctx.beginPath(); ctx.arc(0, 0, R * 0.52, 0, 7); ctx.stroke();
            ctx.restore();
            // 領域の種類の色（属性・回復・デバフ）：内側の細い輪
            ctx.globalAlpha = a * (0.45 + 0.2 * Math.sin(now * 3)); ctx.strokeStyle = d.c || '#c070ff'; ctx.lineWidth = 5;
            ctx.beginPath(); ctx.arc(0, 0, R * 0.9, 0, 7); ctx.stroke();
            ctx.restore();
        });
    }

    // 旋回：自分の周りを回る光球。同じ敵には ptick 秒に1回ずつヒットする
    function updateOrbit(dt) {
        const o = me.orb; if (!o) return;
        o.t -= dt;
        if (o.t <= 0 || me.dead) { me.orb = null; return; }
        Object.keys(o.tick).forEach(id => { o.tick[id] -= dt; if (o.tick[id] <= 0) delete o.tick[id]; });
        const base = performance.now() / 1000 * o.spin;
        for (let i = 0; i < o.n; i++) {
            const a = base + i * Math.PI * 2 / o.n, ox = me.x + Math.cos(a) * o.r, oy = me.y + Math.sin(a) * o.r;
            enemies.forEach(e => {
                if (e.hp <= 0 || o.tick[e.id] > 0 || dist(ox, oy, e.x, e.y) > e.r + 16) return;
                o.tick[e.id] = o.ptick; skillHit(e, o.base, o.hasDmg, o.eff, a);
            });
        }
    }
    function flashEnergy() { const b = el('enBar'); if (!b) return; b.classList.add('flash'); setTimeout(() => b.classList.remove('flash'), 300); }

    function buildSkillBar() {
        const box = el('skillBar'); box.innerHTML = '';
        const KEYS = ['Z', 'X', 'C', 'V'];
        skillSlots.forEach((s, i) => {
            const b = document.createElement('button'); b.type = 'button'; b.className = 'skill-btn';
            if (s) b.innerHTML = '<span class="sk-key">' + KEYS[i] + '</span><span class="sk-icon">' + ActionSkills.FORMS[s.skill.form].icon + '</span><span class="sk-name">' + escapeHtml(s.skill.name) + '</span><span class="sk-cost">' + s.cost + '</span><span class="sk-cd"></span>';
            else { b.classList.add('empty'); b.innerHTML = '<span class="sk-key">' + KEYS[i] + '</span><span class="sk-name">未設定</span>'; }
            b.addEventListener('pointerdown', (e) => { e.preventDefault(); castSkill(i); });
            box.appendChild(b);
        });
    }
    function updateSkillBar() {
        Array.from(el('skillBar').children).forEach((b, i) => {
            const s = skillSlots[i]; if (!s) return;
            const cd = b.querySelector('.sk-cd'); const t = s.cdLeft > 0 ? s.cdLeft.toFixed(1) : '';
            if (cd && cd.textContent !== t) cd.textContent = t;
            b.classList.toggle('ready', me.energy >= s.cost && s.cdLeft <= 0);
            b.classList.toggle('short', me.energy < s.cost);
        });
    }
    function addEnergy(v) { me.energy = Math.min(ENERGY_MAX, me.energy + v); updateEnergyUI(); }

    // ---------- 更新 ----------
    function updateMe(dt) {
        accTick(dt);
        tickCharge(dt);
        if (A('selfBleed') > 0 && !me.dead && run.phase === 'run') me.hp = Math.max(1, me.hp - me.maxHp * A('selfBleed') * dt);      // 血の契約（HP1で止まる）
        // 毒（毒牙の敵に触れると付く）。ダメージはじわじわ減り、0になったら毒は切れる
        if (me.poisonT > 0 && !me.dead && run.phase === 'run') {
            me.poisonT -= dt; me.hp -= (me.poisonDps || 0) * dt;
            if (me.poisonT <= 0 || me.hp <= 0) {
                if (me.hp <= 0) { me.hp = 0; me.dead = true; me.reviveT = 0; me.stunT = 0; me.orb = null; if (window.SBSound) SBSound.sfx('defeat'); announce('毒で倒れた！ 仲間が近くに来れば復活できます', 2200); }
                me.poisonT = 0; me.poisonDps = 0;
            }
        }
        me.atkCd -= dt; me.dashCd -= dt; me.inv -= dt; if (me.invHard > 0) me.invHard -= dt; if (me.haste > 0) me.haste -= dt; if (me.flash > 0) me.flash -= dt;
        if (me.dead) {
            // 仲間が近くにいると復活する
            const near = !PVP && !me.escaped && Object.keys(allies).some(id => { const a = allies[id]; return !a.dead && dist(a.x, a.y, me.x, me.y) < 90; });
            if (near) { me.reviveT += dt; if (me.reviveT > 2.5) { me.dead = false; me.stg = 0; me.hp = Math.round(me.maxHp * 0.4); me.inv = 1.5; me.invHard = 1.5; announce('復活！', 900); } } else me.reviveT = Math.max(0, me.reviveT - dt);
            return;
        }
        // スタン（動けない・攻撃も回避もできない）。復帰後は少しのあいだスタンしない
        if (me.stunT > 0) {
            me.stunT -= dt; me.dashT = 0;
            if (me.stunT <= 0) { me.stunT = 0; me.stunImm = PVP ? PVP_STUN_IMM : STUN_IMM; popups.push({ x: me.x, y: me.y - 34, t: 0.9, text: '復帰！', c: '#9df0ff' }); }
        } else if (me.stunImm > 0) me.stunImm -= dt;
        const stunned = me.stunT > 0 || !!me.cast || me.gch > 0 || me.ultT > 0;      // 動けない（スタン・スキルの溜め・守りの溜め）
        // 移動
        let mx = (keys['KeyD'] || keys['ArrowRight'] ? 1 : 0) - (keys['KeyA'] || keys['ArrowLeft'] ? 1 : 0) + input.stick.x;
        let my = (keys['KeyS'] || keys['ArrowDown'] ? 1 : 0) - (keys['KeyW'] || keys['ArrowUp'] ? 1 : 0) + input.stick.y;
        const l = Math.hypot(mx, my); if (l > 1) { mx /= l; my /= l; }
        input.mx = mx; input.my = my;
        if (window.ClassPerks) { const pf = ClassPerks.moveFilter(mx, my); mx = pf[0]; my = pf[1]; }      // 職業パーク：移動の制限
        const sp = P.move * (me.haste > 0 ? 1.3 : 1) * (window.ClassPerks ? ClassPerks.moveMul() : 1) * (GMK === 'duality' && me.chill > 0 ? 1 - Math.min(0.45, me.chill * 0.045) : 1);
        if (me.dashT > 0) {
            me.dashT -= dt; moveSolid(me, me.dashVX * dt, me.dashVY * dt, me.r);
            if (me.dashT <= 0 && me.dashBlast) { const v = me.dashBlast; me.dashBlast = 0; fx.push({ k: 'ring', x: me.x, y: me.y, r: 0, max: 130, t: 0.3, life: 0.3, c: '#cfe8ff' }); enemies.forEach(e => { if (e.hp > 0 && dist(e.x, e.y, me.x, me.y) < 140 + e.r) dealHit(e, weapon.dmg * P.atkMul * v, { kx: (e.x - me.x) * 3, ky: (e.y - me.y) * 3 }); }); }
        } else if (!stunned) { moveSolid(me, mx * sp * dt, my * sp * dt, me.r); }
        pushOutOfRocks(me, me.r);
        if (input.aimOn && !isTouch) me.ang = Math.atan2(input.aimY - (VH / 2 + (me.y - camBase.y)), input.aimX - (VW / 2 + (me.x - camBase.x)));
        if (!stunned && wantsAttack() && me.atkCd <= 0 && run.phase === 'run' && (!window.ClassPerks || ClassPerks.attackOk())) { doAttack(); if (window.ClassPerks) ClassPerks.afterAttack(); }
        if (me.orb) updateOrbit(dt);
        // 持続回復
        if (A('regen') > 0) addHp(me.maxHp * A('regen') * dt);
        if (me.gutsT > 0) me.gutsT -= dt;
        if (me.regenT > 0) { me.regenT -= dt; addHp(me.maxHp * 0.03 * dt); }
        if (me.fortifyT > 0) me.fortifyT -= dt;
        if (me.empowerT > 0) me.empowerT -= dt;
        // 接触ダメージ
        for (const e of enemies) {
            if (e.pvp || e.hp <= 0 || e.st.stunT > 0 || e.air > 20 || e.noContact) continue;
            if (!e.boss && (e.arch === 'chaser' || e.arch === 'swarm' || e.arch === 'tank')) { meleeHitCheck(e); continue; }      // 近接の敵：触れてもダメージなし。攻撃モーションの「攻撃」の瞬間にだけ当たる
            if (e.arch === 'ranged' && !e.boss) continue;      // 遠距離の敵は弾で攻撃する（体当たりはしない）
            if (e.arch === 'charger' && !e.boss && e.state !== 2) continue;      // 突進の敵は、突進中だけ当たる
            if (dist(e.x, e.y, me.x, me.y) < e.r + me.r - 2) { if (e.arch === 'bomber' || e.arch === 'heart' || e.arch === 'wscale' || e.arch === 'wcore' || (e.arch === 'slime' && (e.air || 0) > e.r * 0.4) || (G.hid && (e.boss || e.arch === 'wseg')) || (GMK === 'worm' && wmZone(e.x) !== wmZone(me.x))) continue; hurtMe(ed(e) * (e.arch === 'charger' && e.state === 2 ? 1.3 : (e.boss && e.state === 11 ? 1.7 : 1.0)), e.affix === 'venom' ? { poison: true } : null); }
        }
        // 敵弾
        for (let i = eBullets.length - 1; i >= 0; i--) {
            const b = eBullets[i];
            if (b.refl === 2) continue;   // 跳ね返した弾は味方に当たらない
            if (dist(b.x, b.y, me.x, me.y) < b.r + me.r) { hurtMe(b.dmg); eBullets.splice(i, 1); if (!isHost) netSend('bhit', { id: b.id }); }
        }
    }

    // 他のプレイヤーの弾：動かして、岩・自分・敵に当たったら消すだけ（ダメージ判定はしない）
    function updateGhostShots(dt) {
        for (let i = ghostShots.length - 1; i >= 0; i--) {
            const g = ghostShots[i];
            g.x += g.vx * dt; g.y += g.vy * dt; g.life -= dt;
            let dead = g.life <= 0 || g.x < 0 || g.y < 0 || g.x > WORLD_W || g.y > WORLD_H;
            if (!dead) for (const k of rocks) if (dist(g.x, g.y, k.x, k.y) < k.r) { dead = true; break; }
            if (!dead && PVP && !me.dead && dist(g.x, g.y, me.x, me.y) < g.r + me.r) dead = true;     // 対人戦：自分に当たった弾は消える
            if (!dead && !PVP) for (const e of enemies) { if (e.hp > 0 && !g.hit && dist(g.x, g.y, e.x, e.y) < g.r + e.r) { if (g.pierce-- <= 0) { dead = true; break; } } }
            if (dead) {
                if (g.aoe && g.life > 0) fx.push({ k: 'ring', x: g.x, y: g.y, r: 0, max: g.aoe, t: 0.3, life: 0.3, c: '#ffb04a', fill: true });
                ghostShots.splice(i, 1);
            }
        }
        if (ghostShots.length > 300) ghostShots.splice(0, ghostShots.length - 300);
    }
    // ================= 神話（オリジナル武器）：分身の剣 =================
    //  通常攻撃や必殺技のとき、剣が何本かに分かれて、敵を攻撃する（動きと描画は blades.js）。威力の合計は、自作の動きの設定にかかわらず一定（hw-weapons.js の motionCombo / motionUlt）
    function bladeLook() { return { type: weapon.type, col: FXCOL || HW.rarityOf(weapon).color, pc: MYPC, mythic: weapon.mythicId || null }; }
    function addMyBlades(spec) {
        if (!window.SBBlades) return;
        const look = bladeLook(); if (spec.col) look.col = spec.col;
        const alive = enemies.filter(e => e.hp > 0 && e.act !== false && dist(me.x, me.y, e.x, e.y) < 600).sort((a, b) => dist(me.x, me.y, a.x, a.y) - dist(me.x, me.y, b.x, b.y));
        const pick = alive.slice(0, Math.max(1, spec.n | 0));
        spec.tg = (spec.mode === 'sweep' ? pick.slice(0, 1) : pick).map(e => [Math.round(e.x), Math.round(e.y)]);
        const bl = SBBlades.make(spec, look, { targets: pick });
        myBlades = myBlades.concat(bl).slice(-18);
        netSend('atk', { k: 'blades', mode: spec.mode, n: Math.min(spec.mode === 'dance' ? 8 : 4, spec.n | 0), hits: spec.hits | 0, sz: spec.sz || 1, sp: spec.sp || 1, a: +(spec.a || 0).toFixed(3), x: Math.round(spec.x), y: Math.round(spec.y), tg: spec.tg, c: look.col, fin: spec.fin ? 1 : 0, life: spec.life || 0 });
    }
    function bladeHit(e, b) {
        pvpProj = true; const h = strike(e, b.bm, 40); pvpProj = false;
        hitFeel(e, { fin: false, i: 0, ult: true }, h);
    }
    function ghostBladesFrom(d, owner) {
        if (!window.SBBlades || !SBBlades.MODES[d.mode]) return;
        const num = v => (typeof v === 'number' && isFinite(v)) ? v : 0;
        const tg = Array.isArray(d.tg) ? d.tg.slice(0, 4).filter(q => Array.isArray(q) && q.length >= 2).map(q => [clamp(num(q[0]), 0, WORLD_W), clamp(num(q[1]), 0, WORLD_H)]) : [];
        const col = (typeof d.c === 'string' && /^#[0-9a-f]{6}$/i.test(d.c)) ? d.c : '#ffffff';
        const spec = { mode: d.mode, n: clamp(num(d.n) | 0 || 1, 1, d.mode === 'dance' ? 8 : 4), hits: clamp(num(d.hits) | 0 || 1, 1, 4), sz: clamp(num(d.sz) || 1, 0.8, 2), sp: clamp(num(d.sp) || 1, 0.6, 1.6), a: num(d.a), x: clamp(num(d.x), 0, WORLD_W), y: clamp(num(d.y), 0, WORLD_H), tg: tg, life: clamp(num(d.life), 0, 6), fin: d.fin ? 1 : 0 };
        const bl = SBBlades.make(spec, { type: owner.wt || 'sword', col: col, pc: owner.wpc || null, mythic: owner.wm || null }, { vis: true });
        bl.forEach(b => { b.owner = owner; });
        ghostBlades = ghostBlades.concat(bl).slice(-24);
    }
    function updateBlades(dt) {
        if (!window.SBBlades) return;
        if (me.dead) myBlades = [];
        if (myBlades.length) {
            const env = { targets: enemies.filter(e => e.hp > 0 && e.act !== false), hit: bladeHit };
            for (let i = myBlades.length - 1; i >= 0; i--) { const b = myBlades[i]; SBBlades.step(b, dt, me.x, me.y, env); if (b.dead) myBlades.splice(i, 1); }
        }
        for (let i = ghostBlades.length - 1; i >= 0; i--) { const b = ghostBlades[i], o = b.owner; SBBlades.step(b, dt, o ? o.x : b.x, o ? o.y : b.y, null); if (b.dead) ghostBlades.splice(i, 1); }
    }
    function drawBlades() { if (window.SBBlades) { myBlades.forEach(b => SBBlades.draw(ctx, b)); ghostBlades.forEach(b => SBBlades.draw(ctx, b)); } }

    function updateShots(dt) {
        updateGhostShots(dt); updateBlades(dt);
        for (let i = myShots.length - 1; i >= 0; i--) {
            const s = myShots[i];
            if (s.homing) { const n = nearestEnemy(s.x, s.y, 360); if (n) { const sp = Math.hypot(s.vx, s.vy); const a = Math.atan2(s.vy, s.vx), ta = Math.atan2(n.y - s.y, n.x - s.x); let da = ta - a; da = Math.atan2(Math.sin(da), Math.cos(da)); const na = a + clamp(da, -4 * dt, 4 * dt); s.vx = Math.cos(na) * sp; s.vy = Math.sin(na) * sp; } }
            s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt;
            let dead = s.life <= 0 || s.x < 0 || s.y < 0 || s.x > WORLD_W || s.y > WORLD_H;
            if (!dead) for (const k of rocks) if (dist(s.x, s.y, k.x, k.y) < k.r) { dead = true; break; }
            if (!dead && CORR_ON && corrSolid(s.x, s.y)) dead = true;
            if (!dead) {
                for (const e of enemies) {
                    if (e.hp <= 0 || s.hit[e.id]) continue;
                    if (dist(s.x, s.y, e.x, e.y) < s.r + e.r) {
                        s.hit[e.id] = 1; pvpProj = true;
                        if (s.skill) skillHit(e, s.skill.base, s.skill.hasDmg, s.skill.eff, Math.atan2(s.vy, s.vx));
                        else {      // 通常攻撃の弾：当たった手応えと、必殺ゲージ（1回の射撃につき1回だけ溜まる。散弾でも増えすぎない）
                            const hh = strike(e, s.m || 1, 30); hitFeel(e, { fin: !!s.fin, i: s.cs | 0, ult: true }, hh);
                            if (s.vol && s.vol !== me.ultGainShot) { me.ultGainShot = s.vol; ultGain(s.fin ? 8 : 2.5); }
                        }
                        pvpProj = false;
                        if (s.aoe) { boomMine(s.x, s.y, s.aoe); s.aoe = 0; }     // 魔導砲：着弾点で爆発（周囲の敵にも当たる）
                        if (s.pierce-- <= 0) { dead = true; break; }
                    }
                }
            }
            if (dead) myShots.splice(i, 1);
        }
    }

    function updateHost(dt) {
        updateEnemies(dt);
        gmUpdate(dt);
        // 敵弾
        for (let i = eBullets.length - 1; i >= 0; i--) {
            const b = eBullets[i];
            if (b.refl === 2) {   // 跳ね返された弾：ボスへ飛んでいく。最初の1発が核を砕く
                const bo = enemies.find(o => o.boss && !o.echo && o.hp > 0);
                if (bo) {
                    const a = Math.atan2(bo.y - b.y, bo.x - b.x); b.vx = Math.cos(a) * 640; b.vy = Math.sin(a) * 640; b.life = 6;
                    if (dist(b.x, b.y, bo.x, bo.y) < bo.r + 50) { if (b.core) dimCoreBreak(bo); eBullets.splice(i, 1); continue; }
                }
            }
            b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
            let dead = b.life <= 0 || b.x < -50 || b.y < -50 || b.x > WORLD_W + 50 || b.y > WORLD_H + 50;
            if (!dead) for (const k of rocks) if (dist(b.x, b.y, k.x, k.y) < k.r) { dead = true; break; }
            if (!dead && CORR_ON && b.kd !== 9 && corrSolid(b.x, b.y)) dead = true;
            if (dead) eBullets.splice(i, 1);
        }
        // 予告範囲
        for (let i = telegraphs.length - 1; i >= 0; i--) {
            const t = telegraphs[i]; t.t -= dt;
            if (t.t <= 0) {
                boomAt(t.x, t.y, t.r, t.dmg, t.c, { sh: t.sh, a: t.a, arc: t.arc, ri: t.ri, w: t.w, stun: t.stun });
                if (t.rep > 0) { t.rep--; t.t = t.max = t.gap || 0.3; t.live = true; } else telegraphs.splice(i, 1);
            }
        }
        // 湧き
        if (RUSH_ON) { if (run.phase === 'run') rushHost(dt); }
        else if (AMB_ON) { if (run.phase === 'run') ambHost(dt); }
        else if (CORR_ON) { /* 無限回廊の敵は階層を作るときに配置する */ }
        else if (run.phase === 'run' && !run.bossSpawned && stage.bossOnly) startBoss();   // ゲートは雑魚なしで最初からボス戦
        else if (run.phase === 'run' && !run.bossSpawned) {
            spawnT -= dt;
            const cap = ENEMY_CAP_BASE + 8 * (partyCount() - 1);
            if (spawnT <= 0 && enemies.length < cap) { spawnGroup(); spawnT = clamp(1.5 - run.kills / 110, 0.55, 1.5) / (1 + 0.25 * (partyCount() - 1)); }
            const need = Math.round(KILLS_BASE * (1 + 0.35 * (partyCount() - 1)));
            run.need = need;
            if (run.kills >= need) startBoss();
        }
        if (run.bossSpawned && run.bossDead && !run.ended) { run.ended = true; setTimeout(() => finishHost(true), CINE.used ? Math.round(CINE_END * 1000 + 300) : 2600); }      // 撃破の演出が終わってから結果へ
        if (run.phase === 'run' && !run.ended) {
            const everyoneDown = me.dead && Object.keys(allies).every(id => allies[id].dead || allies[id].esc);
            if (everyoneDown) { run.ended = true; setTimeout(() => finishHost(false, 'down'), 1200); }
            else if (run.time > TIME_LIMIT) { run.ended = true; finishHost(false, 'time'); }
        }
    }

    // ================= 大討伐戦 第三幕：ネクロマンスド・シャーマン =================
    //  ・常に死霊を召喚し続ける（NECRO_GAP 秒ごとに1体＝約5体/秒）。生きている死霊は NECRO_CAP 体まで（それ以上は、減るまで呼ばない）
    //  ・シャーマンの軍勢に倒されたプレイヤーは、その場に「自分とそっくりのステータスのゾンビ」を残す（ホストが生む）
    //  ・ゾンビ／死霊は雑魚（boss:false）なので、倒してもクリアにはならない。シャーマン本体を倒すと、全部消える
    const NECRO_GAP = 0.2, NECRO_CAP = 110;
    const ZOMBIE_K = { hp: 4, atk: 1.5, dmgMin: 0.04, dmgMax: 0.25 };      // ゾンビの強さの調整用（体力の倍率／攻撃の倍率／攻撃の下限・上限）
    function necroMinions() { return enemies.filter(o => (o.necroM || o.zombie) && !o.dead && o.hp > 0); }
    function necroSummon(b) {
        const a = rnd(0, Math.PI * 2), rr = b.r + rnd(20, 70), ghost = Math.random() < 0.28;
        const def = ghost ? { name: '亡霊', icon: '👻', arch: 'ranged', color: '#b9a8ff' } : { name: '骸骨兵', icon: '💀', arch: 'chaser', color: '#d6dccb' };
        const m = spawnEnemy(def, clamp(b.x + Math.cos(a) * rr, 40, WORLD_W - 40), clamp(b.y + Math.sin(a) * rr, 40, WORLD_H - 40), false, false);
        m.maxHp = m.hp = Math.max(1, Math.round(m.maxHp * 0.5)); m.dmg *= 0.6; m.noLoot = true; m.necroM = true; m.affix = null;
        pushOutOfRocks(m, m.r);
        return m;
    }
    function updateNecro(e, dt, tgt, d, ang, slow) {
        if (!e.enraged && e.hp / e.maxHp < 0.5) { e.enraged = true; netAnnounce('💀 シャーマンが、死霊をさらに呼び覚ました！', 2000); }
        const sp = e.spd * slow * 1.1;      // 距離をとって、後ろから死霊を送り込む
        if (d > 520) { e.x += Math.cos(ang) * sp * dt; e.y += Math.sin(ang) * sp * dt; } else if (d < 320) { e.x -= Math.cos(ang) * sp * dt; e.y -= Math.sin(ang) * sp * dt; }
        e.x = clamp(e.x, 80, WORLD_W - 80); e.y = clamp(e.y, 80, WORLD_H - 80);
        e.sumT = (e.sumT == null ? 0 : e.sumT) - dt;      // 召喚：1秒に5体ペース（ラグで溜まった分は、いっぺんに出しすぎない）
        let cnt = necroMinions().length, guard = 0;
        while (e.sumT <= 0 && guard++ < 4) { e.sumT += NECRO_GAP; if (cnt < NECRO_CAP) { necroSummon(e); cnt++; } }
        if (guard > 0 && Math.random() < 0.25) fx.push({ k: 'puff', x: e.x, y: e.y + 10, t: 0.3, life: 0.3, c: '#a070ff' });
        // 本体の攻撃：5種類を、短い間隔でたたみかける（HP50%以下ではさらに激しく）。弾幕の連射「魂の螺旋」は、ほかの攻撃と同時に続く
        const enr = !!e.enraged, k = ed(e) * (enr ? 1.2 : 1.1);
        if (e.spiT > 0) {
            e.spiT -= dt; e.spiE = (e.spiE || 0) - dt;
            if (e.spiE <= 0) { e.spiE = enr ? 0.07 : 0.1; e.spiA = (e.spiA || 0) + 0.42; [0, 2.094, 4.189].forEach(o => bullet(e.x, e.y, e.spiA + o, 300, k * 0.7, 7, 4, '#c06aff')); }
        }
        e.atkT = (e.atkT == null ? 2 : e.atkT) - dt;
        if (e.atkT <= 0) {
            e.atkT = enr ? 1.15 : 1.8; const i = (e.patIdx = (e.patIdx | 0) + 1) % 5;
            if (i === 0) { const n = enr ? 17 : 11, w = enr ? 3 : 2; for (let q = 0; q < w; q++) for (let j = 0; j < n; j++) bullet(e.x, e.y, ang + (j - (n - 1) / 2) * 0.15, 330 + q * 90, k, 8, 3.4, '#cdb8ff'); }      // 骨の扇弾（速さをずらして2〜3段）
            else if (i === 1) { const n = enr ? 40 : 28, off = rnd(0, 6.28); for (let j = 0; j < n; j++) bullet(e.x, e.y, off + j * Math.PI * 2 / n, 250, k, 8, 4.5, '#a070ff'); for (let j = 0; j < n; j++) bullet(e.x, e.y, off + (j + 0.5) * Math.PI * 2 / n, 170, k, 8, 5, '#7a4fd0'); }      // 死霊の輪（二重）
            else if (i === 2) { alivePlayersPos().forEach(p => { telegraph(p.x, p.y, 125, 1.1, k * 1.7, '#a070ff'); telegraph(p.x + rnd(-200, 200), p.y + rnd(-200, 200), 100, 1.3, k * 1.5, '#a070ff'); }); telegraph(e.x, e.y, 190, 1.0, k * 1.4, '#7a4fd0'); }      // 魂の叩きつけ（本人の足元＋ばらまき）
            else if (i === 3) { e.spiT = enr ? 3.2 : 2.4; }      // 魂の螺旋（渦巻きの弾幕を連射）
            else { const ps = alivePlayersPos(), n = enr ? 18 : 12; if (ps.length) for (let j = 0; j < n; j++) { const p = ps[Math.floor(Math.random() * ps.length)]; telegraph(clamp(p.x + rnd(-300, 300), 40, WORLD_W - 40), clamp(p.y + rnd(-300, 300), 40, WORLD_H - 40), 85, 0.8 + j * 0.08, k * 1.4, '#cdb8ff'); } }      // 骨の雨（時間差の着弾予告）
        }
    }
    function necroHost(dt) {
        G.nt = (G.nt || 0) - dt; if (G.nt > 0) return; G.nt = 0.4;
        const l = necroMinions(); G.nm = l.length; G.zb = l.filter(o => o.zombie).length;
    }
    function necroCleanup() {      // シャーマンが倒れた：死霊もゾンビも、みんな崩れ落ちる
        enemies.forEach(o => { if ((o.necroM || o.zombie) && !o.dead) { o.hp = 0; o.dead = true; fx.push({ k: 'puff', x: o.x, y: o.y, t: 0.4, life: 0.4, c: '#cdb8ff' }); } });
        netAnnounce('💀 シャーマンが倒れ、死霊たちが崩れ落ちた！', 2600);
    }
    function necroCorpse() {      // 自分がシャーマンの軍勢に倒された：自分のステータスを、ホストに知らせる（ホストなら、その場で生む）
        if (me.corpseAt && Date.now() - me.corpseAt < 3000) return; me.corpseAt = Date.now();
        const d = { k: 'corpse', x: Math.round(me.x), y: Math.round(me.y), n: String(myName).slice(0, 12), mhp: Math.round(me.maxHp), atk: Math.round(weapon.dmg * P.atkMul * 10) / 10, spd: Math.round(P.move), def: Math.round(P.def) };
        if (isHost) hostCorpse(d); else netSend('gm', d);
    }
    function hostCorpse(d) {      // ホスト：倒されたプレイヤーの死体から、そっくりのステータスのゾンビを生む
        if (!isHost || !run.bossSpawned || run.ended) return;
        const num = (v, lo, hi, df) => { v = Number(v); return isFinite(v) ? clamp(v, lo, hi) : df; };
        const mhp = num(d.mhp, 10, 1e7, REF_HP), atk = num(d.atk, 0, 1e7, 20), spd = num(d.spd, 60, 520, 235), df = num(d.def, 0, 1e7, 0);
        const z = spawnEnemy({ name: String(d.n || '冒険者').slice(0, 12) + 'のゾンビ', icon: '🧟', arch: 'chaser', color: '#7fae6a' }, clamp(num(d.x, 0, WORLD_W, WORLD_W / 2), 30, WORLD_W - 30), clamp(num(d.y, 0, WORLD_H, WORLD_H / 2), 30, WORLD_H - 30), false, false);
        z.zombie = true; z.noLoot = true; z.affix = null;
        z.maxHp = z.hp = Math.max(1, Math.round(z.maxHp * clamp(mhp / REF_HP, 0.4, 8) * ZOMBIE_K.hp));      // 体力：その人の最大HP（基準HPとの比）
        z.dmg = clamp(atk / REF_HP * ZOMBIE_K.atk, ZOMBIE_K.dmgMin, ZOMBIE_K.dmgMax);                        // 攻撃：その人の1発の威力（基準HPに対する割合）
        z.spd = clamp(spd * 0.9, 80, 280);                                                                   // 速さ：その人の移動速度
        z.takeMul = 1 - Math.min(0.55, df / (df + 250)) * 0.8;                                               // 防御：その人の防御（受けるダメージが減る）
        fx.push({ k: 'ring', x: z.x, y: z.y, r: 0, max: 120, t: 0.6, life: 0.6, c: '#7fae6a' });
        netAnnounce('🧟 ' + z.def.name + 'が生まれた！', 1400);
    }
    function drawNecro(e) {
        const now = performance.now() / 1000, fl = e.flash > 0, r = e.r, bob = Math.sin(now * 2.2) * 5;
        ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(e.x, e.y + r * 0.9, r * 0.95, r * 0.38, 0, 0, 7); ctx.fill();
        for (let i = 0; i < 5; i++) { const a = now * 1.4 + i * 1.2566; ctx.globalAlpha = 0.75; ctx.fillStyle = '#c9b8ff'; ctx.beginPath(); ctx.arc(e.x + Math.cos(a) * r * 1.25, e.y - r * 0.2 + bob + Math.sin(a * 1.3) * r * 0.5, 7, 0, 7); ctx.fill(); }      // まわりを漂う魂
        ctx.globalAlpha = 1; ctx.save(); ctx.translate(e.x, e.y + bob);
        ctx.fillStyle = fl ? '#fff' : '#2a1a47'; ctx.beginPath(); ctx.moveTo(-r * 0.9, r * 0.9); ctx.quadraticCurveTo(-r * 1.0, -r * 0.2, 0, -r * 1.05); ctx.quadraticCurveTo(r * 1.0, -r * 0.2, r * 0.9, r * 0.9); for (let i = 0; i < 6; i++) ctx.lineTo(r * 0.9 - (i + 0.5) * r * 0.3, r * (i % 2 ? 0.9 : 1.1)); ctx.closePath(); ctx.fill();      // ぼろぼろのローブ
        ctx.strokeStyle = '#a070ff'; ctx.lineWidth = 3; ctx.stroke();
        ctx.fillStyle = fl ? '#fff' : '#e9e4d2'; ctx.beginPath(); ctx.arc(0, -r * 0.45, r * 0.38, 0, 7); ctx.fill();      // 頭蓋骨
        ctx.fillStyle = '#14121c'; [-1, 1].forEach(sd => { ctx.beginPath(); ctx.arc(sd * r * 0.15, -r * 0.5, r * 0.1, 0, 7); ctx.fill(); }); ctx.fillRect(-r * 0.12, -r * 0.28, r * 0.24, r * 0.08);
        ctx.fillStyle = '#c06aff'; [-1, 1].forEach(sd => { ctx.beginPath(); ctx.arc(sd * r * 0.15, -r * 0.5, r * 0.04, 0, 7); ctx.fill(); });
        ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(r * 0.85, r * 0.9); ctx.lineTo(r * 0.85, -r * 0.9); ctx.stroke();      // 杖
        ctx.fillStyle = '#c06aff'; ctx.beginPath(); ctx.arc(r * 0.85, -r * 1.0, r * 0.16, 0, 7); ctx.fill();
        ctx.restore();
    }

    // ================= 大討伐戦 第五幕：機械真王・リレインバー =================
    //  ・燃料が MC_FUEL 秒（約20分）で切れる耐久戦。何もしなくても減る。攻撃を受けると自動でバリアを張り、そのたびに燃料を MC_BAR_COST 秒ぶん消費する
    //  ・基本は空を飛んでいて、遠距離武器なら地上から撃てる。近接は、ステージの「上昇気流」に乗っている間だけ届く
    //  ・レーザー（掃射）とミサイル（大量の着弾予告）を撃ってくる。燃料が切れると墜落して、近接でも殴れる（被ダメージ増）
    const MC_FUEL = 20 * 60, MC_BAR_SEC = 1.6, MC_BAR_CD = 2.4, MC_BAR_COST = 6;
    function machineInit(b) {
        b.fuel = MC_FUEL; b.barT = 0; b.barCd = 0; b.mcT = 3; b.takeMul = 1;
        G.fuel = MC_FUEL; G.mfl = 1; G.bar = 0; G.crash = 0; G.lz = null;
        const cx = WORLD_W / 2, cy = WORLD_H / 2; G.ud = [[cx, cy, 100]];      // 上昇気流：[x, y, 半径]。中央と、その周りに6本
        for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3 + 0.3; G.ud.push([Math.round(cx + Math.cos(a) * 620), Math.round(cy + Math.sin(a) * 400), 90]); }
    }
    function machineHit(e) {      // ホスト：攻撃を受けた。バリア中なら無効。バリアが空いていれば、この一撃は通して、バリアを張る
        if (G.crash) return true;
        if (e.barT > 0) return false;
        if (!(e.barCd > 0)) { e.barT = MC_BAR_SEC; e.fuel = Math.max(0, e.fuel - MC_BAR_COST); G.bar = MC_BAR_SEC; fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: e.r * 1.8, t: 0.4, life: 0.4, c: '#7fd8ff' }); }
        return true;
    }
    function machineCrash(b) {
        G.crash = 1; G.mfl = 0; G.lz = null; G.bar = 0; b.barT = 0; b.fuel = 0; G.fuel = 0;
        b.st.stunT = Math.max(b.st.stunT, 6); b.takeMul = 1.5;
        fx.push({ k: 'ring', x: b.x, y: b.y, r: 0, max: 520, t: 0.8, life: 0.8, c: '#ff9a3a', fill: true }); addShake(10, 0.6);
        netAnnounce('⛽ 燃料切れ！　機械真王が墜落した！　近接でも殴れる！', 3200);
    }
    function machineHost(dt) {
        const b = gmBoss(); if (!b || b.arch !== 'machine') return;
        if (!G.crash) { b.fuel -= dt; if (b.fuel <= 0) machineCrash(b); }
        if (b.barT > 0) { b.barT -= dt; if (b.barT <= 0) { b.barT = 0; b.barCd = MC_BAR_CD; } } else if (b.barCd > 0) b.barCd -= dt;
        G.bar = b.barT > 0 ? Math.round(b.barT * 10) / 10 : 0; G.fuel = Math.max(0, Math.ceil(b.fuel));
    }
    function machineLocal(dt) {      // 全員：上昇気流に乗っている間は飛べる（離れても少しのあいだは浮いている）
        if (run.phase !== 'run') return;
        const inZone = !me.dead && (G.ud || []).some(u => dist(me.x, me.y, u[0], u[1]) < u[2] + 8);
        if (inZone) me.udT = 2.4; else if (me.udT > 0) me.udT = Math.max(0, me.udT - dt);
    }
    function updateMachine(e, dt, tgt, d, ang, slow) {
        const crash = !!G.crash, low = !crash && (e.fuel || 0) < MC_FUEL * 0.25, k = ed(e);
        if (!e.enraged && e.hp / e.maxHp < 0.5) { e.enraged = true; netAnnounce('🤖 リレインバーが、全武装を解放した！', 2000); }
        if (!crash) { const sp = e.spd * slow * 0.8; if (d > 260) { e.x += Math.cos(ang) * sp * dt; e.y += Math.sin(ang) * sp * dt; } }      // 空を飛んで、ゆっくり追ってくる
        else if (d > 120) { const sp = e.spd * slow * 0.5; e.x += Math.cos(ang) * sp * dt; e.y += Math.sin(ang) * sp * dt; }      // 墜落後は、地上をのろのろ歩く
        e.x = clamp(e.x, 100, WORLD_W - 100); e.y = clamp(e.y, 100, WORLD_H - 100);
        if (G.lz) {      // レーザー掃射：予告（約0.8秒）→ 弾の列で薙ぎ払う。掃射中も、ほかの攻撃は続く
            const L = G.lz, nb = e.enraged || low ? [0, 0.5, -0.5, 1.0, -1.0] : [0, 0.55, -0.55];      // ビームは3本（激しいときは5本）
            if (L.t > 0) { L.t -= dt; if (L.t > 0.25) L.a = ang; }
            else { L.s += dt; const a0 = L.a + L.dir * (L.s / 1.5 - 0.5) * 1.8; e.lzE = (e.lzE || 0) - dt; if (e.lzE <= 0) { e.lzE = 0.035; nb.forEach(off => bullet(e.x, e.y, a0 + off, 900, k * 0.55, 8, 1.2, '#ff4040')); } if (L.s > 1.5) G.lz = null; }
        }
        if (e.gunT > 0) {      // 機関砲の連射：いちばん近い人を、ばらつかせて撃ち続ける
            e.gunT -= dt; e.gunE = (e.gunE || 0) - dt;
            if (e.gunE <= 0) { e.gunE = 0.07; for (let j = -1; j <= 1; j++) bullet(e.x, e.y, ang + j * 0.2 + rnd(-0.06, 0.06), 520, k * 0.55, 7, 2.2, '#ffd36a'); }
        }
        e.mcT = (e.mcT == null ? 2 : e.mcT) - dt; if (e.mcT > 0) return;
        e.mcT = (crash ? 1.9 : (e.enraged || low ? 1.0 : 1.55)) * rnd(0.85, 1.15);
        let pick = crash ? 2 + (e.patIdx = (e.patIdx | 0) + 1) % 3 : Math.floor(Math.random() * 5);
        if (pick === 1 && G.lz) pick = 0;      // レーザー中に、レーザーは重ねない
        if (pick === 0) {      // ミサイル斉射：あちこちに、時間差で着弾の予告
            const ps = alivePlayersPos(), n = Math.min(44, 16 + 4 * partyCount() + (e.enraged || low ? 8 : 0)); if (!ps.length) return;
            for (let i = 0; i < n; i++) { const p = ps[Math.floor(Math.random() * ps.length)]; telegraph(clamp(p.x + rnd(-300, 300), 40, WORLD_W - 40), clamp(p.y + rnd(-300, 300), 40, WORLD_H - 40), 100, 0.8 + i * 0.05, k * 1.4, '#ff9a3a'); }
            netAnnounce('🚀 ミサイル斉射！', 1000);
        } else if (pick === 1) { G.lz = { a: ang, t: 0.8, s: 0, dir: Math.random() < 0.5 ? -1 : 1 }; netAnnounce('🔴 レーザー照射！', 1000); }
        else if (pick === 2) { const n = e.enraged || low ? 40 : 30, off = rnd(0, 6.28); for (let i = 0; i < n; i++) bullet(e.x, e.y, off + i * Math.PI * 2 / n, 280, k, 8, 4, '#ffd36a'); for (let i = 0; i < n; i++) bullet(e.x, e.y, off + (i + 0.5) * Math.PI * 2 / n, 190, k, 8, 4.5, '#ffb04a'); }      // 全方位弾（二重）
        else if (pick === 4) { e.gunT = e.enraged || low ? 3.0 : 2.2; netAnnounce('🔫 機関砲！', 900); }
        else { alivePlayersPos().forEach(p => { telegraph(p.x, p.y, 130, 1.0, k * 1.6, '#ff9a3a'); telegraph(p.x + rnd(-220, 220), p.y + rnd(-220, 220), 105, 1.2, k * 1.5, '#ff9a3a'); }); telegraph(e.x, e.y, 200, 0.9, k * 1.5, '#ff7a3a'); }
    }
    function drawMachine(e) {
        const now = performance.now() / 1000, fl = e.flash > 0, r = e.r, crash = !!G.crash, hv = crash ? 0 : 46 + Math.sin(now * 1.7) * 6;
        ctx.fillStyle = 'rgba(0,0,0,' + (crash ? 0.35 : 0.22) + ')'; ctx.beginPath(); ctx.ellipse(e.x, e.y + r * 0.9, r * (crash ? 1.1 : 0.8), r * 0.4, 0, 0, 7); ctx.fill();      // 空を飛んでいる間は、地面に影だけ
        ctx.save(); ctx.translate(e.x, e.y - hv);
        if (!crash) { const f = 0.6 + 0.4 * Math.sin(now * 30); ctx.fillStyle = '#ff9a3a'; [-1, 1].forEach(sd => { ctx.beginPath(); ctx.moveTo(sd * r * 0.45 - 9, r * 0.55); ctx.lineTo(sd * r * 0.45 + 9, r * 0.55); ctx.lineTo(sd * r * 0.45, r * (0.9 + 0.5 * f)); ctx.closePath(); ctx.fill(); }); }
        ctx.fillStyle = fl ? '#fff' : (crash ? '#4a4f5c' : '#7d8799'); ctx.strokeStyle = '#2b3040'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(-r * 1.5, r * 0.1); ctx.lineTo(-r * 0.6, -r * 0.35); ctx.lineTo(r * 0.6, -r * 0.35); ctx.lineTo(r * 1.5, r * 0.1); ctx.lineTo(r * 0.7, r * 0.5); ctx.lineTo(-r * 0.7, r * 0.5); ctx.closePath(); ctx.fill(); ctx.stroke();      // 翼と船体
        ctx.fillStyle = fl ? '#fff' : (crash ? '#3a3f4c' : '#a9b4c9'); ctx.beginPath(); ctx.ellipse(0, -r * 0.1, r * 0.55, r * 0.5, 0, 0, 7); ctx.fill(); ctx.stroke();
        const glow = crash ? 0.2 : 0.6 + 0.4 * Math.sin(now * 4); ctx.fillStyle = 'rgba(255,70,60,' + glow + ')'; ctx.beginPath(); ctx.arc(0, -r * 0.1, r * 0.22, 0, 7); ctx.fill();      // 赤い核
        ctx.fillStyle = '#14121c'; ctx.fillRect(-r * 0.35, -r * 0.42, r * 0.7, r * 0.1);
        if (G.bar > 0) { ctx.globalAlpha = 0.55 + 0.3 * Math.sin(now * 20); ctx.strokeStyle = '#7fd8ff'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(0, 0, r * 1.7, 0, 7); ctx.stroke(); ctx.fillStyle = 'rgba(127,216,255,0.15)'; ctx.fill(); ctx.globalAlpha = 1; }
        ctx.restore();
        if (crash) { ctx.fillStyle = 'rgba(60,60,70,0.5)'; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.arc(e.x + Math.sin(now * 2 + i * 2) * 20, e.y - 30 - ((now * 40 + i * 25) % 90), 14 + i * 3, 0, 7); ctx.fill(); } }
        if (e.hp < e.maxHp) { const w = r * 2; ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(e.x - w / 2, e.y - hv - r - 22, w, 5); ctx.fillStyle = '#ffb04a'; ctx.fillRect(e.x - w / 2, e.y - hv - r - 22, w * clamp(e.hp / e.maxHp, 0, 1), 5); }
    }
    function drawMachineWorld() {      // 上昇気流・レーザーの予告・飛んでいる自分の表示
        const now = performance.now() / 1000;
        (G.ud || []).forEach(u => {
            ctx.save(); ctx.globalAlpha = 0.28 + 0.1 * Math.sin(now * 3); ctx.fillStyle = '#9fe8ff'; ctx.beginPath(); ctx.arc(u[0], u[1], u[2], 0, 7); ctx.fill(); ctx.globalAlpha = 0.8; ctx.strokeStyle = '#d8f6ff'; ctx.lineWidth = 3; ctx.stroke();
            for (let i = 0; i < 4; i++) { const t = (now * 0.9 + i * 0.25) % 1, ax = u[0] + (i - 1.5) * u[2] * 0.4; ctx.globalAlpha = 1 - t; ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.moveTo(ax, u[1] + u[2] * 0.4 - t * u[2] * 1.2); ctx.lineTo(ax - 7, u[1] + u[2] * 0.4 - t * u[2] * 1.2 + 12); ctx.lineTo(ax + 7, u[1] + u[2] * 0.4 - t * u[2] * 1.2 + 12); ctx.closePath(); ctx.fill(); }
            ctx.restore();
        });
        const b = gmBoss();
        if (b && G.lz && G.lz.t > 0) { ctx.save(); ctx.strokeStyle = 'rgba(255,60,60,' + (0.35 + 0.4 * Math.sin(now * 25)) + ')'; ctx.lineWidth = 6; ctx.setLineDash([16, 10]); [0, 0.55].forEach(off => { ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + Math.cos(G.lz.a + off) * 1800, b.y + Math.sin(G.lz.a + off) * 1800); ctx.stroke(); }); ctx.restore(); }
        if (me.udT > 0 && !me.dead) { ctx.save(); ctx.globalAlpha = 0.5; ctx.strokeStyle = '#d8f6ff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(me.x, me.y - 6, me.r + 10 + Math.sin(now * 8) * 2, 0, 7); ctx.stroke(); ctx.globalAlpha = 1; ctx.font = 'bold 13px sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#d8f6ff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 3; ctx.strokeText('⬆ 飛行中 ' + me.udT.toFixed(1), me.x, me.y - me.r - 22); ctx.fillText('⬆ 飛行中 ' + me.udT.toFixed(1), me.x, me.y - me.r - 22); ctx.restore(); }
    }

    // ================= 襲撃ステージ：ニンゲンの襲来 =================
    //  ・ステージをクリアしたあと、一定の確率で30分だけ出現する（finish() で抽選）。町のステージゲートの隣の「⚔ 襲撃」から入る
    //  ・6つの波。波ごとに、あらゆる方向（円周）から、いろいろな「ニンゲン」の集団が押し寄せる。波が進むほど、方向も数も種類も増える
    //  ・波が終わって数が減ったら、最後のボス「ニンゲンの王・ヒューマニア」が現れる（背後への瞬間移動・連撃・人海戦術・多数決 など）
    //  ・強さは、パーティでいちばん高いステータス合計 × corrMul(AMB_FLOOR) を基準にする（AMB_FLOOR を上げると全体が強くなる）
    const AMB_FLOOR = 8, AMB_WAVES = 6, AMB_WAVE_SEC = 45, AMB_OPEN_MIN = 30, AMB_CHANCE = 0.15;
    const AM = { t: 0, wave: 0, gap: 0, init: false, bossAt: 0 };
    const AMB_HUMANS = [      // w=出やすさ / from=何波から出るか / role=特殊な動き
        { name: '暴徒', icon: '😠', arch: 'chaser', color: '#d9a07a', w: 6, from: 1 },
        { name: '槍兵', icon: '🔱', arch: 'charger', color: '#c9c9d6', w: 3, from: 1 },
        { name: '弓兵', icon: '🏹', arch: 'ranged', color: '#a8c97a', w: 4, from: 1 },
        { name: '盾兵', icon: '🛡️', arch: 'tank', color: '#8fa0bf', w: 3, from: 1 },
        { name: '爆弾魔', icon: '💣', arch: 'bomber', color: '#ff8a4a', w: 3, from: 2 },
        { name: '衛生兵', icon: '🩹', arch: 'ranged', color: '#f5f5f5', role: 'medic', w: 2, from: 2 },
        { name: '魔術師', icon: '🔮', arch: 'ranged', color: '#b58cff', role: 'caster', w: 2, from: 2 },
        { name: '狂戦士', icon: '🪓', arch: 'charger', color: '#e0503a', role: 'berserk', w: 2, from: 3 },
        { name: '忍者', icon: '🥷', arch: 'charger', color: '#4a4a66', role: 'ninja', w: 2, from: 3 },
        { name: '狙撃手', icon: '🎯', arch: 'ranged', color: '#7fd8ff', role: 'sniper', w: 2, from: 3 },
        { name: '火炎兵', icon: '🔥', arch: 'ranged', color: '#ff7a3a', role: 'fire', w: 2, from: 4 },
        { name: '指揮官', icon: '👑', arch: 'tank', color: '#ffcf6a', role: 'commander', w: 1, from: 4 }
    ];
    function ambAlive() { return enemies.filter(o => o.amb && !o.boss && o.hp > 0).length; }
    function ambPick(wave) {
        const ok = AMB_HUMANS.filter(h => h.from <= wave); let tot = 0; ok.forEach(h => { tot += h.w; });
        let r = Math.random() * tot; for (const h of ok) { r -= h.w; if (r <= 0) return h; } return ok[0];
    }
    function ambSpawn(def, x, y, wave) {
        const e = spawnEnemy({ name: def.name, icon: def.icon, arch: def.arch, color: def.color, role: def.role }, clamp(x, 40, WORLD_W - 40), clamp(y, 40, WORLD_H - 40), false, false);
        const k = 0.85 + 0.1 * wave; e.maxHp = e.hp = Math.max(1, Math.round(e.maxHp * k)); e.dmg *= 0.9 + 0.06 * wave; e.amb = true; e.rt = rnd(1, 3);
        if (def.role === 'commander') { e.maxHp = e.hp = Math.round(e.maxHp * 1.6); e.r *= 1.2; }
        pushOutOfRocks(e, e.r);
        return e;
    }
    function ambBurst(wave) {      // 円周のあちこちから、同時に集団を送り込む
        const ps = alivePlayersPos(); if (!ps.length) return;
        const dirs = wave <= 1 ? 2 : (wave <= 3 ? 3 : (wave <= 5 ? 5 : 8)), base = rnd(0, Math.PI * 2);
        for (let k = 0; k < dirs; k++) {
            const c = ps[Math.floor(Math.random() * ps.length)], ang = base + k * Math.PI * 2 / dirs + rnd(-0.2, 0.2), dd = rnd(560, 700);
            const def = ambPick(wave), n = def.arch === 'tank' ? Math.floor(rnd(1, 3)) : Math.floor(rnd(3, 6)) + Math.floor(wave / 2);
            for (let i = 0; i < n; i++) ambSpawn(i === 0 || Math.random() < 0.6 ? def : ambPick(wave), c.x + Math.cos(ang) * dd + rnd(-70, 70), c.y + Math.sin(ang) * dd + rnd(-70, 70), wave);
        }
    }
    function ambNearest(e) {
        let best = null, bd = 1e12; alivePlayersPos().forEach(p => { const d = dist(e.x, e.y, p.x, p.y); if (d < bd) { bd = d; best = p; } });
        return best ? { x: best.x, y: best.y, d: bd } : null;
    }
    function ambRoles(dt) {      // 役職ごとの特殊な動き（ホストだけ）
        for (const e of enemies) {
            if (!e.amb || e.boss || e.hp <= 0 || !e.def.role) continue;
            const role = e.def.role; e.rt = (e.rt == null ? 2 : e.rt) - dt; const tg = ambNearest(e); if (!tg) continue;
            const ang = Math.atan2(tg.y - e.y, tg.x - e.x), k = ed(e);
            if (role === 'berserk') { if (!e.enr && e.hp / e.maxHp < 0.5) { e.enr = true; e.spd *= 1.5; e.dmg *= 1.3; fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: 60, t: 0.4, life: 0.4, c: '#e0503a' }); } continue; }
            if (role === 'sniper' && tg.d < 420) { e.x -= Math.cos(ang) * e.spd * 0.7 * dt; e.y -= Math.sin(ang) * e.spd * 0.7 * dt; e.x = clamp(e.x, 40, WORLD_W - 40); e.y = clamp(e.y, 40, WORLD_H - 40); }
            if (e.rt > 0) continue;
            if (role === 'medic') {
                e.rt = 3; let healed = 0;
                enemies.forEach(o => { if (o.amb && o !== e && o.hp > 0 && o.hp < o.maxHp && dist(o.x, o.y, e.x, e.y) < 260) { o.hp = Math.min(o.maxHp, o.hp + o.maxHp * 0.1); healed++; } });
                if (healed) fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: 260, t: 0.5, life: 0.5, c: '#7fe08a' });
            } else if (role === 'caster') { e.rt = 3.8; telegraph(tg.x, tg.y, 105, 1.2, k * 1.3, '#b58cff'); }
            else if (role === 'ninja') {
                e.rt = 5; if (tg.d > 200) { const a = rnd(0, 6.28); fx.push({ k: 'puff', x: e.x, y: e.y, t: 0.3, life: 0.3, c: '#222' }); e.x = clamp(tg.x + Math.cos(a) * 80, 40, WORLD_W - 40); e.y = clamp(tg.y + Math.sin(a) * 80, 40, WORLD_H - 40); telegraph(e.x, e.y, 90, 0.5, k * 1.2, '#9aa6c0'); }
            } else if (role === 'sniper') { e.rt = 3.4; bullet(e.x, e.y, ang, 780, k * 1.6, 7, 2.4, '#7fd8ff'); }
            else if (role === 'fire') { e.rt = 2.8; telegraph(tg.x, tg.y, 72, 1.0, k * 0.6, '#ff7a3a', { rep: 2, gap: 0.5 }); }
            else if (role === 'commander') { e.rt = 9; if (ambAlive() < 80) for (let i = 0; i < 3; i++) ambSpawn(AMB_HUMANS[0], e.x + rnd(-60, 60), e.y + rnd(-60, 60), Math.max(1, AM.wave)); netAnnounce('👑 指揮官が増援を呼んだ！', 900); }
        }
    }
    function ambHost(dt) {
        if (!AM.init) { AM.init = true; AM.t = -3; netAnnounce('⚔ 襲撃！ ニンゲンたちが、あらゆる方向から襲ってくる！', 3200); }
        AM.t += dt; ambRoles(dt); G.gh = (G.gh || []).map(g => [g[0], g[1], g[2] - dt]).filter(g => g[2] > 0);
        if (run.bossSpawned || AM.t < 0) return;
        const span = AMB_WAVES * AMB_WAVE_SEC, wave = Math.min(AMB_WAVES, 1 + Math.floor(AM.t / AMB_WAVE_SEC));
        G.aw = wave; G.an = ambAlive(); run.need = 1;
        if (AM.t < span) {
            if (wave !== AM.wave) {
                AM.wave = wave; applyScale(Math.round(raidTotal() * corrMul(AMB_FLOOR)), 30, { hp: 1, dmg: 1, spd: Math.min(1.25, 1 + AMB_FLOOR * 0.005) }); SC.hpMul = 1;
                netAnnounce('🌀 第' + wave + '波　' + (wave <= 1 ? '2方向' : wave <= 3 ? '3方向' : wave <= 5 ? '5方向' : '全方位') + 'から、ニンゲンが来る！', 2200); AM.gap = 0;
            }
            AM.gap -= dt;
            if (AM.gap <= 0 && enemies.length < ENEMY_CAP_BASE + 8 * (partyCount() - 1) + 24) { ambBurst(wave); AM.gap = Math.max(2.2, 6.5 - wave * 0.7) / (1 + 0.2 * (partyCount() - 1)); }
        } else {
            if (!AM.bossAt) { AM.bossAt = AM.t; netAnnounce('…静かになった。だが、何かが近づいてくる。', 2600); }
            if (ambAlive() <= 5 || AM.t > span + 25) startBoss();
        }
    }
    // ---- 最後のボス：ニンゲンの王・ヒューマニア ----
    function ambGhost(x, y) { G.gh = (G.gh || []); G.gh.push([Math.round(x), Math.round(y), 0.6]); if (G.gh.length > 8) G.gh.shift(); }
    function ningenTeleport(e, tg, side) {      // 相手のすぐそばへ瞬間移動（残像を残す）
        ambGhost(e.x, e.y); const a = side == null ? rnd(0, 6.28) : side;
        e.x = clamp(tg.x + Math.cos(a) * 85, 60, WORLD_W - 60); e.y = clamp(tg.y + Math.sin(a) * 85, 60, WORLD_H - 60);
        fx.push({ k: 'puff', x: e.x, y: e.y, t: 0.3, life: 0.3, c: '#ffcf6a' });
        return Math.atan2(tg.y - e.y, tg.x - e.x);
    }
    function updateNingen(e, dt, tgt, d, ang, slow) {
        const k = ed(e) * (e.enraged ? 1.15 : 1);
        if (!e.enraged && e.hp / e.maxHp < 0.4) { e.enraged = true; netAnnounce('👑 「正義は、数で決まる！」　王が、すべてを呼び寄せた！', 2600); ambBurst(AMB_WAVES); }
        if (e.comboN > 0) {      // 裏切りの連撃：続けざまに相手の横へ飛んで、斬る
            e.comboT -= dt;
            if (e.comboT <= 0) { e.comboN--; e.comboT = 0.5; const tg = ambNearest(e); if (tg) { const a = ningenTeleport(e, tg); telegraph(e.x, e.y, 150, 0.45, k * 1.5, '#ffcf6a', { sh: 'cone', a: a, arc: 1.4 }); } }
            return;
        }
        if (d > 200) { const sp = e.spd * slow * 0.9; e.x += Math.cos(ang) * sp * dt; e.y += Math.sin(ang) * sp * dt; }
        e.x = clamp(e.x, 60, WORLD_W - 60); e.y = clamp(e.y, 60, WORLD_H - 60);
        e.atkT = (e.atkT == null ? 2.5 : e.atkT) - dt; if (e.atkT > 0) return;
        e.atkT = e.enraged ? 1.5 : 2.4; const i = (e.patIdx = (e.patIdx | 0) + 1) % (e.enraged ? 5 : 4);
        if (i === 0) { const tg = ambNearest(e); if (tg) { const a = ningenTeleport(e, tg); telegraph(e.x, e.y, 170, 0.55, k * 1.8, '#ffcf6a', { sh: 'cone', a: a, arc: 1.5 }); netAnnounce('👑 背後に回られた！', 700); } }      // 背後斬り
        else if (i === 1) { for (let j = 0; j < 6; j++) { const a = j * 1.047 + rnd(-0.2, 0.2); ambSpawn(ambPick(AMB_WAVES), e.x + Math.cos(a) * 120, e.y + Math.sin(a) * 120, AMB_WAVES); } const n = 18, off = rnd(0, 6.28); for (let j = 0; j < n; j++) bullet(e.x, e.y, off + j * Math.PI * 2 / n, 260, k * 0.9, 8, 4, '#ffcf6a'); netAnnounce('👑 人海戦術！', 800); }
        else if (i === 2) { const ps = alivePlayersPos(); ps.forEach(p => telegraph(p.x, p.y, 120, 1.1, k * 1.7, '#ff8a4a')); for (let j = 0; j < 8; j++) { const p = ps[Math.floor(Math.random() * ps.length)]; if (p) telegraph(p.x + rnd(-300, 300), p.y + rnd(-300, 300), 90, 0.9 + j * 0.08, k * 1.4, '#ff8a4a'); } netAnnounce('👑 多数決！', 800); }
        else if (i === 3) { e.comboN = 3; e.comboT = 0.2; netAnnounce('👑 裏切りの連撃！', 900); }
        else { telegraph(e.x, e.y, 280, 1.2, k * 2.2, '#fff2b0'); telegraph(e.x, e.y, 460, 1.8, k * 1.6, '#ffcf6a', { sh: 'donut', ri: 280 }); netAnnounce('👑 正義の光！ 近づくか、離れるか！', 1200); }      // 近くにいるか、遠くにいるかで避ける
    }
    function drawNingen(e) {
        const now = performance.now() / 1000, r = e.r, fl = e.flash > 0;
        (G.gh || []).forEach(g => { ctx.save(); ctx.globalAlpha = Math.max(0, g[2]) * 0.8; ctx.fillStyle = '#ffcf6a'; ctx.beginPath(); ctx.arc(g[0], g[1] - r * 0.3, r * 0.7, 0, 7); ctx.fill(); ctx.restore(); });      // 瞬間移動の残像
        ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(e.x, e.y + r * 0.95, r * 0.9, r * 0.32, 0, 0, 7); ctx.fill();
        for (let i = 0; i < 6; i++) { const a = now * 0.8 + i * 1.047; ctx.globalAlpha = 0.6; ctx.fillStyle = '#e9c9a0'; ctx.beginPath(); ctx.arc(e.x + Math.cos(a) * r * 1.5, e.y + Math.sin(a) * r * 0.5, 9, 0, 7); ctx.fill(); ctx.fillRect(e.x + Math.cos(a) * r * 1.5 - 7, e.y + Math.sin(a) * r * 0.5 + 8, 14, 16); }      // 周りをぐるぐる回る、小さなニンゲンたち
        ctx.globalAlpha = 1; ctx.save(); ctx.translate(e.x, e.y);
        ctx.fillStyle = fl ? '#fff' : '#7a1d2a'; ctx.beginPath(); ctx.moveTo(-r * 1.0, r * 0.95); ctx.lineTo(-r * 0.5, -r * 0.2); ctx.lineTo(r * 0.5, -r * 0.2); ctx.lineTo(r * 1.0, r * 0.95); ctx.closePath(); ctx.fill();      // マント
        ctx.fillStyle = fl ? '#fff' : '#3a3550'; ctx.fillRect(-r * 0.4, -r * 0.2, r * 0.8, r * 0.95);      // 服
        ctx.fillStyle = fl ? '#fff' : '#f0c9a0'; ctx.beginPath(); ctx.arc(0, -r * 0.55, r * 0.4, 0, 7); ctx.fill();      // 顔
        ctx.fillStyle = '#14121c'; [-1, 1].forEach(sd => { ctx.beginPath(); ctx.arc(sd * r * 0.15, -r * 0.58, r * 0.06, 0, 7); ctx.fill(); }); ctx.fillRect(-r * 0.15, -r * 0.4, r * 0.3, r * 0.05);
        ctx.fillStyle = '#ffcf6a'; ctx.beginPath(); ctx.moveTo(-r * 0.42, -r * 0.8); ctx.lineTo(-r * 0.42, -r * 1.2); ctx.lineTo(-r * 0.2, -r * 0.95); ctx.lineTo(0, -r * 1.3); ctx.lineTo(r * 0.2, -r * 0.95); ctx.lineTo(r * 0.42, -r * 1.2); ctx.lineTo(r * 0.42, -r * 0.8); ctx.closePath(); ctx.fill();      // 王冠
        ctx.strokeStyle = '#d8dce8'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(r * 0.7, r * 0.8); ctx.lineTo(r * 1.3, -r * 0.9); ctx.stroke(); ctx.strokeStyle = '#ffcf6a'; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(r * 0.62, r * 0.55); ctx.lineTo(r * 0.82, r * 0.62); ctx.stroke();      // 剣
        if (e.enraged) { ctx.globalAlpha = 0.35 + 0.2 * Math.sin(now * 10); ctx.strokeStyle = '#ffcf6a'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(0, 0, r * 1.6, 0, 7); ctx.stroke(); }
        ctx.restore(); ctx.globalAlpha = 1;
    }
    // 緊急ステージ（ニグス）のボスを倒した：混沌の結晶・昇華の結晶・武器・防具・アクセサリー（通常のボス報酬に上乗せ）
    function emgBossBonus(ev) {
        const rb = A('rarePct') + DIFF.luck;
        run.stats.coins += Math.round((1 + stage.ilvl * 0.8) * 60 * (1 + A('goldPct')));
        rollLoot(stage.bossDrops, rb + 1.4, 'epic', ev.x + 24, ev.y, 'boss'); rollLoot(stage.bossDrops, rb + 1.8, 'legendary', ev.x - 24, ev.y + 14, 'boss');
        rollArmor(rb + 1.2, 'epic', ev.x, ev.y - 30, 'boss'); rollAcc(rb + 1.4, 'epic', ev.x - 30, ev.y + 30);
        const chaos = 3 + Math.floor(Math.random() * 3), sub = 1 + (Math.random() < 0.35 ? 1 : 0);      // 混沌の結晶 3〜5個／昇華の結晶 1〜2個
        try {
            const p = getPlayerData();
            if (p) { const cc = p.craftCurrency || (p.craftCurrency = { chaos: 0, divine: 0, imprint: 0 }); cc.chaos = (cc.chaos | 0) + chaos; localStorage.setItem('player', JSON.stringify(p)); }
            const h = HW.load(); HW.addItem(h, 'rarity', sub); HW.save(h);
        } catch (e) { /* 結晶の付与に失敗してもステージは続ける */ }
        run.stats.items = run.stats.items || {}; run.stats.items.rarity = (run.stats.items.rarity || 0) + sub;
        run.stats.chaosCrystal = (run.stats.chaosCrystal || 0) + chaos;
        popups.push({ x: ev.x, y: ev.y - 56, t: 2.2, text: '🔮 混沌の結晶×' + chaos + '　🔶 昇華の結晶×' + sub, c: '#e0b0ff', big: true });
    }
    function ambKillReward(ev) {      // 王を倒した：専用の報酬（大量のコイン・素材・エピック装備・レジェンダリー確定・称号）
        const rb = A('rarePct') + DIFF.luck;
        run.stats.coins += Math.round((1 + 46 * 0.8) * 40 * (1 + A('goldPct')));
        rollMats('boss', ev.x, ev.y); rollMats('boss', ev.x + 20, ev.y); rollMats('boss', ev.x - 20, ev.y);
        const pool = (window.STAGE_DATA.RUSH && window.STAGE_DATA.RUSH.lootPool) ? window.STAGE_DATA.RUSH.lootPool(5).bossDrops : [];
        if (pool.length) { rollLoot(pool, rb + 1.2, 'epic', ev.x, ev.y, 'ambush'); rollLoot(pool, rb + 1.6, 'epic', ev.x + 24, ev.y, 'ambush'); rollLoot(pool, rb + 2.0, 'legendary', ev.x, ev.y + 26, 'ambush'); }
        rollArmor(rb + 1.2, 'epic', ev.x, ev.y - 22, 'ambush'); rollAcc(rb + 1.4, 'epic', ev.x - 30, ev.y + 30);
        try { if (window.SBAch && !DBG) SBAch.report('raid', 1, 'ambush'); } catch (e) { /* 実績の記録に失敗してもゲームは続ける */ }
    }

    // ================= ギミックボス本体 =================
    function gmBoss() { return enemies.find(e => e.boss && !e.echo && e.hp > 0) || null; }
    function gmUpdate(dt) {          // ホストだけ
        if (!GMK || !run.bossSpawned || run.phase !== 'run' || run.ended) return;
        if (GMK === 'stigma') stigmaHost(dt); else if (GMK === 'pressure') pressureHost(dt); else if (GMK === 'twin') twinHost(dt); else if (GMK === 'dimension') dimensionHost(dt); else if (GMK === 'duality') dualityHost(dt); else if (GMK === 'increase') incHost(dt); else if (GMK === 'worm') wormHost(dt); else if (GMK === 'necro') necroHost(dt); else if (GMK === 'machine') machineHost(dt);
    }
    // --- 死神：スティグマ ---
    function stigmaHost(dt) {
        const b = gmBoss(); if (!b) return;
        if (G.sT == null) { G.sT = STIGMA_EVERY; G.sE = 0; G.cE = 0; G.cl = 0; }
        G.sT -= dt;
        if (G.sT <= 0) { G.sT += STIGMA_EVERY; G.sE++; netAnnounce('☠ スティグマが刻まれた…', 900); }
        // スティグマを減らす方法はない：10秒ごとに必ず増え、13個（約130秒）で死亡する。それまでに倒す
    }
    // --- 炉心の巨人：圧力と安全弁 ---
    function pressureHost(dt) {
        const b = gmBoss(); if (!b) return;
        if (G.pT == null) { G.pT = 14; G.cT = 0; G.vl = 0; }
        if (b.vuln > 0) b.vuln -= dt;
        if (G.cT > 0) {
            G.cT -= dt; G.vl = enemies.filter(e => e.valve && e.hp > 0).length;
            if (G.vl === 0) {   // 安全弁を全部壊した：爆発を阻止。ボスは動けず、受けるダメージ+30%
                telegraphs = telegraphs.filter(t => t.id !== G.tid);
                G.cT = 0; G.pT = 24; b.st.stunT = Math.max(b.st.stunT, 5); b.vuln = 6; b.mv = null; b.state = 0;
                netAnnounce('🔧 安全弁を破壊！　圧力が抜けてボスが動けない！（被ダメージ+30%）', 3000);
            } else if (G.cT <= 0) { G.pT = 24; enemies.forEach(e => { if (e.valve) e.hp = 0; }); }   // 間に合わなかった：予告範囲が炸裂する
        } else { G.pT -= dt; if (G.pT <= 0) pressureStart(b); }
    }
    function pressureStart(b) {
        G.cT = 7; const n = Math.min(4, 2 + partyCount());
        for (let i = 0; i < n; i++) {
            const a = i * Math.PI * 2 / n + rnd(0, 0.6);
            const v = spawnEnemy({ name: '安全弁', icon: '🔧', arch: 'tank', color: '#9ac0ff' }, clamp(b.x + Math.cos(a) * 340, 60, WORLD_W - 60), clamp(b.y + Math.sin(a) * 340, 60, WORLD_H - 60), false);
            v.valve = true; v.noLoot = true; v.noContact = true; v.spd = 0; v.maxHp = v.hp = Math.max(1, Math.round(b.maxHp * 0.018));
        }
        telegraph(b.x, b.y, 800, G.cT, ed(b) * 2.6, '#ff6a2a'); G.tid = telegraphs[telegraphs.length - 1].id;
        netAnnounce('♨ 圧力が限界に！　安全弁を全部壊せ！', 2800);
    }
    // --- ゼウス＆プロメテウス：片方が倒れたら15秒で蘇生 ---
    function twinOnDeath(dead) {
        const o = enemies.find(x => x.boss && !x.echo && x !== dead && x.hp > 0); if (!o) return;
        o.rage = 1.3; o.enraged = true;
        G.used = G.used || {};
        if (!G.used[dead.pairIdx]) { G.used[dead.pairIdx] = 1; G.rv = { i: dead.pairIdx, t: 15, x: dead.x, y: dead.y, n: dead.def.name }; netAnnounce('⚠ ' + o.def.name + ' が ' + dead.def.name + ' を蘇らせようとしている！　15秒以内に倒せ！', 3200); }
        else netAnnounce('💢 ' + o.def.name + ' が怒り狂った！', 2000);
    }
    // --- 魔装合体ヴェルスザーク：合体と、距離で技を選ぶ ---
    function vzFuse(dead) {
        if (G.vzF) return; G.vzF = 1;
        const o = enemies.find(x => x.boss && !x.echo && x !== dead && !x.dead && x.hp > 0);
        const px = o ? (o.x + dead.x) / 2 : dead.x, py = o ? (o.y + dead.y) / 2 : dead.y;
        if (o) { o.hp = 0; o.dead = true; fx.push({ k: 'ring', x: o.x, y: o.y, r: 0, max: 220, t: 0.6, life: 0.6, c: '#ffe9a0', fill: true }); }
        const bd = stage.boss;
        const b = spawnEnemy({ name: bd.name, icon: bd.icon, arch: 'chaser', color: bd.color }, clamp(px, 120, WORLD_W - 120), clamp(py, 120, WORLD_H - 120), true);
        b.spd = 78 * (1 + SC.ilvl * 0.012) * PW.spd * 1.5; b.bd = bd; b.pairIdx = 2; b.vz = 'f'; b.fusion = true; b.r = 96;
        raidBossStats(b);      // 合体後はHP満タン（2体ぶんの割引はなし）
        if (DBG && DBG.hp > 0) b.maxHp = b.hp = Math.max(1, Math.round(b.maxHp * DBG.hp));
        b.bset = (BM && BM.SETS && BM.SETS.raid_vz_fusion) || null; b.mv = null; b.state = 0; b.t = -2.4; b.mvIdx = 0; b.mvCount = 0; b.ultN = 0;
        fx.push({ k: 'ring', x: b.x, y: b.y, r: 0, max: 320, t: 0.8, life: 0.8, c: '#ffd86a', fill: true }); fx.push({ k: 'ring', x: b.x, y: b.y, r: 0, max: 240, t: 0.8, life: 0.8, c: '#ff3a52' });
        addShake(10, 0.7);
        netAnnounce('⚡ ' + dead.def.name + ' が倒れた！　2体が合体する…「魔装合体 ヴェルスザーク」！', 3200);
    }
    function vzPick(e) {      // 遠い：ヴェルスの技／瞬間移動　近い：ザークの技。HPが満タンから。大技とスタン技は他のボスと同じ流れ
        const S = (BM && BM.SETS && BM.SETS.raid_vz_fusion); if (!S) return null;
        e.mvCount = (e.mvCount || 0) + 1;
        const ult = S.ult && BM.MOVES[S.ult];
        if (ult) {
            e.ultN = e.ultN || 0;
            if (e.ultN < S.ultAt.length && e.hp / e.maxHp < S.ultAt[e.ultN]) { e.ultN++; return ult; }
            if (e.enraged && e.mvCount % 6 === 0) return ult;
        }
        if (e.mvCount % (e.enraged ? 3 : 4) === 0 && BM.MOVES[S.stun]) return BM.MOVES[S.stun];
        const p = nearestPlayer(e.x, e.y), d = p ? dist(e.x, e.y, p.x, p.y) : 0;
        const list = (d > 460 ? S.far : S.near) || S.moves;
        let k, tries = 0; do { k = Math.floor(Math.random() * list.length); } while (list[k] === e.vzLast && ++tries < 8);
        e.vzLast = list[k]; return BM.MOVES[list[k]] || null;
    }
    function twinHost(dt) {
        if (!G.rv) return;
        G.rv.t -= dt; if (G.rv.t > 0) return;
        const r = G.rv; G.rv = null; const bd = stage.bosses[r.i];
        const b = spawnEnemy({ name: bd.name, icon: bd.icon, arch: 'chaser', color: bd.color }, r.x, r.y, true);
        b.spd = 78 * (1 + SC.ilvl * 0.012) * PW.spd; b.bd = bd; b.pairIdx = r.i; b.bset = (BM && BM.SETS && BM.SETS[bd.set]) || null;
        b.maxHp = Math.round(b.maxHp * (bd.hp || 1)); b.hp = Math.round(b.maxHp * 0.4); b.rage = 1.15; b.enraged = true;
        fx.push({ k: 'ring', x: r.x, y: r.y, r: 0, max: 200, t: 0.6, life: 0.6, c: '#ffe9a0', fill: true });
        netAnnounce('🔥 ' + bd.name + ' が蘇った！', 2400);
    }
    // --- ディメンション・キーパー ---
    function spawnEcho(stageId, x, y) {
        const st = window.getStageById(stageId); if (!st) return null;
        const bd = st.boss, b = spawnEnemy({ name: bd.name, icon: bd.icon, arch: 'chaser', color: bd.color }, clamp(x, 80, WORLD_W - 80), clamp(y, 80, WORLD_H - 80), true);
        b.echo = true; b.bd = bd; b.bset = (BM && BM.SETS && BM.SETS[stageId]) || null;
        b.maxHp = b.hp = Math.max(1, Math.round(b.maxHp * 0.14 * ((DBG && DBG.hp > 0) ? DBG.hp : 1))); b.spd = 78 * (1 + SC.ilvl * 0.012) * PW.spd;
        fx.push({ k: 'ring', x: b.x, y: b.y, r: 0, max: 220, t: 0.7, life: 0.7, c: '#ffe9a0', fill: true });
        return b;
    }
    function dimensionHost(dt) {
        const b = gmBoss(); if (!b) return;
        if (G.dp == null) { G.dp = 1; G.dc = (DBG && DBG.cores != null) ? clamp(DBG.cores | 0, 0, 6) : 6; G.wt = 5; G.wd = 0; G.de = 0; G.dw = 0; b.bset = (BM && BM.SETS && BM.SETS.dim_keeper1) || null; b.inv = true; }
        if (G.dp === 1) {
            b.inv = G.dc > 0;
            if (G.wd > 0) { G.wd -= dt; if (G.wd <= 0) dimFire(b); }
            else { G.wt -= dt; if (G.wt <= 0) { G.wt = 8; G.wd = 1.0; telegraph(b.x, b.y, 170, 1.0, 0, '#ff7aff', { sh: 'portal' }); netAnnounce('💠 次元放射！　引きつけて「スキル」を発動し、跳ね返せ！', 1700); } }
            if (G.dc <= 0) dimPhase2(b);
        } else {
            const echoAlive = enemies.some(e => e.echo && e.hp > 0);
            if (G.dw && !echoAlive) { G.dw = 0; G.de++; b.inv = false; netAnnounce('🚪 門が閉じた…　ゲートキーパーが再び動き出す！', 2200); }
            if (!G.dw && G.de < DK_ECHO.length && b.hp / b.maxHp < DK_ECHO[G.de][1]) {
                const st = window.getStageById(DK_ECHO[G.de][0]);
                spawnEcho(DK_ECHO[G.de][0], b.x + rnd(-260, 260), b.y + rnd(160, 320));
                G.dw = 1; b.inv = true;
                netAnnounce('🚪 ゲートから「' + (st ? st.boss.name : '') + '」が現れた！　倒すまでキーパーは無敵！', 3000);
            }
        }
    }
    function dimFire(b) {            // 反射できる全方位弾（白い輪が付いた弾）
        const n = 20, off = rnd(0, 6.28), k = ed(b) * 1.2;
        for (let i = 0; i < n; i++) { bullet(b.x, b.y, off + i * Math.PI * 2 / n, 215, k, 11, 4.6, '#ff7aff'); eBullets[eBullets.length - 1].refl = 1; }
    }
    function hostReflect(px, py) {   // ホスト：スキルを発動した人の周りの放射弾を跳ね返す。1回で核1つ
        if (GMK !== 'dimension' || G.dp !== 1) return;
        let first = true, n = 0;
        eBullets.forEach(b => { if (b.refl === 1 && dist(b.x, b.y, px, py) <= REFL_R) { b.refl = 2; b.c = '#7fffd4'; b.life = 6; if (first) { b.core = true; first = false; } n++; } });
        if (n) { fx.push({ k: 'ring', x: px, y: py, r: 0, max: REFL_R, t: 0.4, life: 0.4, c: '#7fffd4' }); netSend('gm', { k: 'refl', x: Math.round(px), y: Math.round(py) }); }
    }
    function dimCoreBreak(b) {
        G.dc = Math.max(0, (G.dc == null ? 6 : G.dc) - 1);
        fx.push({ k: 'ring', x: b.x, y: b.y, r: 0, max: 200, t: 0.5, life: 0.5, c: '#ff7aff', fill: true });
        netSend('gm', { k: 'core', x: Math.round(b.x), y: Math.round(b.y) });
        netAnnounce('💠 核が砕けた！　残り ' + G.dc + ' / 6', 1800);
    }
    function dimPhase2(b) {
        G.dp = 2; G.de = 0; G.dw = 0;
        b.inv = false; b.hp = b.maxHp; b.enraged = false; b.bset = (BM && BM.SETS && BM.SETS.dim_keeper2) || null; b.mv = null; b.state = 0; b.t = -2; b.ultN = 0; b.mvIdx = 0; b.mvCount = 0;
        eBullets = eBullets.filter(x => !x.refl);
        netAnnounce('⛩ 核がすべて砕けた！　ゲートキーパーの真の姿が現れる…', 3600);
    }
    // ============================================================
    // ゴースト戦：オンラインマッチに相手がいないとき、ほかのプレイヤーの「分身」（ゴースト）と戦う
    //  ・ゴーストは、相手の名前・武器の種類・レア度を借りたAI。ダメージは対人戦と同じ「最大HPの割合」なので、ステータスの差は関係ない
    //  ・ロビーで取得した相手（localStorage sbGhostFoe）が無ければ、練習用のゴーストが出る。勝敗はPvPの勝利数には数えない
    // ============================================================
    const GHOST_PRESETS = [
        { name: '剣のゴースト', wtype: 'sword', rar: 'rare' }, { name: '弓のゴースト', wtype: 'bow', rar: 'rare' }, { name: '槍のゴースト', wtype: 'spear', rar: 'rare' },
        { name: '杖のゴースト', wtype: 'wand', rar: 'rare' }, { name: '大剣のゴースト', wtype: 'greatsword', rar: 'epic' }, { name: '拳銃のゴースト', wtype: 'pistol', rar: 'epic' }
    ];
    let GH = null;
    function ghostLoad() {
        let g = null;
        try { g = JSON.parse(localStorage.getItem('sbGhostFoe') || 'null'); localStorage.removeItem('sbGhostFoe'); } catch (e) { g = null; }
        if (!g || typeof g.wtype !== 'string' || !HW.TYPES[g.wtype]) { const pr = GHOST_PRESETS[Math.floor(Math.random() * GHOST_PRESETS.length)]; g = Object.assign({ practice: 1 }, pr); if (!HW.TYPES[g.wtype]) g.wtype = Object.keys(HW.TYPES).find(k => !HW.TYPES[k].exclusive) || 'sword'; }
        g.name = String(g.name || 'ゴースト').slice(0, 12);
        return g;
    }
    function startGhost() {
        run.bossSpawned = true; G = {}; enemies = [];
        const g = ghostLoad(), T = HW.TYPES[g.wtype] || HW.TYPES.sword;
        const e = { id: 'pv:ghost', pvp: true, ghost: true, pid: 'ghost', def: { name: g.name, icon: '👻', color: '#cfd8ff' }, arch: 'chaser', boss: false, elite: false, r: 16, maxHp: 100, hp: 100, flash: 0, kx: 0, ky: 0, state: 0, air: 0, x: WORLD_W - 300, y: WORLD_H / 2, spd: 0, dmg: 0, st: { burn: 0, burnT: 0, poison: 0, poisonT: 0, bleed: 0, bleedT: 0, slowT: 0, stunT: 0, weakenT: 0, blindT: 0, curseT: 0 } };
        enemies.push(e);
        GH = { e: e, g: g, T: T, cd: 1.4, dashCd: 3, dashT: 0, dvx: 0, dvy: 0, inv: 0, strafe: 1, strafeT: 1, stun: 0, ultT: 18, ultWind: 0, ultX: 0, ultY: 0, bolts: [], ang: Math.PI, dmgDone: 0 };
        me.x = 300; me.y = WORLD_H / 2; me.ang = 0; window.__ghostDbg = { name: g.name, wtype: g.wtype, practice: !!g.practice };
        announce('👻 ゴースト「' + g.name + '」が現れた！　武器：' + (T.label || g.wtype) + (g.practice ? '（練習用）' : ''), 3200);
    }
    function ghostHurt(e, dmg, o) {      // プレイヤーの攻撃がゴーストに当たった
        if (!GH || e.hp <= 0) return;
        let f = PVP_BASE * dmg / PVP_REF; if (!isFinite(f) || f < 0) f = 0; f = Math.min(f, 100);
        if (GH.inv > 0) { popups.push({ x: e.x, y: e.y - 26, t: 0.5, text: 'MISS', c: '#9fe0ff' }); return; }
        if (Math.random() < 0.12) { popups.push({ x: e.x, y: e.y - 26, t: 0.6, text: 'GUARD', c: '#cfd8ff' }); e.flash = 0.05; return; }      // ときどき防ぐ
        popups.push({ x: e.x + rnd(-8, 8), y: e.y - e.r - 6, t: 0.7, text: (f * 100).toFixed(1) + '%', c: o.crit ? '#ffd84a' : '#fff', big: !!o.crit });
        run.stats.dmg += f * 100; GH.dmgDone += f * 100; e.hp = Math.max(0, e.hp - f * 100); e.flash = 0.1;
        e.x = clamp(e.x + (o.kx || 0) * 0.05, 40, WORLD_W - 40); e.y = clamp(e.y + (o.ky || 0) * 0.05, 40, WORLD_H - 40);
        if (o.st && o.st.stun) GH.stun = Math.max(GH.stun, Math.min(PVP_STUN_MAX, typeof o.st.stun === 'number' ? o.st.stun : 1));
    }
    function ghostUpdate(dt) {
        if (!GH || run.phase !== 'run') return;
        const e = GH.e, T = GH.T, kind = T.kind || 'cone';
        if (e.hp <= 0) { endGhost(true, 'ko'); return; }
        if (me.dead) { endGhost(false, 'ko'); return; }
        if (run.time >= TIME_LIMIT) { endGhost((e.hp / 100) < (me.hp / me.maxHp), 'time'); return; }
        GH.inv = Math.max(0, GH.inv - dt);
        const dx = me.x - e.x, dy = me.y - e.y, d = Math.hypot(dx, dy) || 1, a = Math.atan2(dy, dx);
        GH.ang = a;
        // 弾
        GH.bolts.forEach(b => { b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt; if (dist(b.x, b.y, me.x, me.y) < b.r + me.r) { hurtPvp(b.f, b.vx * 0.2, b.vy * 0.2, null, 'ghost', 1); b.life = 0; } });
        GH.bolts = GH.bolts.filter(b => b.life > 0 && b.x > 0 && b.y > 0 && b.x < WORLD_W && b.y < WORLD_H);
        if (GH.stun > 0) { GH.stun -= dt; return; }
        // 大技：ときどき、足もとに予告の輪を出して、少しあとに爆発する
        if (GH.ultWind > 0) {
            GH.ultWind -= dt;
            if (GH.ultWind <= 0) { fx.push({ k: 'ring', x: GH.ultX, y: GH.ultY, r: 0, max: 210, t: 0.4, life: 0.4, c: '#cfd8ff', fill: true }); addShake(4, 0.2); if (dist(GH.ultX, GH.ultY, me.x, me.y) < 210 + me.r) hurtPvp(0.16, Math.cos(a) * 300, Math.sin(a) * 300, { stun: 1 }, 'ghost', 0); }
        } else if ((GH.ultT -= dt) <= 0) { GH.ultT = 20 + rnd(0, 8); GH.ultWind = 1.0; GH.ultX = me.x; GH.ultY = me.y; fx.push({ k: 'warn', x: GH.ultX, y: GH.ultY, r: 210, t: 1.0, life: 1.0, c: '#cfd8ff' }); popups.push({ x: e.x, y: e.y - 40, t: 1.0, text: '👻 ゴーストの大技！', c: '#cfd8ff', big: true }); }
        // 移動：武器に合った間合いを保つ。ときどき横へ避ける
        const melee = kind === 'cone' || kind === 'line' || kind === 'smash' || kind === 'chain' || kind === 'duality' || kind === 'ring';
        const want = melee ? Math.max(50, (T.range || 80) * 0.7) : Math.max(220, Math.min(380, (T.range || 300) * 0.65));
        if ((GH.strafeT -= dt) <= 0) { GH.strafe = Math.random() < 0.5 ? 1 : -1; GH.strafeT = 0.8 + rnd(0, 1.4); }
        let vx = 0, vy = 0; const sp = 205;
        if (GH.dashT > 0) { GH.dashT -= dt; vx = GH.dvx; vy = GH.dvy; }
        else {
            if (d > want + 30) { vx += Math.cos(a) * sp; vy += Math.sin(a) * sp; } else if (d < want - 50 && !melee) { vx -= Math.cos(a) * sp; vy -= Math.sin(a) * sp; }
            vx += -Math.sin(a) * GH.strafe * sp * 0.55; vy += Math.cos(a) * GH.strafe * sp * 0.55;
            GH.dashCd -= dt;
            if (GH.dashCd <= 0 && d < 190) { GH.dashCd = 3.5 + rnd(0, 2.5); GH.dashT = 0.18; GH.inv = 0.22; GH.dvx = -Math.sin(a) * GH.strafe * 600; GH.dvy = Math.cos(a) * GH.strafe * 600; }
        }
        moveSolid(e, vx * dt, vy * dt, e.r); pushOutOfRocks(e, e.r);
        // 攻撃
        if ((GH.cd -= dt) <= 0) {
            const R = T.range || 100, base = 0.8 * PVP_BASE * (T.mult || 0.8);
            if ((kind === 'cone' || kind === 'line' || kind === 'smash' || kind === 'chain' || kind === 'duality') && d <= R + me.r) {
                GH.cd = (T.cd || 0.5) * 1.25 * (0.9 + rnd(0, 0.4));
                fx.push({ k: 'pslash', x: e.x, y: e.y, a: a, rng: R, arc: T.arc || 1.4, dir: Math.random() < 0.5 ? 1 : -1, t: 0.2, life: 0.2, c: '#cfd8ff' });
                hurtPvp(base * (kind === 'duality' ? 1.6 : 1), Math.cos(a) * 200, Math.sin(a) * 200, null, 'ghost', 0);
            } else if (kind === 'ring' && d <= (T.range || 100) + me.r) {
                GH.cd = (T.cd || 0.6) * 1.25; fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: T.range || 100, t: 0.25, life: 0.25, c: '#cfd8ff' });
                hurtPvp(base, Math.cos(a) * 150, Math.sin(a) * 150, null, 'ghost', 0);
            } else if ((kind === 'proj' || kind === 'lasers') && d <= Math.max(R, 520)) {
                GH.cd = (T.cd || 0.5) * 1.35 * (0.9 + rnd(0, 0.5));
                const n = kind === 'lasers' ? 3 : Math.max(1, T.n || T.count || 1), spread = T.spread || 0.18;
                for (let i = 0; i < n; i++) { const an = a + (i - (n - 1) / 2) * spread + rnd(-0.05, 0.05); GH.bolts.push({ x: e.x, y: e.y, vx: Math.cos(an) * (T.speed || 560), vy: Math.sin(an) * (T.speed || 560), r: T.radius || 8, life: 1.3, f: base / Math.max(1, n * 0.6) }); }
            } else GH.cd = 0.12;
        }
    }
    function endGhost(win, reason) { if (run.phase === 'end') return; finish(win, { reason: reason }); }
    function drawGhost() {
        if (!GH) return;
        const e = GH.e, p = { x: e.x, y: e.y, ang: GH.ang, name: '👻 ' + GH.g.name, hp: e.hp, maxHp: 100, rar: GH.g.rar || 'normal', dead: e.hp <= 0, wt: GH.g.wtype, wm: GH.g.mythicId || '', stun: GH.stun > 0, ti: GH.g.title || '', id: 'ghost' };
        ctx.save(); ctx.strokeStyle = '#cfd8ff'; ctx.globalAlpha = 0.5; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(e.x, e.y, 24, 0, 7); ctx.stroke(); ctx.restore();
        drawPlayer(p, false);
        GH.bolts.forEach(b => { ctx.fillStyle = '#cfd8ff'; ctx.globalAlpha = 0.9; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, 7); ctx.fill(); ctx.globalAlpha = 1; });
    }

    // --- 双界の覇竜ツイン・エレメンタル（大討伐戦）---
    //  ・戦場は左（赤い炎）と右（青い氷）に割れている。赤に長くいると「熱狂」（攻撃UP＋持続ダメージ）、青に長くいると「悪寒」（移動DOWN＋被ダメージUP）が溜まる
    //  ・属性シールド：ボスが赤バリアを張ったら、青エリアにいる人の攻撃がバリアに大ダメージ（逆も同様）。割るとボスが怯んで大チャンス
    //  ・カタストロフ・レイン：全員に赤（隕石）か青（氷塊）の印。印と同じ色のエリアにいると被弾。反対の色のエリアへ逃げれば相殺
    //  ・HP50%以下：臨界突破・紫炎の崩壊（攻撃がすべて紫になり、威力と速さが上がる）
    //  ・双界終焉：HPが一定を切るか、時間がたつと発動。赤と青のクリスタルを、制限時間内に全員で手分けして「同時に」壊せばボスがダウン。失敗すると全滅級の大技
    const FIELD_NEUTRAL = 70, DU_STACK_MAX = 10, EOD_AT = [0.72, 0.42, 0.16], EOD_EVERY = 200, EOD_SEC = 26;
    const DU_COL = { r: '#ff5a3a', b: '#4ac8ff', n: '#c06aff' };
    let DU = {};                 // ホストだけが持つ進行管理（タイマーなど）。みんなに見せるものは G に入れる
    let crLocal = null, crMarks = {};      // カタストロフ・レイン：自分の画面でのカウントダウンと、全員の印（'r'|'b'）
    const fieldOf = x => x < WORLD_W / 2 - FIELD_NEUTRAL ? 'r' : (x > WORLD_W / 2 + FIELD_NEUTRAL ? 'b' : 'n');
    const duOpp = c => c === 'r' ? 'b' : 'r';
    function duPlayers() { const l = []; if (!me.dead) l.push(myId); Object.keys(allies).forEach(id => { if (!allies[id].dead && !allies[id].esc) l.push(id); }); return l; }
    function dualityHost(dt) {
        const b = gmBoss(); if (!b) return;
        if (!DU.init) { DU = { init: 1, t: 0, shT: 12, sh: 0, shHp: 0, shMax: 0, shLeft: 0, crT: 22, eodN: 0, eodNext: EOD_EVERY, eod: null }; G = { ph: 1 }; b.bset = (BM && BM.SETS && BM.SETS.raid_duality) || null; }
        DU.t += dt; if (window.__raidDbg) window.__raidDbg.hpNow = Math.round(b.hp);
        // ---- 臨界突破：紫炎の崩壊（HP50%以下）----
        if (G.ph === 1 && b.hp / b.maxHp <= 0.5 && !DU.eod) {
            G.ph = 2; b.bset = (BM && BM.SETS && BM.SETS.raid_duality2) || null; b.mv = null; b.state = 0; b.t = -2; b.mvIdx = 0; b.mvCount = 0; b.ultN = 0;
            b.rage = 1.3; b.enraged = true; b.spd *= 1.2; eBullets = []; telegraphs = [];
            fx.push({ k: 'ring', x: b.x, y: b.y, r: 0, max: 520, t: 0.8, life: 0.8, c: '#b060ff', fill: true }); addShake(8, 0.5);
            netSend('gm', { k: 'ph2', x: Math.round(b.x), y: Math.round(b.y) });
            netAnnounce('⚠ 臨界突破：紫炎の崩壊！　赤と青が混ざった、紫の力が解き放たれる…', 3600);
        }
        if (DU.eod) duEod(b, dt);
        else {
            // ---- 属性シールド ----
            if (!DU.sh) { DU.shT -= dt; if (DU.shT <= 0 && !crLocal) duShieldStart(b); }
            else { DU.shLeft -= dt; if (DU.shLeft <= 0) duShieldFail(b); }
            // ---- カタストロフ・レイン ----
            DU.crT -= dt;
            if (DU.crT <= 0) {
                DU.crT = G.ph === 2 ? 26 : 34;
                const marks = {}; duPlayers().forEach(id => { marks[id] = Math.random() < 0.5 ? 'r' : 'b'; });
                const dm = ed(b) * (G.ph === 2 ? 2.2 : 1.8);
                crStart(marks, dm); netSend('gm', { k: 'cr', m: marks, dm: +dm.toFixed(4) });
                netAnnounce('☄ カタストロフ・レイン！　赤い印は青エリアへ、青い印は赤エリアへ逃げろ！', 2800);
            }
            // ---- 双界終焉（HPが一定を切る／時間がたつ）----
            if (!DU.sh && !crLocal && (DU.eodN < EOD_AT.length && b.hp / b.maxHp <= EOD_AT[DU.eodN] || DU.t >= DU.eodNext)) duEodStart(b);
        }
        // みんなに見せる状態
        G.sh = DU.sh || 0; G.shp = DU.sh ? Math.max(0, Math.round(DU.shHp / DU.shMax * 100)) : 0; G.shL = DU.sh ? Math.max(0, Math.ceil(DU.shLeft)) : 0;
        const E = DU.eod; G.eT = E ? Math.max(0, Math.ceil(E.t)) : 0; G.eN = E ? E.list.length : 0; G.eA = E ? E.list.filter(it => it.dAt == null).length : 0;
    }
    function duShieldStart(b) {
        DU.sh = Math.random() < 0.5 ? 'r' : 'b'; DU.shMax = DU.shHp = Math.max(1, b.maxHp * 0.03); DU.shLeft = 22;
        fx.push({ k: 'ring', x: b.x, y: b.y, r: 0, max: 260, t: 0.5, life: 0.5, c: DU_COL[DU.sh], fill: true });
        netAnnounce('🛡 ' + (DU.sh === 'r' ? '赤' : '青') + 'いバリア！　' + (DU.sh === 'r' ? '青' : '赤') + 'エリアから攻撃して破れ！', 3000);
    }
    function duShieldBreak(b) {       // バリア破壊：ボスが怯んで、受けるダメージが増える
        DU.sh = 0; DU.shT = 28; b.st.stunT = Math.max(b.st.stunT, 5); b.vuln = 8; b.mv = null; b.state = 0;
        fx.push({ k: 'ring', x: b.x, y: b.y, r: 0, max: 320, t: 0.5, life: 0.5, c: '#ffffff', fill: true }); addShake(5, 0.3);
        netAnnounce('💥 バリア破壊！　ボスが怯んだ！　総攻撃！', 2600);
    }
    function duShieldFail(b) {       // 破れなかった：バリアが弾けて、全域に反撃
        const col = DU_COL[DU.sh] || '#c06aff'; DU.sh = 0; DU.shT = 24;
        telegraph(b.x, b.y, 1100, 1.8, ed(b) * 2.0, col);
        netAnnounce('⚠ バリアが弾ける！　距離を取れ！', 2200);
    }
    function crStart(marks, dm) {
        crMarks = marks || {}; crLocal = { t: 4.0, dm: Number(dm) || 1 };
        const m = crMarks[myId];
        if (m && !me.dead) popups.push({ x: me.x, y: me.y - 52, t: 1.6, text: '☄ ' + (m === 'r' ? '赤い隕石' : '青い氷塊') + '！ → ' + (m === 'r' ? '青' : '赤') + 'エリアへ', c: DU_COL[m], big: true });
    }
    function crResolve() {
        const m = crMarks[myId], dm = crLocal ? crLocal.dm : 1; crLocal = null; const keep = crMarks; crMarks = {};
        if (!m || me.dead) return;
        const f = fieldOf(me.x);
        fx.push({ k: 'ring', x: me.x, y: me.y, r: 0, max: 130, t: 0.5, life: 0.5, c: DU_COL[m], fill: true });
        if (f === m || f === 'n') { popups.push({ x: me.x, y: me.y - 40, t: 0.9, text: '直撃！', c: DU_COL[m], big: true }); hurtMe(dm); }
        else popups.push({ x: me.x, y: me.y - 40, t: 0.9, text: '相殺！', c: '#7fffd4', big: true });
        void keep;
    }
    function duEodStart(b) {
        DU.eodN++; DU.eodNext = DU.t + EOD_EVERY; DU.sh = 0; DU.shT = 30;
        const alive = Math.max(1, duPlayers().length); let n = Math.min(10, Math.max(2, Math.round(alive * 0.6))); if (n % 2) n++;
        DU.crHp = Math.max(1, b.maxHp * 0.03 / n);       // クリスタル全部の合計HPは、ボスのHPの約3%
        DU.eod = { t: EOD_SEC, list: [] };
        b.inv = true; b.st.stunT = EOD_SEC + 3; b.mv = null; b.state = 0; eBullets = []; telegraphs = [];
        const off = rnd(0, 6.28);
        for (let i = 0; i < n; i++) {
            const c = i % 2 ? 'b' : 'r', a = off + i * Math.PI * 2 / n, x = clamp(WORLD_W / 2 + Math.cos(a) * 760, 80, WORLD_W - 80), y = clamp(WORLD_H / 2 + Math.sin(a) * 560, 80, WORLD_H - 80);
            DU.eod.list.push({ c: c, x: x, y: y, e: duCrystal(c, x, y), dAt: null });
        }
        fx.push({ k: 'ring', x: b.x, y: b.y, r: 0, max: 700, t: 1.0, life: 1.0, c: '#c06aff' }); addShake(6, 0.5);
        netAnnounce('⚠ 双界終焉！　赤いクリスタルは青エリアから、青いクリスタルは赤エリアから攻撃して、' + EOD_SEC + '秒以内に「全部を同時に」破壊しろ！', 4200);
    }
    function duCrystal(c, x, y) {
        const v = spawnEnemy({ name: c === 'r' ? '赤のクリスタル' : '青のクリスタル', icon: c === 'r' ? '🔴' : '🔵', arch: 'tank', color: DU_COL[c] }, x, y, false);
        v.valve = true; v.noLoot = true; v.noContact = true; v.spd = 0; v.crystal = c; v.maxHp = v.hp = Math.max(1, Math.round(DU.crHp));
        fx.push({ k: 'ring', x: x, y: y, r: 0, max: 90, t: 0.4, life: 0.4, c: DU_COL[c], fill: true });
        return v;
    }
    function duEod(b, dt) {
        const E = DU.eod; E.t -= dt; const L = E.list;
        L.forEach(it => { const e = it.e; if (e && (e.dead || e.hp <= 0)) { if (it.dAt == null) it.dAt = DU.t; } else it.dAt = null; });
        if (L.length && L.every(it => it.dAt != null)) {      // 全部が同時に壊れている：成功
            DU.eod = null; b.inv = false; b.st.stunT = 9; b.vuln = 10; b.mv = null; b.state = 0;
            enemies.forEach(o => { if (o.crystal) { o.hp = 0; o.dead = true; } });
            fx.push({ k: 'ring', x: b.x, y: b.y, r: 0, max: 520, t: 0.7, life: 0.7, c: '#ffffff', fill: true }); addShake(7, 0.4);
            netAnnounce('✨ 全てのクリスタルを同時に破壊！　ボスがダウンした！　総攻撃のチャンス！', 3600);
            return;
        }
        L.forEach(it => { if (it.dAt != null && DU.t - it.dAt > 5) { it.e = duCrystal(it.c, it.x, it.y); it.dAt = null; popups.push({ x: it.x, y: it.y - 30, t: 1.2, text: 'クリスタルが復活！（同時に壊せ）', c: DU_COL[it.c], big: true }); } });      // 他が残ったまま5秒たつと復活する
        if (E.t <= 0) {      // 失敗：全域が消し飛ぶ
            DU.eod = null; b.inv = false; b.st.stunT = 0; b.t = -3; enemies.forEach(o => { if (o.crystal) { o.hp = 0; o.dead = true; } });
            netSend('gm', { k: 'wipe' }); duWipe();
            netAnnounce('☠ 双界終焉が放たれた…！', 3000);
        }
    }
    function duWipe() {
        fx.push({ k: 'ring', x: me.x, y: me.y, r: 0, max: 400, t: 0.6, life: 0.6, c: '#ffffff', fill: true }); addShake(9, 0.6);
        if (me.dead) return;
        if (me.guardT > 0 || me.invHard > 0) { popups.push({ x: me.x, y: me.y - 40, t: 1.2, text: '防いだ！', c: '#7fffd4', big: true }); return; }
        me.hp = 0; me.dead = true; me.reviveT = 0; me.stunT = 0; me.orb = null; announce('☠ 双界終焉に飲み込まれた…', 3000);
    }
    // ホスト：ヒットの補正。バリアは「反対の色のエリア」からの攻撃で大きく削れる。クリスタルも同じ。0なら、ボスのHPには入らない
    function duHitMul(e, d) {
        const ax = d.by === myId ? me.x : (allies[d.by] ? allies[d.by].x : null), f = ax == null ? 'n' : fieldOf(ax);
        if (e.crystal) return f === duOpp(e.crystal) ? 1 : 0.1;
        if (e.boss && !e.echo && DU.sh) {
            DU.shHp -= d.dmg * (f === duOpp(DU.sh) ? 3 : 0.25);
            if (DU.shHp <= 0) duShieldBreak(e);
            return 0;
        }
        return 1;
    }
    // 各自の画面：エリアの効果（熱狂／悪寒）とカタストロフ・レインの判定
    function duLocal(dt) {
        if (me.hot == null) { me.hot = 0; me.chill = 0; }
        if (me.dead) { me.hot = 0; me.chill = 0; }
        else {
            const f = fieldOf(me.x);
            if (f === 'r') { me.hot = Math.min(DU_STACK_MAX, me.hot + dt); me.chill = Math.max(0, me.chill - 2 * dt); }
            else if (f === 'b') { me.chill = Math.min(DU_STACK_MAX, me.chill + dt); me.hot = Math.max(0, me.hot - 2 * dt); }
            else { me.hot = Math.max(0, me.hot - dt); me.chill = Math.max(0, me.chill - dt); }
            if (me.hot >= 1) {      // 熱狂：攻撃力UP＋持続ダメージ
                me.empowerT = Math.max(me.empowerT || 0, 0.2);
                me.hp -= me.maxHp * 0.0022 * me.hot * dt;
                if (me.hp <= 0) { me.hp = 0; me.dead = true; me.reviveT = 0; me.stunT = 0; me.orb = null; announce('🔥 熱狂の炎に焼かれた…　赤と青を行き来しよう', 2600); }
            }
        }
        if (crLocal) { crLocal.t -= dt; if (crLocal.t <= 0) crResolve(); }
    }
    function drawDualityField() {
        const cx = WORLD_W / 2, t = performance.now() / 1000;
        ctx.save();
        ctx.globalAlpha = 0.2 + 0.04 * Math.sin(t * 2); ctx.fillStyle = DU_COL.r; ctx.fillRect(0, 0, cx - FIELD_NEUTRAL, WORLD_H);
        ctx.fillStyle = DU_COL.b; ctx.fillRect(cx + FIELD_NEUTRAL, 0, WORLD_W - cx - FIELD_NEUTRAL, WORLD_H);
        ctx.globalAlpha = 0.16; ctx.fillStyle = DU_COL.n; ctx.fillRect(cx - FIELD_NEUTRAL, 0, FIELD_NEUTRAL * 2, WORLD_H);
        ctx.globalAlpha = 0.5; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 3; ctx.setLineDash([16, 12]);
        ctx.beginPath(); ctx.moveTo(cx - FIELD_NEUTRAL, 0); ctx.lineTo(cx - FIELD_NEUTRAL, WORLD_H); ctx.moveTo(cx + FIELD_NEUTRAL, 0); ctx.lineTo(cx + FIELD_NEUTRAL, WORLD_H); ctx.stroke(); ctx.setLineDash([]);
        const b = enemies.find(e => e.boss && !e.echo && e.hp > 0);
        if (b) {
            if (G.ph === 2) { ctx.globalAlpha = 0.35 + 0.1 * Math.sin(t * 5); ctx.strokeStyle = '#b060ff'; ctx.lineWidth = 8; ctx.beginPath(); ctx.arc(b.x, b.y, b.r + 26, 0, 7); ctx.stroke(); }
            if (G.sh) { ctx.globalAlpha = 0.5 + 0.15 * Math.sin(t * 6); ctx.strokeStyle = DU_COL[G.sh]; ctx.lineWidth = 10; ctx.beginPath(); ctx.arc(b.x, b.y, b.r + 40, 0, 7); ctx.stroke(); ctx.globalAlpha = 0.14; ctx.fillStyle = DU_COL[G.sh]; ctx.fill(); }
        }
        ctx.restore();
    }
    function drawDualityMarks() {      // カタストロフ・レイン：全員の頭の上に、印の色の円
        if (!crLocal) return;
        const at = id => id === myId ? me : allies[id];
        Object.keys(crMarks).forEach(id => { const p = at(id); if (!p || p.dead) return; const x = p.x, y = p.y - 44 + Math.sin(performance.now() / 160) * 3; ctx.fillStyle = DU_COL[crMarks[id]]; ctx.globalAlpha = 0.9; ctx.beginPath(); ctx.arc(x, y, 9, 0, 7); ctx.fill(); ctx.globalAlpha = 1; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke(); });
    }
    // --- 全員が自分の画面で行う処理 ---
    function gmPullStart(x, y, dur, f) { pullFx = { x: x, y: y, t: dur, f: f }; fx.push({ k: 'ring', x: x, y: y, r: 0, max: 320, t: 0.8, life: 0.8, c: '#9a8aff' }); }
    function onGm(d) {               // ホストからの通知（クライアント側）
        if (d.k === 'pull') gmPullStart(Number(d.x) || 0, Number(d.y) || 0, Math.min(4, Number(d.dur) || 1), Math.min(600, Number(d.f) || 200));
        else if (d.k === 'refl') fx.push({ k: 'ring', x: Number(d.x) || 0, y: Number(d.y) || 0, r: 0, max: REFL_R, t: 0.4, life: 0.4, c: '#7fffd4' });
        else if (d.k === 'core') fx.push({ k: 'ring', x: Number(d.x) || 0, y: Number(d.y) || 0, r: 0, max: 200, t: 0.5, life: 0.5, c: '#ff7aff', fill: true });
        else if (d.k === 'cr' && GMK === 'duality') crStart(d.m && typeof d.m === 'object' ? d.m : {}, Number(d.dm) || 1);
        else if (d.k === 'wipe' && GMK === 'duality') duWipe();
        else if (d.k === 'swal' && GMK === 'worm') { if (Array.isArray(d.ids) && d.ids.indexOf(me.id) >= 0) wormEnterInner(); }
        else if (d.k === 'eject' && GMK === 'worm') wormEjectMe();
        else if (d.k === 'ph2') { fx.push({ k: 'ring', x: Number(d.x) || 0, y: Number(d.y) || 0, r: 0, max: 520, t: 0.8, life: 0.8, c: '#b060ff', fill: true }); addShake(8, 0.5); }
    }
    function gmApplySnap(g) { G = (g && typeof g === 'object') ? g : {}; }
    function gmLocal(dt) {
        if (!GMK || !run.bossSpawned || run.phase !== 'run') return;
        if (GMK === 'duality') duLocal(dt);
        if (GMK === 'worm') wormLocal(dt);
        if (GMK === 'machine') machineLocal(dt);
        if (pullFx && pullFx.t > 0) {
            pullFx.t -= dt;
            if (!me.dead) { const dx = pullFx.x - me.x, dy = pullFx.y - me.y, d = Math.hypot(dx, dy); if (d > 80) { moveSolid(me, dx / d * pullFx.f * dt, dy / d * pullFx.f * dt, me.r); } }
        }
        if (GMK === 'stigma') {
            if (me.stg == null) me.stg = 0;
            const sE = G.sE || 0, cE = G.cE || 0;
            if (sE > stgLastS) { if (!me.dead) { me.stg += sE - stgLastS; popups.push({ x: me.x, y: me.y - 40, t: 0.9, text: '☠ スティグマ ' + me.stg, c: '#c9a0ff', big: true }); } stgLastS = sE; }
            if (cE > stgLastC) { me.stg = Math.max(0, me.stg - 4 * (cE - stgLastC)); stgLastC = cE; }
            if (me.stg >= STIGMA_MAX && !me.dead) { me.stg = 0; me.hp = 0; me.dead = true; me.reviveT = 0; me.stunT = 0; me.orb = null; announce('☠ スティグマが13個…　死神に魂を刈り取られた', 2600); }
        }
    }
    function gmHudText() {
        if (!run.bossSpawned && !AMB_ON) return '';
        if (GMK === 'stigma') return '☠ スティグマ ' + (me.stg || 0) + ' / ' + STIGMA_MAX + '　次の刻印まで ' + Math.max(0, Math.ceil(G.sT == null ? STIGMA_EVERY : G.sT)) + '秒';
        if (GMK === 'pressure' && G.cT > 0) return '♨ 圧力爆発まで ' + Math.ceil(G.cT) + '秒　安全弁 あと ' + (G.vl || 0);
        if (GMK === 'duality') {
            const parts = ['🔥熱狂 ' + Math.floor(me.hot || 0) + '　❄悪寒 ' + Math.floor(me.chill || 0)];
            if (G.eT > 0) parts.push('⚠ 双界終焉まで ' + G.eT + '秒　クリスタル ' + ((G.eN || 0) - (G.eA || 0)) + ' / ' + (G.eN || 0) + ' 破壊中（全部を同時に壊せ！）');
            else {
                if (G.sh) parts.push('🛡 ' + (G.sh === 'r' ? '赤' : '青') + 'バリア ' + (G.shp || 0) + '%　' + (G.sh === 'r' ? '青' : '赤') + 'エリアから攻撃！（あと' + (G.shL || 0) + '秒）');
                if (crLocal && crMarks[myId]) parts.push('☄ あなたは' + (crMarks[myId] === 'r' ? '赤' : '青') + 'の印　' + (crMarks[myId] === 'r' ? '青' : '赤') + 'エリアへ！ ' + Math.ceil(crLocal.t));
            }
            return parts.join('　');
        }
        if (GMK === 'worm') {
            const z = wmZone(me.x), an = G.an || [];
            if (G.wm === 'B') return '🪝 アンカーに乗り続けて、ワームを引きずり出せ！　起動 ' + an.filter(a => a.p >= 100).length + ' / ' + an.length + '　残り ' + (G.at | 0) + ' 秒';
            if (G.wm === 'C') return z ? '🫀 体内：心臓核を壊せ！（酸に注意）　残り ' + (G.ct | 0) + ' 秒' : '🛡 外：鱗を砕け！（残り ' + (G.sc | 0) + ' 枚）→ 口の核を壊せ！　残り ' + (G.ct | 0) + ' 秒';
            if (G.wm === 'D') return '💥 大ダウン！　長い体のどこを殴っても大ダメージ！';
            return '🪱 世界喰らい：足場が崩れていく！　外周に近づくな';
        }
        if (AMB_ON && !run.bossSpawned) return AM.t < 0 ? '⚔ 襲撃に備えろ！' : (AM.t < AMB_WAVES * AMB_WAVE_SEC ? '⚔ 第' + (G.aw || 1) + '波 / ' + AMB_WAVES + '　ニンゲン ' + (G.an || 0) + ' 体　あらゆる方向から来る！' : '…王が近づいている');
        if (GMK === 'ambush') return '👑 ニンゲンの王：背後に回られるぞ！　残像に注意';
        if (GMK === 'necro') return '💀 死霊の軍勢 ' + (G.nm || 0) + ' 体' + (G.zb ? '（うちゾンビ ' + G.zb + ' 体）' : '') + '　倒されると、あなたのゾンビが生まれる！';
        if (GMK === 'machine') { const f = Math.max(0, G.fuel || 0), mm = Math.floor(f / 60), ss = String(f % 60).padStart(2, '0'); return G.crash ? '⛽ 燃料切れ！　墜落した機械真王を、今のうちに叩け！' : '⛽ 燃料 ' + mm + ':' + ss + '　' + (G.bar > 0 ? '🛡 バリア展開中！' : '空の上：遠距離で撃つ／上昇気流に乗って近づく'); }
        if (GMK === 'increase') return G.heart ? '❤ 増殖の心臓が現れた！　逃げ回る心臓に、一撃を当てれば勝ち！' : '🟢 増殖スライム ' + (G.n || 1) + ' / ' + INC_HEART_AT + ' 体　（' + INC_HEART_AT + ' 体に分裂すると、心臓が現れる）';
        if (GMK === 'velzark') return G.vzF ? '⚡ 魔装合体ヴェルスザーク：遠いとヴェルスの技か瞬間移動、近いとザークの技！' : '😇 ヴェルス と 😈 ザーク：どちらかが倒れると合体する！（合体後はHP満タン）';
        if (GMK === 'twin' && G.rv) return '⚠ ' + G.rv.n + ' が蘇るまで ' + Math.ceil(G.rv.t) + '秒　先に倒せ！';
        if (GMK === 'dimension') return G.dp === 2 ? (G.dw ? '🚪 ゲートの主が出現中：倒さないとキーパーは無敵' : '🚪 歴代ラスボスの召喚 ' + (G.de || 0) + ' / ' + DK_ECHO.length) : '💠 核 ' + (G.dc == null ? 6 : G.dc) + ' / 6　（放射弾をスキルで跳ね返すと砕ける）';
        return '';
    }

    // 大討伐戦のボスの強さの基準：パーティの中でいちばんステータス合計が高い人に合わせる（平均ではない）。ソロなら自分の合計
    function raidTotal() { let m = corrTotal(); Object.keys(allies).forEach(id => { if (allies[id].tt > m) m = allies[id].tt; }); return m; }
    function raidBossStats(b) {
        const mul = stage.raidMul || RAID_MUL, S = Math.round(raidTotal() * corrMul(AMB_ON ? AMB_FLOOR : RAID_REF_FLOOR) * 1.9 * 1.35 * mul), st = enemyStats(b.def, true, false, S);
        b.maxHp = b.hp = st.maxHp; b.dmg = st.dmg; b.spd = st.spd; b.takeMul = 1; b.dmgMul = 1; b.sh = [1, 1, 1, 1, 1];
        window.__raidDbg = { total: raidTotal(), S: S, hp: st.maxHp, dmg: st.dmg, ps: partyScale(), refHp: REF_HP };      // 調整用（コンソールで確認できる）
    }
    function startBoss() {
        if (PVP && run.ghostMode) { startGhost(); return; }      // アリーナにひとりで入った：ゴースト戦
        run.bossSpawned = true; G = {};
        if (window.SBSound) { SBSound.sfx('boss'); SBSound.bgm(RAID ? 'raid' : (RUSH_ON ? 'rush' : 'boss'), stage.id + ':boss'); }      // ボスの曲（ステージごとに違う）
        enemies.forEach(e => { if (!e.boss) { e.hp = 0; fx.push({ k: 'puff', x: e.x, y: e.y, t: 0.3, life: 0.3, c: '#aaa' }); } });
        enemies = enemies.filter(e => e.hp > 0);
        if (RAID || AMB_ON) { DU = {}; applyScale(Math.round(raidTotal()), AMB_ON ? 30 : 46, { hp: 1, dmg: 1, spd: Math.min(1.3, 1 + (AMB_ON ? AMB_FLOOR : RAID_REF_FLOOR) * 0.005) }); SC.hpMul = 1; }      // 基準はパーティでいちばん高いステータス合計（raidTotal）。ボスの強さは raidBossStats が「合計ステータス」から決める（無限回廊と同じ）
        const defs = stage.bosses || [stage.boss];
        defs.forEach((bd, i) => {
            const b = spawnEnemy({ name: bd.name, icon: bd.icon, arch: 'chaser', color: bd.color }, WORLD_W / 2 + (bd.dx || 0), RAID ? WORLD_H * 0.28 : WORLD_H / 2 - 200, true);
            b.spd = 78 * (1 + SC.ilvl * 0.012) * PW.spd;
            b.bd = bd; b.pairIdx = i; if (RAID) b.r = 78; if (AMB_ON) b.r = 58;
            if (RAID || AMB_ON) raidBossStats(b);
            if (GMK === 'ambush') { b.arch = 'ningen'; b.def.arch = 'ningen'; b.atkT = 2.5; b.comboN = 0; }      // ニンゲンの王・ヒューマニア
            if (GMK === 'increase') { b.arch = 'slime'; b.def.arch = 'slime'; b.gen = 0; b.hopT = 0; b.r = 86; G.n = 1; }      // 増殖スライム：はねて動く
            if (GMK === 'necro') { b.arch = 'necro'; b.def.arch = 'necro'; b.r = 70; b.sumT = 1.0; b.atkT = 3; G.nm = 0; G.zb = 0; }      // ネクロマンスド・シャーマン
            if (GMK === 'machine') { b.arch = 'machine'; b.def.arch = 'machine'; b.r = 90; b.x = WORLD_W / 2; b.y = WORLD_H * 0.35; machineInit(b); }      // 機械真王・リレインバー
            if (GMK === 'worm') { b.x = WM.cx; b.y = WM.cy - 240; b.r = 74; b.def.arch = 'chaser'; }      // ワールドワーム：足場の中央に現れる
            if (bd.set) b.bset = (BM && BM.SETS && BM.SETS[bd.set]) || null;
            if (bd.hp) b.maxHp = b.hp = Math.round(b.maxHp * bd.hp);       // ニコイチのボスは1体ぶんのHPを少なめにする
            if (DBG && DBG.hp > 0) b.maxHp = b.hp = Math.max(1, Math.round(b.maxHp * DBG.hp));
            if (GMK === 'worm') wormInit(b);
            if (GMK === 'velzark') { b.vz = bd.vz; if (bd.vz === 'z') { b.spd *= 2.3; b.r = 72; } else b.r = 66; b.t = -1.5 - i * 0.6; }      // ヴェルス（天使）とザーク（悪魔）。ザークは超インファイトなので足が速い
        });
        netAnnounce('⚠ ' + defs.map(d => d.name).join(' と ') + ' が現れた！', 2600);
        if (GMK === 'stigma') setTimeout(() => netAnnounce('☠ 10秒ごとに「スティグマ」が刻まれる…13個たまると死ぬ！', 3200), 2700);
    }

    function finishHost(win, reason) {
        const d = { win: win, reason: reason || '' };
        netSend('end', d);
        finish(win, d);
    }

    // ---------- スナップショット ----------
    // 近い順に n 個だけ残す（弾・予告が多すぎて、サーバーの中継の大きさの上限を超えると、仲間の画面が止まって見えるため）
    function nearestN(arr, n, xi, yi) {
        if (arr.length <= n) return arr;
        const ps = alivePlayersPos(); if (!ps.length) return arr.slice(0, n);
        const key = a => { let m = 1e12; for (const q of ps) { const d = (a[xi] - q.x) * (a[xi] - q.x) + (a[yi] - q.y) * (a[yi] - q.y); if (d < m) m = d; } return m; };
        return arr.map(a => [key(a), a]).sort((p, q) => p[0] - q[0]).slice(0, n).map(p => p[1]);
    }
    function makeSnap() {
        const m = makeSnap0();
        let nb = 150, nt = 50, len = JSON.stringify(m).length;
        while (len > 16000 && nb > 20) {      // 大きすぎるときは、遠くの弾・予告から切り捨てる
            nb = Math.floor(nb * 0.7); nt = Math.max(16, Math.floor(nt * 0.8));
            m.b = nearestN(m.b, nb, 1, 2); m.t = nearestN(m.t, nt, 1, 2); len = JSON.stringify(m).length;
        }
        if (m.b.length > nb) m.b = nearestN(m.b, nb, 1, 2);
        m.q = ++snapSeq; m.ht = Math.round(performance.now()); snapBytes = len;      // ht：ホスト側で作った時刻（受け取る側が、届く間隔のばらつきに惑わされず速度を出せるように）
        return m;
    }
    function makeSnap0() {
        const fullRows = ((snapSeq + 1) % 16) === 0;      // 16回に1回は、全員ぶんの名前・絵文字・色を送る（途中から入った人・取りこぼした人のため）
        return {
            e: enemies.map(e => { const fl = ((e.sn = (e.sn || 0) + 1) <= 4) || fullRows; return [e.id, fl ? e.def.icon : 0, fl ? e.def.color : 0, Math.round(e.x), Math.round(e.y), Math.round(e.hp), e.maxHp, e.r, e.boss ? 1 : 0, e.state, fl ? e.def.name : 0, fl ? (e.arch || 'chaser') : 0, e.elite ? 1 : 0, e.dmgMul || 1, Math.round(e.air || 0), (e.inv ? 1 : 0) | (e.echo ? 2 : 0) | (e.boss && !e.echo && bdef(e).gate ? 4 : 0) | (e.valve ? 8 : 0), e.ma > 0 ? [e.ma, Math.round(e.mt * 100), Math.round((e.maim || 0) * 100), e.mk | 0, e.mn | 0, Math.round(e.mL || 0)] : 0]; }),
            b: eBullets.map(b => [b.id, Math.round(b.x), Math.round(b.y), b.r, b.c, b.kd || 0, b.kd ? +Math.atan2(b.vy, b.vx).toFixed(2) : 0, b.refl || 0]),
            t: telegraphs.map(t => [t.id, t.x, t.y, t.r, +t.t.toFixed(2), t.max, t.c, t.sh || '', t.a != null ? +t.a.toFixed(2) : 0, t.arc != null ? +t.arc.toFixed(2) : 0, t.ri || 0, t.w || 0, t.stun ? 1 : 0, t.live ? 1 : 0]),
            k: run.kills, n: run.need, tm: Math.round(run.time), bs: run.bossSpawned ? 1 : 0, g: G,
            rs: RUSH_ON ? [RS.ph, RS.st, Math.round(RS.limit - RS.t), Math.round(RS.inter)] : 0,
            cf: CORR_ON && CF.rc ? [CF.floor, CF.seed, CF.inBoss ? 1 : 0, CF.portalIdx, CF.exit ? 1 : 0] : 0
        };
    }
    function applySnap(s) {
        if (s.q != null) { if (s.q <= lastSnapQ && s.q > lastSnapQ - 50) return; lastSnapQ = s.q; }      // 古い・順番が入れ替わったスナップショットは捨てる
        const nowS = performance.now(), dtS = clamp((nowS - (lastSnapAt || nowS - 80)) / 1000, 0.03, 0.4); lastSnapAt = nowS; snapAge = 0;
        const dtH = (s.ht != null && lastHt != null) ? clamp((s.ht - lastHt) / 1000, 0.03, 0.4) : dtS; if (s.ht != null) lastHt = s.ht;
        { const iv = dtH * 1000; ivEma += (iv - ivEma) * 0.1; if (lastArriveS) jitEma += (Math.abs((nowS - lastArriveS) - iv) - jitEma) * 0.1; lastArriveS = nowS; interpMs = clamp(ivEma * 1.6 + jitEma * 2.5 + 15, 100, 330); }      // 間隔が広い（人数が多くて送る回数が減った）・届き方がばらつくときは、遅れを大きくして、止まらないようにする
        const htS = (s.ht != null) ? s.ht : nowS;      // ホスト時刻（古い版のホストとつないだときは、受け取った時刻で代用）
        if (snapHtLast != null && (htS < snapHtLast - 1500 || htS - snapHtLast > 8000)) { rT = null; enemies.forEach(e => { e.hist = null; }); eBullets.forEach(b => { b.hist = null; }); }      // ホストが替わった（時計が別になった）
        snapHtLast = htS; snapArrive = nowS;      // 速度は、ホストが作った間隔で割る
        run.kills = s.k; run.need = s.n; run.time = s.tm; if (s.bs && !run.bossSpawned) run.bossSpawned = true;
        if (RUSH_ON && s.rs) {      // ボスラッシュ：フェーズが進んだら、敵の強さの基準を合わせ、幕間に入ったら回復する
            const prevSt = RS.st, prevPh = RS.ph;
            RS.ph = s.rs[0]; RS.st = s.rs[1]; RS.t = RS.limit - s.rs[2]; RS.inter = s.rs[3];
            if (RS.ph !== prevPh && RS.ph > 0) { const pd = rushPd(RS.ph); applyScale(pd.req, pd.ilvl, pd.pw); SC.dmgMul = pd.final ? 1 : RUSHD.perBossDmg; if (prevPh > 0) { me.inv = Math.max(me.inv, 3); me.invHard = Math.max(me.invHard || 0, 3); } RS.limit = (DIFF.phaseMin || 10) * 60; RS.t = RS.limit - s.rs[2]; }
            if (RS.st === 2 && prevSt !== 2) rushLocalInter();
        }
        if (CORR_ON && s.cf) corrSync(s.cf);
        gmApplySnap(s.g);
        const dmgMemo = {};      // foeDmg は同じ引数なら同じ値：敵ごと・弾ごとに毎回計算しない
        const fdm = (arch, boss, elite) => { const k = arch + (boss ? 'b' : '') + (elite ? 'e' : ''); return k in dmgMemo ? dmgMemo[k] : (dmgMemo[k] = foeDmg(arch, boss, elite)); };
        const old = {}; enemies.forEach(e => { old[e.id] = e; });
        enemies = s.e.map(a => {
            let ic = a[1], co = a[2], nm = a[10], ar = a[11];      // 0 のときは省略されている：前に受け取ったものを使う
            if (ic === 0) { const sc = snapStat[a[0]]; if (sc) { ic = sc[0]; co = sc[1]; nm = sc[2]; ar = sc[3]; } else { ic = '👾'; co = '#9aa6b8'; nm = ''; ar = 'chaser'; } } else snapStat[a[0]] = [ic, co, nm, ar];
            const o = old[a[0]] || { x: a[3], y: a[4], flash: 0 };
            let evx = 0, evy = 0; if (o.sx != null) { evx = clamp((a[3] - o.sx) / dtH, -1400, 1400); evy = clamp((a[4] - o.sy) / dtH, -1400, 1400); if (o.vx != null) { evx = o.vx * 0.4 + evx * 0.6; evy = o.vy * 0.4 + evy * 0.6; } if (Math.hypot(a[3] - o.sx, a[4] - o.sy) > 380) { evx = evy = 0; o.x = a[3]; o.y = a[4]; } }      // 前の位置との差から速度を求めて、次が届くまで先読みする。瞬間移動は補間しない
            return { id: a[0], def: { icon: ic, color: co, name: nm }, x: o.x, y: o.y, tx: a[3], ty: a[4], sx: a[3], sy: a[4], vx: evx, vy: evy, hist: pushHist(o.hist, a[3], a[4], htS), hp: a[5], maxHp: a[6], r: a[7], boss: !!a[8], state: a[9], flash: o.flash || 0, st: { stunT: 0 }, arch: ar || 'chaser', elite: !!a[12], dmg: fdm(ar || 'chaser', !!a[8], !!a[12]), dmgMul: a[13] || 1, air: a[14] || 0, inv: !!((a[15] || 0) & 1), echo: !!((a[15] || 0) & 2), gate: !!((a[15] || 0) & 4), valve: !!((a[15] || 0) & 8), noContact: !!((a[15] || 0) & 8), ma: a[16] ? a[16][0] : 0, mt: a[16] ? a[16][1] / 100 : 0, maim: a[16] ? a[16][2] / 100 : 0, mk: a[16] ? a[16][3] : 0, mn: a[16] ? a[16][4] : 0, mL: a[16] ? a[16][5] : 0, mrx: nowS };
        });
        if (Object.keys(snapStat).length > enemies.length + 160) { const keep = {}; enemies.forEach(e => { if (snapStat[e.id]) keep[e.id] = snapStat[e.id]; }); snapStat = keep; }
        const oldB = {}; eBullets.forEach(x => { oldB[x.id] = x; });
        eBullets = s.b.map(a => { const o = oldB[a[0]]; const bvx = o && o.sx != null ? clamp((a[1] - o.sx) / dtH, -1800, 1800) : 0, bvy = o && o.sx != null ? clamp((a[2] - o.sy) / dtH, -1800, 1800) : 0; return { id: a[0], x: o ? o.x : a[1], y: o ? o.y : a[2], tx: a[1], ty: a[2], sx: a[1], sy: a[2], vx: bvx, vy: bvy, hist: pushHist(o && o.hist, a[1], a[2], htS), r: a[3], c: a[4], kd: a[5] || 0, ang: a[6] || 0, refl: a[7] || 0, dmg: 0, dm: 0 }; });
        // クライアント側の弾はダメージ値を持たないので、ホストが送った値で最小限の被弾を行う（体当たり相当）
        telegraphs = s.t.map(a => ({ id: a[0], x: a[1], y: a[2], r: a[3], t: a[4], max: a[5], c: a[6], sh: a[7] || null, a: a[8], arc: a[9], ri: a[10], w: a[11], stun: !!a[12], live: !!a[13] }));
        const bulletDmg = fdm('ranged', false, false); for (let i = 0; i < eBullets.length; i++) eBullets[i].dmg = bulletDmg;
    }
    // <interp-start>
    //  ホスト以外の画面：ホストから届く敵・弾の位置を、少し（INTERP_MS）遅らせて、届いた位置と位置のあいだを時刻で補間して描く。
    //  通信の遅れにばらつきがあっても、動きが等速で滑らかに見える（以前は、最新の位置を追いかけていたので、届くのが遅れるたびにカクついた）
    const INTERP_MS = 110;
    let interpMs = INTERP_MS, ivEma = 62, jitEma = 8, lastArriveS = 0, snapStat = {};      // interpMs：いまの補間の遅れ（スナップショットの間隔と、届くばらつきに合わせて100〜330ms）／snapStat：敵の名前・絵文字・色（ホストが省略した分を補う）
    let rT = null, snapHtLast = null, snapArrive = 0;      // rT：いま描いている時刻（ホスト時計）
    function pushHist(h, x, y, t) {      // 直近5つの位置を持つ（配列とオブジェクトを使い回して、毎回作り直さない）
        if (!h) return [{ x: x, y: y, t: t }];
        const l = h[h.length - 1];
        if (l) { if (t <= l.t) return h; if (Math.hypot(x - l.x, y - l.y) > 380) h.length = 0; }      // 古い・同時刻の位置は捨てる。大きく飛んだら、補間せずそこへ移る
        const o = h.length >= 5 ? h.shift() : {}; o.x = x; o.y = y; o.t = t; h.push(o); return h;
    }
    function histPos(h, t, out) {
        const n = h ? h.length : 0; if (!n) return false;
        if (n === 1 || t <= h[0].t) { out.x = h[0].x; out.y = h[0].y; return true; }
        const L = h[n - 1];
        if (t >= L.t) { const P = h[n - 2], u = Math.min(1.35, (t - P.t) / ((L.t - P.t) || 1)); out.x = P.x + (L.x - P.x) * u; out.y = P.y + (L.y - P.y) * u; return true; }      // 次の位置が遅れているときは、同じ向きに少しだけ進める
        for (let i = n - 1; i > 0; i--) { const A = h[i - 1], B = h[i]; if (t >= A.t) { const u = (t - A.t) / ((B.t - A.t) || 1); out.x = A.x + (B.x - A.x) * u; out.y = A.y + (B.y - A.y) * u; return true; } }
        out.x = h[0].x; out.y = h[0].y; return true;
    }
    function interpTime(dt, nowMs) {
        const target = snapHtLast - interpMs + (nowMs - snapArrive);
        if (rT == null) rT = target; else { rT += dt * 1000; rT += (target - rT) * Math.min(1, dt * 4); }      // 時計は実時間どおり進め、ずれはゆっくり直す（急に変えない）
        rT = clamp(rT, snapHtLast - 500, snapHtLast + 60);
        return rT;
    }
    // <interp-end>
    const interpTmp = { x: 0, y: 0 };
    function lerpRemote(dt) {
        snapAge += dt;
        if (snapHtLast != null) {
            const t = interpTime(dt, performance.now());
            enemies.forEach(e => { if (histPos(e.hist, t, interpTmp)) { e.x = interpTmp.x; e.y = interpTmp.y; } });
            eBullets.forEach(b => { if (histPos(b.hist, t, interpTmp)) { b.x = interpTmp.x; b.y = interpTmp.y; } });
            return;
        }
        // まだスナップショットが届いていない間：これまでどおり、目標位置を追いかける
        const ext = snapAge < 0.25, k = 1 - Math.exp(-dt * 24);
        enemies.forEach(e => { if (e.tx != null) { if (ext && e.vx) { e.tx += e.vx * dt; e.ty += e.vy * dt; } e.x += (e.tx - e.x) * k; e.y += (e.ty - e.y) * k; } });
        eBullets.forEach(b => { if (b.tx != null) { if (ext && b.vx) { b.tx += b.vx * dt; b.ty += b.vy * dt; } b.x += (b.tx - b.x) * k; b.y += (b.ty - b.y) * k; } });
    }



    // ================= アクセサリー =================
    //  装備しているアクセサリーのスキルが、条件を満たすたびに自動で発動する（範囲攻撃が中心）。対人戦では使わない。
    //  データと発動条件は accessories.js、ここは「効果の中身」と「いつ呼ぶか」
    const accSlots = (!PVP && window.SBAcc) ? SBAcc.equippedList(hack).filter(Boolean).map(a => ({ a: a, b: SBAcc.baseOf(a), cd: 1.2 + Math.random() * 1.5, kills: 0 })).filter(x => x.b) : [];
    let accBusy = false;
    function accDmg(mult) { return weapon.dmg * P.atkMul * atkDyn() * mult * SKILL_MUL() * (me.empowerT > 0 ? 1.15 : 1) * (AB('guts') && me.hp <= 1.5 ? 3 : 1); }
    function accNear(r) { for (const e of enemies) if (e.hp > 0 && e.act !== false && dist(me.x, me.y, e.x, e.y) < r + e.r) return true; return false; }
    function accHitAll(x, y, r, base, eff) { enemies.forEach(e => { if (e.hp > 0 && dist(x, y, e.x, e.y) <= r + e.r) skillHit(e, base, true, eff, 0); }); }
    function accLater(sec, fn) { setTimeout(() => { if (run.phase !== 'run' || me.dead) return; const was = accBusy; accBusy = true; try { fn(); } finally { accBusy = was; } }, sec * 1000); }
    function accBurstFx(x, y, r, col, fill) {
        fx.push({ k: 'ring', x: x, y: y, r: 0, max: r, t: 0.4, life: 0.4, c: col, fill: !!fill });
        if (fx.length < 420) for (let i = 0; i < 12; i++) { const a = Math.random() * Math.PI * 2, v = 100 + Math.random() * 300; fx.push({ k: 'spark', x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, sz: 2.5 + Math.random() * 3, t: 0.35 + Math.random() * 0.25, life: 0.6, c: Math.random() < 0.4 ? '#fff' : col }); }
    }
    function accBolt(x1, y1, x2, y2, col, w) {      // 稲妻（ぎざぎざの線）
        const pts = [[x1, y1]], n = Math.max(3, Math.round(dist(x1, y1, x2, y2) / 34)), nx = -(y2 - y1), ny = x2 - x1, nl = Math.hypot(nx, ny) || 1;
        for (let i = 1; i < n; i++) { const t = i / n, j = (Math.random() - 0.5) * 34; pts.push([x1 + (x2 - x1) * t + nx / nl * j, y1 + (y2 - y1) * t + ny / nl * j]); }
        pts.push([x2, y2]); fx.push({ k: 'bolt', pts: pts, c: col, w: w || 4, t: 0.18, life: 0.18 });
    }
    function accTargets(range) {      // 近い順の敵
        return enemies.filter(e => e.hp > 0 && e.act !== false && dist(me.x, me.y, e.x, e.y) < range).sort((a, b) => dist(me.x, me.y, a.x, a.y) - dist(me.x, me.y, b.x, b.y));
    }
    function accFire(s) {
        const a = s.a, f = s.b.fx, pw = a.pw || 1, base = accDmg(f.mult * pw), eff = (f.eff || []).slice(), col = f.col || '#fff';
        popups.push({ x: me.x, y: me.y - 52, t: 0.9, text: s.b.icon + ' ' + s.b.name, c: col });
        const was = accBusy; accBusy = true;
        try {
            if (f.kind === 'nova') {
                accBurstFx(me.x, me.y, f.r, col, true); accHitAll(me.x, me.y, f.r, base, eff); addShake(2.5, 0.12);
            } else if (f.kind === 'chain') {
                const hit = {}; let from = { x: me.x, y: me.y }, list = accTargets(f.range + 200);
                for (let i = 0; i < f.n; i++) {
                    const e = list.filter(x => !hit[x.id]).sort((p, q) => dist(from.x, from.y, p.x, p.y) - dist(from.x, from.y, q.x, q.y))[0];
                    if (!e || dist(from.x, from.y, e.x, e.y) > f.range) break;
                    hit[e.id] = 1; accBolt(from.x, from.y, e.x, e.y, col, 4); fx.push({ k: 'ring', x: e.x, y: e.y, r: 0, max: 46, t: 0.25, life: 0.25, c: col });
                    skillHit(e, base * (1 - i * 0.05), true, eff, 0); from = { x: e.x, y: e.y };
                }
            } else if (f.kind === 'meteor') {
                const ts = accTargets(760); const pts = [];
                for (let i = 0; i < f.n; i++) { const e = ts.length ? ts[Math.floor(Math.random() * Math.min(ts.length, 12))] : null; pts.push(e ? { x: e.x + (Math.random() - 0.5) * 50, y: e.y + (Math.random() - 0.5) * 50 } : { x: me.x + (Math.random() - 0.5) * 520, y: me.y + (Math.random() - 0.5) * 520 }); }
                pts.forEach((q, i) => {
                    fx.push({ k: 'ring', x: q.x, y: q.y, r: f.r * 0.4, max: f.r, t: 0.45 + i * 0.1, life: 0.45 + i * 0.1, c: col });
                    accLater(0.45 + i * 0.1, () => { accBolt(q.x - 90, q.y - 520, q.x, q.y, col, 7); accBurstFx(q.x, q.y, f.r, col, true); accHitAll(q.x, q.y, f.r, base, eff); addShake(2, 0.1); });
                });
            } else if (f.kind === 'spin') {
                for (let i = 0; i < f.ticks; i++) accLater(i * f.gap, () => { accBurstFx(me.x, me.y, f.r, col, false); accHitAll(me.x, me.y, f.r, base, eff); });
            } else if (f.kind === 'quake') {
                for (let i = 0; i < f.rings; i++) accLater(i * 0.28, () => { const r = f.r * (0.55 + 0.45 * (i + 1) / f.rings); accBurstFx(me.x, me.y, r, col, true); accHitAll(me.x, me.y, r, base, eff); addShake(4, 0.18); });
            } else if (f.kind === 'radial') {
                const off = Math.random() * 6.28;
                for (let i = 0; i < f.n; i++) { const ang = off + i * Math.PI * 2 / f.n; myShots.push({ x: me.x, y: me.y, vx: Math.cos(ang) * f.speed, vy: Math.sin(ang) * f.speed, r: 8, life: 0.9, pierce: f.pierce || 0, hit: {}, homing: false, c: col, skill: { base: base, hasDmg: true, eff: eff } }); }
                fx.push({ k: 'ring', x: me.x, y: me.y, r: 0, max: 90, t: 0.25, life: 0.25, c: col });
            } else if (f.kind === 'blackhole') {
                const ts = accTargets(520), c = ts.length ? { x: ts[0].x, y: ts[0].y } : { x: me.x + Math.cos(me.ang) * 200, y: me.y + Math.sin(me.ang) * 200 }, ticks = Math.round(f.dur / 0.25);
                for (let i = 0; i < ticks; i++) accLater(i * 0.25, () => {
                    fx.push({ k: 'ring', x: c.x, y: c.y, r: f.r, max: 20, t: 0.25, life: 0.25, c: col });
                    enemies.forEach(e => { if (e.hp > 0 && dist(c.x, c.y, e.x, e.y) <= f.r + e.r) { const an = Math.atan2(c.y - e.y, c.x - e.x); dealHit(e, Math.round(base), { kx: Math.cos(an) * 300 * (e.boss ? 0.3 : 1), ky: Math.sin(an) * 300 * (e.boss ? 0.3 : 1) }); } });
                });
            } else if (f.kind === 'heal') {
                healMe(me.maxHp * f.pct); accBurstFx(me.x, me.y, f.r, col, true); accHitAll(me.x, me.y, f.r, base, eff); addShake(3, 0.15);
            } else if (f.kind === 'rain') {
                for (let i = 0; i < f.n; i++) { const q = { x: me.x + (Math.random() - 0.5) * f.spread * 2, y: me.y + (Math.random() - 0.5) * f.spread * 2 }, dl = Math.random() * 0.9; fx.push({ k: 'ring', x: q.x, y: q.y, r: 40, max: 8, t: 0.3 + dl, life: 0.3 + dl, c: col }); accLater(0.3 + dl, () => { accBolt(q.x + 30, q.y - 380, q.x, q.y, col, 3); accBurstFx(q.x, q.y, 64, col, true); accHitAll(q.x, q.y, 64, base, eff); }); }
            } else if (f.kind === 'beam') {
                const off = Math.random() * 6.28;
                for (let i = 0; i < f.n; i++) {
                    const an = off + i * Math.PI * 2 / f.n, x2 = me.x + Math.cos(an) * f.len, y2 = me.y + Math.sin(an) * f.len;
                    const d = { f: 'laser', x: me.x, y: me.y, a: an, len: f.len, w: f.w }; skillFx(d); netSend('sk', d);
                    enemies.forEach(e => { if (e.hp > 0 && distSeg(e.x, e.y, me.x, me.y, x2, y2) <= f.w / 2 + e.r) skillHit(e, base, true, eff, an); });
                }
            } else if (f.kind === 'shield') {
                me.barrierHp = (me.barrierHp || 0) + Math.max(10, Math.round(me.maxHp * f.pct)); popups.push({ x: me.x, y: me.y - 46, t: 0.9, text: 'バリア', c: '#7fc8ff' });
                accBurstFx(me.x, me.y, f.r, col, true); accHitAll(me.x, me.y, f.r, base, eff); addShake(3, 0.15);
                if (f.spinR) for (let i = 1; i <= 6; i++) accLater(i * 0.25, () => { accBurstFx(me.x, me.y, f.spinR, col, false); accHitAll(me.x, me.y, f.spinR, base * 0.6, eff); });
            }
        } finally { accBusy = was; }
    }
    function accTick(dt) {
        if (!accSlots.length || me.dead || run.phase !== 'run' || me.stunT > 0) return;
        for (const s of accSlots) {
            if (s.cd > 0) { s.cd -= dt; continue; }
            const t = s.b.trig;
            if (t.t === 'timer') { if (accNear(720)) { accFire(s); s.cd = SBAcc.cdOf(s.a); } }
            else if (t.t === 'lowhp') { if (me.hp > 0 && me.hp / me.maxHp < t.hp) { accFire(s); s.cd = SBAcc.cdOf(s.a); } }
        }
    }
    function accEvent(type) {
        if (!accSlots.length || accBusy || me.dead || run.phase !== 'run') return;
        for (const s of accSlots) {
            const t = s.b.trig; if (t.t !== type) continue;
            if (type === 'kills') { s.kills++; if (s.kills >= t.n) { s.kills = 0; accFire(s); } continue; }
            if (s.cd > 0) continue;
            if (t.chance && Math.random() > t.chance) continue;
            accFire(s); s.cd = SBAcc.cdOf(s.a);
        }
    }
    // アクセサリーのドロップ（手に入れたものは、無限回廊では袋に入る）
    function rollAcc(luck, minR, x, y) {
        if (!window.SBAcc || PVP) return;
        const a = SBAcc.roll({ ilvl: L().ilvl, luck: luck, minRarity: minR, source: L().id });
        if (CORR_ON) BAG.accs.push(a); else { const d = hwLoad(); SBAcc.ensure(d); d.accs.push(a); hwSave(d); }
        run.stats.accs = run.stats.accs || []; run.stats.accs.push(a);
        const R = HW.rarityOf(a);
        popups.push({ x: x, y: y - 20, t: 1.6, text: '✨ ' + a.name, c: R.color, big: true });
        fx.push({ k: 'ring', x: x, y: y, r: 0, max: 70, t: 0.5, life: 0.5, c: R.color });
    }

    // ================= ボスラッシュ =================
    //  フェーズ1〜5＝第N世界のボスから4体が選ばれて同時に出る（第四世界のボス並に強化。進むごとにさらに強く）。Final＝強化ディメンション・キーパー。
    //  フェーズごとに制限時間があり、ボスを全員倒すと幕間（回復）のあと次のフェーズへ。ホストだけが進行を動かし、クライアントはスナップショットで追いかける。
    function rushPd(n) { return RUSHD.phases[Math.max(1, Math.min(RUSHD.phases.length, n)) - 1]; }
    function shuffled(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
    function rushStartPhase(n) {
        const pd = rushPd(n);
        RS.ph = n; RS.st = 1; RS.t = 0; RS.limit = (DIFF.phaseMin || 10) * 60; RS.inter = 0;
        applyScale(pd.req, pd.ilvl, pd.pw); SC.hpMul = pd.final ? 2.4 : RUSHD.perBossHp; SC.dmgMul = pd.final ? 1 : RUSHD.perBossDmg;
        me.inv = Math.max(me.inv, 3); me.invHard = Math.max(me.invHard || 0, 3);      // フェーズの最初の3秒は無敵（登場の瞬間に倒されないように）
        enemies = []; eBullets = []; telegraphs = []; G = {}; myShots = []; ghostShots = []; myBlades = []; ghostBlades = [];
        run.bossSpawned = true; run.bossDead = false;
        if (pd.final) {
            const fb = RUSHD.finalBoss;
            const b = spawnEnemy({ name: fb.name, icon: fb.icon, arch: 'chaser', color: fb.color }, WORLD_W / 2, WORLD_H * 0.3, true);
            b.bd = fb; b.bset = (BM && BM.SETS && BM.SETS[fb.set]) || null; b.rushSrc = 'dimension_end'; b.spd = 70 * (1 + SC.ilvl * 0.012) * PW.spd; b.t = -2.5;
            netAnnounce('🌀 Final　強化されたディメンション・キーパーが現れた！', 3200);
        } else {
            let pool = RUSHD.pool(pd.world); if (!pool.length) pool = RUSHD.pool(1);
            const pick = shuffled(pool).slice(0, RUSHD.bossCount);
            while (pick.length < RUSHD.bossCount) pick.push(pool[pick.length % pool.length]);
            pick.forEach((st, i) => {
                const bd = st.boss, x = WORLD_W * (0.2 + 0.2 * i), y = WORLD_H * (0.22 + (i % 2) * 0.1);
                const b = spawnEnemy({ name: bd.name, icon: bd.icon, arch: 'chaser', color: bd.color }, x, y, true);
                b.bd = bd; b.bset = (BM && BM.SETS && BM.SETS[st.id]) || null; b.rushSrc = st.id; b.spd = 70 * (1 + SC.ilvl * 0.012) * PW.spd; b.pairIdx = i; b.t = -1.6 - i * 1.0;      // 4体が同時に撃ち始めないよう、登場から攻撃までの間をずらす
                if (DBG && DBG.hp > 0) b.maxHp = b.hp = Math.max(1, Math.round(b.maxHp * DBG.hp));
            });
            netAnnounce('🏆 ' + pd.label + '　第' + pd.world + '世界のボス' + RUSHD.bossCount + '体が同時に現れた！', 3200);
        }
        netSend('rsp', { ph: n });
    }
    function rushPhaseClear() {
        RS.st = 2; RS.inter = RUSHD.intermission; eBullets = []; telegraphs = []; G = {};
        netAnnounce('🏆 ' + rushPd(RS.ph).label + ' クリア！　次のフェーズへ…', 2800);
        rushLocalInter();
    }
    // 幕間：倒れていたら復活し、HPを6割まで戻す（ルール上の回復なので、難易度の回復低下は受けない）
    function rushLocalInter() {
        if (me.dead) { me.dead = false; me.stg = 0; me.reviveT = 0; }
        me.hp = Math.max(me.hp, Math.round(me.maxHp * 0.6)); me.inv = 2; me.invHard = 2; me.stunT = 0; me.energy = Math.max(me.energy, ENERGY_MAX * 0.6);
        myShots = []; ghostShots = []; myBlades = []; ghostBlades = [];
        popups.push({ x: me.x, y: me.y - 34, t: 1.2, text: 'HP回復', c: '#7aff9a', big: true });
    }
    function rushHost(dt) {
        if (RS.ph === 0) { rushStartPhase(1); return; }
        if (RS.st === 1) { RS.t += dt; if (RS.t > RS.limit && !run.ended) { run.ended = true; finishHost(false, 'time'); } }
        else if (RS.st === 2) { RS.inter -= dt; if (RS.inter <= 0 && !run.ended) rushStartPhase(RS.ph + 1); }
    }
    // ボスラッシュの撃破報酬：1体ごとに武器（マジック以上）、フェーズの最後の1体はレア以上を複数。Final は伝説も狙える
    function rushKillReward(ev) {
        const last = ev.rb === 2, rareBonus = A('rarePct') + DIFF.luck + (last ? 1.0 : 0.4) + (ev.fin ? 1.5 : 0) + (ev.ph || 1) * 0.12;
        const coin = Math.round((1 + ev.ilvl * 0.8) * (last ? 40 : 14) * (1 + DIFF.luck * 0.3) * (1 + A('goldPct')));
        run.stats.coins += coin;
        rollMats('boss', ev.x, ev.y);
        if (!last) {
            if (Math.random() < 0.3) rollAcc(rareBonus, 'magic', ev.x + 12, ev.y);
            rollLoot(L().bossDrops, rareBonus, 'magic', ev.x, ev.y, 'rush');
            if (Math.random() < 0.45) rollArmor(rareBonus, 'magic', ev.x, ev.y - 18, 'rush');
            if (Math.random() < 0.4) giveOrb(true);
        } else {
            rollLoot(L().bossDrops, rareBonus, 'rare', ev.x, ev.y, 'rush'); rollLoot(L().bossDrops, rareBonus, 'rare', ev.x + 22, ev.y, 'rush'); rollLoot(L().drops, rareBonus, 'magic', ev.x - 22, ev.y, 'rush');
            rollArmor(rareBonus, 'rare', ev.x, ev.y - 20, 'rush'); if (Math.random() < 0.6) rollArmor(rareBonus, 'rare', ev.x + 18, ev.y - 24, 'rush');
            giveOrb(true); if ((ev.ph || 1) >= 4) giveOrb(true);
            rollAcc(rareBonus, (ev.ph || 1) >= 3 ? 'rare' : 'magic', ev.x - 14, ev.y);      // フェーズの最後のボスは、アクセサリーを必ず落とす
            if (ev.fin) { rollAcc(rareBonus + 1.5, 'epic', ev.x + 26, ev.y); rollAcc(rareBonus + 1.5, 'epic', ev.x - 26, ev.y); rollLoot(L().bossDrops, rareBonus + 1.5, 'epic', ev.x, ev.y + 20, 'rush'); rollLoot(L().bossDrops, rareBonus + 1.5, 'epic', ev.x + 24, ev.y + 20, 'rush'); giveOrb(true); giveOrb(true); }
        }
        if (ev.by === myId) onMyKill();
    }

    // ================= 無限回廊 =================
    //  迷路の階層（ランダム生成）を下へ下へ。敵の強さ＝「自分のステータス合計」×「階層で上がる倍率」。
    //  宝箱（ミミックの罠あり）／ボス部屋の入口（行かなくてもよい）／下への階段。ソロ専用。
    function corrTotal() { return Math.max(250, (base.maxHp || 0) + (base.atk || 0) + (base.def || 0) + (base.speed || 0) + (base.special || 0)); }
    // 敵の強さの基準：マルチのときは、パーティ全員のステータス合計の平均（各自の合計は pos で配られる）
    function corrPartyTotal() {
        const arr = [corrTotal()]; Object.keys(allies).forEach(id => { if (allies[id].tt > 0) arr.push(allies[id].tt); });
        return arr.reduce((a, b) => a + b, 0) / arr.length;
    }
    function corrMul(f) { return 0.85 * Math.pow(1.095, f - 1); }                   // 階層ごとの倍率（敵の合計ステータス ＝ プレイヤーの合計 × この倍率 × 敵の種類の倍率）。1階は0.85倍、約5階で1.2倍、10階で1.9倍、20階で4.7倍、40階で48倍（深いほど急に自分より強くなる）
    function corrIlvl(f) { return Math.min(46, 6 + f * 0.85); }                      // 階層ごとのドロップ・敵のレベル
    function corrScaleFloor(f) { applyScale(corrPartyTotal(), corrIlvl(f), { hp: 1, dmg: 1, spd: Math.min(1.3, 1 + f * 0.005) }); SC.hpMul = 1; }      // 基準はプレイヤーの合計ステータス。敵ごとの強さは spawnEnemy が「合計ステータス」から決める
    function corrPool(il) {      // この階層で出る武器の表（レベルが近い武器）
        const B = (HW.BASES || []).filter(b => b.tier >= il - 10 && b.tier <= il + 3);
        return (B.length ? B : (HW.BASES || []).slice(-12)).map(b => b.id);
    }
    function corrSolid(x, y) {
        if (!CF.on) return false;
        const tx = Math.floor(x / TILE), ty = Math.floor(y / TILE);
        if (tx < 0 || ty < 0 || tx >= CF.tw || ty >= CF.th) return true;
        return CF.solid[ty * CF.tw + tx] === 1;
    }
    function corrLOS(x1, y1, x2, y2) {
        if (!CF.on) return true;
        const d = Math.hypot(x2 - x1, y2 - y1), n = Math.ceil(d / 14);
        for (let i = 1; i < n; i++) { const t = i / n; if (corrSolid(x1 + (x2 - x1) * t, y1 + (y2 - y1) * t)) return false; }
        return true;
    }
    // 円と壁タイルの押し出し（2回まわして、角でも埋まらないようにする）
    function corrPushOut(o, rad) {
        if (!CF.on) return;
        for (let pass = 0; pass < 2; pass++) {
            const tx0 = Math.floor((o.x - rad) / TILE), tx1 = Math.floor((o.x + rad) / TILE), ty0 = Math.floor((o.y - rad) / TILE), ty1 = Math.floor((o.y + rad) / TILE);
            for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
                if (tx < 0 || ty < 0 || tx >= CF.tw || ty >= CF.th || !CF.solid[ty * CF.tw + tx]) continue;
                const rx = tx * TILE, ry = ty * TILE, cx = clamp(o.x, rx, rx + TILE), cy = clamp(o.y, ry, ry + TILE);
                const dx = o.x - cx, dy = o.y - cy, d = Math.hypot(dx, dy);
                if (d >= rad) continue;
                if (d > 0.001) { o.x = cx + dx / d * rad; o.y = cy + dy / d * rad; }
                else {
                    const l = o.x - rx, r2 = rx + TILE - o.x, t = o.y - ry, b = ry + TILE - o.y, m = Math.min(l, r2, t, b);
                    if (m === l) o.x = rx - rad; else if (m === r2) o.x = rx + TILE + rad; else if (m === t) o.y = ry - rad; else o.y = ry + TILE + rad;
                }
            }
        }
    }
    // 深さごとの景色（5階ごとに変わる）と、階層ごとの特性（毎回同じ階層にならないように）
    const CPALS = [      // 床は明るめ、壁はとても暗め（明るさの差を大きくして、同系色でも境目が見えるようにする）。edge は壁のふちの線の色
        { n: '石の回廊', wall: '#0e0a18', hi: 'rgba(190,170,255,0.30)', floor: '#4b4468', edge: 'rgba(210,195,255,0.75)' },
        { n: '凍てつく洞窟', wall: '#0a1622', hi: 'rgba(170,230,255,0.34)', floor: '#46647f', edge: 'rgba(190,240,255,0.8)' },
        { n: '溶岩の洞窟', wall: '#1c0b06', hi: 'rgba(255,170,90,0.36)', floor: '#6a4332', edge: 'rgba(255,190,120,0.8)' },
        { n: '古代遺跡', wall: '#1a1608', hi: 'rgba(255,230,140,0.34)', floor: '#6b6140', edge: 'rgba(255,238,160,0.8)' },
        { n: '深き森', wall: '#07160c', hi: 'rgba(150,255,170,0.32)', floor: '#3f6a4a', edge: 'rgba(170,255,190,0.78)' },
        { n: '虚無の回廊', wall: '#07040f', hi: 'rgba(255,120,230,0.34)', floor: '#3c2c5c', edge: 'rgba(255,150,235,0.8)' }
    ];
    const CTHEMES = [
        { id: 'normal', w: 5, n: '' },
        { id: 'horde', w: 2, n: '大群の階', d: '敵がとても多い。数は多いが、1体ずつは弱い' },
        { id: 'elite', w: 2, n: '精鋭の階', d: '強敵が多い。そのぶん報酬も良い' },
        { id: 'treasure', w: 2, n: '宝物庫の階', d: '宝箱がたくさん。ミミックに注意' },
        { id: 'dark', w: 2, n: '暗闇の階', d: '視界が狭い。仲間と離れすぎないこと' },
        { id: 'swift', w: 2, n: '疾風の階', d: '敵の足がとても速い。止まると囲まれる' },
        { id: 'quiet', w: 1, n: '静寂の階', d: '敵は少なめ。回復の泉が必ずある' }
    ];
    const CAFFIX = [{ id: 'swift', n: '俊足の', i: '💨' }, { id: 'giant', n: '巨躯の', i: '🛡️' }, { id: 'explosive', n: '爆ぜる', i: '💥' }];
    const CDIR = [[0, -1, 1, 4], [1, 0, 2, 8], [0, 1, 4, 1], [-1, 0, 8, 2]];        // [dx, dy, 出口のビット, 向こう側の入口のビット]
    function corrCellOf(x, y) {
        const cx = clamp(Math.floor((x / TILE - 1) / CELL_T), 0, CF.cols - 1), cy = clamp(Math.floor((y / TILE - 1) / CELL_T), 0, CF.rows - 1);
        return cy * CF.cols + cx;
    }
    function corrCenter(c) { return CF.rc[c]; }          // 区画の部屋の中心（px）
    function corrBfs(from) {      // マスごとの、from からの歩数
        const f = new Int16Array(CF.cols * CF.rows).fill(-1), q = [from]; f[from] = 0;
        for (let h = 0; h < q.length; h++) {
            const c = q[h], cx = c % CF.cols, cy = Math.floor(c / CF.cols);
            CDIR.forEach(d => { if (!(CF.open[c] & d[2])) return; const nx = cx + d[0], ny = cy + d[1]; if (nx < 0 || ny < 0 || nx >= CF.cols || ny >= CF.rows) return; const n = ny * CF.cols + nx; if (f[n] < 0) { f[n] = f[c] + 1; q.push(n); } });
        }
        return f;
    }
    function corrWaypoint(e, tgt) {      // 壁ごしにプレイヤーが見えないときは、部屋と通路の道なりに進む
        if (!CF.on || corrLOS(e.x, e.y, tgt.x, tgt.y)) return tgt;
        const ec = corrCellOf(e.x, e.y), tc = corrCellOf(tgt.x, tgt.y);
        if (ec === tc) return corrCenter(ec);
        CF.flows = CF.flows || new Map();
        let f = CF.flows.get(tc); if (!f) { if (CF.flows.size > 6) CF.flows.clear(); f = corrBfs(tc); CF.flows.set(tc, f); }
        const cx = ec % CF.cols, cy = Math.floor(ec / CF.cols); let best = -1, bd = f[ec] < 0 ? 1e9 : f[ec];
        CDIR.forEach(d => { if (!(CF.open[ec] & d[2])) return; const nx = cx + d[0], ny = cy + d[1]; if (nx < 0 || ny < 0 || nx >= CF.cols || ny >= CF.rows) return; const n = ny * CF.cols + nx; if (f[n] >= 0 && f[n] < bd) { bd = f[n]; best = n; } });
        if (best < 0) return tgt;
        const nc = corrCenter(best), bend = CF.bend[Math.min(ec, best) * 4096 + Math.max(ec, best)], own = corrCenter(ec);
        if (corrLOS(e.x, e.y, nc.x, nc.y)) return nc;
        if (bend && corrLOS(e.x, e.y, bend.x, bend.y)) return dist(e.x, e.y, bend.x, bend.y) < 26 ? nc : bend;
        return own;
    }
    function corrWake(e) {       // 眠っている敵が起きる条件：誰かが近い／見える／攻撃を受けた
        if (e.flash > 0) { e.act = true; return true; }
        const ps = alivePlayersPos();
        for (const q of ps) { const d = dist(e.x, e.y, q.x, q.y); if (d < 260 || (d < 640 && corrLOS(e.x, e.y, q.x, q.y))) { e.act = true; return true; } }
        return false;
    }
    // 階層を作る（シードが同じなら同じ迷路になる）
    function corrGen(f, spawn) {
        const rng = seeded((CF.seed + f * 7919) >>> 0), RI = n => Math.floor(rng() * n);
        const cols = Math.min(15, 9 + Math.floor(f / 5)), rows = Math.min(10, 6 + Math.floor(f / 7));
        CF.pal = CPALS[Math.min(CPALS.length - 1, Math.floor((f - 1) / 5))];
        { let tw0 = 0; CTHEMES.forEach(t => { tw0 += t.w; }); let r0 = rng() * tw0, th0 = CTHEMES[0]; for (const t of CTHEMES) { if ((r0 -= t.w) <= 0) { th0 = t; break; } } CF.theme = f < 2 ? CTHEMES[0] : th0; }
        const open = new Uint8Array(cols * rows), vis = new Uint8Array(cols * rows), st = [], idx = (cx, cy) => cy * cols + cx;
        const sy = RI(rows); vis[idx(0, sy)] = 1; st.push([0, sy]);
        while (st.length) {      // 穴掘り法（行き止まりの多い、迷路らしい形になる）
            const cur = st[st.length - 1], nb = CDIR.filter(d => { const nx = cur[0] + d[0], ny = cur[1] + d[1]; return nx >= 0 && ny >= 0 && nx < cols && ny < rows && !vis[idx(nx, ny)]; });
            if (!nb.length) { st.pop(); continue; }
            const d = nb[RI(nb.length)], nx = cur[0] + d[0], ny = cur[1] + d[1];
            open[idx(cur[0], cur[1])] |= d[2]; open[idx(nx, ny)] |= d[3]; vis[idx(nx, ny)] = 1; st.push([nx, ny]);
        }
        for (let i = 0, n = Math.floor(cols * rows * 0.1); i < n; i++) {      // 近道：壁を少し抜く
            const cx = RI(cols), cy = RI(rows), d = CDIR[RI(4)], nx = cx + d[0], ny = cy + d[1];
            if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
            open[idx(cx, cy)] |= d[2]; open[idx(nx, ny)] |= d[3];
        }
        CF.cols = cols; CF.rows = rows; CF.open = open;
        // 壁タイル：区画ごとに部屋（5〜12タイル四方）を1つ作り、つながっている区画どうしを幅4タイルの通路（L字）で結ぶ
        const tw = cols * CELL_T + 2, th = rows * CELL_T + 2, solid = new Uint8Array(tw * th).fill(1);
        const carve = (x0, y0, x1, y1) => { for (let y = Math.max(1, y0); y < Math.min(th - 1, y1); y++) for (let x = Math.max(1, x0); x < Math.min(tw - 1, x1); x++) solid[y * tw + x] = 0; };
        const rc = new Array(cols * rows), big = new Uint8Array(cols * rows), roomR = new Array(cols * rows);
        for (let cy = 0; cy < rows; cy++) for (let cx = 0; cx < cols; cx++) {
            const ox = 1 + cx * CELL_T, oy = 1 + cy * CELL_T, rw = 5 + RI(8), rh = 5 + RI(8);       // 区画の内側は 12 タイル四方（周りに壁の余白）
            const rx = ox + 1 + RI(12 - rw + 1), ry = oy + 1 + RI(12 - rh + 1);
            carve(rx, ry, rx + rw, ry + rh);
            rc[idx(cx, cy)] = { x: (rx + rw / 2) * TILE, y: (ry + rh / 2) * TILE }; roomR[idx(cx, cy)] = { x: rx, y: ry, w: rw, h: rh }; big[idx(cx, cy)] = 1;
        }
        const bend = {};
        for (let cy = 0; cy < rows; cy++) for (let cx = 0; cx < cols; cx++) {
            const a = idx(cx, cy), o = open[a];
            [[2, cx + 1, cy], [4, cx, cy + 1]].forEach(t => {
                if (!(o & t[0])) return; const b = idx(t[1], t[2]);
                const ax = Math.round(rc[a].x / TILE), ay = Math.round(rc[a].y / TILE), bx = Math.round(rc[b].x / TILE), by = Math.round(rc[b].y / TILE);
                carve(Math.min(ax, bx) - 2, ay - 2, Math.max(ax, bx) + 2, ay + 2);       // 横
                carve(bx - 2, Math.min(ay, by) - 2, bx + 2, Math.max(ay, by) + 2);       // 縦
                bend[Math.min(a, b) * 4096 + Math.max(a, b)] = { x: bx * TILE, y: ay * TILE };
            });
        }
        CF.tw = tw; CF.th = th; CF.solid = solid; CF.rc = rc; CF.bend = bend; CF.big = big;
        // 描画用の矩形（横につなげて、縦にも同じ幅のものをつなげる）
        const rects = []; let prev = {};
        for (let ty = 0; ty < th; ty++) {
            const cur = {}; let tx = 0;
            while (tx < tw) {
                if (!solid[ty * tw + tx]) { tx++; continue; }
                let x2 = tx; while (x2 < tw && solid[ty * tw + x2]) x2++;
                const key = tx + ':' + (x2 - tx);
                if (prev[key]) { prev[key][3] += TILE; cur[key] = prev[key]; } else { const r = [tx * TILE, ty * TILE, (x2 - tx) * TILE, TILE]; rects.push(r); cur[key] = r; }
                tx = x2;
            }
            prev = cur;
        }
        CF.rects = rects;
        WORLD_W = tw * TILE; WORLD_H = th * TILE;
        // スタートは左端のマス、階段はそこから最も遠いマス
        const startC = idx(0, sy), dist0 = corrBfs(startC);
        let far = startC; for (let c = 0; c < cols * rows; c++) if (dist0[c] > dist0[far]) far = c;
        const bits = n => (n & 1) + ((n >> 1) & 1) + ((n >> 2) & 1) + ((n >> 3) & 1);
        const dead = []; for (let c = 0; c < cols * rows; c++) if (c !== startC && c !== far && bits(open[c]) === 1 && dist0[c] >= 3) dead.push(c);
        const free = []; for (let c = 0; c < cols * rows; c++) if (c !== startC && c !== far && dist0[c] >= 3) free.push(c);
        const takeCell = () => { const src = dead.length ? dead : free; if (!src.length) return startC; return src.splice(RI(src.length), 1)[0]; };
        const props = [];
        const sc = corrCenter(startC), fc = corrCenter(far);
        const inRoom = c => { const r = roomR[c]; return { x: (r.x + 1 + rng() * (r.w - 2)) * TILE, y: (r.y + 1 + rng() * (r.h - 2)) * TILE }; };
        CF.start = sc; props.push({ k: 'stairs', x: fc.x, y: fc.y, r: 34, c: far });
        { const c = takeCell(), p = inRoom(c); props.push({ k: 'gate', x: p.x, y: p.y, r: 30, c: c }); }       // 脱出ゲート：各階層に1つ。どこかの部屋にある
        const thm = CF.theme.id, nChest = 1 + (rng() < 0.5 ? 1 : 0) + (f % 5 === 0 ? 1 : 0) + (thm === 'treasure' ? 3 : 0) + (thm === 'quiet' ? 1 : 0);
        for (let i = 0; i < nChest; i++) { const c = takeCell(), p = inRoom(c); props.push({ k: 'chest', x: p.x, y: p.y, r: 20, c: c, mimic: f >= 2 && rng() < (thm === 'treasure' ? 0.3 : 0.16) }); }
        // 回復の泉（使い切り）：たまにある。静寂の階では必ずある
        if (f >= 2 && (thm === 'quiet' || rng() < 0.4)) { const c = takeCell(), p = inRoom(c); props.push({ k: 'spring', x: p.x, y: p.y, r: 28, c: c }); }
        // 棘の罠：部屋の中にある。見えている間は、周期的に飛び出す
        { const nTrap = Math.min(14, 3 + Math.floor(f / 2)); for (let i = 0; i < nTrap; i++) { const c = free.length ? free[RI(free.length)] : far, p = inRoom(c); props.push({ k: 'trap', x: p.x, y: p.y, r: 26, c: c, ph: rng() * 3.2 }); } }
        if (f >= 2 && rng() < 0.42) { const c = takeCell(), p = inRoom(c); props.push({ k: 'portal', x: p.x, y: p.y, r: 30, c: c }); }
        CF.props = props; CF.seen = new Uint8Array(cols * rows); CF.flow = null; CF.flowFor = -1;
        CF.mini = document.createElement('canvas'); CF.mini.width = tw; CF.mini.height = th; CF.miniCtx = CF.mini.getContext('2d'); CF.miniDone = new Uint8Array(cols * rows);
        // 敵（グループごとに、スタートから離れたマスへ）。乱数の使い方は全員同じにして（同じ迷路・同じ宝箱になる）、敵を実際に出すのはホストだけ
        const avail = CD.mobs.filter(m => m.from <= f), recent = avail.filter(m => m.from > f - 10);
        const dens = thm === 'horde' ? 1.6 : (thm === 'quiet' ? 0.55 : 1), eliteP = thm === 'elite' ? Math.max(0.45, DIFF.elite * 3) : DIFF.elite;
        const groups = Math.min(34, Math.round((6 + Math.floor(f * 0.5)) * 1.4 * dens)); let planned = 0;
        const put = (def, q, elite) => {
            const ai = Math.floor(rng() * CAFFIX.length), af = elite ? CAFFIX[ai] : null;      // 精鋭には、特性（俊足・巨躯・爆ぜる）がつく。乱数は全員同じように使う
            if (!spawn) return;
            const d2 = af ? Object.assign({}, def, { name: af.n + def.name }) : def, e = spawnEnemy(d2, q.x, q.y, false, elite, corrEnemyTotal(d2, false, elite));
            e.act = false; if (thm === 'swift') e.spd *= 1.25;
            if (af) { e.affix = af.id; if (af.id === 'swift') e.spd *= 1.5; else if (af.id === 'giant') { e.hp = e.maxHp = Math.round(e.maxHp * 1.5); e.r *= 1.25; e.dmg *= 1.15; } }
            pushOutOfRocks(e, e.r);
        };
        for (let g = 0; g < groups && planned < 70; g++) {
            const cands = free.length ? free : [far]; const c = cands[RI(cands.length)];
            const useRecent = recent.length && rng() < 0.6, pool = useRecent ? recent : avail;
            const def = pool[RI(pool.length)] || avail[0];
            const elite = def.arch !== 'swarm' && rng() < eliteP;
            const n = elite ? 1 : Math.round((def.arch === 'swarm' ? 4 + RI(3) : (def.arch === 'tank' ? 1 + RI(2) : (def.arch === 'ranged' ? 2 + RI(2) : 2 + RI(3)))) * 1.4);
            for (let i = 0; i < n; i++) { put(def, inRoom(c), elite); planned++; }
        }
        // モンスターハウス：たまに、部屋ひとつぶんの敵が詰まった部屋と、その奥の宝箱
        if (f >= 4 && rng() < 0.25 && free.length) {
            const c = free[RI(free.length)], def = avail[RI(avail.length)];
            for (let i = 0; i < 14; i++) put(def, inRoom(c), false);
            const p = inRoom(c); props.push({ k: 'chest', x: p.x, y: p.y, r: 20, c: c, mimic: false });
        }
        props.forEach((q, i) => { q.i = i; });      // 添字（宝箱やミミックを、他のプレイヤーに伝えるときの番号）
    }

    function corrPlaceMe() {      // 参加者を、スタート地点の周りに等間隔で並べる（全員が同じ並びで計算する）
        const ids = [myId].concat(Object.keys(allies)).sort(), i = ids.indexOf(myId), a = i / Math.max(1, ids.length) * Math.PI * 2, n = ids.length > 1 ? 34 : 0;
        me.x = CF.start.x + Math.cos(a) * n; me.y = CF.start.y + Math.sin(a) * n; me.dashT = 0; me.inv = Math.max(me.inv, 1.0); pushOutOfRocks(me, me.r);
    }
    function corrNewFloor(f, spawn) {      // spawn=true はホスト（敵を出す）。クライアントは同じ迷路だけ作り、敵はスナップショットで受け取る
        CF.floor = f; CF.on = true; CF.inBoss = false; CF.exit = null; CF.saved = null; CF.gateT = 0; CF.flows = new Map(); CF.portalIdx = -1;
        enemies = []; eBullets = []; telegraphs = []; myShots = []; ghostShots = []; myBlades = []; ghostBlades = []; minions = []; domains = []; fx = []; G = {};
        run.bossSpawned = false;
        corrScaleFloor(f);
        corrGen(f, spawn !== false);
        corrPlaceMe();
        try { if (window.SBAch && !DBG) SBAch.report('corrFloor', f, weapon.type); } catch (e) { /* 実績の記録に失敗してもゲームは続ける */ }
        if (me.dead && !me.escaped) { me.dead = false; me.stg = 0; me.reviveT = 0; me.hp = Math.round(me.maxHp * 0.4); }      // 倒れていた仲間も、次の階層へは連れていける
        if (f > 1 && !me.escaped) { run.stats.floors = f - 1; run.stats.coins += Math.round((1 + corrIlvl(f - 1) * 0.6) * 6 * (1 + A('goldPct'))); addHp(me.maxHp * 0.15); announce('🌀 地下' + f + '階　' + CF.pal.n + (CF.theme.n ? '「' + CF.theme.n + '」' : ''), 2000); if (CF.theme.d) setTimeout(() => { if (CF.floor === f) announce(CF.theme.d, 2600); }, 2100); }
        CF.fade = 0.6;
    }
    function corrDescend() {       // ホスト（ソロ含む）だけが呼ぶ。クライアントは「階段に着いた」とお願いして、スナップショットで追いかける
        if (CF.fade > 0 || !CF.on) return;
        corrNewFloor(CF.floor + 1, true);
    }
    // ホストから届いた階層の状態（スナップショット）に、クライアントが合わせる
    function corrSync(c) {
        if (isHost || run.phase !== 'run') return;
        const f = c[0], seed = c[1], inB = !!c[2], ex = !!c[4];
        if (!inB) {
            if (CF.inBoss) corrLeaveBossLocal();
            if (f !== CF.floor || seed !== CF.seed || !CF.rc) { CF.seed = seed; corrNewFloor(f, false); }
        } else {
            if (!CF.inBoss && CF.rc) corrEnterBossLocal(c[3]);
            CF.exit = ex ? { x: WORLD_W / 2, y: WORLD_H / 2, r: 34 } : null;
        }
    }
    function corrEnterBossLocal(pi) {
        CF.saved = { enemies: enemies, W: WORLD_W, H: WORLD_H, px: 0, py: 0, portal: corrProp(pi) };
        const pr = CF.saved.portal; if (pr) { CF.saved.px = pr.x; CF.saved.py = pr.y; }
        enemies = []; eBullets = []; telegraphs = []; myShots = []; ghostShots = []; myBlades = []; ghostBlades = []; minions = []; domains = []; fx = []; G = {};
        CF.on = false; CF.inBoss = true; CF.exit = null; WORLD_W = 1700; WORLD_H = 1100;
        const ids = [myId].concat(Object.keys(allies)).sort(), i = ids.indexOf(myId);
        me.x = 240; me.y = WORLD_H / 2 + (i - (ids.length - 1) / 2) * 70; me.dashT = 0; me.inv = Math.max(me.inv, 1.2);
        if (me.dead && !me.escaped) { me.dead = false; me.stg = 0; me.reviveT = 0; me.hp = Math.round(me.maxHp * 0.4); }
        run.bossSpawned = true; CF.fade = 0.4;
    }
    function corrLeaveBossLocal() {
        const sv = CF.saved; WORLD_W = sv ? sv.W : WORLD_W; WORLD_H = sv ? sv.H : WORLD_H;
        enemies = sv && isHost ? sv.enemies : []; eBullets = []; telegraphs = []; myShots = []; ghostShots = []; myBlades = []; ghostBlades = []; minions = []; domains = []; fx = []; G = {};
        CF.on = true; CF.inBoss = false; CF.exit = null;
        if (sv && sv.portal) sv.portal.k = 'portal_done';
        CF.saved = null; if (sv) { me.x = sv.px; me.y = sv.py + 48; } me.dashT = 0; me.inv = Math.max(me.inv, 1.0); pushOutOfRocks(me, me.r);
        corrScaleFloor(CF.floor); CF.fade = 0.4; run.bossSpawned = false;
    }
    // 宝箱：武器・防具・特殊アイテムのどれかが出る
    function corrGiveItem(kind, x, y, n) {
        n = n || 1; BAG.items[kind] = (BAG.items[kind] || 0) + n;      // 袋に入れる（脱出するまで保存されない）
        run.stats.items = run.stats.items || {}; run.stats.items[kind] = (run.stats.items[kind] || 0) + n;
        const it = HW.SPECIAL_ITEMS[kind];
        popups.push({ x: x, y: y - 14, t: 1.8, text: it.icon + ' ' + it.name + (n > 1 ? '×' + n : ''), c: it.color, big: true });
        fx.push({ k: 'ring', x: x, y: y, r: 0, max: 56, t: 0.5, life: 0.5, c: it.color });
        refreshLootLog();
    }
    function corrPickItem() { const r = Math.random() * 100; return r < 38 ? 'slot' : (r < 55 ? 'rarity' : 'reroll'); }      // 昇華の結晶がいちばん出にくい
    function corrChestReward(x, y) {
        const f = CF.floor, il = corrIlvl(f), pool = corrPool(il), rb = A('rarePct') + DIFF.luck + Math.min(2, f * 0.03);
        LT = { ilvl: il, id: 'infinite_corridor', mats: stage.mats, drops: pool, bossDrops: pool };
        try {
            const r = Math.random();
            if (r < 0.50) rollLoot(pool, rb, 'magic', x, y, 'chest');
            else if (r < 0.64) rollAcc(rb, 'normal', x, y);              // アクセサリー 14%
            else if (r < 0.80) corrGiveItem(corrPickItem(), x, y, 1);      // 特殊アイテム 16%（以前は36%）
            else rollArmor(rb, 'magic', x, y, 'chest');
            run.stats.coins += Math.round((1 + il * 0.6) * 8 * (1 + A('goldPct')));
        } finally { LT = null; }
    }
    function corrOpenChest(p) {
        p.k = 'open'; CF.st.chests++; netSend('cho', { i: p.i });
        try { if (window.SBAch) SBAch.report('chest', 0); } catch (e) { /* 実績の記録に失敗してもゲームは続ける */ }
        fx.push({ k: 'ring', x: p.x, y: p.y, r: 0, max: 70, t: 0.5, life: 0.5, c: '#ffd84a' });
        corrChestReward(p.x, p.y);
    }
    function corrWakeMimic(p) {
        CF.props = CF.props.filter(q => q !== p); CF.st.mimics++; netSend('cmim', { i: p.i });
        try { if (window.SBAch) SBAch.report('chest', 1); } catch (e) { /* 実績の記録に失敗してもゲームは続ける */ }
        const e = spawnEnemy(CD.mimic, p.x, p.y, false, true, corrEnemyTotal(CD.mimic, false, true, 1.4)); e.mimic = true; e.act = true; e.hp = e.maxHp = Math.round(e.maxHp * 0.9); e.spd *= 1.2;
        pushOutOfRocks(e, e.r);
        popups.push({ x: p.x, y: p.y - 30, t: 1.4, text: 'ミミックだ！', c: '#ff6a5a', big: true });
        fx.push({ k: 'ring', x: p.x, y: p.y, r: 0, max: 90, t: 0.4, life: 0.4, c: '#ff6a5a' });
    }
    // 敵を倒したときの報酬（無限回廊）
    function corrKillReward(ev) {
        const il = ev.ilvl || corrIlvl(CF.floor), rb = A('rarePct') + DIFF.luck + (ev.elite ? 0.5 : 0) + (ev.cm ? 0.6 : 0) + (ev.cb ? 0.8 + ev.cb * 0.08 : 0), luck = A('dropPct');
        run.stats.coins += Math.round((1 + il * 0.6) * (ev.cb ? 30 + ev.cb * 8 : (ev.cm ? 12 : (ev.elite ? 6 : 1))) * (1 + A('goldPct')));
        rollMats(ev.cb ? 'boss' : (ev.elite ? 'elite' : 'mob'), ev.x, ev.y);
        if (ev.cb) {
            const t = ev.cb;      // ボス部屋のボス：特別な報酬（強いボスほど豪華）
            if (t >= 10) giveUnbreakable(ev.x, ev.y);      // 不壊の悪魔だけが落とす、専用の神話武器
            rollLoot(L().bossDrops, rb + 0.8, 'rare', ev.x, ev.y, 'cboss'); rollLoot(L().bossDrops, rb + 1.2, 'epic', ev.x + 24, ev.y, 'cboss');
            if (t >= 6) rollLoot(L().bossDrops, rb + 1.6, 'epic', ev.x - 24, ev.y, 'cboss');
            rollArmor(rb + 0.8, 'rare', ev.x, ev.y - 22, 'cboss');
            rollAcc(rb + 1.0, t >= 6 ? 'epic' : 'rare', ev.x, ev.y + 34); if (t >= 8) rollAcc(rb + 1.4, 'epic', ev.x - 36, ev.y + 34);      // ボスは、アクセサリーを必ず落とす
            corrGiveItem('slot', ev.x - 30, ev.y + 20, t >= 8 ? 2 : 1); if (t >= 4 || Math.random() < 0.5) corrGiveItem('rarity', ev.x, ev.y + 26, t >= 9 ? 2 : 1); corrGiveItem('reroll', ev.x + 30, ev.y + 20, 1);      // ボスの特殊アイテムも控えめに
            giveOrb(true);
        } else if (ev.cm) {
            rollLoot(L().drops, rb, 'rare', ev.x, ev.y, 'mimic'); if (Math.random() < 0.4) rollAcc(rb, 'magic', ev.x - 14, ev.y); if (Math.random() < 0.3) corrGiveItem(corrPickItem(), ev.x + 20, ev.y + 10, 1); if (Math.random() < 0.4) rollArmor(rb, 'magic', ev.x, ev.y - 16, 'mimic');
        } else if (ev.elite) {
            if (Math.random() < 0.55 * (1 + luck)) rollLoot(L().drops, rb, 'magic', ev.x, ev.y, 'elite');
            if (Math.random() < 0.22 * (1 + luck)) rollArmor(rb, 'magic', ev.x, ev.y - 16, 'elite');
            if (Math.random() < 0.06 * (1 + luck)) rollAcc(rb, 'normal', ev.x + 12, ev.y);
            if (Math.random() < 0.04) corrGiveItem(corrPickItem(), ev.x + 16, ev.y + 8, 1);
            if (Math.random() < 0.22 * (1 + A('orbPct'))) giveOrb(false);
        } else {
            if (Math.random() < 0.07 * (1 + luck)) rollLoot(L().drops, rb, 'normal', ev.x, ev.y, 'mob');
            if (Math.random() < 0.025 * (1 + luck)) rollArmor(rb, 'normal', ev.x, ev.y - 12, 'mob');
            if (Math.random() < 0.006 * (1 + luck)) rollAcc(rb, 'normal', ev.x + 10, ev.y);
            if (Math.random() < 0.035 * (1 + A('orbPct'))) giveOrb(false);
        }
        if (ev.by === myId) {
            onMyKill();
            if (!me.dead && Math.random() < (ev.elite || ev.cb || ev.cm ? 0.5 : 0.09)) { addHp(me.maxHp * (ev.elite || ev.cb || ev.cm ? 0.2 : 0.1)); popups.push({ x: me.x, y: me.y - 34, t: 0.9, text: '+HP', c: '#7aff9a' }); }
        }
    }
    // ボス部屋：入口に入ると、壁のない広間でボスと戦う。倒すと出口が現れ、迷路の元の場所に戻れる
    function corrEnterBoss(p) {      // ホストだけが呼ぶ
        if (!CF.on) return;
        corrEnterBossLocal(p.i);
        CF.saved.enemies = CF.saved.enemies; CF.portalIdx = p.i;
        const tier = (DBG && DBG.corrBoss) ? clamp(DBG.corrBoss | 0, 1, 10) : clamp(Math.round(1 + CF.floor / 4.5 + rnd(-1.2, 1.2)), 1, 10), bd = CD.bosses[tier - 1];      // デバッグ戦闘では、ボスを指定できる
        applyScale(corrPartyTotal(), corrIlvl(CF.floor) + 4, { hp: 1, dmg: 1, spd: 1.05 }); SC.hpMul = 1.2 + tier * 0.1;
        const b = spawnEnemy({ name: bd.name, icon: bd.icon, arch: 'chaser', color: bd.color }, WORLD_W - 420, WORLD_H / 2, true, false, corrPartyTotal() * corrMul(CF.floor) * bd.mul * 1.35);
        b.bd = { name: bd.name, icon: bd.icon, color: bd.color, stand: true, patterns: ['radial'], set: bd.set }; b.bset = (BM && BM.SETS && BM.SETS[bd.set]) || null; b.cboss = tier; b.spd = 60 * PW.spd; b.t = -1.5;
        if (DBG && DBG.hp > 0 && DBG.hp !== 1) b.maxHp = b.hp = Math.max(1, Math.round(b.maxHp * DBG.hp));
        run.bossSpawned = true; run.bossDead = false;
        netAnnounce('⚠ ' + bd.name + ' が現れた！', 2800);
    }
    function corrBossDown() {      // ボス部屋のボスを倒した
        CF.st.bosses++; run.bossSpawned = false;
        CF.exit = { x: WORLD_W / 2, y: WORLD_H / 2, r: 34 };
        netAnnounce('🏆 ボスを討伐！　出口から回廊へ戻れる', 3000);
    }
    function corrLeaveBoss() { if (CF.inBoss) corrLeaveBossLocal(); }
    // 毎フレーム：階段・宝箱・入口・出口との接触
    function corrUpdate(dt) {
        if (!CORR_ON || run.phase !== 'run' || !CF.rc) return;
        if (CF.fade > 0) CF.fade -= dt; if (CF.reqT > 0) CF.reqT -= dt;
        if (isHost && CF.on) {      // ミミックは、誰かが近づいたらホストが起こす（ホストが倒れていても、仲間が近づけば動く）
            const ps = alivePlayersPos();
            for (const p of CF.props.slice()) if (p.k === 'chest' && p.mimic && ps.some(q => dist(q.x, q.y, p.x, p.y) < 74)) corrWakeMimic(p);
        }
        if (me.dead || me.escaped) { CF.gateT = 0; return; }
        if (CF.on) {
            const c = corrCellOf(me.x, me.y); CF.seen[c] = 1;
            const cx = c % CF.cols, cy = Math.floor(c / CF.cols);
            CDIR.forEach(d => { if (CF.open[c] & d[2]) { const nx = cx + d[0], ny = cy + d[1]; if (nx >= 0 && ny >= 0 && nx < CF.cols && ny < CF.rows) { const n = corrCenter(ny * CF.cols + nx); if (dist(me.x, me.y, n.x, n.y) < 330) CF.seen[ny * CF.cols + nx] = 1; } } });
            CF.clock = (CF.clock || 0) + dt;
            let onGate = false;
            for (const p of CF.props.slice()) {
                const d = dist(me.x, me.y, p.x, p.y);
                if (p.k === 'trap') { const ph = (CF.clock + p.ph) % 3.2; p.on = ph > 2.5 ? 2 : (ph > 2.0 ? 1 : 0); if (p.on === 2 && d < p.r + 6) hurtMe(foeDmg('chaser', false, false) * 0.9); continue; }
                if (p.k === 'spring' && d < p.r + 10) { p.k = 'spring_done'; netSend('cuse', { i: p.i }); addHp(me.maxHp * 0.5); me.energy = Math.min(ENERGY_MAX, me.energy + ENERGY_MAX * 0.5); popups.push({ x: p.x, y: p.y - 28, t: 1.2, text: '泉：HP回復', c: '#7aff9a', big: true }); fx.push({ k: 'ring', x: p.x, y: p.y, r: 0, max: 110, t: 0.6, life: 0.6, c: '#7aff9a' }); continue; }
                if (p.k === 'stairs' && d < p.r + 6) { corrAsk('stairs'); return; }
                else if (p.k === 'chest' && !p.mimic && d < p.r + 18) corrOpenChest(p);
                else if (p.k === 'portal' && d < p.r + 6) { corrAsk('portal', p.i); return; }
                else if (p.k === 'gate' && d < p.r) onGate = true;
            }
            if (onGate) { CF.gateT += dt; if (CF.gateT >= 1.2) { CF.gateT = 0; corrEscape(); } }
            else CF.gateT = Math.max(0, CF.gateT - dt * 2);
        } else if (CF.inBoss && CF.exit && dist(me.x, me.y, CF.exit.x, CF.exit.y) < CF.exit.r + 6) corrAsk('exit');
    }
    // 袋の中身を、持ち物に反映する（脱出に成功したときだけ呼ばれる）
    function corrCommit() {
        const d = HW.load();
        BAG.weapons.forEach(w => d.weapons.push(w));
        if (window.SBArmor) BAG.armors.forEach(a => SBArmor.add(d, a));
        if (window.SBAcc) { SBAcc.ensure(d); BAG.accs.forEach(a => d.accs.push(a)); }
        Object.keys(BAG.items).forEach(k => HW.addItem(d, k, BAG.items[k]));
        HW.save(d);
        const p = getPlayerData();
        if (p) {
            if (!p.materials || Array.isArray(p.materials)) p.materials = {};
            Object.keys(BAG.mats).forEach(id => { p.materials[id] = (p.materials[id] || 0) + BAG.mats[id]; });
            if (!Array.isArray(p.orbs)) p.orbs = [];
            BAG.orbs.forEach(o => p.orbs.push(o));
            try { localStorage.setItem('player', JSON.stringify(p)); } catch (e) {}
        }
        BAG.weapons = []; BAG.armors = []; BAG.accs = []; BAG.items = {}; BAG.mats = {}; BAG.orbs = [];
    }
    // 脱出ゲートの上で少し立ち止まると脱出できる。脱出すると、ここまでの報酬を持ち帰って、この冒険は終わる
    function corrEscape() {
        if (run.escaped || me.dead || run.phase !== 'run') return;
        run.escaped = true; me.escaped = true;
        try { if (window.SBAch && !DBG) SBAch.report('escape', CF.floor, weapon.type, !run.hitTaken); } catch (e) { /* 実績の記録に失敗してもゲームは続ける */ }
        netSend('esc', {});
        const others = Object.keys(allies).some(id => !allies[id].dead && !allies[id].esc);
        if (isHost && others) {          // ホストが先に脱出：仲間が続けられるよう、裏でゲームを動かし続ける（自分は倒れた扱いで敵に狙われない）
            me.dead = true; me.hp = 0; me.stunT = 0; me.orb = null;
            finish(true, { reason: 'escape', ghost: true });
        } else if (isHost) finishHost(true, 'escape');
        else finish(true, { reason: 'escape' });
    }
    function corrGiveUp() { if (run.ended || run.phase !== 'run' || run.settled) return; if (isHost && Object.keys(allies).some(id => !allies[id].dead && !allies[id].esc)) { alert('仲間が冒険を続けているので、ホストはあきらめられません。脱出ゲートから脱出してください。'); return; } if (isHost) { run.ended = true; finishHost(false, 'giveup'); } else { netSend('esc', {}); finish(false, { reason: 'giveup' }); } }
    function corrAsk(k, i) {        // 階段・ボス部屋の入口・出口に触れた：ホストなら実行、クライアントならホストにお願いする
        if (isHost) { if (k === 'stairs') corrDescend(); else if (k === 'portal') { const p = corrProp(i); if (p && p.k === 'portal') corrEnterBoss(p); } else if (k === 'exit') corrLeaveBoss(); }
        else if (CF.reqT <= 0) { CF.reqT = 1.2; netSend('creq', { k: k, i: i }); }
    }
    function corrProp(i) { return CF.props.find(p => p.i === i) || null; }

    // ---------- 開始・終了 ----------
    function beginRun() {
        if (run.phase !== 'wait') return;
        run.phase = 'run'; run.time = 0;
        run.pvpMode = PVP && partyCount() > 1; run.ghostMode = PVP && !TEAM && !run.pvpMode;      // 1人でアリーナに入ったら、ゴースト戦
        if (run.ghostMode) startGhost();
        if (COSTCHK && (PVP || COSTCHK.over)) setTimeout(() => { if (run.phase === 'run') announce(SBCost.summaryText(COSTCHK), 3400); }, 3300);      // コスト制度の結果を知らせる（ステージでは、超過しているときだけ）
        document.getElementById('waitRoom').style.display = 'none';
        if (run.pvpMode && TEAM && room) {
            // チーム戦：部屋の参加順に、青(0)・赤(1)へ交互に振り分ける（全員が同じ順番を持っているので一致する）。青は左、赤は右に並ぶ
            teamMap = {}; room.members.forEach((m, i) => { teamMap[m.id] = i % 2; });
            const mine = room.members.filter(m => teamMap[m.id] === teamMap[myId]), k = Math.max(0, mine.findIndex(m => m.id === myId));
            me.x = teamMap[myId] === 0 ? 300 : WORLD_W - 300; me.y = WORLD_H / 2 + (k - (mine.length - 1) / 2) * 170; pushOutOfRocks(me, me.r);
            me.ang = teamMap[myId] === 0 ? 0 : Math.PI;
            announce('⚔ ' + (teamMap[myId] === 0 ? '🔵青' : '🔴赤') + 'チーム！　相手チームを全員倒そう（制限時間 ' + Math.round(TIME_LIMIT / 60) + '分）', 2800);
        } else if (run.pvpMode) {
            // 参加者を円周上に等間隔で配置（全員が同じ並びで計算するので一致する）
            const ids = [myId].concat(Object.keys(allies)).sort(), i = ids.indexOf(myId), a = i / ids.length * Math.PI * 2;
            me.x = WORLD_W / 2 + Math.cos(a) * 380; me.y = WORLD_H / 2 + Math.sin(a) * 300; pushOutOfRocks(me, me.r);
            announce('⚔ 最後まで立っていた人の勝ち！（制限時間 ' + Math.round(TIME_LIMIT / 60) + '分）', 2600);
        } else if (RAID) {
            // 大討伐戦：全員が同じ並びで、南側（手前）に横一列に並ぶ。ボスは北の中央
            const ids = [myId].concat(Object.keys(allies)).sort(), i = ids.indexOf(myId), n = ids.length, per = 10, row = Math.floor(i / per), col = i % per, cnt = Math.min(per, n - row * per);
            if (stage.id === 'raid_worm') { me.x = WM.cx + (col - (cnt - 1) / 2) * 90; me.y = WM.cy + 260 + row * 80; }      // ワールドワーム：足場（円盤）の中央の南側に並ぶ（以前は、足場の外＝崖に出ていた）
            else { me.x = WORLD_W / 2 + (col - (cnt - 1) / 2) * 90; me.y = WORLD_H - 260 + row * 80; }
            pushOutOfRocks(me, me.r);
            const hint = stage.id === 'ambush' ? 'あらゆる方向から ニンゲンが襲ってくる！　囲まれるな！' : stage.id === 'raid_necro' ? '1秒に5体の死霊！　倒れるとゾンビになるぞ！' : stage.id === 'raid_velzark' ? '遠くはヴェルスのビーム、近くはザークの猛攻！　倒すと合体するぞ！' : stage.id === 'raid_machine' ? '燃料が切れるまで耐えろ！　近接は上昇気流へ！' : stage.id === 'raid_worm' ? '足場が崩れる！　縁に近づくな！' : stage.id === 'raid_increase' ? '倒すと分裂する！　10体になると心臓が出る！' : '色の通りに動け！';
            announce('🐉 大討伐戦　' + ((stage.boss && stage.boss.name) || 'ボス') + 'が待ち受ける…　' + hint + '（制限時間 ' + Math.round(TIME_LIMIT / 60) + '分）', 3200);
        } else if (RUSH_ON) announce('🏆 ボスラッシュ（' + DIFF.name + '）　フェーズ1〜5とFinal！', 2600);
        else if (CORR_ON) {
            corrMakeRetreatBtn();
            if (isHost) {      // 迷路はホストが決める（シード）。仲間にはスナップショットで伝わり、同じ迷路が作られる
                CF.seed = (Math.random() * 4294967295) >>> 0;
                const go = () => { if (run.phase === 'run' && !CF.rc && DBG && DBG.corrBoss) { const tb = clamp(DBG.corrBoss | 0, 1, 10); corrNewFloor(DBG.floor > 0 ? DBG.floor | 0 : Math.max(1, Math.round((tb - 1) * 4.5 + 1)), true); const pt = CF.props.find(q => q.k === 'portal'); corrEnterBoss({ i: pt ? pt.i : 0 }); return; }      // デバッグ戦闘：その階層を作ってすぐボス部屋へ
                    if (run.phase === 'run' && !CF.rc) corrNewFloor(Math.max(1, Math.min((room && room.startFloor) || launch.startFloor | 0 || 1, Math.max(1, hack.corridorBest | 0 || 1))), true); };      // 行ったことのある階層（最深まで）から始められる
                if (partyCount() > 1) setTimeout(go, 700); else go();      // マルチのときは、仲間のステータス（敵の強さの基準）が届くのを少し待つ
            }
            announce('🌀 無限回廊　階段を探して下へ！　持ち帰るには「脱出ゲート」から脱出', 3400);
        }
        else announce(stage.icon + ' ' + stage.name + (PVP ? '　スパーリングボットを倒せ！' : '　敵を倒してボスを呼び出せ！'), 2600);
        if (DBG) announce('🛠 デバッグ戦闘（報酬・クリア記録なし）' + (DBG.god ? '　無敵' : '') + (DBG.hp && DBG.hp !== 1 ? '　ボスHP×' + DBG.hp : ''), 3200);
        refreshLootLog();
    }

    function finish(win, d) {
        if (run.phase === 'end') return;
        if (run.settled) {      // 無限回廊：ホストが先に脱出して精算を済ませている。ほんとうに終わるときは、ゲームを止めるだけ
            run.phase = 'end'; run.ended = true; return;
        }
        if (!(d && d.ghost)) { run.phase = 'end'; run.ended = true; }
        else run.settled = true;
        if (DBG) { run.stats.coins = 0; showResult(win, d || {}); return; }   // デバッグ戦闘：コインもクリア記録も反映しない
        // 報酬の反映
        if (CORR_ON) {      // 無限回廊：脱出に成功したときだけ、袋の中身とコインを持ち帰れる。倒れたら（あきらめても）ぜんぶ失う
            if (run.escaped) corrCommit();
            else { run.lost = { coins: run.stats.coins, n: run.stats.loot.length, orbs: run.stats.orbs, mats: Object.keys(run.stats.mats).reduce((a, k) => a + run.stats.mats[k], 0), items: Object.assign({}, run.stats.items || {}) }; run.stats.coins = 0; }
        }
        const p = getPlayerData();
        if (PVP && run.pvpMode) run.stats.coins += win ? 400 : 120;      // 対人戦：勝てば400、負けても120
        if (PVP && run.ghostMode) run.stats.coins += win ? 200 : 60;      // ゴースト戦：勝てば200、負けても60
        if (PVP && run.pvpMode && window.SBPvpEvent) run.evGain = SBPvpEvent.award(win);   // シーズン最終週のPvPイベント：イベントポイント
        if (p) {
            p.coins = (p.coins || 0) + run.stats.coins;
            if (PVP && run.pvpMode && win) p.pvpWins = (p.pvpWins || 0) + 1;
            try { localStorage.setItem('player', JSON.stringify(p)); } catch (e) {}
        }
        const h = HW.load();
        if (PVP) h.pvpPlayed = true;      // ビギナーミッション「オンラインマッチに参加しよう」用
        if (!h.clearedDiff) h.clearedDiff = {};
        const diffIdx = DIFFS.indexOf(DIFF);
        if (CORR_ON) { h.corridorBest = Math.max(h.corridorBest | 0, CF.floor); }
        if (RUSH_ON) { const reached = win ? RUSHD.phases.length : Math.max(0, RS.ph - (RS.st === 2 ? 0 : 1)); h.rushBest = h.rushBest || {}; h.rushBest[diffIdx] = Math.max(h.rushBest[diffIdx] | 0, reached); run.rushReached = reached; }
        if (win && !PVP && !CORR_ON) { const cd = h.clearedDiff[stage.id] = h.clearedDiff[stage.id] || {}; cd[diffIdx] = (cd[diffIdx] | 0) + 1; }     // どの難易度でクリアしたか（ボスラッシュのエクストリーム解放などに使う）
        if (win && RUSH_ON && !h.corridorOpen) { h.corridorOpen = true; h.worldNotice = { t: '無限回廊が解放された！', s: '果てしない迷宮が、町のステージゲートに現れた' }; run.worldBanner = { t: '🌀 無限回廊が解放された！', s: 'ステージゲートの「無限回廊」へ。階段を探して、どこまでも下へ' }; }
        if (win) {
            h.cleared[stage.id] = (h.cleared[stage.id] || 0) + 1;
            const wo = worldOpenedByThisStage(), wg = worldOpenedByGate();
            if (wo && !h[wo.unlock.gateFlag]) { h[wo.unlock.gateFlag] = true; h.worldNotice = { t: wo.unlock.openText, s: wo.unlock.openSub }; run.worldBanner = { t: '🚪 ' + wo.unlock.openText, s: wo.unlock.openSub }; }
            if (stage.id === 'gate_world4' && h.cleared[stage.id] === 1) run.formUnlock = '新しいスキルの形「🌌包囲弾幕」を解放！（オリジナルスキルの「①形」から選べます）';   // 初めて機神の門のゲートキーパーを倒した
            if (wg && !h[wg.unlock.flag]) { h[wg.unlock.flag] = true; h.worldNotice = { t: wg.unlock.clearText, s: wg.unlock.clearSub }; run.worldBanner = { t: '🌌 ' + wg.unlock.clearText, s: wg.unlock.clearSub }; }
            if (AMB_ON) delete h.ambush;      // 襲撃を退けた：出現していた襲撃ステージは閉じる（負けたときは、30分のあいだ何度でも挑める）
            else if (!PVP && !CORR_ON && !RUSH_ON && !RAID && !stage.mini && !stage.gateTo && !(h.ambush && h.ambush.until > Date.now()) && Math.random() < AMB_CHANCE) {      // ステージクリア：一定の確率で、襲撃ステージが30分だけ出現する
                h.ambush = { until: Date.now() + AMB_OPEN_MIN * 60000, from: stage.id };
                if (!run.worldBanner) run.worldBanner = { t: '⚔ 襲撃ステージが出現！', s: 'ニンゲンが迫っている…' + AMB_OPEN_MIN + '分以内に、ステージゲートの「襲撃」へ向かえ！' };
            }
            HW.save(h);
        }
        HW.save(h);
        try { if (window.SBAch) { if (PVP && !run.ghostMode) SBAch.report('pvp', win ? 1 : 0, weapon.type); if (RUSH_ON && win && diffIdx === RUSHD_EXTREME) SBAch.report('rushEx', 1, weapon.type); if (win && !PVP && !CORR_ON) SBAch.report('clear', stage.id); SBAch.evaluate(); } } catch (e) { /* 実績の記録に失敗してもゲームは続ける */ }
        showResult(win, d || {});
    }

    // ---------- 描画 ----------
    const cam = { x: 0, y: 0 }, camBase = { x: 0, y: 0 };      // camBase：演出で動かす前のカメラ（照準の計算に使う）
    function render() {
        ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
        ctx.fillStyle = stage.bg2; ctx.fillRect(0, 0, VW, VH);
        cam.x = clamp(me.x, VW / 2, Math.max(VW / 2, WORLD_W - VW / 2)); cam.y = clamp(me.y, VH / 2, Math.max(VH / 2, WORLD_H - VH / 2));
        if (WORLD_W < VW) cam.x = WORLD_W / 2; if (WORLD_H < VH) cam.y = WORLD_H / 2;
        camBase.x = cam.x; camBase.y = cam.y;
        { const cf = cineFocus(); if (cf > 0) { cam.x += (clamp(CINE.x, VW / 2, Math.max(VW / 2, WORLD_W - VW / 2)) - cam.x) * cf; cam.y += (clamp(CINE.y, VH / 2, Math.max(VH / 2, WORLD_H - VH / 2)) - cam.y) * cf; } }      // 撃破演出：遠くで倒したときも、カメラがボスへ移る
        const ox = VW / 2 - cam.x, oy = VH / 2 - cam.y;
        ctx.save();
        { const cz = cineZoom(); if (cz !== 1) { const bx = CINE.x + ox, by = CINE.y + oy; ctx.translate(bx, by); ctx.scale(cz, cz); ctx.translate(-bx, -by); } }      // ボス撃破：ボスへズーム
        ctx.translate(ox, oy);
        // 床
        const floorCol = (CORR_ON && CF.on && CF.pal && CF.pal.floor) || stage.bg, pxOn = !!(window.SBPix && SBPix.on() && SBPix.pattern);
        if (pxOn) ctx.imageSmoothingEnabled = false;
        if (GMK === 'worm') { drawWormWorld(); } else if (pxOn) {      // ドット絵の床：色から地面の種類（草・土・石・砂・雪・溶岩・虚空）を決めて、タイルを敷き詰める
            const fk = (CORR_ON && CF.on) ? 'stone' : (stage._fk || (stage._fk = SBPix.kindOfColor(stage.bg)));
            ctx.imageSmoothingEnabled = false; ctx.fillStyle = SBPix.pattern(ctx, fk, floorCol); ctx.fillRect(0, 0, WORLD_W, WORLD_H);
            if (!(CORR_ON && CF.on)) SBPix.drawScatter(ctx, fk, floorCol, cam.x - VW / 2 - 20, cam.y - VH / 2 - 20, cam.x + VW / 2 + 20, cam.y + VH / 2 + 20, WORLD_W, WORLD_H, stage.id ? stage.id.length * 977 : 7, (x, y) => rocks.some(k => dist(x, y, k.x, k.y) < k.r + 14));
        } else {
        ctx.fillStyle = floorCol; ctx.fillRect(0, 0, WORLD_W, WORLD_H);
        ctx.strokeStyle = 'rgba(0,0,0,0.12)'; ctx.lineWidth = 1;
        ctx.beginPath(); for (let x = 0; x <= WORLD_W; x += 100) { ctx.moveTo(x, 0); ctx.lineTo(x, WORLD_H); } for (let y = 0; y <= WORLD_H; y += 100) { ctx.moveTo(0, y); ctx.lineTo(WORLD_W, y); } ctx.stroke();
        }
        ctx.strokeStyle = 'rgba(0,0,0,0.55)'; ctx.lineWidth = 6; ctx.strokeRect(0, 0, WORLD_W, WORLD_H);
        if (GMK === 'duality') drawDualityField();
        if (CORR_ON) corrDrawWorld();
        // 岩
        rocks.forEach(k => { if (pxOn) { SBPix.drawRock(ctx, k.x, k.y, k.r); return; } ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.arc(k.x + 4, k.y + 6, k.r, 0, 7); ctx.fill(); ctx.fillStyle = '#6b6f78'; ctx.beginPath(); ctx.arc(k.x, k.y, k.r, 0, 7); ctx.fill(); ctx.fillStyle = '#868b95'; ctx.beginPath(); ctx.arc(k.x - k.r * 0.25, k.y - k.r * 0.3, k.r * 0.55, 0, 7); ctx.fill(); });
        // 予告範囲
        telegraphs.forEach(t => { if (wmHidden(t.x)) return; drawTele(t); });
        // 敵
        drawDomains();
        enemies.forEach(e => drawEnemy(e));
        drawMinions();
        drawHealer();
        // 敵弾
        eBullets.forEach(b => { if (wmHidden(b.x)) return; if (b.kd === 1) { drawSword(b); return; } if (b.refl === 1) { ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(b.x, b.y, b.r + 5, 0, 7); ctx.stroke(); } if (pxOn && SBPix.drawBullet) { SBPix.drawBullet(ctx, b.x, b.y, b.r, b.c || '#ff6a5a', { vx: b.vx, vy: b.vy }); return; } ctx.fillStyle = b.c || '#ff6a5a'; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, 7); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.6)'; ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 0.4, 0, 7); ctx.fill(); });
        // 自分の弾
        if (pxOn && SBPix.drawBullet) { myShots.forEach(s => { if (s.kd === 1) drawSword(s); else if (s.tx >= 0 && MY_TEX[s.tx] && SBPix.drawTex) SBPix.drawTex(ctx, MY_TEX[s.tx], s.x, s.y, Math.atan2(s.vy, s.vx), s.ts); else SBPix.drawBullet(ctx, s.x, s.y, s.r, s.c, { vx: s.vx, vy: s.vy, arrow: !!s.ar }); }); ghostShots.forEach(s => { if (s.kd === 1) drawSword(s); else if (s.tp && SBPix.drawTex) SBPix.drawTex(ctx, s.tp, s.x, s.y, Math.atan2(s.vy || 0, s.vx || 0), s.ts); else SBPix.drawBullet(ctx, s.x, s.y, s.r, s.c, { vx: s.vx || 0, vy: s.vy || 0 }); }); }
        else {
        myShots.forEach(s => { if (s.kd === 1) { drawSword(s); return; } ctx.fillStyle = s.c; ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 7); ctx.fill(); });
        ghostShots.forEach(s => { if (s.kd === 1) { drawSword(s); return; } ctx.fillStyle = s.c; ctx.globalAlpha = 0.85; ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 7); ctx.fill(); ctx.globalAlpha = 1; });
        }
        drawBlades();
        // 味方
        Object.keys(allies).forEach(id => { if (wmHidden(allies[id].x)) return; drawPlayer(allies[id], false); });
        if (GH) drawGhost();
        drawPlayer(me, true);
        if (GMK === 'duality') drawDualityMarks();
        if (GMK === 'machine') drawMachineWorld();
        // 演出
        fx.forEach(f => { if (f.x != null && wmHidden(f.x)) return; drawFx(f); });
        if (window.ClassForms) ClassForms.draw(ctx);       // 職業の専用の形（世界座標）
        if (window.ClassFx) ClassFx.draw(ctx);             // 職業の固有効果のゲージなど
        popups.forEach(p => { ctx.globalAlpha = Math.min(1, p.t * 2); ctx.font = (p.big ? 'bold 18px' : 'bold 14px') + ' sans-serif'; ctx.textAlign = 'center'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,0.8)'; ctx.strokeText(p.text, p.x, p.y - (0.7 - Math.min(0.7, p.t)) * 30); ctx.fillStyle = p.c; ctx.fillText(p.text, p.x, p.y - (0.7 - Math.min(0.7, p.t)) * 30); ctx.globalAlpha = 1; });
        cineDraw();
        ctx.restore();
        cineFlash();
        if (CORR_ON && CF.on && CF.theme && CF.theme.id === 'dark' && !me.dead && !(window.SBAcc && SBAcc.hasSpecial(hack, 'antidark'))) {      // 暗闇の階：自分の周りだけが見える
            const sx = me.x - cam.x + VW / 2, sy = me.y - cam.y + VH / 2, g = ctx.createRadialGradient(sx, sy, 90, sx, sy, 330);
            g.addColorStop(0, 'rgba(0,0,10,0)'); g.addColorStop(1, 'rgba(0,0,10,0.93)');
            ctx.fillStyle = g; ctx.fillRect(0, 0, VW, VH);
        }
        drawHUD();
    }

        // 無限回廊の壁・階段・宝箱・入口の描画
    function corrDrawWorld() {
        const x0 = cam.x - VW / 2 - 60, x1 = cam.x + VW / 2 + 60, y0 = cam.y - VH / 2 - 60, y1 = cam.y + VH / 2 + 60;
        if (CF.on) {
            const pal = CF.pal || CPALS[0];
            ctx.fillStyle = (window.SBPix && SBPix.on() && SBPix.pattern) ? SBPix.pattern(ctx, 'brick', SBPix.shade(pal.wall, 0.2)) : pal.wall;
            for (const r of CF.rects) { if (r[0] > x1 || r[1] > y1 || r[0] + r[2] < x0 || r[1] + r[3] < y0) continue; ctx.fillRect(r[0], r[1], r[2], r[3]); }
            ctx.fillStyle = pal.hi;
            for (const r of CF.rects) { if (r[0] > x1 || r[1] > y1 || r[0] + r[2] < x0 || r[1] + r[3] < y0) continue; ctx.fillRect(r[0], r[1], r[2], 4); }
            // 壁のふち取り：床に接している辺だけに明るい線を引く（床との境目をはっきりさせる）
            ctx.fillStyle = pal.edge || 'rgba(255,255,255,0.6)';
            const tx0 = Math.max(0, Math.floor(x0 / TILE)), tx1 = Math.min(CF.tw - 1, Math.floor(x1 / TILE)), ty0 = Math.max(0, Math.floor(y0 / TILE)), ty1 = Math.min(CF.th - 1, Math.floor(y1 / TILE));
            const sol = (tx, ty) => tx < 0 || ty < 0 || tx >= CF.tw || ty >= CF.th || CF.solid[ty * CF.tw + tx] === 1;
            for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
                if (CF.solid[ty * CF.tw + tx] !== 1) continue;
                const px = tx * TILE, py = ty * TILE;
                if (!sol(tx, ty - 1)) ctx.fillRect(px, py, TILE, 3);
                if (!sol(tx, ty + 1)) ctx.fillRect(px, py + TILE - 3, TILE, 3);
                if (!sol(tx - 1, ty)) ctx.fillRect(px, py, 3, TILE);
                if (!sol(tx + 1, ty)) ctx.fillRect(px + TILE - 3, py, 3, TILE);
            }
        }
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const now = performance.now() / 1000;
        if (CF.on) CF.props.forEach(p => {
            if (p.x < x0 || p.x > x1 || p.y < y0 || p.y > y1) return;
            if (p.k === 'stairs') { ctx.strokeStyle = 'rgba(255,216,74,' + (0.55 + 0.3 * Math.sin(now * 3)) + ')'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(p.x, p.y, 30, 0, 7); ctx.stroke(); ctx.fillStyle = 'rgba(30,20,60,0.8)'; ctx.beginPath(); ctx.arc(p.x, p.y, 26, 0, 7); ctx.fill(); ctx.font = '28px sans-serif'; ctx.fillText('🪜', p.x, p.y + 1); }
            else if (p.k === 'gate') {      // 脱出ゲート：立ち止まると脱出できる
                const pr = Math.min(1, CF.gateT / 1.2), near = dist(me.x, me.y, p.x, p.y) < p.r + 70;
                ctx.strokeStyle = 'rgba(120,255,220,' + (0.55 + 0.3 * Math.sin(now * 3.4)) + ')'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(p.x, p.y, 32, 0, 7); ctx.stroke();
                ctx.fillStyle = 'rgba(0,50,50,0.75)'; ctx.beginPath(); ctx.arc(p.x, p.y, 27, 0, 7); ctx.fill(); ctx.font = '28px sans-serif'; ctx.fillText('🌀', p.x, p.y + 1);
                if (pr > 0) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(p.x, p.y, 38, -Math.PI / 2, -Math.PI / 2 + pr * Math.PI * 2); ctx.stroke(); }
                if (near) { ctx.font = 'bold 13px sans-serif'; ctx.fillStyle = '#c8fff0'; ctx.strokeStyle = 'rgba(0,0,0,.8)'; ctx.lineWidth = 3; ctx.strokeText(pr > 0 ? '脱出中…' : '脱出ゲート（乗ると脱出）', p.x, p.y - 50); ctx.fillText(pr > 0 ? '脱出中…' : '脱出ゲート（乗ると脱出）', p.x, p.y - 50); }
            }
            else if (p.k === 'spring') { ctx.fillStyle = 'rgba(80,220,160,' + (0.25 + 0.12 * Math.sin(now * 2.5)) + ')'; ctx.beginPath(); ctx.arc(p.x, p.y, 34, 0, 7); ctx.fill(); ctx.font = '28px sans-serif'; ctx.fillText('⛲', p.x, p.y); }
            else if (p.k === 'spring_done') { ctx.globalAlpha = 0.4; ctx.font = '26px sans-serif'; ctx.fillText('⛲', p.x, p.y); ctx.globalAlpha = 1; }
            else if (p.k === 'trap') { const on = p.on | 0; ctx.fillStyle = on === 2 ? 'rgba(255,80,80,0.9)' : (on === 1 ? 'rgba(255,200,80,0.55)' : 'rgba(255,255,255,0.12)'); ctx.beginPath(); ctx.arc(p.x, p.y, on === 2 ? 26 : 22, 0, 7); ctx.fill(); if (on === 2) { ctx.font = '22px sans-serif'; ctx.fillText('▲▲', p.x, p.y); } }
            else if (p.k === 'chest') { ctx.font = '30px sans-serif'; ctx.fillText('📦', p.x, p.y); }
            else if (p.k === 'open') { ctx.globalAlpha = 0.45; ctx.font = '26px sans-serif'; ctx.fillText('📭', p.x, p.y); ctx.globalAlpha = 1; }
            else if (p.k === 'portal') { ctx.strokeStyle = 'rgba(255,70,90,' + (0.6 + 0.3 * Math.sin(now * 4)) + ')'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(p.x, p.y, 28, 0, 7); ctx.stroke(); ctx.fillStyle = 'rgba(60,0,20,0.8)'; ctx.beginPath(); ctx.arc(p.x, p.y, 24, 0, 7); ctx.fill(); ctx.font = '26px sans-serif'; ctx.fillText('👹', p.x, p.y + 1); }
            else if (p.k === 'portal_done') { ctx.globalAlpha = 0.4; ctx.font = '24px sans-serif'; ctx.fillText('🕳️', p.x, p.y); ctx.globalAlpha = 1; }
        });
        if (CF.on && !CF.inBoss && window.SBAcc && SBAcc.hasSpecial(hack, 'compass') && !me.dead) {      // 記念の羅針盤：脱出ゲートの方向を示す矢印
            const g = CF.props.find(q => q.k === 'gate');
            if (g && dist(me.x, me.y, g.x, g.y) > 140) {
                const an = Math.atan2(g.y - me.y, g.x - me.x), ax = me.x + Math.cos(an) * 74, ay = me.y + Math.sin(an) * 74;
                ctx.save(); ctx.translate(ax, ay); ctx.rotate(an); ctx.globalAlpha = 0.55 + 0.3 * Math.sin(now * 4);
                ctx.fillStyle = '#6dffe0'; ctx.strokeStyle = 'rgba(0,0,0,.7)'; ctx.lineWidth = 3;
                ctx.beginPath(); ctx.moveTo(14, 0); ctx.lineTo(-8, -9); ctx.lineTo(-4, 0); ctx.lineTo(-8, 9); ctx.closePath(); ctx.stroke(); ctx.fill();
                ctx.restore(); ctx.globalAlpha = 1;
            }
        }
        if (CF.inBoss && CF.exit) { const p = CF.exit; ctx.strokeStyle = 'rgba(120,230,255,' + (0.6 + 0.3 * Math.sin(now * 4)) + ')'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(p.x, p.y, 32, 0, 7); ctx.stroke(); ctx.font = '26px sans-serif'; ctx.fillText('🚪', p.x, p.y + 1); }
        ctx.textBaseline = 'alphabetic';
    }
    function corrDrawMini(mx, my, sx, sy) {      // ミニマップ：行ったことのあるマスと、見つけた階段・宝箱・入口
        if (!CF.on || !CF.seen) return;
        ctx.fillStyle = 'rgba(170,160,220,0.38)';
        for (let c = 0; c < CF.seen.length; c++) { if (!CF.seen[c]) continue; const cx = c % CF.cols, cy = Math.floor(c / CF.cols); ctx.fillRect(mx + (1 + cx * CELL_T) * TILE * sx, my + (1 + cy * CELL_T) * TILE * sy, CELL_T * TILE * sx, CELL_T * TILE * sy); }
        CF.props.forEach(p => { if (!CF.seen[p.c]) return; ctx.fillStyle = p.k === 'stairs' ? '#ffd84a' : (p.k === 'portal' ? '#ff5a5a' : (p.k === 'gate' ? '#6dffe0' : (p.k === 'chest' ? '#ffb347' : ''))); if (ctx.fillStyle && (p.k === 'stairs' || p.k === 'portal' || p.k === 'chest' || p.k === 'gate')) ctx.fillRect(mx + p.x * sx - 2, my + p.y * sy - 2, 4, 4); });
    }
    function corrMakeRetreatBtn() {
        if (document.getElementById('btnRetreat')) return;
        const b = document.createElement('button'); b.id = 'btnRetreat'; b.type = 'button'; b.textContent = '🏳 あきらめる';
        b.style.cssText = 'position:fixed;left:max(10px,env(safe-area-inset-left));bottom:max(10px,env(safe-area-inset-bottom));z-index:7;padding:8px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.4);background:rgba(20,15,40,.75);color:#fff;font-size:.8rem;cursor:pointer';
        b.addEventListener('click', () => { if (confirm('あきらめますか？\n持ち帰れるのは「脱出ゲート」から脱出したときだけです。このまま終わると、ここまでの報酬はすべて失われます。')) corrGiveUp(); });
        document.body.appendChild(b);
    }

    // 予告範囲の描画（円／扇／直線／ドーナツ）。黄色＋⚡はスタン攻撃、橙は持続中の攻撃
    function drawTele(t) {
        const f = t.live ? 1 : clamp(1 - t.t / t.max, 0, 1);
        const rgb = t.stun ? '255,216,74' : (t.live ? '255,130,40' : '255,60,60');
        const edge = t.stun ? 'rgba(255,236,130,0.95)' : 'rgba(255,90,90,0.85)';
        const sh = t.sh || 'circle';
        if (sh === 'portal') { drawPortal(t); return; }
        ctx.lineWidth = t.stun ? 3 : 2; ctx.strokeStyle = edge;
        ctx.fillStyle = 'rgba(' + rgb + ',' + (t.live ? 0.4 : 0.12 + f * 0.22) + ')';
        const inner = 'rgba(' + rgb + ',' + (t.stun ? 0.5 : 0.35) + ')';
        if (sh === 'cone') {
            ctx.beginPath(); ctx.moveTo(t.x, t.y); ctx.arc(t.x, t.y, t.r, t.a - t.arc / 2, t.a + t.arc / 2); ctx.closePath(); ctx.fill(); ctx.stroke();
            if (!t.live) { ctx.fillStyle = inner; ctx.beginPath(); ctx.moveTo(t.x, t.y); ctx.arc(t.x, t.y, t.r * f, t.a - t.arc / 2, t.a + t.arc / 2); ctx.closePath(); ctx.fill(); }
        } else if (sh === 'line') {
            ctx.save(); ctx.translate(t.x, t.y); ctx.rotate(t.a);
            ctx.beginPath(); ctx.rect(0, -t.w / 2, t.r, t.w); ctx.fill(); ctx.stroke();
            if (!t.live) { ctx.fillStyle = inner; ctx.fillRect(0, -t.w / 2, t.r * f, t.w); }
            ctx.restore();
        } else if (sh === 'donut') {
            ctx.beginPath(); ctx.arc(t.x, t.y, t.r, 0, 7); ctx.moveTo(t.x + t.ri, t.y); ctx.arc(t.x, t.y, t.ri, 0, 7, true); ctx.fill('evenodd');
            ctx.beginPath(); ctx.arc(t.x, t.y, t.r, 0, 7); ctx.stroke(); ctx.beginPath(); ctx.arc(t.x, t.y, t.ri, 0, 7); ctx.stroke();
        } else {
            ctx.beginPath(); ctx.arc(t.x, t.y, t.r, 0, 7); ctx.fill(); ctx.stroke();
            if (!t.live) { ctx.fillStyle = inner; ctx.beginPath(); ctx.arc(t.x, t.y, t.r * f, 0, 7); ctx.fill(); }
        }
        if (t.stun) { ctx.font = 'bold 26px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#fff'; const cx = sh === 'cone' ? t.x + Math.cos(t.a) * t.r * 0.55 : (sh === 'line' ? t.x + Math.cos(t.a) * t.r * 0.5 : t.x), cy = sh === 'cone' ? t.y + Math.sin(t.a) * t.r * 0.55 : (sh === 'line' ? t.y + Math.sin(t.a) * t.r * 0.5 : t.y); ctx.fillText('⚡', cx, cy); ctx.textBaseline = 'alphabetic'; }
    }

    // 門：金色の魔法陣が回りながら開く。閉じる直前に点滅する
    function drawPortal(t) {
        const now = performance.now() / 1000, open = clamp((t.max - t.t) / 0.5, 0, 1), fade = clamp(t.t / 0.4, 0, 1), a = open * fade;
        const r = t.r * (0.6 + 0.4 * open);
        ctx.save(); ctx.translate(t.x, t.y); ctx.globalAlpha = a;
        const g = ctx.createRadialGradient(0, 0, 2, 0, 0, r * 1.5);
        g.addColorStop(0, 'rgba(255,250,210,0.95)'); g.addColorStop(0.45, 'rgba(255,210,100,0.55)'); g.addColorStop(1, 'rgba(255,170,40,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, r * 1.5, 0, 7); ctx.fill();
        ctx.strokeStyle = '#ffe9a0'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, r, 0, 7); ctx.stroke();
        ctx.rotate(now * 1.6); ctx.lineWidth = 2; ctx.strokeStyle = '#ffd36a';
        ctx.beginPath(); ctx.arc(0, 0, r * 0.72, 0, 7); ctx.stroke();
        for (let i = 0; i < 6; i++) { ctx.rotate(Math.PI / 3); ctx.beginPath(); ctx.moveTo(r * 0.72, 0); ctx.lineTo(r * 1.0, 0); ctx.stroke(); }
        ctx.restore();
    }
    // 剣：進行方向を向いた金色の刃
    function drawSword(b) {
        if (window.SBPix && SBPix.on() && SBPix.drawKeeperSword) { SBPix.drawKeeperSword(ctx, b.x, b.y, b.vx != null ? b.vx : Math.cos(b.ang || 0), b.vy != null ? b.vy : Math.sin(b.ang || 0)); return; }
        const ang = b.ang != null && b.vx == null ? b.ang : Math.atan2(b.vy, b.vx);
        ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(ang);
        ctx.fillStyle = 'rgba(255,220,120,0.28)'; ctx.beginPath(); ctx.ellipse(-6, 0, 26, 8, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#fff6d0'; ctx.strokeStyle = '#d8a83a'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(24, 0); ctx.lineTo(4, -5); ctx.lineTo(-12, -4); ctx.lineTo(-12, 4); ctx.lineTo(4, 5); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#d8a83a'; ctx.fillRect(-16, -8, 4, 16);
        ctx.restore();
    }
    // ゲートキーパー本体：背後で回る金色の輪（「門」の存在感）
    function drawGateRing(e) {
        const now = performance.now() / 1000, R = e.r * 1.9;
        ctx.save(); ctx.translate(e.x, e.y);
        const g = ctx.createRadialGradient(0, 0, e.r * 0.6, 0, 0, R * 1.25);
        g.addColorStop(0, 'rgba(255,230,140,0.0)'); g.addColorStop(0.7, 'rgba(255,210,100,0.28)'); g.addColorStop(1, 'rgba(255,190,60,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, R * 1.25, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(255,226,140,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, R, 0, 7); ctx.stroke();
        ctx.rotate(now * 0.6); ctx.fillStyle = '#ffe9a0';
        for (let i = 0; i < 12; i++) { ctx.rotate(Math.PI / 6); ctx.beginPath(); ctx.arc(R, 0, 5, 0, 7); ctx.fill(); }
        ctx.restore();
    }
    // ワールドワームの世界：奈落に浮かぶ円盤の足場（崩れる予兆つき）／体内の部屋
    function drawWormWorld() {
        const inner = wmZone(me.x) === 1, now = performance.now() / 1000;
        ctx.fillStyle = inner ? '#2a0d17' : '#05040a'; ctx.fillRect(0, 0, WORLD_W, WORLD_H);
        if (inner) {
            const R = WM.IN, cx = (R.x0 + R.x1) / 2, cy = (R.y0 + R.y1) / 2, g = ctx.createRadialGradient(cx, cy, 60, cx, cy, 640);
            g.addColorStop(0, '#7a2f45'); g.addColorStop(1, '#3d1424'); ctx.fillStyle = g; ctx.fillRect(R.x0, R.y0, R.x1 - R.x0, R.y1 - R.y0);
            ctx.strokeStyle = 'rgba(255,140,170,' + (0.4 + 0.2 * Math.sin(now * 3)) + ')'; ctx.lineWidth = 10; ctx.strokeRect(R.x0, R.y0, R.x1 - R.x0, R.y1 - R.y0);
            ctx.strokeStyle = 'rgba(255,90,120,0.18)'; ctx.lineWidth = 3; for (let i = 0; i < 9; i++) { ctx.beginPath(); ctx.moveTo(R.x0 + i * 120, R.y0); ctx.bezierCurveTo(R.x0 + i * 120 + 60, cy - 200, R.x0 + i * 120 - 60, cy + 200, R.x0 + i * 120, R.y1); ctx.stroke(); }
            ctx.font = 'bold 15px sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(255,200,215,0.8)'; ctx.fillText('ワールドワームの体内', cx, R.y0 + 28); ctx.textAlign = 'start';
            return;
        }
        const STEPS = 96; ctx.beginPath();
        for (let i = 0; i <= STEPS; i++) { const a = i / STEPS * WM_TAU, r = wmRa(a); const x = WM.cx + Math.cos(a) * r, y = WM.cy + Math.sin(a) * r; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); }
        ctx.closePath(); const gg = ctx.createRadialGradient(WM.cx, WM.cy, 40, WM.cx, WM.cy, WM.R0); gg.addColorStop(0, '#4a3a2a'); gg.addColorStop(1, '#2b2118'); ctx.fillStyle = gg; ctx.fill();
        ctx.save(); ctx.clip(); ctx.strokeStyle = 'rgba(0,0,0,0.22)'; ctx.lineWidth = 2; for (let r = 100; r < WM.R0; r += 100) { ctx.beginPath(); ctx.arc(WM.cx, WM.cy, r, 0, 7); ctx.stroke(); } for (let i = 0; i < 12; i++) { const a = i * WM_TAU / 12; ctx.beginPath(); ctx.moveTo(WM.cx, WM.cy); ctx.lineTo(WM.cx + Math.cos(a) * WM.R0, WM.cy + Math.sin(a) * WM.R0); ctx.stroke(); } ctx.restore();
        ctx.strokeStyle = 'rgba(255,200,120,0.55)'; ctx.lineWidth = 6; ctx.stroke();
        (G.cr || []).forEach(i => {      // これから崩れる場所（赤く点滅）
            const a0 = i * WM_TAU / WM.N, a1 = (i + 1) * WM_TAU / WM.N, r1 = G.pr ? G.pr[i] : WM.R0, r0 = Math.max(WM.RMIN * 0.5, r1 - WM.BITE);
            ctx.beginPath(); ctx.arc(WM.cx, WM.cy, r1 + 6, a0, a1); ctx.arc(WM.cx, WM.cy, r0, a1, a0, true); ctx.closePath(); ctx.fillStyle = 'rgba(255,60,40,' + (0.28 + 0.25 * Math.sin(now * 14)) + ')'; ctx.fill();
        });
        (G.an || []).forEach(a => {      // アンカー（バリスタ）：乗り続けると、満タンになる
            ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.arc(a.x, a.y, 52, 0, 7); ctx.fill();
            ctx.strokeStyle = a.p >= 100 ? '#9dff9d' : '#9fe0ff'; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(a.x, a.y, 52, -Math.PI / 2, -Math.PI / 2 + WM_TAU * Math.min(1, a.p / 100)); ctx.stroke();
            ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(a.x, a.y, 52, 0, 7); ctx.stroke();
            ctx.font = '30px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('🪝', a.x, a.y); ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'start';
        });
    }
    // ワールドワームの頭・体・鱗・核
    function drawWorm(e) {
        const fl = e.flash > 0, r = e.r, now = performance.now() / 1000;
        if (e.arch === 'wcore') {
            const beat = 1 + 0.1 * Math.max(0, Math.sin(now * 6)), br = e.broken != null || (e.inv && e.hp <= 1 && e.maxHp > 1);      // 砕けた核：無敵で体力が1（仲間の画面でも分かる）
            ctx.save(); ctx.translate(e.x, e.y); ctx.scale(beat, beat);
            ctx.fillStyle = fl ? '#fff' : (br ? '#cfcfcf' : (e.def.color || '#ff4d8a')); ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, r, 0, 7); ctx.fill(); ctx.stroke();
            ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.beginPath(); ctx.ellipse(-r * 0.3, -r * 0.35, r * 0.25, r * 0.14, -0.6, 0, 7); ctx.fill(); ctx.restore();
            if (e.inv && !br) { ctx.strokeStyle = 'rgba(127,255,212,0.9)'; ctx.lineWidth = 4; ctx.setLineDash([8, 6]); ctx.beginPath(); ctx.arc(e.x, e.y, r + 12, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
            ctx.font = 'bold 13px sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 3; const lb = br ? 'シンクロ待ち！' : (e.inv ? '（鱗を壊すまで無敵）' : '核'); ctx.strokeText(lb, e.x, e.y - r - 14); ctx.fillText(lb, e.x, e.y - r - 14); ctx.textAlign = 'start';
            if (!br && e.hp < e.maxHp) { const w = r * 2; ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(e.x - w / 2, e.y + r + 6, w, 5); ctx.fillStyle = '#ff7a96'; ctx.fillRect(e.x - w / 2, e.y + r + 6, w * clamp(e.hp / e.maxHp, 0, 1), 5); }
            return;
        }
        if (e.arch === 'wscale') {
            ctx.save(); ctx.translate(e.x, e.y); ctx.fillStyle = fl ? '#fff' : '#8fa0b8'; ctx.strokeStyle = '#dfe8f5'; ctx.lineWidth = 3; ctx.beginPath();
            for (let i = 0; i < 6; i++) { const a = i * WM_TAU / 6 + 0.5; const x = Math.cos(a) * r, y = Math.sin(a) * r; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); } ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
            const w = r * 2; ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(e.x - w / 2, e.y - r - 10, w, 4); ctx.fillStyle = '#9fe0ff'; ctx.fillRect(e.x - w / 2, e.y - r - 10, w * clamp(e.hp / e.maxHp, 0, 1), 4);
            return;
        }
        if (G.hid) {      // 地中に潜っている間は、姿が見えない（盛り上がる土だけ）
            if (e.boss) { ctx.strokeStyle = 'rgba(160,112,64,' + (0.35 + 0.2 * Math.sin(now * 10)) + ')'; ctx.lineWidth = 5; ctx.setLineDash([10, 10]); ctx.beginPath(); ctx.arc(e.x, e.y, 90 + 12 * Math.sin(now * 6), 0, 7); ctx.stroke(); ctx.setLineDash([]); }
            return;
        }
        const head = !!e.boss, weak = G.wm === 'D';
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(e.x, e.y + r * 0.8, r * 0.9, r * 0.4, 0, 0, 7); ctx.fill();
        const gr = ctx.createRadialGradient(e.x - r * 0.3, e.y - r * 0.4, r * 0.1, e.x, e.y, r * 1.05); gr.addColorStop(0, fl ? '#fff' : (head ? '#e6bf8a' : '#d4b088')); gr.addColorStop(1, fl ? '#fff' : (head ? '#8a5f34' : '#6e4f2e'));
        ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(e.x, e.y, r, 0, 7); ctx.fill(); ctx.strokeStyle = head ? '#ffd84a' : '#4a3018'; ctx.lineWidth = head ? 4 : 3; ctx.stroke();
        ctx.strokeStyle = 'rgba(60,35,15,0.45)'; ctx.lineWidth = 3; for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.arc(e.x, e.y, r * (0.55 + 0.2 * (k + 1) / 2), -0.9, 0.9); ctx.stroke(); }
        if (head) {
            ctx.fillStyle = '#3a0f14'; ctx.beginPath(); ctx.arc(e.x, e.y, r * 0.55, 0, 7); ctx.fill();
            ctx.fillStyle = '#fff'; for (let i = 0; i < 12; i++) { const a = i * WM_TAU / 12; ctx.beginPath(); ctx.moveTo(e.x + Math.cos(a - 0.12) * r * 0.55, e.y + Math.sin(a - 0.12) * r * 0.55); ctx.lineTo(e.x + Math.cos(a) * r * 0.32, e.y + Math.sin(a) * r * 0.32); ctx.lineTo(e.x + Math.cos(a + 0.12) * r * 0.55, e.y + Math.sin(a + 0.12) * r * 0.55); ctx.fill(); }
            ctx.font = 'bold 13px sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 3; ctx.strokeText('ワールドワーム', e.x, e.y - r - 12); ctx.fillText('ワールドワーム', e.x, e.y - r - 12); ctx.textAlign = 'start';
        }
        if (e.inv) { ctx.strokeStyle = 'rgba(127,255,212,0.9)'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(e.x, e.y, r + 9, 0, 7); ctx.stroke(); }
        if (weak) { ctx.strokeStyle = 'rgba(255,224,138,' + (0.5 + 0.4 * Math.sin(now * 12)) + ')'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(e.x, e.y, r + 8, 0, 7); ctx.stroke(); }
    }
    // 増殖スライム／心臓の描画（ぷるぷる動く、半透明のスライム）
    function drawIncrease(e) {
        const now = performance.now() / 1000, fl = e.flash > 0, air = e.air || 0, r = e.r;
        const sh = 1 - Math.min(0.5, air / (r * 3));
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(e.x, e.y + r * 0.8, r * 0.9 * sh, r * 0.4 * sh, 0, 0, 7); ctx.fill();
        if (e.arch === 'heart') {
            const beat = Math.max(0, Math.sin(now * 7)), pu = 1 + 0.16 * beat;
            ctx.save(); ctx.translate(e.x, e.y); ctx.scale(pu, pu);
            ctx.globalAlpha = 0.35 + 0.3 * beat; ctx.strokeStyle = '#ff9ab0'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(0, 0, r * 1.5, 0, 7); ctx.stroke(); ctx.globalAlpha = 1;
            ctx.fillStyle = fl ? '#fff' : '#ff3b5c'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.moveTo(0, r * 0.95); ctx.bezierCurveTo(-r * 1.6, r * 0.1, -r * 0.95, -r * 1.2, 0, -r * 0.45); ctx.bezierCurveTo(r * 0.95, -r * 1.2, r * 1.6, r * 0.1, 0, r * 0.95); ctx.fill(); ctx.stroke();
            ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.ellipse(-r * 0.5, -r * 0.35, r * 0.22, r * 0.12, -0.6, 0, 7); ctx.fill();
            ctx.restore();
            ctx.font = 'bold 13px sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 3; ctx.strokeText('一撃！', e.x, e.y - r - 16); ctx.fillText('一撃！', e.x, e.y - r - 16); ctx.textAlign = 'start';
            return;
        }
        const g = e.gen | 0, s = clamp(air / (r * 1.5), 0, 1), wob = Math.sin(now * 6 + (e.id | 0)) * 0.04;
        if (e._la > 3 && air <= 3) e._sq = 0.18; e._la = air; if (e._sq > 0) e._sq = Math.max(0, e._sq - 0.016);
        const sq = (e._sq || 0) / 0.18, sx = 1 - 0.12 * s + wob + sq * 0.25, sy = 1 + 0.25 * s - wob - sq * 0.25, col = e.def.color || '#5be37a';
        ctx.save(); ctx.translate(e.x, e.y - air);
        const gr = ctx.createRadialGradient(-r * 0.3, -r * 0.45, r * 0.1, 0, 0, r * 1.1); gr.addColorStop(0, fl ? '#fff' : '#eaffef'); gr.addColorStop(0.35, fl ? '#fff' : col); gr.addColorStop(1, fl ? '#fff' : 'rgba(20,90,50,0.95)');
        ctx.fillStyle = gr; ctx.globalAlpha = 0.93; ctx.beginPath(); ctx.ellipse(0, 0, r * sx, r * sy * 0.9, 0, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
        ctx.strokeStyle = g === 0 ? '#ffd84a' : 'rgba(20,90,50,0.9)'; ctx.lineWidth = g === 0 ? 3 : 2; ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,0.75)'; ctx.beginPath(); ctx.ellipse(-r * 0.38, -r * 0.42, r * 0.2, r * 0.11, -0.6, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.28)'; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(Math.cos(i * 2.1 + e.id) * r * 0.42, Math.sin(i * 2.1 + e.id) * r * 0.3 + r * 0.1, r * (0.1 + 0.03 * i), 0, 7); ctx.fill(); }
        const lk = Math.atan2(me.y - e.y, me.x - e.x), ex = r * 0.3;      // 目は、自分のほうを見る
        [-1, 1].forEach(sd => { ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.ellipse(sd * ex, -r * 0.05, r * 0.16, r * 0.2, 0, 0, 7); ctx.fill(); ctx.fillStyle = '#14121c'; ctx.beginPath(); ctx.arc(sd * ex + Math.cos(lk) * r * 0.06, -r * 0.05 + Math.sin(lk) * r * 0.07, r * 0.08, 0, 7); ctx.fill(); });
        ctx.restore();
        if (e.hp < e.maxHp) { const w = r * 2; ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(e.x - w / 2, e.y - r - 12, w, 4); ctx.fillStyle = '#5be37a'; ctx.fillRect(e.x - w / 2, e.y - r - 12, w * clamp(e.hp / e.maxHp, 0, 1), 4); }
    }
    // ============================================================
    // 近接の敵の「攻撃モーション」（接触ダメージの代わり）
    //  近づく → 予告（赤い範囲が満ちる）→ 攻撃（ドット絵の粒がいっせいに動く）→ 硬直（隙）。ダメージが入るのは「攻撃」の瞬間の範囲だけ。
    //  系統（名前で判定）ごとに技が違う：
    //    engulf  スライム系 … がばっと飲み込む（大きな円。粒が広がって、ぎゅっと縮む）
    //    claw    ドラゴン系 … 爪で3連のひっかき（扇形）
    //    slash   兵士・騎士・ロボ系 … 横なぎ（扇形）／ slam  タンク系 … 叩きつけ（自分の周りの円）
    //    pounce  群れ系（虫・コウモリ・鳥）… 飛びかかり／ swipe … それ以外の素手の一撃
    //  ホストが状態（ma:0なし/1溜め/2攻撃/3硬直、mt:経過秒、maim:向き、mk:系統、mn:攻撃の通し番号、mL:標的までの距離）を動かし、
    //  スナップショットで全員に配る。ダメージは「各自の画面で、自分に当たったか」を攻撃の瞬間に1回だけ判定する。
    //  数字（溜めの長さ・範囲・威力）は MK を触る。
    // ============================================================
    const MK = {
        engulf: { i: 0, shape: 'circle', wind: 0.75, strike: 0.35, rec: 0.8, cd: 0.5, reach: 70, R: 50, dm: 1.5, lunge: 0 },
        claw: { i: 1, shape: 'cone', wind: 0.6, strike: 0.4, rec: 0.6, cd: 0.45, reach: 90, arc: 2.0, dm: 1.4, lunge: 34 },
        slash: { i: 2, shape: 'cone', wind: 0.5, strike: 0.22, rec: 0.5, cd: 0.4, reach: 60, arc: 1.7, dm: 1.25, lunge: 20 },
        slam: { i: 3, shape: 'ring', wind: 0.9, strike: 0.3, rec: 0.9, cd: 0.6, reach: 55, dm: 1.6, lunge: 0 },
        pounce: { i: 4, shape: 'lunge', wind: 0.32, strike: 0.28, rec: 0.5, cd: 0.4, reach: 120, dm: 1.15, lunge: 110 },
        swipe: { i: 5, shape: 'cone', wind: 0.5, strike: 0.22, rec: 0.5, cd: 0.4, reach: 50, arc: 1.5, dm: 1.25, lunge: 16 }
    };
    const MK_BY_I = [MK.engulf, MK.claw, MK.slash, MK.slam, MK.pounce, MK.swipe];
    function meleeKindOf(e) {
        const n = (e.def && e.def.name) || '', ic = (e.def && e.def.icon) || '';
        if (/スライム|ゼリー/.test(n) || /🟢|🟩|🟠/.test(ic)) return 0;
        if (/竜|ドラゴン|トカゲ|ワイバーン/.test(n) || /🐉|🦎|🐲/.test(ic)) return 1;
        if (e.arch === 'tank') return 3;
        if (e.arch === 'swarm') return 4;
        if (/兵|戦士|騎士|ロボ|ゴブリン|オーク|骸骨/.test(n)) return 2;
        return 5;
    }
    const meleeDone = {};      // 敵ID → 最後にダメージを判定した攻撃の通し番号（同じ攻撃で2回当たらないように）
    function meleeUpdate(e, dt, d, ang, sp, mvx, mvy, los) {      // ホストだけ。true を返したら、この敵はこのフレーム、普通には動かない
        if (!e.ma) {
            e.mcd = (e.mcd == null ? 0.4 : e.mcd) - dt;
            if (e.mk == null) e.mk = meleeKindOf(e);
            const K = MK_BY_I[e.mk];
            if (e.mcd <= 0 && los && d < e.r + 14 + K.reach) { e.ma = 1; e.mt = 0; e.maim = ang; e.mL = d; }
            else return false;
            return true;
        }
        const K = MK_BY_I[e.mk | 0]; e.mt += dt;
        if (e.ma === 1) {
            if (e.mt < K.wind * 0.65) { e.maim = ang; e.mL = d; }      // 溜めの前半は標的を追って向きを合わせ、後半で向きを固定（動けば避けられる）
            if (e.mt >= K.wind) { e.ma = 2; e.mt = 0; e.mn = (e.mn | 0) + 1; }
        } else if (e.ma === 2) {
            if (K.lunge) { const v = K.lunge / K.strike * dt; e.x += Math.cos(e.maim) * v; e.y += Math.sin(e.maim) * v; }
            if (e.mt >= K.strike) { e.ma = 3; e.mt = 0; }
        } else if (e.mt >= K.rec) { e.ma = 0; e.mt = 0; e.mcd = K.cd * (0.8 + Math.random() * 0.5); }
        return true;
    }
    function meleeP(e) {      // 今のフェーズの進み具合 { p: 0〜1, el: 経過秒 }（ゲストは、スナップショットが届いてからの時間を足す）
        const K = MK_BY_I[e.mk | 0], el = (e.mt || 0) + (e.mrx ? Math.max(0, (performance.now() - e.mrx) / 1000) : 0);
        const dur = e.ma === 1 ? K.wind : (e.ma === 2 ? K.strike : K.rec);
        return { p: clamp(el / dur, 0, 1), el: el };
    }
    function meleeShape(e) {
        const K = MK_BY_I[e.mk | 0], a = e.maim || 0;
        if (K.shape === 'circle') { const L = Math.min(e.mL || e.r + 14, e.r + 14 + K.reach); return { t: 'c', x: e.x + Math.cos(a) * L, y: e.y + Math.sin(a) * L, R: K.R + e.r * 0.6 }; }
        if (K.shape === 'lunge') { const L = e.r + K.reach * 0.55; return { t: 'c', x: e.x + Math.cos(a) * L, y: e.y + Math.sin(a) * L, R: e.r + 24 }; }
        if (K.shape === 'ring') return { t: 'r', x: e.x, y: e.y, R: e.r + K.reach + 30 };
        return { t: 'k', x: e.x, y: e.y, a: a, len: e.r + K.reach + 25, arc: K.arc };
    }
    function meleeHitCheck(e) {      // 各自の画面で：攻撃の瞬間に、自分が範囲に入っていたらダメージ（1回の攻撃につき1回）
        if (e.pvp || e.hp <= 0 || me.dead) return;
        if (!(e.ma === 2 || (e.ma === 3 && (e.mt || 0) < 0.12))) return;
        if (meleeDone[e.id] === e.mn) return; meleeDone[e.id] = e.mn;
        if (Object.keys(meleeDone).length > 400) { for (const k in meleeDone) delete meleeDone[k]; }
        const sh = meleeShape(e), K = MK_BY_I[e.mk | 0]; let hit = false;
        if (sh.t === 'c') hit = dist(sh.x, sh.y, me.x, me.y) < sh.R + me.r * 0.5;
        else if (sh.t === 'r') hit = dist(sh.x, sh.y, me.x, me.y) < sh.R + me.r * 0.4;
        else { const dd = dist(sh.x, sh.y, me.x, me.y); if (dd < sh.len + me.r * 0.5) { const df = Math.atan2(Math.sin(Math.atan2(me.y - sh.y, me.x - sh.x) - sh.a), Math.cos(Math.atan2(me.y - sh.y, me.x - sh.x) - sh.a)); hit = Math.abs(df) < sh.arc / 2 + me.r / Math.max(30, dd); } }
        if (hit) hurtMe(ed(e) * K.dm, e.affix === 'venom' ? { poison: true } : null);
    }
    // ---- 描画 ----
    function mHash(id, i) { let h = (((id | 0) * 374761393) + i * 668265263) >>> 0; h = ((h ^ (h >>> 13)) * 1274126177) >>> 0; return ((h ^ (h >>> 16)) >>> 0) / 4294967295; }
    function mDot(x, y, s, c, a) { ctx.globalAlpha = a; ctx.fillStyle = c; ctx.fillRect(Math.round((x - s / 2) / 3) * 3, Math.round((y - s / 2) / 3) * 3, s, s); }      // ドット（3px の格子に吸着）
    function drawMeleeTele(e) {
        const P = meleeP(e), sh = meleeShape(e), p = P.p;
        ctx.save(); ctx.fillStyle = 'rgba(255,60,60,' + (0.10 + 0.2 * p).toFixed(3) + ')'; ctx.strokeStyle = 'rgba(255,110,110,' + (0.5 + 0.4 * p).toFixed(3) + ')'; ctx.lineWidth = 2;
        ctx.beginPath();
        if (sh.t === 'k') { ctx.moveTo(sh.x, sh.y); ctx.arc(sh.x, sh.y, sh.len, sh.a - sh.arc / 2, sh.a + sh.arc / 2); ctx.closePath(); } else ctx.arc(sh.x, sh.y, sh.R, 0, 7);
        ctx.fill(); ctx.stroke();
        ctx.fillStyle = 'rgba(255,90,90,' + (0.18 + 0.22 * p).toFixed(3) + ')'; ctx.beginPath();      // 範囲が内側から満ちていく（満ちたら攻撃）
        if (sh.t === 'k') { ctx.moveTo(sh.x, sh.y); ctx.arc(sh.x, sh.y, sh.len * p, sh.a - sh.arc / 2, sh.a + sh.arc / 2); ctx.closePath(); } else ctx.arc(sh.x, sh.y, sh.R * p, 0, 7);
        ctx.fill(); ctx.restore();
    }
    function meleeBodyXf(e) {      // 体の変形：溜め＝しゃがんで引く／攻撃＝攻撃方向へ伸びる（飲み込みは大きく膨らむ）
        const K = MK_BY_I[e.mk | 0], P = meleeP(e), p = P.p, a = e.maim || 0; let st = 0, sq = 0, bx = 0;
        if (e.ma === 1) { sq = 0.16 * p; bx = -9 * p; if (K === MK.engulf) { st = -0.15 * p; sq = -0.12 * p; } }
        else if (e.ma === 2) { const s = Math.sin(p * Math.PI); st = (K === MK.engulf ? 1.0 : (K === MK.pounce ? 0.5 : 0.18)) * s; sq = (K === MK.engulf ? 0.35 : 0.1) * s; }
        else { const q = 1 - p; st = 0.12 * q; sq = -0.1 * q; }
        ctx.translate(e.x + Math.cos(a) * bx, e.y + Math.sin(a) * bx); ctx.rotate(a); ctx.scale(1 + st, 1 - sq); ctx.rotate(-a); ctx.translate(-e.x, -e.y);
    }
    function drawMeleeFx(e) {
        const K = MK_BY_I[e.mk | 0], P = meleeP(e), p = P.p, sh = meleeShape(e), a = e.maim || 0, col = (e.def && e.def.color) || '#ff7a5a', id = e.id | 0, strike = e.ma === 2;
        ctx.save();
        if (K === MK.engulf) {            // 飲み込み：粒が標的の円いっぱいに広がり、ぎゅっと縮む
            const grow = strike ? 1 - Math.pow(1 - p, 3) : Math.max(0, 1 - P.el / (K.rec * 0.55)), N = 52;
            for (let i = 0; i < N; i++) {
                const ang = mHash(id, i) * 6.283, rad = Math.sqrt(mHash(id, i + 99)) * sh.R * 0.95, t = strike ? grow : 1;
                const tx = sh.x + Math.cos(ang) * rad * (strike ? 1 : grow), ty = sh.y + Math.sin(ang) * rad * (strike ? 1 : grow);
                const sx0 = e.x + Math.cos(a) * e.r * 0.4, sy0 = e.y + Math.sin(a) * e.r * 0.4;
                mDot(sx0 + (tx - sx0) * t, sy0 + (ty - sy0) * t - Math.sin(t * 3.14) * 14, 6 + ((mHash(id, i + 5) * 6) | 0), i % 3 ? col : '#eaffef', (strike ? 0.9 : 0.85) * (grow > 0.02 ? 1 : 0));
            }
            for (let i = 0; i < 20; i++) { const ang = i / 20 * 6.283; mDot(sh.x + Math.cos(ang) * sh.R * grow, sh.y + Math.sin(ang) * sh.R * grow, 6, '#ffffff', 0.9 * (grow > 0.05 ? 1 : 0)); }
        } else if (K === MK.claw || K === MK.slash || K === MK.swipe) {      // 爪・斬撃：弧をなぞる粒の軌跡（爪は3本、斬撃は1本）
            const claws = K === MK.claw ? 3 : 1, fade = strike ? 1 : Math.max(0, 1 - P.el / (K.rec * 0.5));
            for (let c = 0; c < claws; c++) {
                const rr = claws === 1 ? e.r + K.reach * 0.7 : e.r + K.reach * (0.5 + 0.25 * c), delay = c * 0.14, pp = strike ? clamp((p - delay) / (1 - delay), 0, 1) : 1;
                const a0 = a - K.arc / 2, a1 = a0 + K.arc * pp;
                for (let i = 0; i <= 26; i++) {
                    const u = i / 26, ang = a0 + (a1 - a0) * u; if (u * K.arc > K.arc * pp) break;
                    const head = pp > 0 ? (1 - Math.abs(u - 1) * 1.0) : 0, al = clamp(0.25 + 0.75 * u, 0, 1) * fade;
                    mDot(e.x + Math.cos(ang) * rr, e.y + Math.sin(ang) * rr, claws === 1 ? 7 : 6, u > 0.9 ? '#ffffff' : (c % 2 ? col : '#ffd2b0'), al);
                    if (i % 3 === 0) mDot(e.x + Math.cos(ang) * (rr + 8 * (mHash(id, i + c * 31) - 0.5) * 2), e.y + Math.sin(ang) * (rr + 8 * (mHash(id, i + c * 31 + 7) - 0.5) * 2), 3, '#ffffff', al * 0.7);
                }
            }
        } else if (K === MK.slam) {      // 叩きつけ：輪が広がり、破片が舞い上がる
            const grow = strike ? 1 - Math.pow(1 - p, 2) : 1, fade = strike ? 1 : Math.max(0, 1 - P.el / (K.rec * 0.5));
            for (let i = 0; i < 40; i++) { const ang = i / 40 * 6.283; mDot(e.x + Math.cos(ang) * sh.R * grow, e.y + Math.sin(ang) * sh.R * grow, 7, i % 2 ? col : '#ffffff', 0.9 * fade); }
            for (let i = 0; i < 18; i++) { const ang = mHash(id, i) * 6.283, rad = sh.R * (0.2 + 0.7 * mHash(id, i + 40)) * grow, t = strike ? p : 1; mDot(e.x + Math.cos(ang) * rad, e.y + Math.sin(ang) * rad - Math.sin(t * 3.14) * 34 * mHash(id, i + 9), 5, '#cfcfcf', 0.85 * fade); }
        } else {      // 飛びかかり：飛んだ道すじに粒の尾
            const fade = strike ? 1 : Math.max(0, 1 - P.el / (K.rec * 0.5));
            for (let i = 1; i <= 14; i++) { const back = i * 9; mDot(e.x - Math.cos(a) * back + (mHash(id, i) - 0.5) * 8, e.y - Math.sin(a) * back + (mHash(id, i + 20) - 0.5) * 8, 7 - i * 0.3, i % 2 ? col : '#ffffff', (1 - i / 15) * fade); }
        }
        ctx.globalAlpha = 1; ctx.restore();
    }

    function drawEnemy(e) {
        if (e.pvp) return;   // 対人戦の相手は drawPlayer で描く
        if (GMK === 'worm' && wmHidden(e.x)) return;      // 外と体内は、お互いに見えない
        if (e.arch === 'slime' || e.arch === 'heart') { drawIncrease(e); return; }
        if (e.arch === 'necro') { drawNecro(e); return; }
        if (e.arch === 'machine') { drawMachine(e); return; }
        if (e.arch === 'ningen') { drawNingen(e); return; }
        if (GMK === 'worm' && (e.arch === 'wseg' || e.arch === 'wscale' || e.arch === 'wcore' || e.boss)) { drawWorm(e); return; }
        const fl = e.flash > 0;
        if (e.boss && !e.echo && (e.gate != null ? e.gate : bdef(e).gate)) drawGateRing(e);
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(e.x, e.y + e.r * 0.8, e.r * 0.9, e.r * 0.4, 0, 0, 7); ctx.fill();
        if (!e.boss && e.ma === 1) drawMeleeTele(e);      // 近接の敵の攻撃予告（赤い範囲）
        ctx.save(); if (e.air > 0) ctx.translate(0, -e.air);   // 跳躍中は影を残して本体だけ浮く
        if (e.arch === 'charger' && e.state === 1 && e.aim != null) { ctx.strokeStyle = 'rgba(255,80,80,0.7)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(e.x + Math.cos(e.aim) * 340, e.y + Math.sin(e.aim) * 340); ctx.stroke(); }
        if (e.boss && e.state === 1 && e.aim != null) { ctx.strokeStyle = 'rgba(255,80,80,0.7)'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(e.x + Math.cos(e.aim) * 600, e.y + Math.sin(e.aim) * 600); ctx.stroke(); }
        const pxE = !!(window.SBPix && SBPix.on() && !e.boss && SBPix.hasEnemy(e.arch));      // ドット絵で描く敵
        const pxB = !!(window.SBPix && SBPix.on() && SBPix.drawBoss && e.boss);      // ドット絵で描くボス
        const mxf = (!e.boss && e.ma > 0); if (mxf) { ctx.save(); meleeBodyXf(e); }      // 攻撃モーション中の体の変形（溜め・伸び・のけぞり）
        ctx.fillStyle = fl ? '#fff' : (e.def.color || '#a44'); ctx.globalAlpha = 0.9; ctx.beginPath(); ctx.arc(e.x, e.y, e.r, 0, 7); if (!pxE && !pxB) ctx.fill(); ctx.globalAlpha = 1;
        if (pxB) SBPix.drawBoss(ctx, e.x, e.y, e.r, e.def.name, e.def.icon, e.def.color, { flash: fl, left: me.x < e.x });
        if (pxE) SBPix.drawEnemy(ctx, e.x, e.y, e.r, e.arch, e.def.color || '#a44', { flash: fl, left: me.x < e.x, seed: (e.id | 0) * 1.7, now: performance.now() });
        if (e.boss) { ctx.strokeStyle = '#ffd84a'; ctx.lineWidth = 3; ctx.stroke(); }
        if (e.inv) { ctx.strokeStyle = 'rgba(127,255,212,0.9)'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 9, 0, 7); ctx.stroke(); }
        if (GMK === 'dimension' && e.boss && !e.echo && G.dp === 1 && G.dc > 0) {      // 6つの核（周回）
            const tn = performance.now() / 1000;
            for (let i = 0; i < G.dc; i++) { const a = tn * 0.9 + i * Math.PI * 2 / 6, cx = e.x + Math.cos(a) * (e.r + 58), cy = e.y + Math.sin(a) * (e.r + 58);
                ctx.fillStyle = '#ff7aff'; ctx.beginPath(); ctx.arc(cx, cy, 13, 0, 7); ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.beginPath(); ctx.arc(cx - 3, cy - 3, 4, 0, 7); ctx.fill(); }
        }
        else if (e.elite) { ctx.strokeStyle = '#ff9a2a'; ctx.lineWidth = 4; ctx.stroke(); ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 6, 0, 7); ctx.globalAlpha = 0.5; ctx.stroke(); ctx.globalAlpha = 1; }
        ctx.font = Math.round(e.r * 1.25) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#000';
        if (!pxE && !pxB) ctx.fillText(e.def.icon, e.x, e.y + 1);
        if (mxf) ctx.restore();
        if (e.st && (e.st.burnT > 0)) ctx.fillText('🔥', e.x + e.r * 0.6, e.y - e.r * 0.8);
        if (e.st && (e.st.poisonT > 0)) ctx.fillText('☠', e.x - e.r * 0.6, e.y - e.r * 0.8);
        if (e.st && (e.st.slowT > 0)) ctx.fillText('❄', e.x, e.y - e.r * 1.1);
        if (e.st && (e.st.stunT > 0)) ctx.fillText('💫', e.x, e.y - e.r * 1.2);
        ctx.textBaseline = 'alphabetic';
        ctx.restore();
        if (!e.boss && e.ma > 1) drawMeleeFx(e);      // 攻撃のドット絵エフェクト（飲み込み・爪・叩きつけ…）
        if (SE && (e.boss || e.elite) && !e.pvp) {   // 弱点（×1.6）と耐性（×0.5）の属性
            const wk = SE.weakOf(e.def && e.def.name);
            ctx.font = '12px sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#fff';
            ctx.fillText('弱' + SE.ELEMS[wk.weak].icon + ' 耐' + SE.ELEMS[wk.resist].icon, e.x, e.y - e.r - 14); ctx.textAlign = 'start';
        }
        if ((!e.boss && e.hp < e.maxHp) || e.elite) { const w = e.r * 2; ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(e.x - w / 2, e.y - e.r - 9, w, 4); ctx.fillStyle = '#e44'; ctx.fillRect(e.x - w / 2, e.y - e.r - 9, w * Math.max(0, e.hp / e.maxHp), 4); }
    }

    // ---------- ドット絵のキャラ・武器 ----------
    let MY_AV = null; try { const pl = JSON.parse(localStorage.getItem('player') || 'null'); MY_AV = pl && pl.avatar ? pl.avatar : null; } catch (e) { MY_AV = null; }      // 自分のアバター設定（アバターカスタマイズの内容）
    function drawPlayerPixel(p, isMe, teamCol, rarC) {
        const now = performance.now(), a = p.ang || 0, ca = Math.cos(a), sa = Math.sin(a);
        const moved = Math.hypot(p.x - (p._px != null ? p._px : p.x), p.y - (p._py != null ? p._py : p.y)) > 0.35; p._px = p.x; p._py = p.y; if (moved) p._mvT = now;
        const moving = now - (p._mvT || 0) < 140;
        if (!p.dead && (isMe ? weapon.rarity : p.rar) === 'mythic') { const tt2 = performance.now() / 1000; ctx.globalAlpha = 0.35 + 0.2 * Math.sin(tt2 * 4); ctx.strokeStyle = rarC; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(p.x, p.y + 13, 22 + 2 * Math.sin(tt2 * 3), 9, 0, 0, 7); ctx.stroke(); ctx.globalAlpha = 1; }      // 神話の武器：足もとに輪
        // 足もとのチームの輪（味方・敵の見分け）
        ctx.strokeStyle = teamCol; ctx.lineWidth = 2; ctx.globalAlpha = 0.85; ctx.beginPath(); ctx.ellipse(p.x, p.y + 13, 15, 6, 0, 0, 7); ctx.stroke(); ctx.globalAlpha = (p.dead ? 0.35 : (isMe && me.inv > 0 && Math.floor(me.inv * 20) % 2 ? 0.45 : 1));
        const wt = isMe ? weapon.type : (p.wt || 'sword'), rar = isMe ? weapon.rarity : p.rar;
        if (!isMe && p.wm && HW.MYTHICS && HW.MYTHICS[p.wm]) rarC = HW.MYTHICS[p.wm].color;      // 仲間の神話の武器の色
        const swAt = isMe ? me.swingAt : p.swingAt, life = (isMe ? me.swingFin : p.swingFin) ? 320 : 220;
        const k = swAt ? (now - swAt) / life : -1, swinging = k >= 0 && k <= 1;
        const wo = { mythic: isMe ? weapon.mythicId : p.wm, custom: isMe ? MYPC : p.wpc, scale: 2, size: isMe ? (weapon.size || 1) : (p.wsz || 1), swing: swinging ? k : null, dir: (isMe ? me.swingDir : p.swingDir) || 1, fin: !!(isMe ? me.swingFin : p.swingFin), kind: swinging ? ((isMe ? me.swingKind : p.swingKind) || 'cone') : 'cone', glint: rar === 'legendary' || rar === 'mythic', alpha: p.dead ? 0.35 : null, now: now };
        const hx = p.x + ca * 7, hy = p.y + 3 + sa * 5, behind = sa < -0.35;
        if (!p.dead && behind) SBPix.drawWeapon(ctx, hx, hy, a, wt, rarC, wo);
        const av = isMe ? MY_AV : p.av;
        SBPix.drawPerson(ctx, p.x, p.y + 10, { avatar: av || null, cloth: av ? null : teamCol, hair: SBPix.hairOf(p.name), moving: moving, left: ca < 0, alpha: p.dead ? 0.35 : null, flash: isMe && me.flash > 0 && Math.floor(me.flash * 30) % 2 === 0, now: now });
        if (!p.dead && !behind) SBPix.drawWeapon(ctx, hx, hy, a, wt, rarC, wo);
    }

    function drawPlayer(p, isMe) {
        const rarC = isMe ? HW.rarityOf(weapon).color : (HW.RARITIES[p.rar] || HW.RARITIES.normal).color;
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(p.x, p.y + 12, 14, 6, 0, 0, 7); ctx.fill();
        ctx.globalAlpha = p.dead ? 0.35 : (isMe && me.inv > 0 && Math.floor(me.inv * 20) % 2 ? 0.45 : 1);
        const teamCol = isMe ? '#4a9eff' : ((TEAM && run.pvpMode && !sameTeam(p.id)) ? '#ff6a6a' : '#4adb9a');
        if (window.SBPix && SBPix.on()) drawPlayerPixel(p, isMe, teamCol, rarC);
        else {
            ctx.fillStyle = teamCol; ctx.beginPath(); ctx.arc(p.x, p.y, 15, 0, 7); ctx.fill();
        ctx.lineWidth = 3; ctx.strokeStyle = rarC; ctx.stroke();
        const a = p.ang || 0; ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + Math.cos(a) * 24, p.y + Math.sin(a) * 24); ctx.stroke();
        }
        ctx.globalAlpha = 1;
        ctx.font = 'bold 12px sans-serif'; ctx.textAlign = 'center'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,0.8)'; const ttl = isMe ? ((window.SBAch && SBAch.titleText()) || '') : (p.ti || ''); if (ttl) { ctx.font = 'bold 10px sans-serif'; ctx.strokeText(ttl, p.x, p.y - 41); ctx.fillStyle = '#ffd86a'; ctx.fillText(ttl, p.x, p.y - 41); ctx.font = 'bold 12px sans-serif'; ctx.fillStyle = '#fff'; }
        ctx.strokeText(p.name, p.x, p.y - 28); ctx.fillStyle = '#fff'; ctx.fillText(p.name, p.x, p.y - 28);
        const hp = isMe ? me.hp / me.maxHp : (p.hp / Math.max(1, p.maxHp));
        ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(p.x - 18, p.y - 24, 36, 5); ctx.fillStyle = hp > 0.3 ? '#4adb6a' : '#ff5a5a'; ctx.fillRect(p.x - 18, p.y - 24, 36 * clamp(hp, 0, 1), 5);
        if (isMe && me.shield) { ctx.strokeStyle = '#9fe0ff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(p.x, p.y, 22, 0, 7); ctx.stroke(); }
        if (p.dead) { ctx.font = '16px sans-serif'; ctx.fillText('💀', p.x, p.y + 5); }
        const orb = isMe ? me.orb : p.orb;
        if (orb && !p.dead) {
            const base = performance.now() / 1000 * (orb.spin || 4.2);
            for (let i = 0; i < orb.n; i++) {
                const a = base + i * Math.PI * 2 / orb.n, ox = p.x + Math.cos(a) * orb.r, oy = p.y + Math.sin(a) * orb.r;
                ctx.fillStyle = 'rgba(157,240,255,0.35)'; ctx.beginPath(); ctx.arc(ox, oy, 17, 0, 7); ctx.fill();
                ctx.fillStyle = '#9df0ff'; ctx.beginPath(); ctx.arc(ox, oy, 9, 0, 7); ctx.fill();
                ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ox, oy, 4, 0, 7); ctx.fill();
            }
        }
        if (!p.dead && (isMe ? me.stunT > 0 : p.stun)) { ctx.font = '20px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('💫', p.x + Math.cos(performance.now() / 120) * 8, p.y - 40); }
    }

    // ---------- ドット絵風のエフェクト（4px の粒だけで描く）----------
    const PXS = 4;
    function pxDot(c, x, y) { c.fillRect(Math.round(x / PXS) * PXS - PXS / 2, Math.round(y / PXS) * PXS - PXS / 2, PXS, PXS); }
    function drawPSlashRaw(c, f, k) {      // 三日月型の斬撃。振り始めから振り終わりへ、弧が描かれていく
        const head = Math.min(1, k * 2.4), fade = Math.max(0, 1 - Math.max(0, k - 0.5) * 2), sa = f.a - f.dir * f.arc / 2;
        const cols = [shade(f.c, -0.5), f.c, shade(f.c, 0.5), '#ffffff'];
        const passes = (f.fin && !(window.SBPix && SBPix.lite)) ? [1, 0.7] : [1];
        passes.forEach((sc, pi) => {
            const R = f.rng * sc, n = Math.max(10, Math.round(f.arc * R / PXS / 1.3));
            for (let i = 0; i <= n; i++) {
                const u = i / n; if (u > head) break;
                const age = head - u; if (age > 0.6) continue;
                c.globalAlpha = fade * (pi ? 0.65 : 1) * (1 - Math.max(0, age - 0.2) / 0.5);
                const an = sa + f.dir * f.arc * u, cx = Math.cos(an), cy = Math.sin(an);
                const th = R * (f.fin ? 0.5 : 0.36) * Math.pow(Math.sin(Math.PI * Math.min(1, u * 0.92 + 0.04)), 0.7), outer = R * (0.88 + 0.12 * Math.sin(Math.PI * u)), inner = outer - th;
                for (let r = inner; r <= outer; r += PXS) {
                    const band = (r - inner) / Math.max(1, th);
                    c.fillStyle = band > 0.82 ? cols[3] : (band > 0.55 ? cols[2] : (band > 0.2 ? cols[1] : cols[0]));
                    pxDot(c, f.x + cx * r, f.y + cy * r);
                }
            }
        });
        c.globalAlpha = 1;
    }
    function drawPThrustRaw(c, f, k) {      // 突きの衝撃：先端が伸びていく細長い光
        const head = Math.min(1, k * 3.2), fade = Math.max(0, 1 - Math.max(0, k - 0.45) * 1.9), cx = Math.cos(f.a), cy = Math.sin(f.a), px = -cy, py = cx;
        const cols = [shade(f.c, -0.4), f.c, shade(f.c, 0.55), '#ffffff'];
        for (let sd = 0; sd <= f.rng * head; sd += PXS) {
            const u = sd / f.rng, hw = Math.max(1, Math.round((f.w * 0.32) * (1 - 0.7 * u) / PXS));
            c.globalAlpha = fade * (1 - Math.max(0, head - u - 0.25) * 1.2);
            for (let o = -hw; o <= hw; o++) {
                const q = Math.abs(o) / Math.max(1, hw);
                c.fillStyle = q > 0.75 ? cols[0] : (q > 0.4 ? cols[1] : (q > 0.1 ? cols[2] : cols[3]));
                pxDot(c, f.x + cx * sd + px * o * PXS, f.y + cy * sd + py * o * PXS);
            }
        }
        c.globalAlpha = 1;
    }
    function drawPRingRaw(c, f, k) {      // 衝撃波：粒で描いた輪が広がる
        const r = f.max * Math.min(1, k * 1.4), n = Math.max(12, Math.round(Math.PI * 2 * r / PXS / 1.2)), fade = Math.max(0, 1 - k);
        c.globalAlpha = fade * (f.fill ? 0.28 : 0); if (f.fill) { c.fillStyle = f.c; c.beginPath(); c.arc(f.x, f.y, r, 0, 7); c.fill(); }
        c.globalAlpha = fade;
        for (let i = 0; i < n; i++) {
            const an = i / n * Math.PI * 2; c.fillStyle = (i % 3 === 0) ? '#ffffff' : f.c;
            pxDot(c, f.x + Math.cos(an) * r, f.y + Math.sin(an) * r); if (r > 16) { c.fillStyle = shade(f.c, -0.4); pxDot(c, f.x + Math.cos(an) * (r - PXS), f.y + Math.sin(an) * (r - PXS)); }
        }
        c.globalAlpha = 1;
    }
    // 斬撃・突き・衝撃波は、同じ形を何度も計算して描くと重いので、「時間の8コマ」だけ一度描いて、使い回す
    const FXC = {}; let fxCount = 0;
    function fxCached(key, W, H, drawFn) {
        let cv = FXC[key];
        if (!cv) { if (++fxCount > 180) { for (const k in FXC) delete FXC[k]; fxCount = 1; } cv = document.createElement('canvas'); cv.width = W; cv.height = H; drawFn(cv.getContext('2d')); FXC[key] = cv; }
        return cv;
    }
    const LITE = () => !!(window.SBPix && SBPix.lite);
    function drawPSlash(f, k) {
        const q = Math.min(7, Math.floor(k * 8)), R = Math.ceil((f.rng + 8) / 4) * 4;
        const cv = fxCached('s|' + Math.round(f.rng / 4) + '|' + Math.round(f.arc * 10) + '|' + f.dir + '|' + (f.fin ? 1 : 0) + '|' + f.c + '|' + q + '|' + (LITE() ? 1 : 0), R * 2, R * 2, g => { g.translate(R, R); drawPSlashRaw(g, { x: 0, y: 0, a: 0, rng: f.rng, arc: f.arc, dir: f.dir, fin: f.fin, c: f.c }, (q + 0.5) / 8); });
        ctx.save(); ctx.translate(f.x, f.y); ctx.rotate(f.a); ctx.drawImage(cv, -R, -R); ctx.restore();
    }
    function drawPThrust(f, k) {
        const q = Math.min(7, Math.floor(k * 8)), L = Math.ceil((f.rng + 12) / 4) * 4, H = Math.max(24, Math.ceil((f.w * 0.34 + 10) / 4) * 8);
        const cv = fxCached('t|' + Math.round(f.rng / 8) + '|' + Math.round(f.w) + '|' + f.c + '|' + q, L, H, g => { g.translate(0, H / 2); drawPThrustRaw(g, { x: 0, y: 0, a: 0, rng: f.rng, w: f.w, fin: f.fin, c: f.c }, (q + 0.5) / 8); });
        ctx.save(); ctx.translate(f.x, f.y); ctx.rotate(f.a); ctx.drawImage(cv, 0, -H / 2); ctx.restore();
    }
    function drawPRing(f, k) {
        const q = Math.min(7, Math.floor(k * 8)), R = Math.ceil((f.max + 12) / 4) * 4;
        const cv = fxCached('r|' + Math.round(f.max / 8) + '|' + f.c + '|' + (f.fill ? 1 : 0) + '|' + q, R * 2, R * 2, g => { g.translate(R, R); drawPRingRaw(g, { x: 0, y: 0, max: f.max, c: f.c, fill: f.fill }, (q + 0.5) / 8); });
        ctx.drawImage(cv, Math.round(f.x / 4) * 4 - R, Math.round(f.y / 4) * 4 - R);
    }


    // スキルなどの効果を、ドット絵の見た目で描く（描いたら true）
    function drawFxPixel(f, k) {
        const q = PXS;
        if (f.k === 'arc') { drawPSlash({ x: f.x, y: f.y, a: f.a, rng: f.rng, arc: f.arc, dir: 1, fin: false, c: f.c }, Math.min(1, k * 1.15)); return true; }
        if (f.k === 'line') { const L = Math.hypot(f.x2 - f.x, f.y2 - f.y); drawPThrust({ x: f.x, y: f.y, a: Math.atan2(f.y2 - f.y, f.x2 - f.x), rng: L, w: Math.max(16, (f.w || 4) * 2), fin: false, c: f.c }, k); return true; }
        if (f.k === 'ring') { drawPRing(f, k); return true; }
        if (f.k === 'puff') { ctx.fillStyle = f.c; for (let i = 0; i < 6; i++) { const an = i * 1.047 + f.x * 0.01, rr = 6 + k * 22, z = Math.max(4, Math.round(10 * (1 - k * 0.7) / 2) * 2); ctx.fillRect(Math.round((f.x + Math.cos(an) * rr) / 2) * 2 - z / 2, Math.round((f.y + Math.sin(an) * rr) / 2) * 2 - z / 2, z, z); } return true; }
        if (f.k === 'bolt') {
            const w = Math.max(4, Math.round(f.w * (1.2 - k * 0.7) / 2) * 2);
            for (let pass = 0; pass < 2; pass++) {
                ctx.fillStyle = pass ? '#ffffff' : f.c; const z = pass ? Math.max(2, Math.round(w * 0.4 / 2) * 2) : w;
                for (let i = 1; i < f.pts.length; i++) { const a = f.pts[i - 1], b = f.pts[i], L = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.max(1, Math.ceil(L / q)); for (let j = 0; j <= n; j++) ctx.fillRect(Math.round((a[0] + (b[0] - a[0]) * j / n) / 2) * 2 - z / 2, Math.round((a[1] + (b[1] - a[1]) * j / n) / 2) * 2 - z / 2, z, z); }
            }
            ctx.globalAlpha = 1; return true;
        }
        if (f.k === 'spark') { ctx.fillStyle = f.c; const z = Math.max(2, Math.round(f.sz * (1 - k * 0.7) * 1.6 / 2) * 2); ctx.fillRect(Math.round(f.x / 2) * 2 - z / 2, Math.round(f.y / 2) * 2 - z / 2, z, z); return true; }
        if (f.k === 'warn') { ctx.fillStyle = f.c; const n = Math.max(8, Math.floor(Math.PI * 2 * f.r / 10)); for (let i = 0; i < n; i += 2) { const an = i / n * Math.PI * 2; ctx.fillRect(Math.round((f.x + Math.cos(an) * f.r) / 2) * 2 - 2, Math.round((f.y + Math.sin(an) * f.r) / 2) * 2 - 2, 4, 4); } return true; }
        return false;
    }
    // ゲートキーパーの「門」：開く→しばらく光る→閉じる。金色の輪と、回る光の粒
    function drawGateFx(f) {
        const el = f.life - f.t, open = Math.min(1, el / 0.3), close = Math.min(1, f.t / 0.4), sc = open * (0.6 + 0.4 * close), now = performance.now() / 1000, R = 38 * sc;
        if (R < 3) return;
        ctx.save(); ctx.translate(f.x, f.y); ctx.globalAlpha = Math.min(1, close) * 0.95;
        ctx.fillStyle = 'rgba(255,214,110,0.22)'; ctx.beginPath(); ctx.arc(0, 0, R, 0, 7); ctx.fill();
        const n = 16; for (let i = 0; i < n; i++) { const an = i / n * Math.PI * 2; ctx.fillStyle = i % 4 === 0 ? '#fff6d0' : '#ffd36a'; ctx.fillRect(Math.round(Math.cos(an) * R / 2) * 2 - 2, Math.round(Math.sin(an) * R / 2) * 2 - 2, 4, 4); }
        for (let i = 0; i < 6; i++) { const an = i / 6 * Math.PI * 2 + now * 1.8; ctx.fillStyle = '#ffffff'; ctx.fillRect(Math.round(Math.cos(an) * R * 0.62 / 2) * 2 - 2, Math.round(Math.sin(an) * R * 0.62 / 2) * 2 - 2, 4, 4); }
        ctx.restore(); ctx.globalAlpha = 1;
    }
    // 隕石：空から落ちてくる火の玉（ドットの玉＋尾）。着地点には、広がる目印の輪
    function drawMeteorFx(f) {
        const k = 1 - f.t / f.life, x = f.sx + (f.x - f.sx) * k, y = f.sy + (f.y - f.sy) * k, dx = f.x - f.sx, dy = f.y - f.sy, L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L;
        const rr = f.r * (0.35 + 0.65 * k), n = Math.max(8, Math.floor(rr / 5));
        ctx.globalAlpha = 0.85; ctx.fillStyle = '#ffe9a0'; for (let i = 0; i < n; i++) { const an = i / n * Math.PI * 2; ctx.fillRect(Math.round((f.x + Math.cos(an) * rr) / 2) * 2 - 2, Math.round((f.y + Math.sin(an) * rr * 0.6) / 2) * 2 - 2, 4, 4); }
        for (let i = 9; i >= 1; i--) { ctx.globalAlpha = 0.5 * (1 - i / 10); ctx.fillStyle = i < 4 ? '#ffd36a' : '#ff8a3a'; const z = Math.max(4, 16 - i), px = Math.round((x - ux * i * 11) / 2) * 2, py = Math.round((y - uy * i * 11) / 2) * 2; ctx.fillRect(px - z / 2, py - z / 2, z, z); }
        ctx.globalAlpha = 1; const hx = Math.round(x / 2) * 2, hy = Math.round(y / 2) * 2; ctx.fillStyle = '#ff7a2a'; ctx.fillRect(hx - 9, hy - 9, 18, 18); ctx.fillStyle = '#ffd36a'; ctx.fillRect(hx - 6, hy - 6, 12, 12); ctx.fillStyle = '#ffffff'; ctx.fillRect(hx - 3, hy - 3, 6, 6);
    }
    function drawFx(f) {
        if (f.k === 'gate') { drawGateFx(f); return; }
        if (f.k === 'meteor') { drawMeteorFx(f); return; }
        const k = 1 - f.t / f.life;
        ctx.globalAlpha = Math.max(0, 1 - k);
        if (window.SBPix && SBPix.on() && drawFxPixel(f, k)) { ctx.globalAlpha = 1; return; }
        if (f.k === 'arc') { ctx.fillStyle = f.c; ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.arc(f.x, f.y, f.rng, f.a - f.arc / 2, f.a + f.arc / 2); ctx.closePath(); ctx.globalAlpha *= 0.45; ctx.fill(); }
        else if (f.k === 'line') { ctx.strokeStyle = f.c; ctx.lineWidth = f.w || 4; ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.lineTo(f.x2, f.y2); ctx.stroke(); }
        else if (f.k === 'ring') { const r = f.max * Math.min(1, k * 1.4); ctx.strokeStyle = f.c; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(f.x, f.y, r, 0, 7); if (f.fill) { ctx.globalAlpha *= 0.3; ctx.fillStyle = f.c; ctx.fill(); ctx.globalAlpha = Math.max(0, 1 - k); } ctx.stroke(); }
        else if (f.k === 'pslash') drawPSlash(f, k);
        else if (f.k === 'pthrust') drawPThrust(f, k);
        else if (f.k === 'pring') drawPRing(f, k);
        else if (f.k === 'pspark') { ctx.fillStyle = f.c; const z = f.sz * (1 - k * 0.5); ctx.fillRect(Math.round(f.x / 4) * 4 - z / 2, Math.round(f.y / 4) * 4 - z / 2, z, z); }
        else if (f.k === 'puff') { ctx.fillStyle = f.c; ctx.beginPath(); ctx.arc(f.x, f.y, 8 + k * 22, 0, 7); ctx.globalAlpha *= 0.4; ctx.fill(); }
        else if (f.k === 'bolt') { ctx.strokeStyle = f.c; ctx.lineWidth = f.w * (1.2 - k * 0.7); ctx.beginPath(); f.pts.forEach((q, i) => { if (i) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); }); ctx.stroke(); ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(1, f.w * 0.35); ctx.stroke(); ctx.globalAlpha = 1; }
        else if (f.k === 'spark') { ctx.fillStyle = f.c; const z = f.sz * (1 - k * 0.7); ctx.beginPath(); ctx.arc(f.x, f.y, Math.max(0.5, z), 0, 7); ctx.fill(); }
        else if (f.k === 'warn') { ctx.strokeStyle = f.c; ctx.lineWidth = 3; ctx.setLineDash([6, 5]); ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
        ctx.globalAlpha = 1;
    }

    // ---------- HUD ----------
    const el = id => document.getElementById(id);
    function drawHUD() {
        // 溜め・バリアの表示（自分の頭上のゲージ／足もとの輪）と、仲間のバリア
        {
            const msx = VW / 2 + (me.x - cam.x), msy = VH / 2 + (me.y - cam.y), tt = performance.now() / 1000;
            const gauge = (frac, col, label) => {
                const w = 64, x0 = msx - w / 2, y0 = msy - 58;
                ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(x0 - 2, y0 - 2, w + 4, 9); ctx.fillStyle = col; ctx.fillRect(x0, y0, w * Math.max(0, Math.min(1, frac)), 5);
                ctx.font = 'bold 10px sans-serif'; ctx.textAlign = 'center'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,0.8)'; ctx.strokeText(label, msx, y0 - 5); ctx.fillStyle = '#fff'; ctx.fillText(label, msx, y0 - 5);
            };
            const ring = (r, col, alpha, lw) => { ctx.globalAlpha = alpha; ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.beginPath(); ctx.arc(msx, msy, r, 0, Math.PI * 2); ctx.stroke(); ctx.globalAlpha = 1; };
            if (!PVP && !me.dead) {      // 必殺ゲージ（足もとの小さなバー）
                const uf = (me.ult || 0) / ULT_MAX, w = 48, x0 = msx - w / 2, y0 = msy + 26, full = uf >= 1;
                ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(x0 - 2, y0 - 2, w + 4, 8);
                ctx.fillStyle = full ? (Math.floor(tt * 6) % 2 ? '#fff2a8' : '#ffd84a') : '#c9a227'; ctx.fillRect(x0, y0, w * uf, 4);
                if (full) { ctx.font = 'bold 10px sans-serif'; ctx.textAlign = 'center'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.8)'; ctx.strokeText('R 必殺技！', msx, y0 + 18); ctx.fillStyle = '#ffd84a'; ctx.fillText('R 必殺技！', msx, y0 + 18); }
                const bu = document.getElementById('btnUlt'); if (bu) { const txt = full ? '⚡必殺' : '⚡' + Math.floor(uf * 100) + '%'; if (bu.textContent !== txt) bu.textContent = txt; bu.style.opacity = full ? '1' : '0.55'; }
            }
            if (ultFlashT > 0) { ctx.globalAlpha = Math.min(0.5, ultFlashT * 1.6); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, VW, VH); ctx.globalAlpha = 1; }
            if (me.cast && !me.dead) {
                const f = 1 - me.cast.t / me.cast.max;
                ring(60 - 40 * f, '#ffe08a', 0.35 + 0.5 * f, 3); ring(20 + 14 * Math.sin(tt * 18), '#fff2b8', 0.5, 2);
                gauge(f, '#ffe08a', '溜め ' + (CHARGE_NAME[me.cast.form] || ''));
            }
            if (me.gch > 0 && !me.dead) {
                const f = me.gch / GUARD_CHARGE;
                ring(70 - 45 * f, '#8fe8ff', 0.3 + 0.5 * f, 3);
                gauge(f, '#8fe8ff', '🛡 バリアを溜めている… ' + Math.max(0, GUARD_CHARGE - me.gch).toFixed(1));
            }
            if (me.guardT > 0 && !me.dead) {
                const f = me.guardT / GUARD_SEC;
                ctx.fillStyle = 'rgba(143,232,255,0.16)'; ctx.beginPath(); ctx.arc(msx, msy, 38, 0, Math.PI * 2); ctx.fill();
                ring(38 + 2 * Math.sin(tt * 10), '#8fe8ff', 0.85, 3);
                ctx.globalAlpha = 0.9; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(msx, msy, 44, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * f); ctx.stroke(); ctx.globalAlpha = 1;
            }
            Object.keys(allies).forEach(id => {
                const a = allies[id]; if (!a.g || a.dead) return;
                const ax = VW / 2 + (a.x - cam.x), ay = VH / 2 + (a.y - cam.y);
                ctx.fillStyle = 'rgba(143,232,255,0.14)'; ctx.beginPath(); ctx.arc(ax, ay, 36, 0, Math.PI * 2); ctx.fill();
                ctx.globalAlpha = 0.8; ctx.strokeStyle = '#8fe8ff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(ax, ay, 36 + 2 * Math.sin(tt * 10), 0, Math.PI * 2); ctx.stroke(); ctx.globalAlpha = 1;
            });
        }
        // 通信の状態（Ping と接続方式）：マルチのカクつきの原因を見分けるため、右上に小さく出す
        if (socket && room) {
            const nowP = performance.now();
            if (!netPingBusy && nowP - netPingT > 3000 && socket.connected) {
                netPingBusy = true; netPingT = nowP; const t0 = nowP;
                try { socket.timeout(4000).emit('stage:ping', t0, (err) => { netPingBusy = false; netPing = err ? -1 : Math.round(performance.now() - t0); }); } catch (e) { netPingBusy = false; }
            }
            let tr = ''; try { tr = socket.io && socket.io.engine && socket.io.engine.transport ? (socket.io.engine.transport.name === 'websocket' ? 'WS' : 'poll') : ''; } catch (e) { tr = ''; }
            ctx.font = '10px sans-serif'; ctx.textAlign = 'right'; ctx.fillStyle = netPing < 0 ? '#ff8a8a' : (netPing < 80 ? '#8affb0' : (netPing < 160 ? '#ffe08a' : '#ff8a8a'));
            ctx.fillText((netPing < 0 ? 'Ping --' : 'Ping ' + netPing + 'ms') + '　' + Math.round(1 / Math.max(0.005, perfEma)) + 'fps' + (tr ? ' ' + tr : ''), VW - 10, VH < 520 ? 28 : 48);
        }
        // ミニマップ
        const mw = VH < 520 ? 92 : 140, mh = Math.round(mw * WORLD_H / WORLD_W), mx = VW - mw - 10, my = VH < 520 ? 34 : 56;
        ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(mx, my, mw, mh);
        const sx = mw / WORLD_W, sy = mh / WORLD_H;
        if (CORR_ON) corrDrawMini(mx, my, sx, sy);
        enemies.forEach(e => { if (e.pvp) return; ctx.fillStyle = e.boss ? '#ffd84a' : '#ff6a5a'; ctx.fillRect(mx + e.x * sx - 1, my + e.y * sy - 1, e.boss ? 5 : 2, e.boss ? 5 : 2); });
        Object.keys(allies).forEach(id => { ctx.fillStyle = (TEAM && run.pvpMode && !sameTeam(id)) ? '#ff6a6a' : '#4adb9a'; ctx.fillRect(mx + allies[id].x * sx - 2, my + allies[id].y * sy - 2, 4, 4); });
        ctx.fillStyle = '#4a9eff'; ctx.fillRect(mx + me.x * sx - 2, my + me.y * sy - 2, 4, 4);
        // タッチスティック
        [input.stick, input.aimStick].forEach(st => { if (st.id === null) return; ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(st.ox, st.oy, 56, 0, 7); ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.arc(st.ox + st.x * 56, st.oy + st.y * 56, 24, 0, 7); ctx.fill(); });
        // スタン表示（動けない時間と、復帰後のスタン耐性）
        if (me.stunT > 0 && !me.dead) {
            ctx.fillStyle = 'rgba(255,225,80,0.12)'; ctx.fillRect(0, 0, VW, VH);
            const big = VH < 520 ? 24 : 34, txt = '💫 スタン中… ' + me.stunT.toFixed(1) + '秒';
            ctx.textAlign = 'center'; ctx.font = 'bold ' + big + 'px sans-serif'; ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(0,0,0,0.85)';
            ctx.strokeText(txt, VW / 2, VH * 0.3); ctx.fillStyle = '#ffe14a'; ctx.fillText(txt, VW / 2, VH * 0.3);
            ctx.font = 'bold ' + Math.round(big * 0.45) + 'px sans-serif'; ctx.lineWidth = 3;
            ctx.strokeText('動けない・攻撃も回避もできない（クイズは解けます）', VW / 2, VH * 0.3 + big * 0.9); ctx.fillStyle = '#fff'; ctx.fillText('動けない・攻撃も回避もできない（クイズは解けます）', VW / 2, VH * 0.3 + big * 0.9);
        } else if (me.stunImm > 0 && !me.dead) {
            ctx.textAlign = 'center'; ctx.font = 'bold 13px sans-serif'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,0.8)';
            const t2 = '⚡ スタン耐性 ' + me.stunImm.toFixed(1); ctx.strokeText(t2, VW / 2, VH - 150); ctx.fillStyle = '#ffe14a'; ctx.fillText(t2, VW / 2, VH - 150);
        }
        // 対人戦：サドンデスの表示（時間とともに攻撃力が上がり、防御・回復が下がる）と、自分の総合ダメージ量
        if (PVP && run.pvpMode && run.phase === 'run') {
            const prog = sdProg(), am = sdAtkMul(), left = Math.max(0, TIME_LIMIT - run.time);
            const t1 = run.time < SD.start ? ('サドンデスまで ' + Math.ceil(SD.start - run.time) + '秒') : ('⚠ サドンデス　攻撃 ×' + am.toFixed(1) + ' / 防御 -' + Math.round(prog * 100) + '% / 回復 -' + Math.round((1 - Math.max(SD.healMin, 1 - prog)) * 100) + '%');
            const t2 = '与ダメージ合計 ' + Math.round(dmgOf(myId)) + '%　　残り ' + Math.floor(left / 60) + ':' + String(Math.floor(left % 60)).padStart(2, '0');
            ctx.save(); ctx.textAlign = 'center'; ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,0.85)'; ctx.font = 'bold 15px sans-serif';
            ctx.strokeText(t1, VW / 2, 92); ctx.fillStyle = run.time < SD.start ? '#cfe6ff' : (prog > 0.6 ? '#ff6a6a' : '#ffb347'); ctx.fillText(t1, VW / 2, 92);
            ctx.font = 'bold 13px sans-serif'; ctx.strokeText(t2, VW / 2, 112); ctx.fillStyle = '#fff'; ctx.fillText(t2, VW / 2, 112);
            ctx.restore();
        }
        // ボスラッシュ：幕間の表示／無限回廊：階の切り替わりの暗転
        if (RUSH_ON && run.phase === 'run' && RS.st === 2) {
            ctx.save(); ctx.textAlign = 'center'; ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(0,0,0,0.85)';
            const t1 = '🏆 ' + rushPd(RS.ph).label + ' クリア！', t2 = RS.ph < RUSHD.phases.length ? ('次：' + rushPd(RS.ph + 1).label + (rushPd(RS.ph + 1).final ? '（強化ディメンション・キーパー）' : '（第' + rushPd(RS.ph + 1).world + '世界のボス）') + '　' + Math.max(0, Math.ceil(RS.inter)) + '秒') : '';
            ctx.font = 'bold 30px sans-serif'; ctx.strokeText(t1, VW / 2, VH * 0.3); ctx.fillStyle = '#ffe08a'; ctx.fillText(t1, VW / 2, VH * 0.3);
            ctx.font = 'bold 16px sans-serif'; ctx.strokeText(t2, VW / 2, VH * 0.3 + 30); ctx.fillStyle = '#fff'; ctx.fillText(t2, VW / 2, VH * 0.3 + 30); ctx.restore();
        }
        if (CORR_ON && CF.fade > 0) { ctx.fillStyle = 'rgba(0,0,0,' + Math.min(1, CF.fade * 1.6) + ')'; ctx.fillRect(0, 0, VW, VH); }
        // 復活ゲージ
        if (me.dead) { ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(0, 0, VW, VH); ctx.fillStyle = '#fff'; ctx.font = 'bold 22px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('倒れています…仲間の復活を待っています', VW / 2, VH / 2); }
        // 上部情報
        const hpR = clamp(me.hp / me.maxHp, 0, 1);
        el('hpFill').style.width = (hpR * 100) + '%'; el('hpText').textContent = Math.ceil(me.hp) + ' / ' + me.maxHp;
        const mm = Math.floor(run.time / 60), ss = String(Math.floor(run.time % 60)).padStart(2, '0');
        el('timer').textContent = '⏱ ' + mm + ':' + ss;
        if (RUSH_ON && RS.st === 1) { const rl = Math.max(0, RS.limit - RS.t); el('timer').textContent = '⏱ ' + Math.floor(rl / 60) + ':' + String(Math.floor(rl % 60)).padStart(2, '0'); }
        if (CORR_ON && !run.bossSpawned) {
            let seen = 0; if (CF.seen) for (let i = 0; i < CF.seen.length; i++) seen += CF.seen[i];
            const gt = CF.props.find(q => q.k === 'gate'), gOk = gt && CF.seen && CF.seen[gt.c]; el('prog').textContent = '🌀 地下' + CF.floor + '階　探索 ' + seen + '/' + (CF.cols * CF.rows) + '　脱出ゲート：' + (gOk ? '発見！' : '未発見'); el('progFill').style.width = (CF.seen ? seen / (CF.cols * CF.rows) * 100 : 0) + '%'; el('challengeBar').style.display = 'none';
        } else if (AMB_ON && !run.bossSpawned) { el('prog').textContent = '⚔ 第' + (G.aw || 1) + '波 / ' + AMB_WAVES; el('progFill').style.width = (Math.min(1, AM.t / (AMB_WAVES * AMB_WAVE_SEC)) * 100) + '%'; el('challengeBar').style.display = 'none';
        } else if (!run.bossSpawned) { el('prog').textContent = '解答 ' + Math.min(run.kills, run.need) + ' / ' + run.need; el('progFill').style.width = (Math.min(1, run.kills / run.need) * 100) + '%'; el('challengeBar').style.display = 'none'; }
        else {
            el('prog').textContent = '最終問題'; el('progFill').style.width = '100%';
            if (RUSH_ON) { const bs0 = enemies.filter(x => x.boss && !x.echo); let hp0 = 0, mh0 = 0; bs0.forEach(x => { hp0 += Math.max(0, x.hp); mh0 += x.maxHp; }); el('prog').textContent = '🏆 ' + rushPd(Math.max(1, RS.ph)).label + '　' + DIFF.name; el('progFill').style.width = (mh0 ? hp0 / mh0 * 100 : 0) + '%'; }
            else if (CORR_ON) el('prog').textContent = '👹 チャレンジ部屋　地下' + CF.floor + '階';
            const bs = enemies.filter(e => e.boss), b = bs.find(x => !x.echo) || bs[0];
            if (GMK === 'increase' && bs.length) {      // 増殖スライム：全員ぶんの体力を1本にまとめる／心臓が出たら心臓
                const sl = bs.filter(x => x.arch === 'slime'), ht = bs.find(x => x.arch === 'heart'); let hp0 = 0, mh0 = 0; sl.forEach(x => { hp0 += Math.max(0, x.hp); mh0 += x.maxHp; });
                el('challengeBar').style.display = 'block'; el('challengeName').textContent = ht ? '❤ 増殖の心臓　（一撃で勝ち）' : '🟢 増殖スライム インクリーズ　×' + sl.length;
                el('challengeFill').style.width = (ht ? 100 : (mh0 ? clamp(hp0 / mh0 * 100, 0, 100) : 0)) + '%';
                const bx0 = document.getElementById('challengeExtra'); if (bx0 && bx0.innerHTML) { bx0.innerHTML = ''; bx0.dataset.sig = ''; }
            } else if (b) {
                el('challengeBar').style.display = 'block'; el('challengeName').textContent = (b.def.name || stage.boss.name) + (SE ? '　弱点' + SE.ELEMS[SE.weakOf(b.def.name).weak].icon + ' 耐性' + SE.ELEMS[SE.weakOf(b.def.name).resist].icon : ''); el('challengeFill').style.width = (clamp(b.hp / b.maxHp, 0, 1) * 100) + '%';
                const ex = bs.filter(x => x !== b).map(x => '<div style="font-size:.7rem;margin-top:3px;text-shadow:0 0 4px #000">' + (x.echo ? '🚪 ' : '') + x.def.name + '<div style="height:5px;background:rgba(0,0,0,.6);border-radius:3px;overflow:hidden"><div style="height:100%;width:' + Math.round(clamp(x.hp / x.maxHp, 0, 1) * 100) + '%;background:' + (x.echo ? '#7fffd4' : '#ff5a8a') + '"></div></div></div>').join('');
                let bx = document.getElementById('challengeExtra'); if (!bx) { bx = document.createElement('div'); bx.id = 'challengeExtra'; el('challengeBar').appendChild(bx); }
                if (bx.dataset.sig !== ex) { bx.dataset.sig = ex; bx.innerHTML = ex; }
            } else el('challengeBar').style.display = 'none';
            const gt = gmHudText(); let gh = document.getElementById('gmHud');
            if (!gh) { gh = document.createElement('div'); gh.id = 'gmHud'; gh.style.cssText = 'position:fixed;top:calc(max(8px,env(safe-area-inset-top)) + 52px);left:50%;transform:translateX(-50%);z-index:6;pointer-events:none;font-weight:bold;font-size:.82rem;color:#fff;background:rgba(20,10,30,.72);border:1px solid #c090ff;border-radius:8px;padding:4px 10px;text-shadow:0 0 4px #000;white-space:nowrap;display:none'; document.body.appendChild(gh); }
            gh.style.display = gt ? 'block' : 'none'; if (gt && gh.textContent !== gt) gh.textContent = gt;
        }
    }
    function updateEnergyUI() { el('enFill').style.width = (me.energy / ENERGY_MAX * 100) + '%'; el('enText').textContent = 'ENERGY ' + Math.round(me.energy) + ' / ' + ENERGY_MAX; if (skillSlots.length) updateSkillBar(); }
    let annTimer = 0;
    function announce(text, ms) { const a = el('announce'); a.textContent = text; a.classList.add('show'); clearTimeout(annTimer); annTimer = setTimeout(() => a.classList.remove('show'), ms || 2000); }
    function refreshLootLog() {
        const box = el('lootLog');
        box.innerHTML = run.stats.loot.slice(-5).map(w => '<div style="color:' + HW.rarityOf(w).color + '">' + (w.kind === 'armor' ? '🛡 ' : '✦ ') + escapeHtml(w.name) + '</div>').join('');
    }
    function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

    // ---------- 待機室 ----------
    function showWaitMsg(t) { const m = el('waitMsg'); if (m) m.textContent = t; }
    function renderWait() {
        const w = el('waitRoom'); w.style.display = 'flex';
        el('waitTitle').textContent = stage.icon + ' ' + stage.name + ' [' + DIFF.name + ']';
        el('waitCode').textContent = room ? ('ルームID: ' + room.id) : '';
        el('waitMembers').innerHTML = room ? room.members.map((m, i) => '<div class="mem">' + (TEAM ? (i % 2 === 0 ? '🔵 ' : '🔴 ') : '') + (m.id === room.hostId ? '👑 ' : '') + escapeHtml(m.name) + '<small> ' + escapeHtml(m.wname || '') + '</small></div>').join('') : '';
        const startBtn = el('waitStart');
        startBtn.style.display = isHost ? 'inline-block' : 'none';
        showWaitMsg(isHost ? (TEAM ? ('チーム戦 ' + TEAM + 'v' + TEAM + '：参加した順に 青・赤・青・赤… と振り分けられます。人数が足りなくても出発できます。1人で「出発」するとボット練習になります（途中参加はできません）') : RAID ? '大討伐戦：最大20人まで参加できます。人数が揃ったら「出発」を押してください（途中参加はできません）' : PVP ? '2〜4人の乱戦です。1人で「出発」すると、ゴースト（他のプレイヤーの分身）との対戦になります（途中参加はできません）' : '準備ができたら「出発」を押してください（途中参加はできません）') : 'ホストの出発を待っています…');
    }

    // ---------- 結果 ----------
    function showResult(win, d) {
        const o = el('result'); o.style.display = 'flex';
        const loot = run.stats.loot.slice().sort((a, b) => HW.RARITY_ORDER.indexOf(b.rarity) - HW.RARITY_ORDER.indexOf(a.rarity));
        el('resTitle').textContent = run.ghostMode ? (win ? '👻 ゴーストに勝利！' : (d.reason === 'time' ? '⌛ 時間切れ…（残りHPで判定）' : '💀 ゴーストに敗北…')) : (PVP && run.pvpMode) ? (win ? '🏆 勝利！最後の1人' : (d.reason === 'time' ? '⌛ 時間切れ…（総合ダメージ量で判定）' : '💀 敗北…')) : (win ? '🏆 ステージクリア！' : (d.reason === 'time' ? '⌛ 時間切れ…' : '💀 全滅…'));
        if (TEAM && run.pvpMode) el('resTitle').textContent = win ? '🏆 勝利！相手チームを倒した' : (d.winnerTeam === -1 ? '🤝 引き分け' : (d.reason === 'time' ? '⌛ 時間切れ…（チームの総合ダメージ量で判定）' : '💀 敗北…相手チームに倒された'));
        if (run.evGain) el('resTitle').textContent += '　⚔PvPイベント +' + run.evGain + 'EP';
        if (RUSH_ON) { const rr = run.rushReached | 0; el('resTitle').textContent = win ? '🏆 ボスラッシュ制覇！（' + DIFF.name + '）' : ((d.reason === 'time' ? '⌛ 時間切れ…' : '💀 敗北…') + '　' + (rr > 0 ? rushPd(rr).label + 'までクリア' : 'フェーズ1で敗退') + '（' + DIFF.name + '）'); }
        if (CORR_ON) el('resTitle').textContent = run.escaped ? ('🌀 脱出成功！　地下' + CF.floor + '階（報酬を持ち帰った）') : ((d.reason === 'giveup' ? '🏳 あきらめた' : '💀 力尽きた') + '…　地下' + CF.floor + '階（報酬はすべて失われた）');
        el('resTitle').style.color = win ? '#ffe08a' : '#ff8a8a';
        el('resBody').innerHTML =
            (run.formUnlock ? '<div style="margin:0 0 10px;padding:10px;border:2px solid #c8a0ff;border-radius:10px;background:rgba(90,50,160,.3);color:#f0e0ff;font-weight:bold;text-align:center">🔓 ' + run.formUnlock + '</div>' : '') +
            (run.worldBanner ? '<div style="margin:0 0 10px;padding:10px;border:2px solid #ffc84a;border-radius:10px;background:rgba(120,80,220,.28);color:#fff0c8;font-weight:bold;text-align:center">' + run.worldBanner.t + '<br><span style="font-size:.85em;font-weight:normal">' + run.worldBanner.s + '</span></div>' : '') +
            (CORR_ON && !run.escaped ? '<div style="margin:0 0 10px;padding:10px;border:2px solid #ff8a8a;border-radius:10px;background:rgba(120,30,40,.35);color:#ffd0d0;font-weight:bold;text-align:center">持ち帰れなかったもの（下の一覧）<br><span style="font-size:.85em;font-weight:normal">各階層の「脱出ゲート」から脱出しないと、報酬は持ち帰れません。コイン ' + ((run.lost && run.lost.coins) | 0) + ' も失われました</span></div>' : '') +
            (CORR_ON && run.escaped && d.ghost ? '<div style="margin:0 0 10px;padding:8px;border:2px solid #9fe8ff;border-radius:10px;color:#d8f4ff;text-align:center">仲間はまだ冒険中です。ここで町に戻ると、仲間の冒険も終わります（ホストのため）</div>' : '') +
            '<div>討伐数：' + run.stats.kills + '　与ダメージ：' + Math.round(run.stats.dmg) + '</div>' +
            '<div>コイン +' + (CORR_ON && !run.escaped ? 0 : run.stats.coins) + '　オーブ +' + (CORR_ON && !run.escaped ? 0 : run.stats.orbs) + '</div>' +
            (CORR_ON ? '<div>宝箱 ' + CF.st.chests + '個　ミミック ' + CF.st.mimics + '体　ボス討伐 ' + CF.st.bosses + '体</div>' : '') +
            (run.stats.items ? '<div style="margin:6px 0;color:#ffd9a0">特殊アイテム：' + Object.keys(run.stats.items).map(k => (HW.SPECIAL_ITEMS[k] ? HW.SPECIAL_ITEMS[k].icon + HW.SPECIAL_ITEMS[k].name : k) + '×' + run.stats.items[k]).join('　') + '</div>' : '') +
            '<h4>' + (CORR_ON && !run.escaped ? '失った' : '獲得した') + '素材（' + Object.keys(run.stats.mats).reduce((n, k) => n + run.stats.mats[k], 0) + '）</h4>' +
            (Object.keys(run.stats.mats).length ? '<div style="font-size:.85rem;color:#c8f7a0">' + Object.keys(run.stats.mats).map(id => escapeHtml(matName(id)) + '×' + run.stats.mats[id]).join('　') + '</div>' : '<div style="opacity:.7">なし</div>') +
            (run.stats.accs && run.stats.accs.length ? '<h4>' + (CORR_ON && !run.escaped ? '失った' : '獲得した') + 'アクセサリー（' + run.stats.accs.length + '）</h4>' + run.stats.accs.map(a => '<div style="color:' + HW.rarityOf(a).color + '">✨ ' + esc(a.name) + '</div>').join('') : '') +
            '<h4>' + (CORR_ON && !run.escaped ? '失った' : '獲得した') + '武器（' + loot.length + '）</h4>' +
            (loot.length ? loot.map(w => '<div class="lw" style="color:' + HW.rarityOf(w).color + '">' + escapeHtml(w.name) + ' <small>[' + HW.rarityOf(w).label + ' / 攻撃' + HW.pctLabel(w) + ' / 穴' + w.sockets + ']</small></div>').join('') : '<div style="opacity:.7">なし</div>');
    }

    // ---------- クイズ（正解でエネルギー）----------
    let quizOn = true, quizPool = null, curQ = null, quizLock = false, streak = 0;
    function grade() { const g = clamp(parseInt(pdata.grade, 10) || 1, 1, 12); return g <= 6 ? { l: 'elementary', g: g } : (g <= 9 ? { l: 'junior_high', g: g - 6 } : { l: 'high_school', g: g - 9 }); }
    // 出題元：オンラインマッチ以外では、「復習・統計」画面で選んだ自作の問題リスト（4問以上）から出題できる（localStorage の sbQuizList）
    let quizSrc = 'd';
    function customList() {
        if (PVP) return null;
        try {
            const id = localStorage.getItem('sbQuizList'); if (!id) return null;
            const l = ((window.getPlayerData ? getPlayerData() : pdata).questionLists || []).find(x => x && x.id === id);
            const qs = l && Array.isArray(l.questions) ? l.questions.filter(x => x && String(x.question || '').trim() && String(x.answer || '').trim()) : [];
            return qs.length >= 4 ? { id: l.id, qs: qs } : null;
        } catch (e) { return null; }
    }
    function buildPool() {
        const pool = {}; quizSrc = 'd';
        const cl = customList(); if (cl) { quizSrc = 'l:' + cl.id; pool.list = cl.qs; return pool; }
        if (typeof QUESTIONS_DATA === 'undefined') return pool;
        const gi = grade(), lv = QUESTIONS_DATA[gi.l], gd = lv && lv[String(gi.g)]; if (!gd) return pool;
        ['math', 'jp', 'eng'].forEach(s => { if (gd[s] && gd[s].length) pool[s] = gd[s]; });
        return pool;
    }
    const shuf = a => { const r = a.slice(); for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = r[i]; r[i] = r[j]; r[j] = t; } return r; };
    function opts(q, qs) {
        if (q.options && q.options.length === 4) return shuf(q.options.map(String));
        const ans = String(q.answer), out = [ans], set = new Set(out);
        if (ans.trim() !== '' && !isNaN(ans)) { const n = parseFloat(ans), isInt = Number.isInteger(n); for (const c of shuf([1, -1, 2, -2, 10, -10, 3, -3, 5, 4])) { if (out.length >= 4) break; const v = isInt ? String(n + c) : String(Math.round((n + c * 0.1) * 100) / 100); if (!set.has(v)) { set.add(v); out.push(v); } } }
        else { for (const o of shuf(qs.map(x => String(x.answer)))) { if (out.length >= 4) break; if (!set.has(o)) { set.add(o); out.push(o); } } }
        let k = 1; while (out.length < 4) out.push(ans + '・' + k++);
        return shuf(out);
    }
    function nextQuiz() {
        if (!quizPool) quizPool = buildPool();
        const subs = Object.keys(quizPool);
        if (!subs.length) curQ = { q: '3 + 4 = ?', a: '7', o: ['7', '6', '8', '12'], subj: 'math', src: 'd', rev: false, noLog: true };
        else {
            // 復習のタイミングを過ぎた問題を、ときどき混ぜる（忘却曲線：memory.js）
            let pick = null, rev = false;
            if (window.SBMemory && Math.random() < SBMemory.reviewChance()) {
                const flat = []; subs.forEach(s => quizPool[s].forEach(q => flat.push({ q: q.question, a: String(q.answer), s: s, raw: q })));
                pick = SBMemory.pickDue(flat, () => quizSrc); rev = !!pick;
            }
            if (!pick) { const s = subs[Math.floor(Math.random() * subs.length)], qs = quizPool[s], q = qs[Math.floor(Math.random() * qs.length)]; pick = { q: q.question, a: String(q.answer), s: s, raw: q }; }
            curQ = { q: pick.q, a: pick.a, o: opts(pick.raw, quizPool[pick.s]), subj: pick.s, src: quizSrc, rev: rev };
        }
        quizLock = false;
        el('quizQ').textContent = (curQ.rev ? '🔁 ' : '') + curQ.q;
        const box = el('quizC'); box.innerHTML = '';
        curQ.o.forEach((o, i) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = (i + 1) + '. ' + o; b.dataset.v = o; b.addEventListener('click', () => answer(o, b)); box.appendChild(b); });
    }
    function answer(o, b) {
        if (quizLock || !curQ || run.phase === 'end') return; quizLock = true;
        if (window.SBMemory && !curQ.noLog) SBMemory.record({ q: curQ.q, a: curQ.a, subj: curQ.subj, src: curQ.src, ok: o === curQ.a });      // 忘却曲線の記録
        if (o === curQ.a) { streak++; b.classList.add('ok'); if (window.SBSound) SBSound.sfx('correct'); addEnergy((25 + (streak >= 3 ? 10 : 0)) * P.energyMul); popups.push({ x: me.x, y: me.y - 40, t: 0.8, text: '+ENERGY', c: '#7fe3ff' }); setTimeout(nextQuiz, 300); }
        else { streak = 0; b.classList.add('ng'); if (window.SBSound) SBSound.sfx('wrong'); Array.from(el('quizC').children).forEach(x => { if (x.dataset.v === curQ.a) x.classList.add('ok'); }); setTimeout(nextQuiz, 1300); }
    }
    function quizPick(i) { const b = el('quizC').children[i]; if (b) b.click(); }
    function toggleQuiz() { quizOn = !quizOn; el('quiz').style.display = quizOn ? 'block' : 'none'; }

    // ---------- ループ ----------
    let last = performance.now(), skillT = 0;
    // ゲームの時間を1コマ進める。doRender=false のときは、画面は描かずに、動きと通信だけを進める（別のタブを開いている間に使う）
    function tick(now, doRender) {
        const rawDt = (now - last) / 1000; let dt = Math.min(0.05, rawDt); last = now;
        sparkBudget = LITE() ? 6 : 28;
        // 重くなったら、自動で軽量モードにする（1秒ほど続けて、おおむね30fps以下のとき）。O キーで手動の切り替えもできる
        if (run.phase === 'run' && enemies.length > 0 && window.SBPix) {
            perfEma = perfEma * 0.96 + Math.min(0.2, rawDt) * 0.04;
            if (!SBPix.lite && !liteManual) { if (perfEma > 0.034) { if (++perfSlow > 90) { SBPix.lite = true; fit(); announce('⚡ 動きが重いので、軽量モードにしました（O キーで切り替え）', 2200); } } else perfSlow = Math.max(0, perfSlow - 2); }
        }
        if (hitStopT > 0) { hitStopT -= dt; dt *= 0.06; }      // ヒットストップ：当たった一瞬だけ、ほぼ止める
        if (CINE.on) { CINE.t += dt; if (CINE.t >= CINE_END) CINE.on = false; else { const cs = cineScale(); if (cs < 1) dt *= cs; } }      // ボス撃破の演出：時間はそのまま進め、ゲームの時間だけスローにする
        if (window.SBOrientation && SBOrientation.blocking() && partyCount() === 1) { if (doRender) render(); return; }
        if (run.phase === 'run') {
            run.time += dt;
            skillSlots.forEach(sk => { if (sk && sk.cdLeft > 0) sk.cdLeft = Math.max(0, sk.cdLeft - dt); });
            if ((skillT -= dt) <= 0) { skillT = 0.1; updateSkillBar(); }
            updateMe(dt); updateShots(dt); classInit(); if (window.ClassFx) ClassFx.update(dt); if (window.ClassForms) ClassForms.update(dt); gmLocal(dt); updateDomains(dt); updateMinions(dt); updateHealer(dt); corrUpdate(dt);
            if (DBG) { if (DBG.god) { me.invHard = 99; if (me.dead) { me.dead = false; me.hp = me.maxHp; } } if (DBG.energy !== false) me.energy = ENERGY_MAX; }   // デバッグ：無敵・エネルギー無限
            if (PVP && run.pvpMode) { syncPvpDummies(); if (isHost) pvpHostCheck(); }
            else if (PVP && run.ghostMode) { ghostUpdate(dt); }
            else if (isHost) { updateHost(dt); } else lerpRemote(dt);
            // 位置の送信
            posT -= dt; if (posT <= 0) {
                posT = 1 / (partyCount() <= 3 ? 20 : partyCount() <= 6 ? 15 : 12);      // 人数が増えるほど、全員が受け取る量が増えるので、1人あたりの回数を減らす
                // 速度を一緒に送る（受け取った側が、次の位置が届くまでの間を先読みして動かせる）。一瞬で大きく動いたとき（一閃・階層移動など）は tp=1 で「補間せず、そこへ移動」と伝える
                const nowMs = performance.now(), el0 = Math.max(0.016, (nowMs - posLast.t) / 1000), dx0 = me.x - posLast.x, dy0 = me.y - posLast.y, jump = Math.hypot(dx0, dy0) > 300;
                const vx0 = jump ? 0 : clamp(dx0 / el0, -900, 900), vy0 = jump ? 0 : clamp(dy0 / el0, -900, 900);
                const fullPix = posSeq % 20 === 0 && !!weapon.pix && (posSeq % 200 === 0 || MYPC_SENT !== (MYPC && MYPC.key)); if (fullPix) MYPC_SENT = MYPC && MYPC.key;      // 絵が大きいので、変わったときと、ときどきだけ全部送る
                posLast.x = me.x; posLast.y = me.y; posLast.t = nowMs; posSeq++;
                netSend('pos', { g: me.guardT > 0 ? 1 : 0, ti: (posSeq % 20 === 0) ? ((window.SBAch && SBAch.titleText()) || '') : undefined, wt: (posSeq % 20 === 0) ? weapon.type : undefined, ws: (posSeq % 20 === 0) ? (weapon.size || 1) : undefined, wp: (posSeq % 20 === 0) ? (weapon.pix ? (fullPix ? weapon.pix : { k: MYPC && MYPC.key }) : 0) : undefined, wx: (fullPix && MY_TEXRAW) ? MY_TEXRAW : undefined, wm: (posSeq % 20 === 0) ? (weapon.mythicId || '') : undefined, av: (posSeq % 20 === 0 && MY_AV && window.SBPix && SBPix.avatarString) ? SBPix.avatarString(MY_AV) : undefined, x: Math.round(me.x), y: Math.round(me.y), vx: Math.round(vx0), vy: Math.round(vy0), tp: jump ? 1 : 0, q: posSeq, a: +me.ang.toFixed(2), hp: Math.round(me.hp), mh: me.maxHp, dead: me.dead, st: me.stunT > 0 ? 1 : 0, tt: (CORR_ON || RAID || AMB_ON) ? Math.round(corrTotal()) : 0 });      // 自分のステータス合計：無限回廊に加えて、大討伐戦・待ち伏せでも配る（ボスの強さを、パーティでいちばん高い人に合わせるため）
            }
            if (!isHost) { hitFlushT -= dt; if (hitFlushT <= 0) { hitFlushT = 0.06; flushHits(); } }
            snapT -= dt; if (isHost && room && !(PVP && run.pvpMode) && snapT <= 0) { const sn = makeSnap(); snapT = 1 / (snapBytes > 14000 ? 10 : snapBytes > 8500 ? 13 : SNAP_HZ); netSend('snap', sn); }      // 大きいスナップショットのときは送る回数を減らす（回線が細い人が詰まらないように）
        } else if (run.phase === 'end') { updateShots(dt); }
        Object.keys(allies).forEach(id => { const a = allies[id];
            // 仲間の位置：最後に届いた位置＋速度×経過時間（最大0.25秒ぶん）を目標にして、フレームレートに左右されない補間で近づく。離れすぎたらそこへ移動
            const age = Math.min(0.25, Math.max(0, (performance.now() - (a.pt || 0)) / 1000)), px = a.tx + (a.vx || 0) * age, py = a.ty + (a.vy || 0) * age, kk = 1 - Math.exp(-dt * 18);
            if (Math.hypot(px - a.x, py - a.y) > 320) { a.x = px; a.y = py; } else { a.x += (px - a.x) * kk; a.y += (py - a.y) * kk; } if (a.orb) { a.orb.t -= dt; if (a.orb.t <= 0) a.orb = null; } });
        fx.forEach(f => { f.t -= dt; if (f.vx !== undefined) { f.x += f.vx * dt; f.y += f.vy * dt; const dmp = Math.pow(0.06, dt); f.vx *= dmp; f.vy *= dmp; } }); fx = fx.filter(f => f.t > 0);
        if (comboT > 0) { comboT -= dt; if (comboT <= 0) comboN = 0; }
        if (shakeT > 0) { shakeT -= dt; if (shakeT <= 0) shakeA = 0; }
        popups.forEach(p => { p.t -= dt; }); popups = popups.filter(p => p.t > 0);
        enemies.forEach(e => { if (e.flash > 0) e.flash -= dt; });
        if (doRender) render();
    }
    function loop(now) { tick(now, true); requestAnimationFrame(loop); }
    // ---- 別のタブを開いても、ゲームの時間を止めない ----
    //  ブラウザは、見えていないタブの描画（requestAnimationFrame）を止める。ホストの画面が止まると、敵を動かす計算も、仲間への送信も止まって、
    //  仲間の画面では敵が全員止まって見えていた。そこで、見えていない間は、Worker の時計（止められにくい）で動きと通信だけを進める。
    function bgCatchUp() {
        if (!document.hidden || (run.phase !== 'run' && run.phase !== 'end')) return;
        const n = performance.now(); let guard = 0;
        if (n - last > 1500) last = n - 100;      // 長く止まっていた（スリープ明けなど）ときは、早送りせず、時間を飛ばす
        while (n - last > 20 && guard++ < 12) tick(Math.min(n, last + 33), false);      // 遅れた分は、33msずつ追いつく
    }
    try {
        const bw = new Worker(URL.createObjectURL(new Blob(['setInterval(function(){postMessage(0)},33)'], { type: 'text/javascript' })));
        bw.onmessage = bgCatchUp; window.addEventListener('pagehide', () => { try { bw.terminate(); } catch (e) { /* 終了済み */ } });
    } catch (e) { setInterval(bgCatchUp, 250); }      // Worker が使えないときは、止められにくい範囲で時々進める

    // ---------- 起動 ----------
    el('waitStart').addEventListener('click', () => { if (socket && room) socket.emit('stage:start'); else beginRun(); });
    el('waitLeave').addEventListener('click', () => { if (socket) socket.emit('stage:leave'); location.href = 'index.html'; });
    el('resBack').addEventListener('click', () => { if (socket) socket.emit('stage:leave'); location.href = 'index.html'; });
    el('quizToggle').addEventListener('click', toggleQuiz);
    window.addEventListener('beforeunload', () => { if (socket) socket.emit('stage:leave'); });
    if (isTouch) {
        document.documentElement.classList.add('touch');
        // 最初のタッチ（ユーザー操作）で全画面にして横向きに固定する。対応していない端末では何も起きない
        window.addEventListener('pointerdown', function once() { window.removeEventListener('pointerdown', once); if (window.SBOrientation) SBOrientation.enterFullscreenLandscape(); }, { once: true });
    }

    el('wpnName').textContent = weapon.name; el('wpnName').style.color = HW.rarityOf(weapon).color;
    el('stageName').textContent = stage.icon + ' ' + stage.name + ' [' + DIFF.name + ']';
    buildSkillBar(); updateEnergyUI(); nextQuiz();

    if (launch.mode === 'solo') {
        isHost = true; room = null;
        el('waitRoom').style.display = 'none';
        beginRun();
    } else {
        renderWait();
        if (!setupNet()) { showWaitMsg('通信できないため、ソロで開始します'); setTimeout(beginRun, 1200); }
    }
    // 自動テスト用の窓口（テストページが window.__SB_TEST を用意したときだけ公開する。通常のプレイでは何も起きない）
    if (window.__SB_TEST) window.__SB_TEST.api = { run: run, me: me, RS: RS, CF: CF, get enemies() { return enemies; }, get eBullets() { return eBullets; }, get telegraphs() { return telegraphs; }, get world() { return [WORLD_W, WORLD_H]; }, get domains() { return domains; },
        killEnemy: killEnemy, onKillEvent: onKillEvent, corrDescend: corrDescend, corrEnterBoss: corrEnterBoss, corrLeaveBoss: corrLeaveBoss, corrOpenChest: corrOpenChest, corrWakeMimic: corrWakeMimic, corrTotal: corrTotal, corrMul: corrMul,
        hurtPvp: hurtPvp, dealPvp: dealPvp, rushStartPhase: rushStartPhase, rushPd: rushPd, REF: () => REF_HP, hurtMe: hurtMe, healMe: healMe, addHp: addHp, healMul: healMul, sdAtkMul: sdAtkMul, sdDefMul: sdDefMul, stunMe: stunMe, spawnEnemy: spawnEnemy, DIFF: () => DIFF, SC: SC, tally: tallyDmg, dmgOf: dmgOf, pvpHostCheck: pvpHostCheck, spawnDomain: spawnDomain, accSlots: accSlots, accFire: accFire, accEvent: accEvent, rollAcc: rollAcc, BAG: BAG, corrAsk: corrAsk, corrEscape: corrEscape, corrGiveUp: corrGiveUp, corrProp: corrProp, corrGiveItem: corrGiveItem, get allies() { return allies; }, get isHost() { return isHost; }, get minions() { return minions; }, get remoteMinions() { return remoteMinions; }, step: (dt) => { run.time += 0; } };
    requestAnimationFrame(loop);
})();
