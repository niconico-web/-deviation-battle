// ============================================
// スキルツリーシステム
// Path of Exile style extensive skill trees
// ============================================

// スキルポイント獲得量（レベルアップごと）
const SKILL_POINTS_PER_LEVEL = 2;

// 統合された単一のスキルツリー定義
const SKILL_TREE = {
        name: "総合スキルツリー",
        description: "防御と攻撃のバランスを重視したスキルツリー",
        nodes: [
            // 基礎ステータスノード
            // --- 中央エリア (開始地点) ---
            { id: "start_node", name: "始まりの力", description: "全ての基礎ステータス+5", cost: 0, x: 0, y: 0, type: "stat", effect: { maxHp: 5, atk: 5, def: 5, speed: 5 } },
            { id: "core_atk_1", name: "攻撃+", description: "攻撃+5", cost: 1, x: -1, y: 0, requires: "start_node", type: "stat", effect: { atk: 5 } },
            { id: "core_def_1", name: "防御+", description: "防御+5", cost: 1, x: 1, y: 0, requires: "start_node", type: "stat", effect: { def: 5 } },
            { id: "core_hp_1", name: "体力+", description: "HP+10", cost: 1, x: 0, y: -1, requires: "start_node", type: "stat", effect: { maxHp: 10 } },
            { id: "core_speed_1", name: "速さ+", description: "速さ+5", cost: 1, x: 0, y: 1, requires: "start_node", type: "stat", effect: { speed: 5 } },

            // --- 左上: 攻撃・大剣ルート ---
            { id: "atk_path_1", name: "攻撃II", description: "攻撃+10", cost: 2, x: -3, y: -1, requires: "core_atk_1", type: "stat", effect: { atk: 10 } },
            { id: "atk_path_2", name: "攻撃III", description: "攻撃+15", cost: 2, x: -5, y: -2, requires: "atk_path_1", type: "stat", effect: { atk: 15 } },
            { id: "gs_power_1", name: "剛力", description: "攻撃+10, HP+5", cost: 3, x: -7, y: -3, requires: "atk_path_2", type: "stat", effect: { atk: 10, maxHp: 5 } },
            { id: "gs_cleave", name: "クリーブ", description: "次の攻撃のダメージ1.4倍、ただし自身の防御-10", cost: 4, x: -9, y: -4, requires: "gs_power_1", type: "active", effect: { type: "active", damageMultiplier: 1.4, selfDefDebuff: 10 } },
            { id: "atk_mastery", name: "攻撃の極意", description: "常時攻撃+10%", cost: 5, x: -7, y: -5, requires: "gs_power_1", type: "passive", effect: { atkPercent: 0.1 } },
            { id: "atk_path_3", name: "速さ+", description: "速さ+5", cost: 1, x: -4, y: 0, requires: "atk_path_1", type: "stat", effect: { speed: 5 } },
            // Extended attack path (far left)
            { id: "atk_extreme_1", name: "破壊衝動", description: "攻撃+20, HP+10", cost: 4, x: -11, y: -5, requires: "gs_cleave", type: "stat", effect: { atk: 20, maxHp: 10 } },
            { id: "atk_extreme_2", name: "殺戮の舞", description: "次の攻撃3連撃(0.5倍ダメージ)", cost: 5, x: -13, y: -6, requires: "atk_extreme_1", type: "active", effect: { type: "active", multiStrike: 3, multiStrikeMultiplier: 0.5 } },
            { id: "atk_path_4", name: "攻撃IV", description: "攻撃+25", cost: 3, x: -9, y: -6, requires: "gs_power_1", type: "stat", effect: { atk: 25 } },
            { id: "atk_path_5", name: "攻撃V", description: "攻撃+30", cost: 3, x: -11, y: -3, requires: "atk_path_4", type: "stat", effect: { atk: 30 } },
            { id: "berserker", name: "狂戦士", description: "常時攻撃+15%, 防御-10%", cost: 6, x: -13, y: -4, requires: "atk_path_5", type: "passive", effect: { atkPercent: 0.15, defPercent: -0.1 } },
            // More attack extensions
            { id: "atk_path_6", name: "攻撃VI", description: "攻撃+35", cost: 4, x: -15, y: -5, requires: "atk_path_5", type: "stat", effect: { atk: 35 } },
            { id: "atk_path_7", name: "攻撃VII", description: "攻撃+40", cost: 4, x: -17, y: -6, requires: "atk_path_6", type: "stat", effect: { atk: 40 } },
            { id: "atk_path_8", name: "攻撃VIII", description: "攻撃+45", cost: 4, x: -19, y: -7, requires: "atk_path_7", type: "stat", effect: { atk: 45 } },
            { id: "atyramid_1", name: "攻撃の金字塔I", description: "攻撃+50, HP+20", cost: 5, x: -21, y: -8, requires: "atk_path_8", type: "stat", effect: { atk: 50, maxHp: 20 } },
            { id: "atyramid_2", name: "攻撃の金字塔II", description: "攻撃+60, HP+25", cost: 5, x: -23, y: -9, requires: "atyramid_1", type: "stat", effect: { atk: 60, maxHp: 25 } },
            { id: "atyramid_3", name: "攻撃の金字塔III", description: "攻撃+70, HP+30", cost: 5, x: -25, y: -10, requires: "atyramid_2", type: "stat", effect: { atk: 70, maxHp: 30 } },
            { id: "atyramid_top", name: "攻撃の頂点", description: "常時攻撃+25%, HP+15%", cost: 7, x: -27, y: -11, requires: "atyramid_3", type: "passive", effect: { atkPercent: 0.25, maxHpPercent: 0.15 } },
            // Attack branch down
            { id: "atk_branch_1", name: "精密打撃", description: "攻撃+15, クリティカル率+1%", cost: 3, x: -10, y: -8, requires: "atk_path_4", type: "stat", effect: { atk: 15, critChance: 0.01 } },
            { id: "atk_branch_2", name: "重撃", description: "攻撃+20, クリティカルダメージ+10%", cost: 3, x: -12, y: -9, requires: "atk_branch_1", type: "stat", effect: { atk: 20, critMultiplier: 0.1 } },
            { id: "death_blow", name: "致命の一撃", description: "次の攻撃3倍ダメージ、防御無視", cost: 6, x: -14, y: -10, requires: "atk_branch_2", type: "active", effect: { type: "active", damageMultiplier: 3.0, defenseIgnore: true } },
            // Attack branch up
            { id: "atk_branch_up_1", name: "狂暴", description: "攻撃+25, 速さ+10", cost: 3, x: -12, y: -3, requires: "atk_path_4", type: "stat", effect: { atk: 25, speed: 10 } },
            { id: "atk_branch_up_2", name: "暴虐", description: "攻撃+30, 速さ+15", cost: 3, x: -14, y: -2, requires: "atk_branch_up_1", type: "stat", effect: { atk: 30, speed: 15 } },
            { id: "frenzy", name: "フレンジー", description: "常時攻撃+20%, 速さ+10%", cost: 6, x: -16, y: -1, requires: "atk_branch_up_2", type: "passive", effect: { atkPercent: 0.2, speedPercent: 0.1 } },

            // --- 右上: 防御・盾ルート ---
            { id: "def_path_1", name: "防御II", description: "防御+10", cost: 2, x: 3, y: -1, requires: "core_def_1", type: "stat", effect: { def: 10 } },
            { id: "def_path_2", name: "防御III", description: "防御+15", cost: 2, x: 5, y: -2, requires: "def_path_1", type: "stat", effect: { def: 15 } },
            { id: "ss_tough_1", name: "不屈", description: "防御+10, HP+10", cost: 3, x: 7, y: -3, requires: "def_path_2", type: "stat", effect: { def: 10, maxHp: 10 } },
            { id: "ss_guard_stance", name: "ガードスタンス", description: "次に受けるダメージを30%軽減", cost: 4, x: 9, y: -4, requires: "ss_tough_1", type: "active", effect: { type: "active", damageReduction: 0.3 } },
            { id: "def_mastery", name: "防御の極意", description: "常時防御+10%", cost: 5, x: 7, y: -5, requires: "ss_tough_1", type: "passive", effect: { defPercent: 0.1 } },
            { id: "def_path_3", name: "HP+", description: "HP+10", cost: 1, x: 4, y: 0, requires: "def_path_1", type: "stat", effect: { maxHp: 10 } },
            // Extended defense path (far right)
            { id: "def_extreme_1", name: "鉄壁II", description: "防御+20, HP+15", cost: 4, x: 11, y: -5, requires: "ss_guard_stance", type: "stat", effect: { def: 20, maxHp: 15 } },
            { id: "def_extreme_2", name: "絶対防御", description: "次の攻撃を完全無効化", cost: 5, x: 13, y: -6, requires: "def_extreme_1", type: "active", effect: { type: "active", invincible: true } },
            { id: "def_path_4", name: "防御IV", description: "防御+25", cost: 3, x: 9, y: -6, requires: "ss_tough_1", type: "stat", effect: { def: 25 } },
            { id: "def_path_5", name: "防御V", description: "防御+30", cost: 3, x: 11, y: -3, requires: "def_path_4", type: "stat", effect: { def: 30 } },
            { id: "fortress", name: "要塞", description: "常時防御+15%, HP+10%", cost: 6, x: 13, y: -4, requires: "def_path_5", type: "passive", effect: { defPercent: 0.15, maxHpPercent: 0.1 } },
            // More defense extensions
            { id: "def_path_6", name: "防御VI", description: "防御+35", cost: 4, x: 15, y: -5, requires: "def_path_5", type: "stat", effect: { def: 35 } },
            { id: "def_path_7", name: "防御VII", description: "防御+40", cost: 4, x: 17, y: -6, requires: "def_path_6", type: "stat", effect: { def: 40 } },
            { id: "def_path_8", name: "防御VIII", description: "防御+45", cost: 4, x: 19, y: -7, requires: "def_path_7", type: "stat", effect: { def: 45 } },
            { id: "dpyramid_1", name: "防御の金字塔I", description: "防御+50, HP+20", cost: 5, x: 21, y: -8, requires: "def_path_8", type: "stat", effect: { def: 50, maxHp: 20 } },
            { id: "dpyramid_2", name: "防御の金字塔II", description: "防御+60, HP+25", cost: 5, x: 23, y: -9, requires: "dpyramid_1", type: "stat", effect: { def: 60, maxHp: 25 } },
            { id: "dpyramid_3", name: "防御の金字塔III", description: "防御+70, HP+30", cost: 5, x: 25, y: -10, requires: "dpyramid_2", type: "stat", effect: { def: 70, maxHp: 30 } },
            { id: "dpyramid_top", name: "防御の頂点", description: "常時防御+25%, HP+15%", cost: 7, x: 27, y: -11, requires: "dpyramid_3", type: "passive", effect: { defPercent: 0.25, maxHpPercent: 0.15 } },
            // Defense branch down
            { id: "def_branch_1", name: "堅固", description: "防御+15, HP+15", cost: 3, x: 10, y: -8, requires: "def_path_4", type: "stat", effect: { def: 15, maxHp: 15 } },
            { id: "def_branch_2", name: "不滅", description: "防御+20, HP+20", cost: 3, x: 12, y: -9, requires: "def_branch_1", type: "stat", effect: { def: 20, maxHp: 20 } },
            { id: "immortal", name: "不死身", description: "戦闘不能時HP50%で復活(1回のみ)", cost: 6, x: 14, y: -10, requires: "def_branch_2", type: "active", effect: { type: "active", revive: true, revivePercent: 0.5 } },
            // Defense branch up
            { id: "def_branch_up_1", name: "守護", description: "防御+25, 速さ+10", cost: 3, x: 12, y: -3, requires: "def_path_4", type: "stat", effect: { def: 25, speed: 10 } },
            { id: "def_branch_up_2", name: "庇護", description: "防御+30, 速さ+15", cost: 3, x: 14, y: -2, requires: "def_branch_up_1", type: "stat", effect: { def: 30, speed: 15 } },
            { id: "guardian", name: "守護者", description: "常時防御+20%, 速さ+10%", cost: 6, x: 16, y: -1, requires: "def_branch_up_2", type: "passive", effect: { defPercent: 0.2, speedPercent: 0.1 } },

            // --- 左下: 速さ・双剣ルート ---
            { id: "speed_path_1", name: "速さII", description: "速さ+10", cost: 2, x: -3, y: 2, requires: "core_speed_1", type: "stat", effect: { speed: 10 } },
            { id: "speed_path_2", name: "速さIII", description: "速さ+15", cost: 2, x: -5, y: 3, requires: "speed_path_1", type: "stat", effect: { speed: 15 } },
            { id: "ds_agile_1", name: "俊敏", description: "速さ+10, 攻撃+5", cost: 3, x: -7, y: 4, requires: "speed_path_2", type: "stat", effect: { speed: 10, atk: 5 } },
            { id: "ds_twin_strike", name: "ツインスラッシュ", description: "次の攻撃が2回攻撃になる(1回のダメージは0.6倍)", cost: 4, x: -9, y: 5, requires: "ds_agile_1", type: "active", effect: { type: "active", multiStrike: 2, multiStrikeMultiplier: 0.6 } },
            { id: "speed_mastery", name: "速さの極意", description: "常時速さ+10%", cost: 5, x: -7, y: 6, requires: "ds_agile_1", type: "passive", effect: { speedPercent: 0.1 } },
            { id: "speed_path_3", name: "攻撃+", description: "攻撃+5", cost: 1, x: -4, y: 1, requires: "speed_path_1", type: "stat", effect: { atk: 5 } },
            // Extended speed path (far left)
            { id: "speed_extreme_1", name: "疾風", description: "速さ+20, 攻撃+10", cost: 4, x: -11, y: 5, requires: "ds_twin_strike", type: "stat", effect: { speed: 20, atk: 10 } },
            { id: "speed_extreme_2", name: "閃光", description: "次の攻撃必中、ダメージ1.5倍", cost: 5, x: -13, y: 6, requires: "speed_extreme_1", type: "active", effect: { type: "active", sureHit: true, damageMultiplier: 1.5 } },
            { id: "speed_path_4", name: "速さIV", description: "速さ+25", cost: 3, x: -9, y: 6, requires: "ds_agile_1", type: "stat", effect: { speed: 25 } },
            { id: "speed_path_5", name: "速さV", description: "速さ+30", cost: 3, x: -11, y: 3, requires: "speed_path_4", type: "stat", effect: { speed: 30 } },
            { id: "windrunner", name: "風歩き", description: "常時速さ+15%, 回避率+5%", cost: 6, x: -13, y: 4, requires: "speed_path_5", type: "passive", effect: { speedPercent: 0.15, dodgeChance: 0.05 } },
            // More speed extensions
            { id: "speed_path_6", name: "速さVI", description: "速さ+35", cost: 4, x: -15, y: 5, requires: "speed_path_5", type: "stat", effect: { speed: 35 } },
            { id: "speed_path_7", name: "速さVII", description: "速さ+40", cost: 4, x: -17, y: 6, requires: "speed_path_6", type: "stat", effect: { speed: 40 } },
            { id: "speed_path_8", name: "速さVIII", description: "速さ+45", cost: 4, x: -19, y: 7, requires: "speed_path_7", type: "stat", effect: { speed: 45 } },
            { id: "spyramid_1", name: "速さの金字塔I", description: "速さ+50, 攻撃+20", cost: 5, x: -21, y: 8, requires: "speed_path_8", type: "stat", effect: { speed: 50, atk: 20 } },
            { id: "spyramid_2", name: "速さの金字塔II", description: "速さ+60, 攻撃+25", cost: 5, x: -23, y: 9, requires: "spyramid_1", type: "stat", effect: { speed: 60, atk: 25 } },
            { id: "spyramid_3", name: "速さの金字塔III", description: "速さ+70, 攻撃+30", cost: 5, x: -25, y: 10, requires: "spyramid_2", type: "stat", effect: { speed: 70, atk: 30 } },
            { id: "spyramid_top", name: "速さの頂点", description: "常時速さ+25%, 攻撃+15%", cost: 7, x: -27, y: 11, requires: "spyramid_3", type: "passive", effect: { speedPercent: 0.25, atkPercent: 0.15 } },
            // Speed branch down
            { id: "speed_branch_1", name: "軽足", description: "速さ+15, 回避率+2%", cost: 3, x: -10, y: 8, requires: "speed_path_4", type: "stat", effect: { speed: 15, dodgeChance: 0.02 } },
            { id: "speed_branch_2", name: "神速", description: "速さ+20, 回避率+3%", cost: 3, x: -12, y: 9, requires: "speed_branch_1", type: "stat", effect: { speed: 20, dodgeChance: 0.03 } },
            { id: "phantom", name: "幻影", description: "次のターン、完全回避状態", cost: 6, x: -14, y: 10, requires: "speed_branch_2", type: "active", effect: { type: "active", dodgeChance: 1.0 } },
            // Speed branch up
            { id: "speed_branch_up_1", name: "疾走", description: "速さ+25, 攻撃+15", cost: 3, x: -12, y: 3, requires: "speed_path_4", type: "stat", effect: { speed: 25, atk: 15 } },
            { id: "speed_branch_up_2", name: "飛翔", description: "速さ+30, 攻撃+20", cost: 3, x: -14, y: 2, requires: "speed_branch_up_1", type: "stat", effect: { speed: 30, atk: 20 } },
            { id: "skywalker", name: "天空の行者", description: "常時速さ+20%, 攻撃+10%", cost: 6, x: -16, y: 1, requires: "speed_branch_up_2", type: "passive", effect: { speedPercent: 0.2, atkPercent: 0.1 } },

            // --- 右下: HP・鎌ルート ---
            { id: "hp_path_1", name: "体力II", description: "HP+15", cost: 2, x: 3, y: 2, requires: "core_hp_1", type: "stat", effect: { maxHp: 15 } },
            { id: "hp_path_2", name: "体力III", description: "HP+20", cost: 2, x: 5, y: 3, requires: "hp_path_1", type: "stat", effect: { maxHp: 20 } },
            { id: "sc_vitality_1", name: "生命力", description: "HP+20, 防御+5", cost: 3, x: 7, y: 4, requires: "hp_path_2", type: "stat", effect: { maxHp: 20, def: 5 } },
            { id: "sc_life_hunt", name: "ライフハント", description: "次の攻撃で与えたダメージの30%を吸収する", cost: 4, x: 9, y: 5, requires: "sc_vitality_1", type: "active", effect: { type: "active", lifeSteal: 0.3 } },
            { id: "hp_mastery", name: "体力の極意", description: "常時HP+10%", cost: 5, x: 7, y: 6, requires: "sc_vitality_1", type: "passive", effect: { maxHpPercent: 0.1 } },
            { id: "hp_path_3", name: "防御+", description: "防御+5", cost: 1, x: 4, y: 1, requires: "hp_path_1", type: "stat", effect: { def: 5 } },
            // Extended HP path (far right)
            { id: "hp_extreme_1", name: "生命力II", description: "HP+25, 防御+10", cost: 4, x: 11, y: 5, requires: "sc_life_hunt", type: "stat", effect: { maxHp: 25, def: 10 } },
            { id: "hp_extreme_2", name: "再生", description: "ターン開始時HP10%回復", cost: 5, x: 13, y: 6, requires: "hp_extreme_1", type: "passive", effect: { type: "passive", hpRegen: 0.1 } },
            { id: "hp_path_4", name: "体力IV", description: "HP+25", cost: 3, x: 9, y: 6, requires: "sc_vitality_1", type: "stat", effect: { maxHp: 25 } },
            { id: "hp_path_5", name: "体力V", description: "HP+30", cost: 3, x: 11, y: 3, requires: "hp_path_4", type: "stat", effect: { maxHp: 30 } },
            { id: "undying", name: "不死鳥", description: "常時HP+15%, 防御+5%", cost: 6, x: 13, y: 4, requires: "hp_path_5", type: "passive", effect: { maxHpPercent: 0.15, defPercent: 0.05 } },
            // More HP extensions
            { id: "hp_path_6", name: "体力VI", description: "HP+35", cost: 4, x: 15, y: 5, requires: "hp_path_5", type: "stat", effect: { maxHp: 35 } },
            { id: "hp_path_7", name: "体力VII", description: "HP+40", cost: 4, x: 17, y: 6, requires: "hp_path_6", type: "stat", effect: { maxHp: 40 } },
            { id: "hp_path_8", name: "体力VIII", description: "HP+45", cost: 4, x: 19, y: 7, requires: "hp_path_7", type: "stat", effect: { maxHp: 45 } },
            { id: "hppyramid_1", name: "体力の金字塔I", description: "HP+50, 防御+20", cost: 5, x: 21, y: 8, requires: "hp_path_8", type: "stat", effect: { maxHp: 50, def: 20 } },
            { id: "hppyramid_2", name: "体力の金字塔II", description: "HP+60, 防御+25", cost: 5, x: 23, y: 9, requires: "hppyramid_1", type: "stat", effect: { maxHp: 60, def: 25 } },
            { id: "hppyramid_3", name: "体力の金字塔III", description: "HP+70, 防御+30", cost: 5, x: 25, y: 10, requires: "hppyramid_2", type: "stat", effect: { maxHp: 70, def: 30 } },
            { id: "hppyramid_top", name: "体力の頂点", description: "常時HP+25%, 防御+15%", cost: 7, x: 27, y: 11, requires: "hppyramid_3", type: "passive", effect: { maxHpPercent: 0.25, defPercent: 0.15 } },
            // HP branch down
            { id: "hp_branch_1", name: "健壮", description: "HP+15, 攻撃+10", cost: 3, x: 10, y: 8, requires: "hp_path_4", type: "stat", effect: { maxHp: 15, atk: 10 } },
            { id: "hp_branch_2", name: "強健", description: "HP+20, 攻撃+15", cost: 3, x: 12, y: 9, requires: "hp_branch_1", type: "stat", effect: { maxHp: 20, atk: 15 } },
            { id: "vampire", name: "吸血鬼", description: "常時ライフスティール15%", cost: 6, x: 14, y: 10, requires: "hp_branch_2", type: "passive", effect: { lifeSteal: 0.15 } },
            // HP branch up
            { id: "hp_branch_up_1", name: "活力", description: "HP+25, 速さ+10", cost: 3, x: 12, y: 3, requires: "hp_path_4", type: "stat", effect: { maxHp: 25, speed: 10 } },
            { id: "hp_branch_up_2", name: "活力増進", description: "HP+30, 速さ+15", cost: 3, x: 14, y: 2, requires: "hp_branch_up_1", type: "stat", effect: { maxHp: 30, speed: 15 } },
            { id: "regenerator", name: "再生者", description: "常時HP+15%, ライフスティール5%", cost: 6, x: 16, y: 1, requires: "hp_branch_up_2", type: "passive", effect: { maxHpPercent: 0.15, lifeSteal: 0.05 } },

            // --- 遠距離・魔法ルート (上部) ---
            { id: "magic_path_1", name: "魔力", description: "攻撃+5, 速さ+5", cost: 2, x: 0, y: -3, requires: "core_hp_1", type: "stat", effect: { atk: 5, speed: 5 } },
            { id: "magic_path_2", name: "魔力II", description: "攻撃+10", cost: 2, x: 0, y: -5, requires: "magic_path_1", type: "stat", effect: { atk: 10 } },
            // 特殊ステータス（第二の攻撃）ルート - 大幅拡張
            { id: "special_awakening", name: "特殊の目覚め", description: "特殊+20", cost: 3, x: 4, y: -5, requires: "magic_path_2", type: "stat", effect: { special: 20 } },
            { id: "special_path_1", name: "精神力+", description: "特殊+15", cost: 2, x: 6, y: -5, requires: "special_awakening", type: "stat", effect: { special: 15 } },
            { id: "special_path_2", name: "精神力++", description: "特殊+20", cost: 2, x: 8, y: -5, requires: "special_path_1", type: "stat", effect: { special: 20 } },
            { id: "special_path_3", name: "精神力+++", description: "特殊+25", cost: 2, x: 10, y: -5, requires: "special_path_2", type: "stat", effect: { special: 25 } },
            { id: "psychic_blast", name: "サイキックブラスト", description: "特殊ステータスを使った一撃。次の攻撃1.3倍（特殊基準）", cost: 4, x: 12, y: -7, requires: "special_path_3", type: "active", effect: { type: "active", damageMultiplier: 1.3, useSpecialStat: true } },
            { id: "special_mastery", name: "特殊の極意", description: "常時特殊+15%", cost: 5, x: 12, y: -9, requires: "psychic_blast", type: "passive", effect: { specialPercent: 0.15 } },
            { id: "special_path_4", name: "超能力+", description: "特殊+30", cost: 3, x: 14, y: -7, requires: "special_mastery", type: "stat", effect: { special: 30 } },
            { id: "special_path_5", name: "超能力++", description: "特殊+35", cost: 3, x: 16, y: -7, requires: "special_path_4", type: "stat", effect: { special: 35 } },
            { id: "psychic_overload", name: "サイキックオーバーロード", description: "特殊ステータスを使った渾身の一撃。次の攻撃2.2倍（特殊基準）", cost: 6, x: 18, y: -9, requires: "special_path_5", type: "active", effect: { type: "active", damageMultiplier: 2.2, useSpecialStat: true } },
            { id: "special_mastery_ii", name: "特殊の極意II", description: "常時特殊+20%", cost: 6, x: 18, y: -11, requires: "psychic_overload", type: "passive", effect: { specialPercent: 0.2 } },
            { id: "special_path_6", name: "念力+", description: "特殊+40", cost: 4, x: 20, y: -9, requires: "special_mastery_ii", type: "stat", effect: { special: 40 } },
            { id: "special_path_7", name: "念力++", description: "特殊+45", cost: 4, x: 22, y: -9, requires: "special_path_6", type: "stat", effect: { special: 45 } },
            { id: "psychic_annihilation", name: "サイキックアニヒレーション", description: "特殊ステータスを使った破壊的一撃。次の攻撃3.0倍（特殊基準）", cost: 7, x: 24, y: -11, requires: "special_path_7", type: "active", effect: { type: "active", damageMultiplier: 3.0, useSpecialStat: true } },
            { id: "special_apex", name: "特殊の頂点", description: "常時特殊+25%, 攻撃+10%", cost: 7, x: 24, y: -13, requires: "psychic_annihilation", type: "passive", effect: { specialPercent: 0.25, atkPercent: 0.1 } },
            // 特殊ステータスブランチ（防御系）
            { id: "special_def_1", name: "精神防御", description: "特殊+20, 防御+10", cost: 3, x: 8, y: -8, requires: "special_path_2", type: "stat", effect: { special: 20, def: 10 } },
            { id: "special_def_2", name: "念動防御", description: "特殊+25, 防御+15", cost: 3, x: 10, y: -10, requires: "special_def_1", type: "stat", effect: { special: 25, def: 15 } },
            { id: "psychic_shield", name: "サイキックシールド", description: "特殊ステータスを使った防御。次に受けるダメージ30%軽減（特殊基準）", cost: 5, x: 12, y: -12, requires: "special_def_2", type: "active", effect: { type: "active", damageReduction: 0.3, useSpecialStat: true } },
            // 特殊ステータスブランチ（速さ系）
            { id: "special_spd_1", name: "精神加速", description: "特殊+20, 速さ+10", cost: 3, x: 16, y: -8, requires: "special_path_4", type: "stat", effect: { special: 20, speed: 10 } },
            { id: "special_spd_2", name: "念動加速", description: "特殊+25, 速さ+15", cost: 3, x: 18, y: -10, requires: "special_spd_1", type: "stat", effect: { special: 25, speed: 15 } },
            { id: "psychic_speed", name: "サイキックスピード", description: "特殊ステータスを使った加速。次のターン速さ30%上昇（特殊基準）", cost: 5, x: 20, y: -12, requires: "special_spd_2", type: "active", effect: { type: "active", speedBuff: 0.3, useSpecialStat: true } },
            { id: "mw_fireball", name: "ファイアボール", description: "次の攻撃のダメージ1.2倍、敵に火傷付与", cost: 3, x: 2, y: -6, requires: "magic_path_2", type: "active", effect: { type: "active", damageMultiplier: 1.2, burn: true } },
            { id: "mw_ice_lance", name: "アイスランス", description: "次の攻撃のダメージ1.1倍、敵の速さを低下", cost: 3, x: -2, y: -6, requires: "magic_path_2", type: "active", effect: { type: "active", damageMultiplier: 1.1, speedDebuff: 0.2 } },
            { id: "magic_mastery", name: "魔力の極意", description: "常時 攻撃+5%, 速さ+5%", cost: 5, x: 0, y: -8, requires: ["mw_fireball", "mw_ice_lance"], type: "passive", effect: { atkPercent: 0.05, speedPercent: 0.05 } },
            // Extended magic path (far up)
            { id: "magic_path_3", name: "魔力III", description: "攻撃+15", cost: 3, x: 0, y: -10, requires: "magic_mastery", type: "stat", effect: { atk: 15 } },
            { id: "magic_path_4", name: "魔力IV", description: "攻撃+20", cost: 3, x: 0, y: -12, requires: "magic_path_3", type: "stat", effect: { atk: 20 } },
            { id: "arcane_blast", name: "アークaneブラスト", description: "次の攻撃2.0倍ダメージ", cost: 5, x: 0, y: -14, requires: "magic_path_4", type: "active", effect: { type: "active", damageMultiplier: 2.0 } },
            { id: "archmage", name: "大魔導士", description: "常時攻撃+20%, 次の攻撃30%で毒付与", cost: 6, x: 0, y: -16, requires: "arcane_blast", type: "passive", effect: { atkPercent: 0.2, poisonChance: 0.3 } },
            // Magic branch left
            { id: "magic_branch_1", name: "火魔法", description: "攻撃+15, 火傷付与率+5%", cost: 3, x: -3, y: -11, requires: "magic_path_3", type: "stat", effect: { atk: 15, burnChance: 0.05 } },
            { id: "magic_branch_2", name: "炎の嵐", description: "攻撃+20, 火傷付与率+10%", cost: 3, x: -5, y: -12, requires: "magic_branch_1", type: "stat", effect: { atk: 20, burnChance: 0.1 } },
            { id: "inferno", name: "地獄", description: "次の攻撃2.5倍、敵に火傷3ターン", cost: 6, x: -7, y: -13, requires: "magic_branch_2", type: "active", effect: { type: "active", damageMultiplier: 2.5, burn: true, burnTurns: 3 } },
            // Magic branch right
            { id: "magic_branch_r1", name: "氷魔法", description: "攻撃+15, 敵速さ低下率+5%", cost: 3, x: 3, y: -11, requires: "magic_path_3", type: "stat", effect: { atk: 15, speedDebuff: 0.05 } },
            { id: "magic_branch_r2", name: "絶対零度", description: "攻撃+20, 敵速さ低下率+10%", cost: 3, x: 5, y: -12, requires: "magic_branch_r1", type: "stat", effect: { atk: 20, speedDebuff: 0.1 } },
            { id: "blizzard", name: "ブリザード", description: "次の攻撃2.0倍、敵速さ3ターン低下", cost: 6, x: 7, y: -13, requires: "magic_branch_r2", type: "active", effect: { type: "active", damageMultiplier: 2.0, speedDebuff: 0.3, speedDebuffTurns: 3 } },
            // Magic branch: 雷魔法（火魔法・氷魔法に続く3本目の魔法分岐）
            { id: "thunder_path_1", name: "雷魔法", description: "攻撃+15, クリティカル率+5%", cost: 3, x: -10, y: -12, requires: "magic_path_4", type: "stat", effect: { atk: 15, critChance: 0.05 } },
            { id: "thunder_path_2", name: "雷神", description: "攻撃+20, クリティカル率+8%", cost: 3, x: -13, y: -13, requires: "thunder_path_1", type: "stat", effect: { atk: 20, critChance: 0.08 } },
            { id: "thunder_storm", name: "サンダーストーム", description: "次の攻撃2.2倍、必ずクリティカルになる", cost: 6, x: -16, y: -14, requires: "thunder_path_2", type: "active", effect: { type: "active", damageMultiplier: 2.2, nextAttackCrit: true } },
            // 魔法ルートの拡張（3倍拡張）
            { id: "magic_path_5", name: "魔力V", description: "攻撃+25", cost: 3, x: 0, y: -18, requires: "archmage", type: "stat", effect: { atk: 25 } },
            { id: "magic_path_6", name: "魔力VI", description: "攻撃+30", cost: 3, x: 0, y: -20, requires: "magic_path_5", type: "stat", effect: { atk: 30 } },
            { id: "magic_path_7", name: "魔力VII", description: "攻撃+35", cost: 4, x: 0, y: -22, requires: "magic_path_6", type: "stat", effect: { atk: 35 } },
            { id: "magic_path_8", name: "魔力VIII", description: "攻撃+40", cost: 4, x: 0, y: -24, requires: "magic_path_7", type: "stat", effect: { atk: 40 } },
            { id: "ultimate_arcane", name: "究極の魔導", description: "次の攻撃3.0倍ダメージ、特殊ステータス使用", cost: 7, x: 0, y: -26, requires: "magic_path_8", type: "active", effect: { type: "active", damageMultiplier: 3.0, useSpecialStat: true } },
            { id: "magic_apex", name: "魔力の頂点", description: "常時攻撃+30%, 速さ+15%, 特殊+20%", cost: 7, x: 0, y: -28, requires: "ultimate_arcane", type: "passive", effect: { atkPercent: 0.3, speedPercent: 0.15, specialPercent: 0.2 } },
            // 火魔法の拡張
            { id: "magic_branch_3", name: "炎の熟練", description: "攻撃+25, 火傷付与率+15%", cost: 3, x: -9, y: -14, requires: "inferno", type: "stat", effect: { atk: 25, burnChance: 0.15 } },
            { id: "magic_branch_4", name: "炎の極意", description: "攻撃+30, 火傷付与率+20%", cost: 4, x: -11, y: -15, requires: "magic_branch_3", type: "stat", effect: { atk: 30, burnChance: 0.2 } },
            { id: "magic_branch_5", name: "炎神", description: "攻撃+35, 火傷付与率+25%", cost: 4, x: -13, y: -16, requires: "magic_branch_4", type: "stat", effect: { atk: 35, burnChance: 0.25 } },
            { id: "inferno_apex", name: "炎の頂点", description: "次の攻撃3.0倍、敵に火傷5ターン、火傷付与率+30%", cost: 7, x: -15, y: -17, requires: "magic_branch_5", type: "active", effect: { type: "active", damageMultiplier: 3.0, burn: true, burnTurns: 5, burnChance: 0.3 } },
            // 氷魔法の拡張
            { id: "magic_branch_r3", name: "氷の熟練", description: "攻撃+25, 敵速さ低下率+15%", cost: 3, x: 9, y: -14, requires: "blizzard", type: "stat", effect: { atk: 25, speedDebuff: 0.15 } },
            { id: "magic_branch_r4", name: "氷の極意", description: "攻撃+30, 敵速さ低下率+20%", cost: 4, x: 11, y: -15, requires: "magic_branch_r3", type: "stat", effect: { atk: 30, speedDebuff: 0.2 } },
            { id: "magic_branch_r5", name: "氷神", description: "攻撃+35, 敵速さ低下率+25%", cost: 4, x: 13, y: -16, requires: "magic_branch_r4", type: "stat", effect: { atk: 35, speedDebuff: 0.25 } },
            { id: "blizzard_apex", name: "氷の頂点", description: "次の攻撃2.5倍、敵速さ5ターン低下、敵速さ低下率+30%", cost: 7, x: 15, y: -17, requires: "magic_branch_r5", type: "active", effect: { type: "active", damageMultiplier: 2.5, speedDebuff: 0.4, speedDebuffTurns: 5 } },
            // 雷魔法の拡張
            { id: "thunder_path_3", name: "雷の熟練", description: "攻撃+25, クリティカル率+11%", cost: 3, x: -19, y: -15, requires: "thunder_storm", type: "stat", effect: { atk: 25, critChance: 0.11 } },
            { id: "thunder_path_4", name: "雷の極意", description: "攻撃+30, クリティカル率+14%", cost: 4, x: -22, y: -16, requires: "thunder_path_3", type: "stat", effect: { atk: 30, critChance: 0.14 } },
            { id: "thunder_path_5", name: "雷の神", description: "攻撃+35, クリティカル率+17%", cost: 4, x: -25, y: -17, requires: "thunder_path_4", type: "stat", effect: { atk: 35, critChance: 0.17 } },
            { id: "thunder_apex", name: "雷の頂点", description: "次の攻撃2.8倍、必ずクリティカル、クリティカル率+20%", cost: 7, x: -28, y: -18, requires: "thunder_path_5", type: "active", effect: { type: "active", damageMultiplier: 2.8, nextAttackCrit: true, critChance: 0.2 } },
            // 毒魔法の追加（4本目の魔法分岐）
            { id: "poison_path_1", name: "毒魔法", description: "攻撃+15, 毒付与率+5%", cost: 3, x: 10, y: -14, requires: "magic_path_4", type: "stat", effect: { atk: 15, poisonChance: 0.05 } },
            { id: "poison_path_2", name: "毒の熟練", description: "攻撃+20, 毒付与率+10%", cost: 3, x: 13, y: -15, requires: "poison_path_1", type: "stat", effect: { atk: 20, poisonChance: 0.1 } },
            { id: "poison_path_3", name: "毒の極意", description: "攻撃+25, 毒付与率+15%", cost: 3, x: 16, y: -16, requires: "poison_path_2", type: "stat", effect: { atk: 25, poisonChance: 0.15 } },
            { id: "toxic_cloud", name: "トキシッククラウド", description: "次の攻撃1.8倍、敵に毒3ターン", cost: 6, x: 19, y: -17, requires: "poison_path_3", type: "active", effect: { type: "active", damageMultiplier: 1.8, poison: true, poisonTurns: 3 } },
            { id: "poison_path_4", name: "毒の神", description: "攻撃+30, 毒付与率+20%", cost: 4, x: 22, y: -18, requires: "toxic_cloud", type: "stat", effect: { atk: 30, poisonChance: 0.2 } },
            { id: "poison_apex", name: "毒の頂点", description: "次の攻撃2.2倍、敵に毒5ターン、毒付与率+25%", cost: 7, x: 25, y: -19, requires: "poison_path_4", type: "active", effect: { type: "active", damageMultiplier: 2.2, poison: true, poisonTurns: 5, poisonChance: 0.25 } },

            // --- 特殊・クリティカルルート (左側) ---
            { id: "crit_path_1", name: "精密", description: "クリティカル率+2%（基礎5%に加算）", cost: 2, x: -8, y: 0, requires: "atk_path_1", type: "passive", effect: { critChance: 0.02 } },
            { id: "crit_path_2", name: "痛撃", description: "クリティカルダメージ+10%", cost: 2, x: -10, y: 0, requires: "crit_path_1", type: "passive", effect: { critMultiplier: 0.1 } },
            { id: "crit_mastery", name: "殺意", description: "クリティカル率+5%（基礎5%に加算）, クリティカルダメージ+20%", cost: 5, x: -12, y: 0, requires: "crit_path_2", type: "passive", effect: { critChance: 0.05, critMultiplier: 0.2 } },
            { id: "active_crit", name: "狙い澄まし", description: "次の攻撃は必ずクリティカルになる", cost: 4, x: -14, y: 0, requires: "crit_mastery", type: "active", effect: { type: "active", nextAttackCrit: true } },
            // Extended critical path
            { id: "crit_extreme_1", name: "殺戮者", description: "クリティカル率+8%（基礎5%に加算）, クリティカルダメージ+15%", cost: 4, x: -16, y: 0, requires: "active_crit", type: "passive", effect: { critChance: 0.08, critMultiplier: 0.15 } },
            { id: "crit_extreme_2", name: "処刑人", description: "クリティカル率+10%（基礎5%に加算）, クリティカルダメージ+20%", cost: 4, x: -18, y: 0, requires: "crit_extreme_1", type: "passive", effect: { critChance: 0.1, critMultiplier: 0.2 } },
            { id: "crit_path_3", name: "クリティカル率+", description: "クリティカル率+3%（基礎5%に加算）", cost: 2, x: -14, y: -2, requires: "crit_mastery", type: "passive", effect: { critChance: 0.03 } },
            { id: "crit_path_4", name: "クリティカル率++", description: "クリティカル率+4%（基礎5%に加算）", cost: 2, x: -16, y: -3, requires: "crit_path_3", type: "passive", effect: { critChance: 0.04 } },
            { id: "crit_path_5", name: "クリティカル率+++", description: "クリティカル率+5%（基礎5%に加算）", cost: 2, x: -18, y: -4, requires: "crit_path_4", type: "passive", effect: { critChance: 0.05 } },
            { id: "crit_apex", name: "クリティカルの頂点", description: "常時クリティカル率+20%（基礎5%に加算）, クリティカルダメージ+30%", cost: 7, x: -20, y: -5, requires: "crit_path_5", type: "passive", effect: { critChance: 0.2, critMultiplier: 0.3 } },
            { id: "overkill", name: "オーバーキル", description: "次の攻撃敵HP25%以下残り時即死", cost: 6, x: -22, y: -5, requires: "crit_apex", type: "active", effect: { type: "active", execute: true, executeThreshold: 0.25 } },

            // --- タンク・防御ルート (右側) ---
            { id: "tank_path_1", name: "頑健", description: "HP+20", cost: 2, x: 8, y: 0, requires: "def_path_1", type: "stat", effect: { maxHp: 20 } },
            { id: "tank_path_2", name: "鉄壁", description: "防御+15", cost: 2, x: 10, y: 0, requires: "tank_path_1", type: "stat", effect: { def: 15 } },
            { id: "tank_mastery", name: "不落の要塞", description: "常時 HP+5%, 防御+5%", cost: 5, x: 12, y: 0, requires: "tank_path_2", type: "passive", effect: { maxHpPercent: 0.05, defPercent: 0.05 } },
            { id: "active_unbreakable", name: "不動", description: "次のターン、受けるダメージを80%軽減するが、行動できない", cost: 4, x: 14, y: 0, requires: "tank_mastery", type: "active", effect: { type: "active", damageReduction: 0.8, skipNextTurn: true } },
            // Extended tank path
            { id: "tank_extreme_1", name: "要塞II", description: "HP+30, 防御+20", cost: 4, x: 16, y: 0, requires: "active_unbreakable", type: "stat", effect: { maxHp: 30, def: 20 } },
            { id: "tank_extreme_2", name: "絶対防御", description: "次のターン、ダメージを95%軽減", cost: 5, x: 18, y: 0, requires: "tank_extreme_1", type: "active", effect: { type: "active", damageReduction: 0.95, skipNextTurn: true } },
            { id: "tank_path_3", name: "頑健II", description: "HP+25", cost: 3, x: 14, y: -2, requires: "tank_path_2", type: "stat", effect: { maxHp: 25 } },
            { id: "tank_path_4", name: "頑健III", description: "HP+30", cost: 3, x: 16, y: -3, requires: "tank_path_3", type: "stat", effect: { maxHp: 30 } },
            { id: "tank_path_5", name: "頑健IV", description: "HP+35", cost: 3, x: 18, y: -4, requires: "tank_path_4", type: "stat", effect: { maxHp: 35 } },
            { id: "immortal_guard", name: "不死の守護者", description: "常時HP+20%, 防御+10%", cost: 6, x: 20, y: -5, requires: "tank_path_5", type: "passive", effect: { maxHpPercent: 0.2, defPercent: 0.1 } },
            // Tank branch up
            { id: "tank_branch_1", name: "守護者", description: "HP+20, 防御+15", cost: 3, x: 16, y: -6, requires: "tank_path_3", type: "stat", effect: { maxHp: 20, def: 15 } },
            { id: "tank_branch_2", name: "守護神", description: "HP+25, 防御+20", cost: 3, x: 18, y: -7, requires: "tank_branch_1", type: "stat", effect: { maxHp: 25, def: 20 } },
            { id: "sacrifice", name: "献身", description: "次の攻撃自身HP30%消費してダメージ2倍", cost: 6, x: 20, y: -8, requires: "tank_branch_2", type: "active", effect: { type: "active", damageMultiplier: 2.0, selfHpCost: 0.3 } },
            // Tank branch down
            { id: "tank_branch_d1", name: "硬直", description: "防御+20, 攻撃+5", cost: 3, x: 14, y: 2, requires: "tank_path_3", type: "stat", effect: { def: 20, atk: 5 } },
            { id: "tank_branch_d2", name: "重装甲", description: "防御+25, 攻撃+10", cost: 3, x: 16, y: 3, requires: "tank_branch_d1", type: "stat", effect: { def: 25, atk: 10 } },
            { id: "shield_wall", name: "シールドウォール", description: "次の攻撃を無効化、1ターン反撃不能", cost: 6, x: 18, y: 4, requires: "tank_branch_d2", type: "active", effect: { type: "active", invincible: true, skipNextTurn: true } },

            // --- 下部中央: ユーティリティ ---
            { id: "util_path_1", name: "熟練", description: "スキルコスト-1", cost: 3, x: 0, y: 4, requires: "core_speed_1", type: "passive", effect: { skillCostReduction: 1 } },
            { id: "util_path_2", name: "資源管理", description: "スキルポイントを3獲得", cost: 4, x: 0, y: 6, requires: "util_path_1", type: "passive", effect: { grantSkillPoints: 3 } },
            { id: "active_reset", name: "リセット", description: "使用済みのスキルを1つだけ再度使用可能にする", cost: 5, x: 0, y: 8, requires: "util_path_2", type: "active", effect: { type: "active", resetUsedSkill: 1 } },
            
            // --- 接続ノード ---
            { id: "connector_1", name: "道", cost: 1, x: -6, y: 1, requires: ["speed_path_2", "atk_path_3"], type: "stat", effect: {} },
            { id: "connector_2", name: "道", cost: 1, x: 6, y: -1, requires: ["def_path_2", "def_path_3"], type: "stat", effect: {} },
            { id: "connector_3", name: "道", cost: 1, x: -1, y: -3, requires: ["magic_path_1", "atk_path_1"], type: "stat", effect: {} },
            { id: "connector_4", name: "道", cost: 1, x: 1, y: 3, requires: ["hp_path_1", "core_speed_1"], type: "stat", effect: {} },

            // --- キーストーン：強烈な長所と明確な代償を持つビルド分岐 ---
            { id: "keystone_glass_cannon", name: "ガラスの大砲", description: "攻撃力+30%。代償として防御力-20%。攻撃の極意またはクリティカルの頂点から接続できる", cost: 8, x: -18, y: -13, requiresAny: ["atk_mastery", "crit_apex"], type: "keystone", effect: { atkPercent: 0.30, defPercent: -0.20 } },
            { id: "keystone_iron_wall", name: "不動要塞", description: "防御力+30%。代償として速さ-15%。防御の極意または不落の要塞から接続できる", cost: 8, x: 5, y: -14, requiresAny: ["def_mastery", "tank_mastery"], type: "keystone", effect: { defPercent: 0.30, speedPercent: -0.15 } },
            { id: "keystone_swift_blade", name: "疾風迅雷", description: "速さ+30%。代償として攻撃力-15%。速さの極意または速さVから接続できる", cost: 8, x: -18, y: 10, requiresAny: ["speed_mastery", "speed_path_5"], type: "keystone", effect: { speedPercent: 0.30, atkPercent: -0.15 } },
            { id: "keystone_blood_pact", name: "血の契約", description: "攻撃力+20%。代償として最大HP-15%。体力の極意または吸血鬼から接続できる", cost: 8, x: 5, y: 12, requiresAny: ["hp_mastery", "vampire"], type: "keystone", effect: { atkPercent: 0.20, maxHpPercent: -0.15 } },
        ]
    }

// ============================================
// 巨大な連結型パッシブツリー拡張（PoE型）
// 既存201ノードを維持し、12クラスター×150ノード＋9接続ノードを追加
// ============================================
function extendSkillTreeForPoEStyle() {
    const existing = new Set(SKILL_TREE.nodes.map(node => node.id));
    const branches = [
        { slug: 'bone', mechanic: 'minion', anchor: 'atk_mastery', angle: -158, name: '骨の軍勢', stat: 'atk', sideA: 'special', sideB: 'maxHp' },
        { slug: 'wraith', mechanic: 'minion', anchor: 'magic_mastery', angle: -128, name: '亡霊の契約', stat: 'special', sideA: 'atk', sideB: 'maxHp' },
        { slug: 'beast', mechanic: 'minion', anchor: 'tank_mastery', angle: -98, name: '獣王の群れ', stat: 'def', sideA: 'maxHp', sideB: 'speed' },
        { slug: 'storm', mechanic: 'lightning', anchor: 'speed_mastery', angle: -68, name: '雷嵐', stat: 'speed', sideA: 'atk', sideB: 'special' },
        { slug: 'spark', mechanic: 'lightning', anchor: 'special_mastery', angle: -38, name: '電光', stat: 'special', sideA: 'speed', sideB: 'atk' },
        { slug: 'chain', mechanic: 'lightning', anchor: 'crit_mastery', angle: -8, name: '連鎖放電', stat: 'atk', sideA: 'speed', sideB: 'def' },
        { slug: 'dodge', mechanic: 'mirror', anchor: 'speed_path_5', angle: 22, name: '残影', stat: 'speed', sideA: 'def', sideB: 'maxHp' },
        { slug: 'reflect', mechanic: 'mirror', anchor: 'immortal_guard', angle: 52, name: '鏡の守護', stat: 'def', sideA: 'maxHp', sideB: 'atk' },
        { slug: 'shadow', mechanic: 'mirror', anchor: 'tank_path_5', angle: 82, name: '影渡り', stat: 'speed', sideA: 'special', sideB: 'def' },
        { slug: 'pact', mechanic: 'blood', anchor: 'vampire', angle: 112, name: '血の盟約', stat: 'atk', sideA: 'maxHp', sideB: 'special' },
        { slug: 'sacrifice', mechanic: 'blood', anchor: 'hp_mastery', angle: 142, name: '生贄の祭壇', stat: 'maxHp', sideA: 'def', sideB: 'atk' },
        { slug: 'frenzy', mechanic: 'blood', anchor: 'crit_apex', angle: 172, name: '狂血', stat: 'atk', sideA: 'speed', sideB: 'special' }
    ];
    const anchorMap = new Map(SKILL_TREE.nodes.map(node => [node.id, node]));
    const keyDescriptions = {
        minion: [
            '通常攻撃3回ごとにミニオンを1体召喚。ミニオンは攻撃ごとに追加ダメージを与える。',
            'ミニオン上限+1。召喚したミニオンの追加ダメージが上昇する。',
            'ミニオン上限+1。ミニオンの追加ダメージがさらに上昇する。',
            'ミニオン上限+1。最大4体のミニオン軍団を率いる。'
        ],
        lightning: [
            '通常攻撃4回ごとに雷撃が発生し、追加ダメージを与える。',
            '雷撃の追加ダメージが上昇する。',
            '雷撃の追加ダメージがさらに上昇する。',
            '雷撃が強化され、4回目の攻撃で大きな放電を起こす。'
        ],
        mirror: [
            '回避成功時に残像を作る。次の通常攻撃に追加ダメージ。',
            '残像の反撃ダメージが上昇する。',
            '残像の反撃ダメージがさらに上昇する。',
            '残像の反撃が最大強度になる。'
        ],
        blood: [
            '通常攻撃時に最大HPの3%を消費し、攻撃ダメージを強化する。',
            'HP消費は4%。攻撃ダメージがさらに上昇する。',
            'HP消費は5%。攻撃ダメージがさらに上昇する。',
            'HP消費は6%。攻撃ダメージが大幅に上昇する。'
        ]
    };
    const statNames = { atk: '攻撃', def: '防御', speed: '速さ', special: '特殊', maxHp: '最大HP' };
    for (const branch of branches) {
        const anchor = anchorMap.get(branch.anchor);
        if (!anchor) continue;
        const rad = branch.angle * Math.PI / 180;
        const dx = Math.cos(rad), dy = Math.sin(rad);
        const px = -dy, py = dx;
        for (let depth = 1; depth <= 50; depth++) {
            for (let lane = -1; lane <= 1; lane++) {
                const isKeystone = lane === 0 && [12, 24, 36, 48].includes(depth);
                const tier = [12, 24, 36, 48].indexOf(depth) + 1;
                const id = isKeystone ? `ks_${branch.mechanic}_${branch.slug}_${tier}` : `poe_${branch.slug}_${depth}_${lane + 1}`;
                if (existing.has(id)) continue;
                const x = Number((anchor.x + dx * depth * 1.55 + px * lane * 1.05).toFixed(2));
                const y = Number((anchor.y + dy * depth * 1.55 + py * lane * 1.05).toFixed(2));
                const isNotable = !isKeystone && (depth % 10 === 0 || (lane !== 0 && depth % 15 === 0));
                const stat = lane === 0 ? branch.stat : (lane < 0 ? branch.sideA : branch.sideB);
                const statAmount = isNotable ? (stat === 'maxHp' ? 25 : 5) : (stat === 'maxHp' ? 8 : 2);
                const node = {
                    id,
                    name: isKeystone ? `${branch.name}：${({minion:'死霊の王権',lightning:'雷霆の心臓',mirror:'幻影の残滓',blood:'血盟の誓約'})[branch.mechanic]} ${tier}` : (isNotable ? `${branch.name}の熟達${depth}` : `${branch.name} ${String(depth).padStart(2, '0')}-${lane + 2}`),
                    description: isKeystone ? keyDescriptions[branch.mechanic][tier - 1] : `${statNames[stat]}+${statAmount}。${branch.name}系統を進むためのノード。`,
                    cost: isKeystone ? 7 + tier * 2 : (isNotable ? 3 : 1),
                    x, y,
                    requires: depth === 1 ? branch.anchor : (lane === 0 && [12, 24, 36, 48].includes(depth - 1)
                        ? `ks_${branch.mechanic}_${branch.slug}_${[12, 24, 36, 48].indexOf(depth - 1) + 1}`
                        : `poe_${branch.slug}_${depth - 1}_${lane + 1}`),
                    type: isKeystone ? 'keystone' : (isNotable ? 'passive' : 'stat'),
                    effect: isKeystone ? { keystone: branch.mechanic, tier, atk: 0 } : { [stat]: statAmount }
                };
                SKILL_TREE.nodes.push(node);
                existing.add(id);
            }
        }
    }
    // 9つの横断ブリッジ。複数の系統を横断する別ルートを作る。
    const bridges = [
        ['bridge_pact_bone','骨と血の盟約','atk_mastery','vampire',-10,16],
        ['bridge_storm_shadow','雷影の回廊','speed_mastery','speed_path_5',-6,18],
        ['bridge_wraith_sacrifice','亡霊の祭壇','magic_mastery','hp_mastery',-2,20],
        ['bridge_beast_reflect','獣鏡の結節','tank_mastery','immortal_guard',2,20],
        ['bridge_chain_frenzy','連鎖狂気','crit_mastery','crit_apex',6,18],
        ['bridge_bone_storm','骨雷の交差','atk_mastery','speed_mastery',10,16],
        ['bridge_mirror_pact','鏡血の交差','speed_path_5','vampire',14,14],
        ['bridge_guard_sacrifice','守護と犠牲','tank_mastery','hp_mastery',18,12],
        ['bridge_magic_crit','魔術の臨界','magic_mastery','crit_apex',22,10]
    ];
    for (const [id,name,a,b,x,y] of bridges) {
        if (existing.has(id)) continue;
        SKILL_TREE.nodes.push({ id, name, description: '異なる系統をつなぐ横断ルート。どちらか一方の接続ノードから習得できる。', cost: 4, x, y, requiresAny: [a,b], type: 'passive', effect: {} });
        existing.add(id);
    }
}
extendSkillTreeForPoEStyle();

// ツリー操作状態（ズーム倍率）
let skillTreeZoom = 1;
let skillTreeLayoutCache = null;

// ノードの元座標を保ちながら、近すぎるノードだけを少しずつ押し離す。
// 前提条件・効果データには触れず、表示上の座標だけを補正する。
function getSkillTreeLayout(nodes, hSpacing = 150, vSpacing = 130) {
    if (skillTreeLayoutCache && skillTreeLayoutCache.nodes === nodes) return skillTreeLayoutCache.positions;

    const items = nodes.map((node, index) => ({
        node,
        index,
        x: node.x * hSpacing,
        y: node.y * vSpacing,
        baseX: node.x * hSpacing,
        baseY: node.y * vSpacing
    }));
    const cellSize = 140;
    const minDistance = 120;
    const minDistanceSq = minDistance * minDistance;

    // 空間ハッシュで近傍だけを比較し、約2,000ノードでも二重ループを避ける。
    for (let iteration = 0; iteration < 36; iteration++) {
        const grid = new Map();
        for (const item of items) {
            const gx = Math.floor(item.x / cellSize);
            const gy = Math.floor(item.y / cellSize);
            const key = `${gx},${gy}`;
            if (!grid.has(key)) grid.set(key, []);
            grid.get(key).push(item);
        }

        for (const item of items) {
            const gx = Math.floor(item.x / cellSize);
            const gy = Math.floor(item.y / cellSize);
            for (let oy = -1; oy <= 1; oy++) {
                for (let ox = -1; ox <= 1; ox++) {
                    const nearby = grid.get(`${gx + ox},${gy + oy}`);
                    if (!nearby) continue;
                    for (const other of nearby) {
                        if (other.index <= item.index) continue;
                        let dx = other.x - item.x;
                        let dy = other.y - item.y;
                        let distanceSq = dx * dx + dy * dy;
                        if (distanceSq >= minDistanceSq) continue;
                        if (distanceSq < 0.001) {
                            // 同じ座標のノードも毎回同じ方向に分離する。
                            const angle = ((item.index * 37 + other.index * 17) % 360) * Math.PI / 180;
                            dx = Math.cos(angle) * 0.01;
                            dy = Math.sin(angle) * 0.01;
                            distanceSq = dx * dx + dy * dy;
                        }
                        const distance = Math.sqrt(distanceSq);
                        const push = (minDistance - distance) * 0.42;
                        const px = dx / distance * push;
                        const py = dy / distance * push;
                        item.x -= px; item.y -= py;
                        other.x += px; other.y += py;
                    }
                }
            }
        }

        // 元の枝の形が崩れないよう、毎回少しだけ元座標へ引き戻す。
        for (const item of items) {
            item.x += (item.baseX - item.x) * 0.025;
            item.y += (item.baseY - item.y) * 0.025;
        }
    }

    const positions = new Map(items.map(item => [item.node.id, { x: item.x, y: item.y }]));
    skillTreeLayoutCache = { nodes, positions };
    return positions;
}

// カスタムスキル作成コスト
const CUSTOM_SKILL_COST = 100;

// カスタムスキルのバリデーションルール
const CUSTOM_SKILL_VALIDATION = {
    // 禁止される効果（ゲームバランスを崩壊させるもの - 緩和）
    bannedEffects: [
        "infiniteDamage", // 無限ダメージ
        "deleteEnemy", // 敵削除
        "multiplyStatsByLargeAmount", // ステータス大幅増加
        "all", // 全て
        "every", // 全ての
        "unlimited", // 無制限
    ],
    
    // 効果の強度に基づく必要ステータス合計値
    // 各階級の間隔を約3倍に広げ、分類もtier20まで拡張した
    statRequirements: {
        tier1: { totalStats: 100, maxMultiplier: 1.05, description: "微弱" },
        tier2: { totalStats: 300, maxMultiplier: 1.1, description: "弱い" },
        tier3: { totalStats: 900, maxMultiplier: 1.15, description: "やや弱い" },
        tier4: { totalStats: 2700, maxMultiplier: 1.2, description: "普通" },
        tier5: { totalStats: 8100, maxMultiplier: 1.25, description: "やや強い" },
        tier6: { totalStats: 24300, maxMultiplier: 1.3, description: "強い" },
        tier7: { totalStats: 72900, maxMultiplier: 1.4, description: "かなり強い" },
        tier8: { totalStats: 218700, maxMultiplier: 1.5, description: "非常に強い" },
        tier9: { totalStats: 656100, maxMultiplier: 1.6, description: "極めて強い" },
        tier10: { totalStats: 1968300, maxMultiplier: 1.7, description: "超強力" },
        tier11: { totalStats: 5904900, maxMultiplier: 1.8, description: "伝説級" },
        tier12: { totalStats: 17714700, maxMultiplier: 1.9, description: "神話級" },
        tier13: { totalStats: 53144100, maxMultiplier: 2.0, description: "神級" },
        tier14: { totalStats: 159432300, maxMultiplier: 2.2, description: "超越" },
        tier15: { totalStats: 478296900, maxMultiplier: 2.5, description: "宇宙崩壊レベル" },
        tier16: { totalStats: 1434890700, maxMultiplier: 2.8, description: "極限" },
        tier17: { totalStats: 4304672100, maxMultiplier: 3.1, description: "次元超越" },
        tier18: { totalStats: 12914016300, maxMultiplier: 3.4, description: "創造主級" },
        tier19: { totalStats: 38742048900, maxMultiplier: 3.7, description: "全能" },
        tier20: { totalStats: 116226146700, maxMultiplier: 4.0, description: "理外の力" }
    }
};

// プレイヤーのスキルデータ初期化
function initializeSkillData(player) {
    if (!player.skillTree) {
        player.skillTree = {
            unlockedNodes: [],
            availablePoints: 0
        };
    }
    
    if (player.skillTree.availablePoints == null) {
        player.skillTree.availablePoints = 0;
    }

    // スキルスロットを初期化
    if (!player.skillSlots || !Array.isArray(player.skillSlots) || player.skillSlots.length !== 3) {
        player.skillSlots = [null, null, null]; // 3つのスキルスロット
    }
    
    // レガシーカスタムスキルのマイグレーション（IDがない場合）
    if (player.customSkills && Array.isArray(player.customSkills)) {
        player.customSkills = player.customSkills.map(skill => {
            if (!skill.id) {
                // IDがない場合は生成
                skill.id = `custom_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
            }
            if (!skill.type) {
                // typeがない場合はactiveに設定
                skill.type = "active";
            }
            if (!skill.effect) {
                // effectがない場合はデフォルト効果を設定
                skill.effect = { type: "active", damageMultiplier: 1.2 };
            }
            if (!skill.createdAt) {
                // createdAtがない場合は現在時刻を設定
                skill.createdAt = Date.now();
            }
            if (!skill.strength) {
                // strengthがない場合はデフォルト値を設定
                skill.strength = "tier4";
            }
            return skill;
        });
    }
    
    return player;
}

// レベルアップ時のスキルポイント付与
function addSkillPointsOnLevelUp(player, oldLevel, newLevel) {
    player = initializeSkillData(player);
    
    // 既にポイントを付与したレベルを追跡
    if (!player.skillTree.lastLevelGranted) {
        player.skillTree.lastLevelGranted = oldLevel;
    }
    
    // 既にこのレベルでポイントを付与済みの場合はスキップ
    if (player.skillTree.lastLevelGranted >= newLevel) {
        return player;
    }
    
    const levelsGained = newLevel - player.skillTree.lastLevelGranted;
    const pointsGained = levelsGained * SKILL_POINTS_PER_LEVEL;
    
    player.skillTree.availablePoints += pointsGained;
    player.skillTree.lastLevelGranted = newLevel;
    if (window.SBSound) SBSound.sfx('levelup');

    return player;
}

// スキルノードの解放
function unlockSkillNode(player, nodeId) {
    player = initializeSkillData(player);
    
    const skillTree = SKILL_TREE;
    if (!skillTree) return { success: false, error: 'スキルツリーが見つかりません' };
    
    const node = skillTree.nodes.find(n => n.id === nodeId);
    if (!node) return { success: false, error: 'スキルノードが見つかりません' };
    
    const playerTreeData = player.skillTree;
    if (!playerTreeData) return { success: false, error: 'スキルツリーデータが見つかりません' };
    
    // 既に解放済み
    if (playerTreeData.unlockedNodes.includes(nodeId)) {
        return { success: false, error: 'このスキルは既に解放されています' };
    }
    
    // スキルポイント不足
    if (playerTreeData.availablePoints < node.cost) {
        return { success: false, error: 'スキルポイントが不足しています' };
    }
    
    // 前提条件チェック。requires はすべて必要、requiresAny はいずれか1つでよい。
    if (node.requires) {
        const requirements = Array.isArray(node.requires) ? node.requires : [node.requires];
        if (!requirements.every(reqId => playerTreeData.unlockedNodes.includes(reqId))) {
            return { success: false, error: '前提条件のスキルを解放してください' };
        }
    }
    if (node.requiresAny) {
        const alternatives = Array.isArray(node.requiresAny) ? node.requiresAny : [node.requiresAny];
        if (!alternatives.some(reqId => playerTreeData.unlockedNodes.includes(reqId))) {
            return { success: false, error: '接続されたスキルのいずれかを先に解放してください' };
        }
    }
    
    // スキルを解放
    playerTreeData.unlockedNodes.push(nodeId);
    playerTreeData.availablePoints -= node.cost;
    
    // ポイントを付与するスキルの場合
    if (node.effect && node.effect.grantSkillPoints) {
        playerTreeData.availablePoints += node.effect.grantSkillPoints;
    }
    
    return { success: true, player };
}

// スキルノードの効果を取得
function getSkillNodeEffects(player) {
    player = initializeSkillData(player);
    
    const effects = {
        passive: {
            maxHp: 0, atk: 0, def: 0, speed: 0, special: 0,
            maxHpPercent: 0, atkPercent: 0, defPercent: 0, speedPercent: 0, specialPercent: 0,
            critChance: 0, critMultiplier: 0, skillCostReduction: 0
        },
        active: [],
        keystones: []
    };

    const playerTreeData = player.skillTree;
    if (!playerTreeData) return effects;
    
    const skillTree = SKILL_TREE;
    if (!skillTree) return effects;
    
    for (const nodeId of playerTreeData.unlockedNodes || []) {
        const node = skillTree.nodes.find(n => n.id === nodeId);
        if (!node) continue;
        
        if (node.type === "stat" || node.type === "passive" || node.type === "keystone") {
            // パッシブ効果を適用
            const effect = node.effect || {};
            if (node.type === "keystone" && effect.keystone) {
                effects.keystones.push({ id: node.id, mechanic: effect.keystone, tier: Number(effect.tier) || 1, name: node.name });
            }
            if (effect.grantSkillPoints) {
                // この効果はアンロック時に一度だけ適用されるべき
                // ここでは何もしない
            }

            for (const stat in effect) {
                if (stat !== "type" && effects.passive[stat] !== undefined) {
                    effects.passive[stat] += node.effect[stat];
                }
            }
        } else if (node.type === "active") {
            // アクティブスキルをリストに追加
            effects.active.push({
                id: node.id,
                name: node.name,
                description: node.description,
                effect: node.effect,
                type: "active" // 明示的に型を追加
            });
        }
    }
    // カスタムスキルもアクティブスキルとして含める（重複チェック付き）
    if (player.customSkills && Array.isArray(player.customSkills)) {
        player.customSkills.forEach(customSkill => {
            // レガシースキルのプロパティチェック
            if (!customSkill.id) {
                customSkill.id = `custom_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
            }
            if (!customSkill.type) {
                customSkill.type = "active";
            }
            if (!customSkill.effect) {
                customSkill.effect = { type: "active", damageMultiplier: 1.2 };
            }
            
            // 重複チェック
            if (!effects.active.some(skill => skill.id === customSkill.id)) {
                effects.active.push(customSkill);
            }
        });
    }

    // 重複を削除（カスタムスキルとツリースキルでIDが被ることはないが念のため）
    if (effects.active.length > 1) {
        effects.active = effects.active.filter((skill, index, self) =>
            index === self.findIndex((s) => (
                s.id === skill.id
            ))
        );
    }
    
    return effects;
}

// スキル効果をステータスに適用
function applySkillEffectsToStats(baseStats, player, weaponType) {
    const effects = getSkillNodeEffects(player);
    
    const stats = { ...baseStats };
    stats.maxHp += effects.passive.maxHp;
    stats.atk += effects.passive.atk;
    stats.def += effects.passive.def;
    stats.speed += effects.passive.speed;
    stats.special = (stats.special || 0) + effects.passive.special;
    
    return stats;
}

// カスタムスキルのバリデーション（厳しめのAI判定）
function validateCustomSkill(skillDescription, playerStats) {
    const totalStats = playerStats.maxHp + playerStats.atk + playerStats.def + playerStats.speed;
    const desc = skillDescription.toLowerCase();
    
    // 禁止効果チェック（より厳格）
    for (const banned of CUSTOM_SKILL_VALIDATION.bannedEffects) {
        if (desc.includes(banned.toLowerCase())) {
            return { 
                valid: false, 
                reason: `この効果はゲームバランスを崩壊させるため許可されていません: "${banned}"` 
            };
        }
    }
    
    // 効果の強度を推定（より詳細なAI判定）
    let estimatedStrength = "tier1";
    let estimatedMultiplier = 1.0;
    
    // ダメージ倍率の抽出（より広範なパターン）
    const multiplierMatches = desc.match(/(\d+\.?\d*)\s*倍|(\d+\.?\d*)\s*%|(\d+\.?\d*)x|(\d+\.?\d*)\s*times/i);
    if (multiplierMatches) {
        const num = parseFloat(multiplierMatches[1] || multiplierMatches[2] || multiplierMatches[3] || multiplierMatches[4]);
        if (!isNaN(num)) {
            if (desc.includes('%')) {
                estimatedMultiplier = 1 + (num / 100);
            } else {
                estimatedMultiplier = num;
            }
        }
    }
    
    // キーワードベースの強度判定（緩和された判定 - より広範な解釈）
    if (estimatedMultiplier >= 3.0 || desc.includes('3倍') || desc.includes('3.0') || desc.includes('3x') || desc.includes('triple')) {
        estimatedStrength = "tier8";
    } else if (estimatedMultiplier >= 2.5 || desc.includes('2.5') || desc.includes('2.5x')) {
        estimatedStrength = "tier7";
    } else if (estimatedMultiplier >= 2.0 || desc.includes('2.0') || desc.includes('double') || desc.includes('2x') || desc.includes('二倍')) {
        estimatedStrength = "tier6";
    } else if (estimatedMultiplier >= 1.8 || desc.includes('1.8x') || desc.includes('1.9x')) {
        estimatedStrength = "tier5";
    } else if (estimatedMultiplier >= 1.6 || desc.includes('1.6x') || desc.includes('1.7x')) {
        estimatedStrength = "tier4";
    } else if (estimatedMultiplier >= 1.5 || desc.includes('1.5x') || desc.includes('50%up') || desc.includes('半分')) {
        estimatedStrength = "tier3";
    } else if (estimatedMultiplier >= 1.4 || desc.includes('1.4x')) {
        estimatedStrength = "tier2";
    } else if (estimatedMultiplier >= 1.3 || desc.includes('1.3x') || desc.includes('30%up')) {
        estimatedStrength = "tier1";
    } else if (estimatedMultiplier >= 1.25 || desc.includes('1.25x')) {
        estimatedStrength = "tier1";
    } else if (estimatedMultiplier >= 1.2 || desc.includes('25%') || desc.includes('30%') || desc.includes('少し') || desc.includes('1.2x') || desc.includes('20%up')) {
        estimatedStrength = "tier1";
    } else if (estimatedMultiplier >= 1.15 || desc.includes('1.15x')) {
        estimatedStrength = "tier1";
    } else if (estimatedMultiplier >= 1.1 || desc.includes('10%') || desc.includes('15%') || desc.includes('わずか') || desc.includes('1.1x') || desc.includes('10%up')) {
        estimatedStrength = "tier1";
    } else if (estimatedMultiplier >= 1.05 || desc.includes('5%') || desc.includes('1.05x')) {
        estimatedStrength = "tier1";
    } else if (estimatedMultiplier > 1.0) {
        estimatedStrength = "tier1";
    }
    
    // 特殊効果の補正（緩和された判定 - より広範な解釈）
    if (desc.includes('リスポーン') || desc.includes('復活') || desc.includes('respawn') || desc.includes('revive') || desc.includes('resurrect')) {
        estimatedStrength = "tier13";
    } else if (desc.includes('即死') || desc.includes('一撃') || desc.includes('instant') || desc.includes('onehit') || desc.includes('kill')) {
        estimatedStrength = "tier20";
    } else if (desc.includes('インビジブル') || desc.includes('透明') || desc.includes('invisible') || desc.includes('stealth') || desc.includes('hide')) {
        estimatedStrength = "tier11";
    } else if (desc.includes('リフレクト') || desc.includes('反射') || desc.includes('reflect') || desc.includes('mirror')) {
        estimatedStrength = "tier11";
    } else if (desc.includes('範囲') || desc.includes('全体') || desc.includes('aoe') || desc.includes('area') || desc.includes('splash')) {
        estimatedStrength = "tier10";
    } else if (desc.includes('スタン') || desc.includes('気絶') || desc.includes('stun') || desc.includes('paralyze') || desc.includes('freeze')) {
        estimatedStrength = "tier9";
    } else if (desc.includes('バーサーク') || desc.includes('狂化') || desc.includes('berserk') || desc.includes('rage') || desc.includes('frenzy')) {
        estimatedStrength = "tier10";
    } else if (desc.includes('エクスキュート') || desc.includes('処刑') || desc.includes('execute') || desc.includes('finish') || desc.includes('finisher')) {
        estimatedStrength = "tier12";
    } else if (desc.includes('回復') && (desc.includes('50%') || desc.includes('半分') || desc.includes('大幅') || desc.includes('full') || desc.includes('完全'))) {
        estimatedStrength = "tier10";
    } else if (desc.includes('無効') || desc.includes('パリー') || desc.includes('完全防御') || desc.includes('無傷') || desc.includes('nullify') || desc.includes('negate') || desc.includes('block')) {
        estimatedStrength = "tier11";
    } else if (desc.includes('回避') && (desc.includes('50%') || desc.includes('半分') || desc.includes('確実') || desc.includes('完全'))) {
        estimatedStrength = "tier10";
    } else if (desc.includes('貫通') && (desc.includes('完全') || desc.includes('100%') || desc.includes('true'))) {
        estimatedStrength = "tier10";
    } else if (desc.includes('回復') && (desc.includes('30%') || desc.includes('1/3') || desc.includes('中程度'))) {
        estimatedStrength = "tier8";
    } else if (desc.includes('回避') || desc.includes('dodge') || desc.includes('evade') || desc.includes('miss')) {
        estimatedStrength = "tier8";
    } else if (desc.includes('貫通') || desc.includes('pierce') || desc.includes('penetrate') || desc.includes('ignore')) {
        estimatedStrength = "tier8";
    } else if (desc.includes('吸収') || desc.includes('ライフスティール') || desc.includes('vampiric') || desc.includes('lifesteal') || desc.includes('drain')) {
        estimatedStrength = "tier8";
    } else if (desc.includes('カウンター') || desc.includes('反撃') || desc.includes('counter') || desc.includes('retaliate') || desc.includes('revenge')) {
        estimatedStrength = "tier9";
    } else if (desc.includes('シールド') || desc.includes('バリア') || desc.includes('shield') || desc.includes('barrier') || desc.includes('protect')) {
        estimatedStrength = "tier7";
    } else if (desc.includes('クリティカル') || desc.includes('会心') || desc.includes('critical') || desc.includes('crit') || desc.includes('致命')) {
        estimatedStrength = "tier7";
    } else if (desc.includes('連続') || desc.includes('複数') || desc.includes('multi') || desc.includes('combo') || desc.includes('chain')) {
        estimatedStrength = "tier8";
    } else if (desc.includes('テレポート') || desc.includes('瞬間移動') || desc.includes('teleport') || desc.includes('blink') || desc.includes('dash')) {
        estimatedStrength = "tier8";
    } else if (desc.includes('呪い') || desc.includes('カース') || desc.includes('デバフ') || desc.includes('弱体化') || desc.includes('curse') || desc.includes('debuff') || desc.includes('weaken')) {
        estimatedStrength = "tier6";
    } else if (desc.includes('敵の攻撃低下') || desc.includes('enemy attack down') || desc.includes('相手の攻撃ダウン') || desc.includes('攻撃弱体') || desc.includes('敵の防御低下') || desc.includes('enemy defense down') || desc.includes('相手の防御ダウン') || desc.includes('防御弱体') || desc.includes('敵の命中低下') || desc.includes('enemy accuracy down') || desc.includes('命中率ダウン')) {
        estimatedStrength = "tier3";
    } else if (desc.includes('毒') || desc.includes('poison') || desc.includes('burn') || desc.includes('burning') || desc.includes('bleed')) {
        estimatedStrength = "tier2";
    } else if (desc.includes('リジェネ') || desc.includes('再生') || desc.includes('regen') || desc.includes('regeneration') || desc.includes('restore')) {
        estimatedStrength = "tier3";
    } else if (desc.includes('バフ') || desc.includes('強化') || desc.includes('buff') || desc.includes('enhance') || desc.includes('boost')) {
        estimatedStrength = "tier4";
    } else if (desc.includes('スロー') || desc.includes('遅延') || desc.includes('slow') || desc.includes('delay') || desc.includes('hindrance')) {
        estimatedStrength = "tier4";
    } else if (desc.includes('回復') || desc.includes('heal') || desc.includes('cure') || desc.includes('recover')) {
        estimatedStrength = "tier3";
    }
    
    // パースされたeffectオブジェクトに基づいて効果数をカウント
    const parsedEffect = parseEffectFromDescription(desc);
    let effectCount = 0;
    let effectScore = 0; // 効果のスコア（各効果の重要度に基づく）
    
    if (parsedEffect) {
        // 各効果にスコアを割り当て
        if (parsedEffect.damageMultiplier) {
            effectCount++;
            effectScore += Math.floor((parsedEffect.damageMultiplier - 1) * 10); // 1.2倍なら2点
        }
        if (parsedEffect.damageReduction) {
            effectCount++;
            effectScore += Math.floor(parsedEffect.damageReduction * 10); // 30%なら3点
        }
        if (parsedEffect.lifeSteal) {
            effectCount++;
            effectScore += Math.floor(parsedEffect.lifeSteal * 10); // 30%なら3点
        }
        if (parsedEffect.heal) {
            effectCount++;
            effectScore += Math.min(parsedEffect.heal / 10, 5); // 最大5点
        }
        if (parsedEffect.healPercent) {
            effectCount++;
            effectScore += Math.floor(parsedEffect.healPercent * 10); // 30%なら3点
        }
        if (parsedEffect.sureHit) {
            effectCount++;
            effectScore += 5; // 必中は重要
        }
        if (parsedEffect.ignoreDef) {
            effectCount++;
            effectScore += 4; // 防御無視は重要
        }
        if (parsedEffect.nextAttackCrit) {
            effectCount++;
            effectScore += 5; // クリティカル確定は重要
        }
        if (parsedEffect.critChance) {
            effectCount++;
            effectScore += Math.floor(parsedEffect.critChance * 10); // 20%なら2点
        }
        if (parsedEffect.burn) {
            effectCount++;
            effectScore += 1; // 火傷は中程度
        }
        if (parsedEffect.poison) {
            effectCount++;
            effectScore += 1; // 毒は中程度
        }
        if (parsedEffect.speedDebuff) {
            effectCount++;
            effectScore += Math.floor(parsedEffect.speedDebuff * 10); // 20%なら2点
        }
        if (parsedEffect.enemyAtkDebuff) {
            effectCount++;
            effectScore += Math.floor(parsedEffect.enemyAtkDebuff * 10); // 20%なら2点
        }
        if (parsedEffect.enemyDefDebuff) {
            effectCount++;
            effectScore += Math.floor(parsedEffect.enemyDefDebuff * 10); // 20%なら2点
        }
        if (parsedEffect.enemyAccuracyDebuff) {
            effectCount++;
            effectScore += Math.floor(parsedEffect.enemyAccuracyDebuff * 10); // 20%なら2点
        }
        if (parsedEffect.shield) {
            effectCount++;
            effectScore += Math.min(parsedEffect.shield / 10, 5); // 最大5点
        }
        if (parsedEffect.dodgeChance) {
            effectCount++;
            effectScore += Math.floor(parsedEffect.dodgeChance * 10); // 20%なら2点
        }
        if (parsedEffect.counter) {
            effectCount++;
            effectScore += 4; // 反撃は重要
        }
        if (parsedEffect.multiHit) {
            effectCount++;
            effectScore += (parsedEffect.multiHit - 1) * 3; // 2回なら3点、3回なら6点
        }
        if (parsedEffect.skipNextTurn) {
            effectCount++;
            effectScore += 3; // ターンスキップは中程度
        }
        if (parsedEffect.selfDefDebuff) {
            effectCount++;
            effectScore += 2; // 自身のデバフは軽い
        }
        
        if (parsedEffect.defBuff) {
            effectCount++;
            effectScore += Math.floor((parsedEffect.defBuff - 1) * 10); // 1.2倍なら2点
        }
        
        // 「代わりに」スキルの場合はポイント減点
        if (parsedEffect.hasTradeoff) {
            effectScore = Math.floor(effectScore * 0.8); // 20%減点
            console.log('Tradeoff detected, score reduced to:', effectScore);
        }
        
        console.log('Parsed effect score:', effectScore, 'Effect count:', effectCount);
    }
    
    // パースされた効果に基づいて強度を計算
    if (effectScore > 0) {
        // 効果スコアに基づいてティアを決定
        if (effectScore >= 20) {
            estimatedStrength = "tier12";
        } else if (effectScore >= 15) {
            estimatedStrength = "tier11";
        } else if (effectScore >= 12) {
            estimatedStrength = "tier10";
        } else if (effectScore >= 10) {
            estimatedStrength = "tier9";
        } else if (effectScore >= 8) {
            estimatedStrength = "tier8";
        } else if (effectScore >= 6) {
            estimatedStrength = "tier7";
        } else if (effectScore >= 4) {
            estimatedStrength = "tier6";
        } else if (effectScore >= 3) {
            estimatedStrength = "tier5";
        } else if (effectScore >= 2) {
            estimatedStrength = "tier4";
        } else {
            estimatedStrength = "tier3";
        }
    }
    
    // 複合効果によるランクアップ（ティアシステム対応）
    const strengthLevels = ["tier1", "tier2", "tier3", "tier4", "tier5", "tier6", "tier7", "tier8", "tier9", "tier10", "tier11", "tier12", "tier13", "tier14", "tier15", "tier16", "tier17", "tier18", "tier19", "tier20"];
    const currentIndex = strengthLevels.indexOf(estimatedStrength);
    
    if (effectCount >= 4) {
        // 4つ以上の効果で3ティア昇格
        if (currentIndex < strengthLevels.length - 3) {
            estimatedStrength = strengthLevels[currentIndex + 3];
        } else {
            estimatedStrength = strengthLevels[strengthLevels.length - 1];
        }
    } else if (effectCount >= 3) {
        // 3つの効果で2ティア昇格
        if (currentIndex < strengthLevels.length - 2) {
            estimatedStrength = strengthLevels[currentIndex + 2];
        } else {
            estimatedStrength = strengthLevels[strengthLevels.length - 1];
        }
    } else if (effectCount >= 2) {
        // 2つの効果で1ティア昇格
        if (currentIndex < strengthLevels.length - 1) {
            estimatedStrength = strengthLevels[currentIndex + 1];
        } else {
            estimatedStrength = strengthLevels[strengthLevels.length - 1];
        }
    }
    
    const requirement = CUSTOM_SKILL_VALIDATION.statRequirements[estimatedStrength];
    
    // ティア15（宇宙崩壊レベル）は許可（緩和）
    // 即死や無限ダメージなどの極端な効果はbannedEffectsでフィルタリング済み
    
    if (totalStats < requirement.totalStats) {
        return { 
            valid: false, 
            reason: `ステータスが不足しています。効果強度: ${requirement.description}、必要ステータス: 合計${requirement.totalStats}、現在: 合計${totalStats}` 
        };
    }
    
    return { valid: true, strength: estimatedStrength, requiredStats: requirement.totalStats, description: requirement.description };
}

// スキル説明文からeffectオブジェクトを簡易的に生成
function parseEffectFromDescription(description) {
    const finalEffect = { type: "active" }; // 必ず active タイプを付与
    const desc = description.toLowerCase();
    let effectFound = false;

    // --- 効果のパース（拡張版 - 複数効果対応） ---
    
    // 複数回攻撃 (例: "3段攻撃", "3回攻撃", "triple attack", "3-hit attack")
    const multiHitMatch = desc.match(/(\d+)[\s]*(?:段|回|連)[\s]*攻撃/i);
    if (multiHitMatch) { finalEffect.multiHit = parseInt(multiHitMatch[1]); effectFound = true; }

    // 英語版複数回攻撃 (例: "3-hit attack", "triple attack")
    const multiHitEnglishMatch = desc.match(/(\d+)[\s]*-[\s]*hit[\s]*attack|triple[\s]*attack|double[\s]*attack/i);
    if (multiHitEnglishMatch) {
        if (multiHitEnglishMatch[0].includes('triple')) {
            finalEffect.multiHit = 3;
        } else if (multiHitEnglishMatch[0].includes('double')) {
            finalEffect.multiHit = 2;
        } else if (multiHitEnglishMatch[1]) {
            finalEffect.multiHit = parseInt(multiHitEnglishMatch[1]);
        }
        effectFound = true;
    }

    // 連続攻撃キーワード (例: "連続攻撃", "combo attack", "コンビネーション")
    if (desc.includes("連続攻撃") || desc.includes("combo attack") || desc.includes("連続") || desc.includes("コンビネーション")) {
        if (!finalEffect.multiHit) {
            finalEffect.multiHit = 2; // デフォルトで2回
        }
        effectFound = true;
    }

    // 追加の複数回攻撃キーワード
    if (desc.includes("多段") || desc.includes("多段攻撃") || desc.includes("multi hit") || desc.includes("multi-hit")) {
        if (!finalEffect.multiHit) {
            finalEffect.multiHit = 2;
        }
        effectFound = true;
    }

    // さらなる複数回攻撃パターン
    if (desc.includes("二連撃") || desc.includes("二回攻撃") || desc.includes("2連撃") || desc.includes("double hit")) {
        if (!finalEffect.multiHit) {
            finalEffect.multiHit = 2;
        }
        effectFound = true;
    }

    if (desc.includes("三連撃") || desc.includes("三回攻撃") || desc.includes("3連撃") || desc.includes("triple hit")) {
        if (!finalEffect.multiHit) {
            finalEffect.multiHit = 3;
        }
        effectFound = true;
    }

    if (desc.includes("四連撃") || desc.includes("四回攻撃") || desc.includes("4連撃") || desc.includes("quad hit")) {
        if (!finalEffect.multiHit) {
            finalEffect.multiHit = 4;
        }
        effectFound = true;
    }

    if (desc.includes("五連撃") || desc.includes("五回攻撃") || desc.includes("5連撃") || desc.includes("penta hit")) {
        if (!finalEffect.multiHit) {
            finalEffect.multiHit = 5;
        }
        effectFound = true;
    }
    
    // ターン数のパース (例: "3ターンの間", "for 3 turns", "3 turns")
    const turnsMatch = desc.match(/(\d+)[\s]*(?:ターン|turn|round)[\s]*(?:の間|for|during)/i);
    if (turnsMatch) { 
        finalEffect.turns = parseInt(turnsMatch[1]); 
        effectFound = true; 
    }
    
    // ダメージ倍率 (例: "ダメージ1.2倍", "攻撃が1.5倍", "damage 1.5x", "1.5倍ダメージ")
    const damageMultiplierMatch = desc.match(/(?:ダメージ|攻撃|威力|damage|attack|power)[をが]?[\s]*([\d.]+)[\s]*(?:倍|x|times)/i);
    if (damageMultiplierMatch) { finalEffect.damageMultiplier = parseFloat(damageMultiplierMatch[1]); effectFound = true; }

    // 単独の倍率パターン (例: "0.5倍", "1.2x") - 複数回攻撃と競合しないように
    const simpleMultiplierMatch = desc.match(/([\d.]+)[\s]*(?:倍|x)(?!.*段)(?!.*回攻撃)/i);
    if (simpleMultiplierMatch && !damageMultiplierMatch) {
        const num = parseFloat(simpleMultiplierMatch[1]);
        finalEffect.damageMultiplier = num;
        effectFound = true;
    }

    // パーセンテージ倍率 (例: "150%ダメージ", "50%up", "増加50%")
    const percentMultiplierMatch = desc.match(/([\d.]+)%[\s]*(?:ダメージ|damage|up|増加|increase|boost)/i);
    if (percentMultiplierMatch) {
        finalEffect.damageMultiplier = 1 + (parseFloat(percentMultiplierMatch[1]) / 100);
        effectFound = true;
    }

    // 追加の倍率キーワード（防御強化を除外）
    if ((desc.includes("強化") || desc.includes("増強") || desc.includes("boost") || desc.includes("enhance")) && 
        !desc.includes("防御") && !desc.includes("defense") && !desc.includes("def")) {
        if (!finalEffect.damageMultiplier) {
            finalEffect.damageMultiplier = 1.2; // デフォルトで1.2倍
        }
        effectFound = true;
    }

    // さらなる倍率パターン
    if (desc.includes("強")) {
        if (!finalEffect.damageMultiplier) {
            finalEffect.damageMultiplier = 1.3;
        }
        effectFound = true;
    }

    if (desc.includes("超強化") || desc.includes("超強") || desc.includes("super boost")) {
        if (!finalEffect.damageMultiplier) {
            finalEffect.damageMultiplier = 1.5;
        }
        effectFound = true;
    }

    if (desc.includes("絶大") || desc.includes("巨大") || desc.includes("massive") || desc.includes("huge")) {
        if (!finalEffect.damageMultiplier) {
            finalEffect.damageMultiplier = 2.0;
        }
        effectFound = true;
    }

    // 防御バフ (例: "防御を1.2倍にする", "防御1.2倍", "defense 1.2x")
    const defBuffMatch = desc.match(/(?:防御|defense|def)[をが]?[\s]*([\d.]+)[\s]*(?:倍|x|times)/i);
    if (defBuffMatch) { 
        finalEffect.defBuff = parseFloat(defBuffMatch[1]); 
        effectFound = true; 
    }
    
    // 防御バフのキーワードパターン
    if (desc.includes("防御強化") || desc.includes("defense boost") || desc.includes("def up")) {
        if (!finalEffect.defBuff) {
            finalEffect.defBuff = 1.2; // デフォルトで1.2倍
        }
        effectFound = true;
    }
    
    // ダメージ軽減 (例: "ダメージを30%軽減", "30% damage reduction", "防御30%")
    const damageReductionMatch = desc.match(/(?:ダメージ|damage|攻撃|attack)[をが]?[\s]*([\d.]+)%[\s]*(?:軽減|reduction|減少|reduce|down)/i);
    if (damageReductionMatch) { finalEffect.damageReduction = parseFloat(damageReductionMatch[1]) / 100.0; effectFound = true; }

    // 追加の軽減キーワード
    if (desc.includes("軽減") || desc.includes("カット") || desc.includes("reduce") || desc.includes("mitigate")) {
        if (!finalEffect.damageReduction) {
            finalEffect.damageReduction = 0.3; // デフォルトで30%軽減
        }
        effectFound = true;
    }

    // さらなる軽減パターン
    if (desc.includes("半減") || desc.includes("半分") || desc.includes("half") || desc.includes("50%")) {
        if (!finalEffect.damageReduction) {
            finalEffect.damageReduction = 0.5;
        }
        effectFound = true;
    }

    if (desc.includes("大幅軽減") || desc.includes("大減少") || desc.includes("greatly reduce")) {
        if (!finalEffect.damageReduction) {
            finalEffect.damageReduction = 0.7;
        }
        effectFound = true;
    }

    if (desc.includes("完全無効") || desc.includes("無傷") || desc.includes("nullify") || desc.includes("immune")) {
        if (!finalEffect.damageReduction) {
            finalEffect.damageReduction = 1.0;
        }
        effectFound = true;
    }

    // ライフスティール (例: "与えたダメージの30%を吸収", "30% lifesteal", "30% life steal", "吸収")
    const lifeStealMatch = desc.match(/(?:与えたダメージの|lifesteal|life steal|吸収|ドレイン|drain)[\s]*([\d.]+)%/i);
    if (lifeStealMatch) { finalEffect.lifeSteal = parseFloat(lifeStealMatch[1]) / 100.0; effectFound = true; }
    
    // 追加のライフスティールキーワード
    if (desc.includes("吸収") || desc.includes("吸血") || desc.includes("vampiric") || desc.includes("vampire")) {
        if (!finalEffect.lifeSteal) {
            finalEffect.lifeSteal = 0.3; // デフォルトで30%
        }
        effectFound = true;
    }

    // 回復 (例: "HPを30回復", "heal 30", "recover 30 hp", "回復30")
    const healMatch = desc.match(/(?:hp|health)[\s]*(?:を|to)?[\s]*([\d.]+)[\s]*(?:回復|heal|recover|restore)/i);
    if (healMatch) { finalEffect.heal = parseFloat(healMatch[1]); effectFound = true; }

    // 追加の回復キーワード
    if (desc.includes("回復") || desc.includes("ヒール") || desc.includes("heal") || desc.includes("cure")) {
        if (!finalEffect.heal && !finalEffect.healPercent) {
            finalEffect.heal = 30; // デフォルトで30回復
        }
        effectFound = true;
    }

    // さらなる回復パターン
    if (desc.includes("完全回復") || desc.includes("全回復") || desc.includes("full heal") || desc.includes("full recovery")) {
        if (!finalEffect.healPercent) {
            finalEffect.healPercent = 1.0;
        }
        effectFound = true;
    }

    if (desc.includes("大幅回復") || desc.includes("大回復") || desc.includes("large heal") || desc.includes("major heal")) {
        if (!finalEffect.heal && !finalEffect.healPercent) {
            finalEffect.heal = 50;
        }
        effectFound = true;
    }

    if (desc.includes("小回復") || desc.includes("微回復") || desc.includes("small heal") || desc.includes("minor heal")) {
        if (!finalEffect.heal && !finalEffect.healPercent) {
            finalEffect.heal = 15;
        }
        effectFound = true;
    }
    
    // 回復率 (例: "HPの30%回復", "30% heal", "30%回復")
    const healPercentMatch = desc.match(/(?:hp|health)[\s]*(?:の|of)?[\s]*([\d.]+)%[\s]*(?:回復|heal|recover)/i);
    if (healPercentMatch) { finalEffect.healPercent = parseFloat(healPercentMatch[1]) / 100.0; effectFound = true; }

    // 必中 (例: "攻撃を必中にする", "sure hit", "always hit", "外さない")
    if (desc.includes("必中") || desc.includes("sure hit") || desc.includes("always hit") || desc.includes("外さない") || desc.includes("外れない")) { finalEffect.sureHit = true; effectFound = true; }

    // 防御無視 (例: "敵の防御を無視", "ignore defense", "pierce defense", "貫通", "突破")
    if (desc.includes("防御無視") || desc.includes("ignore defense") || desc.includes("pierce defense") || desc.includes("貫通") || desc.includes("突破") || desc.includes("penetrate")) { finalEffect.ignoreDef = true; effectFound = true; }

    // クリティカル確定 (例: "次の攻撃は必ずクリティカル", "guaranteed crit", "always critical", "必クリ")
    if (desc.includes("必ずクリティカル") || desc.includes("guaranteed crit") || desc.includes("always critical") || desc.includes("必クリ") || desc.includes("必会")) { finalEffect.nextAttackCrit = true; effectFound = true; }

    // クリティカル率アップ (例: "クリティカル率30%アップ", "30% crit chance", "会心率上昇")
    const critChanceMatch = desc.match(/(?:クリティカル|crit|会心)[\s]*(?:率|chance)?[\s]*([\d.]+)%/i);
    if (critChanceMatch) { finalEffect.critChance = parseFloat(critChanceMatch[1]) / 100.0; effectFound = true; }

    // 追加のクリティカルキーワード
    if (desc.includes("クリティカル") || desc.includes("critical") || desc.includes("会心") || desc.includes("crit")) {
        if (!finalEffect.critChance && !finalEffect.nextAttackCrit) {
            finalEffect.critChance = 0.2; // デフォルトで20%
        }
        effectFound = true;
    }

    // さらなるクリティカルパターン
    if (desc.includes("高クリティカル率") || desc.includes("高会心率") || desc.includes("high crit") || desc.includes("high critical")) {
        if (!finalEffect.critChance) {
            finalEffect.critChance = 0.4;
        }
        effectFound = true;
    }

    if (desc.includes("必クリ") || desc.includes("会心確定") || desc.includes("guaranteed crit") || desc.includes("certain crit")) {
        finalEffect.nextAttackCrit = true;
        effectFound = true;
    }

    // 火傷付与 (例: "敵に火傷付与", "burn enemy", "apply burn", "燃やす")
    if (desc.includes("火傷") || desc.includes("burn") || desc.includes("燃やす") || desc.includes("炎")) { 
        finalEffect.burn = { turns: 3 }; 
        effectFound = true; 
    }
    
    // 毒付与 (例: "敵に毒付与", "poison enemy", "apply poison", "毒状態")
    if (desc.includes("毒") || desc.includes("poison") || desc.includes("毒状態")) { 
        finalEffect.poison = { turns: 3 }; 
        effectFound = true; 
    }
    
    // 出血付与 (例: "出血", "bleed", "doom")
    if (desc.includes("出血") || desc.includes("bleed") || desc.includes("doom")) { finalEffect.poison = true; effectFound = true; }

    // 速度低下 (例: "敵の速さを20%低下", "reduce speed by 20%", "slow 20%", "鈍足")
    const speedDebuffMatch = desc.match(/(?:速さ|speed|spped)[\s]*(?:を|by)?[\s]*([\d.]+)%[\s]*(?:低下|reduce|slow|down|減少)/i);
    if (speedDebuffMatch) { finalEffect.speedDebuff = parseFloat(speedDebuffMatch[1]) / 100.0; effectFound = true; }

    // 追加の速度低下キーワード
    if (desc.includes("鈍足") || desc.includes("遅く") || desc.includes("slow") || desc.includes("slower")) {
        if (!finalEffect.speedDebuff) {
            finalEffect.speedDebuff = 0.2; // デフォルトで20%
        }
        effectFound = true;
    }

    // 敵の攻撃力低下 (例: "敵の攻撃力を20%低下", "reduce enemy attack by 20%", "enemy attack -20%")
    const enemyAtkDebuffMatch = desc.match(/(?:敵|enemy|相手)[\s]*(?:の|'?s)?[\s]*(?:攻撃|attack|atk)[\s]*(?:力|power)?[\s]*(?:を|by)?[\s]*-?([\d.]+)%?[\s]*(?:低下|reduce|down|減少|weak)/i);
    if (enemyAtkDebuffMatch) { finalEffect.enemyAtkDebuff = parseFloat(enemyAtkDebuffMatch[1]) / 100.0; effectFound = true; }

    // 追加の敵攻撃力低下キーワード
    if (desc.includes("敵の攻撃低下") || desc.includes("enemy attack down") || desc.includes("相手の攻撃ダウン") || desc.includes("攻撃弱体")) {
        if (!finalEffect.enemyAtkDebuff) {
            finalEffect.enemyAtkDebuff = 0.2; // デフォルトで20%
        }
        effectFound = true;
    }

    // 敵の防御力低下 (例: "敵の防御力を20%低下", "reduce enemy defense by 20%", "enemy defense -20%")
    const enemyDefDebuffMatch = desc.match(/(?:敵|enemy|相手)[\s]*(?:の|'?s)?[\s]*(?:防御|defense|def)[\s]*(?:力|power)?[\s]*(?:を|by)?[\s]*-?([\d.]+)%?[\s]*(?:低下|reduce|down|減少|weak)/i);
    if (enemyDefDebuffMatch) { finalEffect.enemyDefDebuff = parseFloat(enemyDefDebuffMatch[1]) / 100.0; effectFound = true; }

    // 追加の敵防御力低下キーワード
    if (desc.includes("敵の防御低下") || desc.includes("enemy defense down") || desc.includes("相手の防御ダウン") || desc.includes("防御弱体")) {
        if (!finalEffect.enemyDefDebuff) {
            finalEffect.enemyDefDebuff = 0.2; // デフォルトで20%
        }
        effectFound = true;
    }

    // 敵の命中率低下 (例: "敵の命中率を20%低下", "reduce enemy accuracy by 20%", "enemy accuracy -20%")
    const enemyAccuracyDebuffMatch = desc.match(/(?:敵|enemy|相手)[\s]*(?:の|'?s)?[\s]*(?:命中|accuracy)[\s]*(?:率|rate)?[\s]*(?:を|by)?[\s]*-?([\d.]+)%?[\s]*(?:低下|reduce|down|減少)/i);
    if (enemyAccuracyDebuffMatch) { finalEffect.enemyAccuracyDebuff = parseFloat(enemyAccuracyDebuffMatch[1]) / 100.0; effectFound = true; }

    // 追加の敵命中率低下キーワード
    if (desc.includes("敵の命中低下") || desc.includes("enemy accuracy down") || desc.includes("命中率ダウン")) {
        if (!finalEffect.enemyAccuracyDebuff) {
            finalEffect.enemyAccuracyDebuff = 0.2; // デフォルトで20%
        }
        effectFound = true;
    }

    // シールド (例: "シールド30", "shield 30", "barrier 30", "保護")
    const shieldMatch = desc.match(/(?:シールド|shield|barrier|保護|防御壁)[\s]*([\d.]+)/i);
    if (shieldMatch) { finalEffect.shield = parseFloat(shieldMatch[1]); effectFound = true; }

    // 追加のシールドキーワード
    if (desc.includes("シールド") || desc.includes("shield") || desc.includes("バリア") || desc.includes("barrier") || desc.includes("保護")) {
        if (!finalEffect.shield) {
            finalEffect.shield = 30; // デフォルトで30
        }
        effectFound = true;
    }

    // さらなるシールドパターン
    if (desc.includes("強力なシールド") || desc.includes("強シールド") || desc.includes("strong shield") || desc.includes("powerful barrier")) {
        if (!finalEffect.shield) {
            finalEffect.shield = 50;
        }
        effectFound = true;
    }

    if (desc.includes("完全防御") || desc.includes("無敵") || desc.includes("invincible") || desc.includes("untouchable")) {
        if (!finalEffect.shield) {
            finalEffect.shield = 999;
        }
        effectFound = true;
    }

    // 回避率アップ (例: "回避率30%アップ", "30% dodge chance", "30% evade", "回避上昇")
    const dodgeMatch = desc.match(/(?:回避|dodge|evade|miss)[\s]*(?:率|chance)?[\s]*([\d.]+)%/i);
    if (dodgeMatch) { finalEffect.dodgeChance = parseFloat(dodgeMatch[1]) / 100.0; effectFound = true; }

    // 追加の回避キーワード
    if (desc.includes("回避") || desc.includes("dodge") || desc.includes("evade") || desc.includes("避ける")) {
        if (!finalEffect.dodgeChance) {
            finalEffect.dodgeChance = 0.2; // デフォルトで20%
        }
        effectFound = true;
    }

    // さらなる回避パターン
    if (desc.includes("高回避率") || desc.includes("高回避") || desc.includes("high dodge") || desc.includes("high evasion")) {
        if (!finalEffect.dodgeChance) {
            finalEffect.dodgeChance = 0.4;
        }
        effectFound = true;
    }

    if (desc.includes("完全回避") || desc.includes("確実回避") || desc.includes("perfect dodge") || desc.includes("certain evade")) {
        finalEffect.dodgeChance = 1.0;
        effectFound = true;
    }

    // 反撃 (例: "反撃する", "counter attack", "retaliate", "カウンター")
    if (desc.includes("反撃") || desc.includes("counter") || desc.includes("retaliate") || desc.includes("カウンター") || desc.includes("反撃攻撃")) { finalEffect.counter = true; effectFound = true; }

    // 追加の特殊効果パターン
    if (desc.includes("吸血") || desc.includes("vampiric") || desc.includes("blood drain")) {
        if (!finalEffect.lifeSteal) {
            finalEffect.lifeSteal = 0.3;
        }
        effectFound = true;
    }

    if (desc.includes("反射") || desc.includes("mirror") || desc.includes("reflect damage")) {
        finalEffect.counter = true;
        effectFound = true;
    }

    if (desc.includes("無敵") || desc.includes("invincible") || desc.includes("untouchable")) {
        if (!finalEffect.damageReduction) {
            finalEffect.damageReduction = 1.0;
        }
        effectFound = true;
    }
    if (desc.includes("即死") || desc.includes("一撃必殺") || desc.includes("instant kill") || desc.includes("one shot")) {
        if (!finalEffect.damageMultiplier) {
            finalEffect.damageMultiplier = 10.0;
        }
        effectFound = true;
    }

    if (desc.includes("麻痺") || desc.includes("スタン") || desc.includes("paralyze") || desc.includes("stun")) {
        finalEffect.skipNextTurn = true;
        effectFound = true;
    }

    if (desc.includes("沈黙") || desc.includes("封印") || desc.includes("silence") || desc.includes("seal")) {
        finalEffect.skipNextTurn = true;
        effectFound = true;
    }

    if (desc.includes("凍結") || desc.includes("フリーズ") || desc.includes("freeze") || desc.includes("frozen")) {
        finalEffect.skipNextTurn = true;
        effectFound = true;
    }

    if (desc.includes("石化") || desc.includes("ストーン") || desc.includes("petrify") || desc.includes("stone")) {
        finalEffect.skipNextTurn = true;
        effectFound = true;
    }

    if (desc.includes("挑発") || desc.includes("タウント") || desc.includes("taunt") || desc.includes("provoke")) {
        finalEffect.skipNextTurn = true;
        effectFound = true;
    }

    // --- デメリット/コストのパース ---
    // 「代わりに」パターン (例: "攻撃を1.5倍にする代わりに防御を0.8倍にする")
    const insteadMatch = desc.match(/(?:代わりに|instead|in exchange for|but|however)/i);
    if (insteadMatch) {
        finalEffect.hasTradeoff = true; // トレードオフがあることをマーク
        effectFound = true;
    }
    
    // 自身の防御デバフ (例: "自身の防御-10", "self defense -10", "防御ダウン")
    const selfDefDebuffMatch = desc.match(/(?:自身|self|自分)[\s]*(?:の|)?[\s]*(?:防御|defense)[\s]*-([\d.]+)/i);
    if (selfDefDebuffMatch) { finalEffect.selfDefDebuff = parseFloat(selfDefDebuffMatch[1]); effectFound = true; }
    
    // 追加の防御デバフキーワード
    if (desc.includes("防御ダウン") || desc.includes("defense down") || desc.includes("防御低下")) {
        if (!finalEffect.selfDefDebuff) {
            finalEffect.selfDefDebuff = 10; // デフォルトで10
        }
        effectFound = true;
    }

    // 次のターンスキップ (例: "次のターン行動できない", "skip next turn", "休む")
    if (desc.includes("行動できない") || desc.includes("skip") || desc.includes("skip turn") || desc.includes("休む") || desc.includes("休止")) { finalEffect.skipNextTurn = true; effectFound = true; }

    // --- 条件のパース ---
    // HP条件 (例: "hpが50%以下の時", "when hp below 50%", "hp < 50%", "残りHP50%以下")
    const hpConditionMatch = desc.match(/(?:hp|health|残りhp)[\s]*(?:が|is|below|<|以下)[\s]*([\d.]+)%/i);
    if (hpConditionMatch) {
        finalEffect.condition = { type: 'hp_below', value: parseFloat(hpConditionMatch[1]) / 100 };
        effectFound = true;
    }
    
    // 確率条件 (例: "30%の確率で", "30% chance to", "確率30%")
    const chanceConditionMatch = desc.match(/(?:確率|chance|probability)[\s]*([\d.]+)%/i);
    if (chanceConditionMatch) {
        finalEffect.chance = parseFloat(chanceConditionMatch[1]) / 100;
        effectFound = true;
    }

    // 何かしらの効果がパースできた場合のみ effect オブジェクトを返す
    return effectFound ? finalEffect : null;
}


// カスタムスキルの作成
function createCustomSkill(player, skillName, skillDescription) {
    // コインチェック
    if ((player.coins || 0) < CUSTOM_SKILL_COST) {
        return { success: false, error: `コインが不足しています（必要: ${CUSTOM_SKILL_COST}）` };
    }
    
    // ステータスチェック
    const stats = getStatsFromPlayer(player);

    // effectをパース
    const effect = parseEffectFromDescription(skillDescription);
    if (!effect) {
        return { success: false, error: "スキルの効果を解釈できませんでした。指定された形式で入力してください。（例：次の攻撃のダメージ1.2倍）" };
    }
    const validation = validateCustomSkill(skillDescription, stats);
    
    if (!validation.valid) {
        return { success: false, error: validation.reason };
    }
    
    // カスタムスキルを追加
    if (!player.customSkills) {
        player.customSkills = [];
    }
    
    const customSkill = {
        id: `custom_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
        name: skillName,
        description: skillDescription,
        effect: effect,
        strength: validation.strength,
        createdAt: Date.now()
    };
    
    player.customSkills.push(customSkill);
    player.coins -= CUSTOM_SKILL_COST;
    
    return { success: true, player, skill: customSkill };
}

// ============================================
// UI描画関連
// ============================================

function injectSkillTreeCSS() {
    // CSSはstyle.cssに直接追加したため、この関数は何もしない
    return;
}

function renderSkillTreeUI() {
    console.log('renderSkillTreeUI called');
    const container = document.getElementById('skillTreeContainer');
    if (!container) {
        console.log('renderSkillTreeUI: skillTreeContainer not found');
        return;
    }

    const player = getPlayerData();
    if (!player) {
        console.log('renderSkillTreeUI: player not found');
        container.innerHTML = '<p>プレイヤーデータが見つかりません。</p>';
        return;
    }

    console.log('renderSkillTreeUI: player found, skillTree:', player.skillTree);

    // index.htmlの静的UIを使用するため、動的生成は行わない
    // スキルポイント表示のみ更新
    const totalSkillPointsDisplay = document.getElementById('totalSkillPointsDisplay');
    if (totalSkillPointsDisplay) {
        totalSkillPointsDisplay.textContent = `総スキルポイント: ${player.skillTree?.availablePoints || 0}`;
    }

    // 初期表示
    renderTree();

    renderSkillSlots(player);
    renderAvailableSkills(player);
    renderCustomSkillList(player);
    
    // スキル説明表示エリアを作成
    if (!document.getElementById('skillDescriptionArea')) {
        const descArea = document.createElement('div');
        descArea.id = 'skillDescriptionArea';
        descArea.className = 'skill-description-area';
        descArea.style.display = 'none';
        descArea.innerHTML = '<p>スキルを選択してください</p>';
        container.appendChild(descArea);
    }

    // イベントリスナー（index.htmlの静的UIのボタンに対応）
    const createCustomSkillBtn = document.getElementById('createCustomSkillBtn');
    if (createCustomSkillBtn) {
        createCustomSkillBtn.onclick = () => {
            console.log('Create custom skill button clicked');
            const player = getPlayerData();
            console.log('Player data:', player);
            
            const skillName = document.getElementById('customSkillName').value.trim();
            const skillDescription = document.getElementById('customSkillDescription').value.trim();
            
            console.log('Skill name:', skillName);
            console.log('Skill description:', skillDescription);

            if (!skillName || !skillDescription) {
                alert('スキル名と内容を入力してください。');
                return;
            }

            const result = createCustomSkill(player, skillName, skillDescription);
            console.log('Create skill result:', result);

            if (result.success) {
                localStorage.setItem("player", JSON.stringify(result.player));
                alert(`オリジナルスキル「${result.skill.name}」を作成しました！`);
                // 入力をクリア
                document.getElementById('customSkillName').value = '';
                document.getElementById('customSkillDescription').value = '';
                renderSkillTreeUI(); // UI全体を再描画
                if (typeof updateStatus === 'function') updateStatus(result.player);
            } else {
                alert(`作成に失敗しました:\n${result.error}`);
            }
        };
    } else {
        console.log('createCustomSkillBtn not found');
    }
}

// ノード間の接続線を描画するためのヘルパー関数
function drawConnection(svg, x1, y1, x2, y2, isUnlocked) {
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', x1);
    line.setAttribute('y1', y1);
    line.setAttribute('x2', x2);
    line.setAttribute('y2', y2);
    line.setAttribute('stroke', isUnlocked ? '#3498db' : '#2a2d32');
    line.setAttribute('stroke-width', '2');
    svg.appendChild(line);
}

function renderTree() {
    const content = document.getElementById('skillTreeCanvas');
    const pointsDisplay = document.getElementById('totalSkillPointsDisplay');
    if (!content || !pointsDisplay) return;
    const player = getPlayerData();
    if (!player) return;

    const treeData = SKILL_TREE;
    const playerData = player.skillTree || { unlockedNodes: [], availablePoints: 0 };
    const unlocked = new Set(playerData.unlockedNodes || []);
    pointsDisplay.textContent = `総スキルポイント: ${playerData.availablePoints || 0} / ノード: ${treeData.nodes.length.toLocaleString()}`;
    content.innerHTML = '';

    const NODE_WIDTH = 70, NODE_HEIGHT = 48;
    // Layout is cached by getSkillTreeLayout; repeated unlocks no longer rerun the
    // 36-pass collision solver for the same immutable tree.
    const positions = getSkillTreeLayout(treeData.nodes, 150, 130);
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const node of treeData.nodes) {
        const p = positions.get(node.id);
        if (!p) continue;
        minX = Math.min(minX, p.x); minY = Math.min(minY, p.y);
        maxX = Math.max(maxX, p.x); maxY = Math.max(maxY, p.y);
    }
    if (!Number.isFinite(minX)) return;

    const PADDING = 120;
    const offsetX = -minX + PADDING, offsetY = -minY + PADDING;
    const totalWidth = maxX - minX + NODE_WIDTH + PADDING * 2;
    const totalHeight = maxY - minY + NODE_HEIGHT + PADDING * 2;

    const world = document.createElement('div');
    world.className = 'skill-tree-world';
    world.style.width = `${totalWidth * skillTreeZoom}px`;
    world.style.height = `${totalHeight * skillTreeZoom}px`;
    const innerContent = document.createElement('div');
    innerContent.className = 'skill-tree-inner';
    innerContent.style.width = `${totalWidth}px`;
    innerContent.style.height = `${totalHeight}px`;
    innerContent.style.transform = `scale(${skillTreeZoom})`;
    world.appendChild(innerContent);
    content.appendChild(world);

    const nodeById = new Map(treeData.nodes.map(n => [n.id, n]));
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', `0 0 ${totalWidth} ${totalHeight}`);
    svg.setAttribute('width', totalWidth);
    svg.setAttribute('height', totalHeight);
    svg.style.position = 'absolute'; svg.style.inset = '0'; svg.style.pointerEvents = 'none';
    innerContent.appendChild(svg);

    const nodesLayer = document.createElement('div');
    nodesLayer.className = 'skill-tree-nodes-layer';
    nodesLayer.style.position = 'absolute'; nodesLayer.style.inset = '0';
    innerContent.appendChild(nodesLayer);

    // Virtualize the tree: only create buttons and SVG edges near the visible
    // viewport. The full world remains scrollable, so no gameplay/navigation changes.
    let refreshQueued = false;
    const refreshViewport = () => {
        refreshQueued = false;
        const zoom = Math.max(0.02, skillTreeZoom);
        const margin = Math.max(650, 900 / zoom);
        const left = Math.max(0, content.scrollLeft / zoom - margin);
        const top = Math.max(0, content.scrollTop / zoom - margin);
        const right = Math.min(totalWidth, (content.scrollLeft + content.clientWidth) / zoom + margin);
        const bottom = Math.min(totalHeight, (content.scrollTop + content.clientHeight) / zoom + margin);
        const visible = [];

        nodesLayer.replaceChildren();
        while (svg.firstChild) svg.removeChild(svg.firstChild);

        for (const node of treeData.nodes) {
            const pos = positions.get(node.id);
            if (!pos) continue;
            const x = pos.x + offsetX, y = pos.y + offsetY;
            if (x + NODE_WIDTH < left || x > right || y + NODE_HEIGHT < top || y > bottom) continue;
            visible.push({ node, x, y });
        }

        for (const item of visible) {
            const node = item.node;
            const requiredIds = [
                ...(node.requires ? (Array.isArray(node.requires) ? node.requires : [node.requires]) : []),
                ...(node.requiresAny ? (Array.isArray(node.requiresAny) ? node.requiresAny : [node.requiresAny]) : [])
            ];
            for (const reqId of requiredIds) {
                const requiredNode = nodeById.get(reqId);
                const reqPos = requiredNode && positions.get(requiredNode.id);
                if (!reqPos) continue;
                const rx = reqPos.x + offsetX, ry = reqPos.y + offsetY;
                if (rx + NODE_WIDTH < left || rx > right || ry + NODE_HEIGHT < top || ry > bottom) continue;
                drawConnection(svg,
                    rx + NODE_WIDTH / 2, ry + NODE_HEIGHT / 2,
                    item.x + NODE_WIDTH / 2, item.y + NODE_HEIGHT / 2,
                    unlocked.has(node.id));
            }
        }

        for (const item of visible) {
            const node = item.node;
            const nodeEl = document.createElement('button');
            nodeEl.type = 'button';
            nodeEl.className = `skill-node ${node.type}`;
            nodeEl.style.left = `${item.x}px`; nodeEl.style.top = `${item.y}px`;
            nodeEl.title = `${node.name}\n${node.description}\nコスト: ${node.cost}`;
            nodeEl.setAttribute('aria-label', `${node.name}。${node.description}`);
            const isUnlocked = unlocked.has(node.id);
            const requirements = node.requires ? (Array.isArray(node.requires) ? node.requires : [node.requires]) : [];
            const alternatives = node.requiresAny ? (Array.isArray(node.requiresAny) ? node.requiresAny : [node.requiresAny]) : [];
            const allRequired = requirements.every(reqId => unlocked.has(reqId));
            const anyAlternative = alternatives.length === 0 || alternatives.some(reqId => unlocked.has(reqId));
            const isUnlockable = !isUnlocked && (playerData.availablePoints || 0) >= node.cost && allRequired && anyAlternative;
            nodeEl.classList.add(isUnlocked ? 'unlocked' : (isUnlockable ? 'unlockable' : 'locked'));
            const label = document.createElement('span'); label.textContent = node.name; nodeEl.appendChild(label);
            nodeEl.onclick = e => { e.stopPropagation(); showSkillDescription(node, isUnlocked, isUnlockable); };
            nodeEl.ondblclick = e => {
                e.stopPropagation();
                if (!isUnlockable) { alert(isUnlocked ? 'このスキルは既に習得済みです。' : '前提ノードとスキルポイントを確認してください。'); return; }
                if (!confirm(`${node.name} を習得しますか？ (コスト: ${node.cost})`)) return;
                const result = unlockSkillNode(getPlayerData(), node.id);
                if (!result.success) { alert(result.error); return; }
                localStorage.setItem('player', JSON.stringify(result.player));
                if (typeof syncPlayerToServer === 'function') syncPlayerToServer(true);
                if (typeof updateStatus === 'function') updateStatus(result.player);
                renderTree(); renderAvailableSkills(result.player);
            };
            nodesLayer.appendChild(nodeEl);
        }
    };
    content._skillTreeRefreshViewport = () => {
        if (refreshQueued) return;
        refreshQueued = true;
        requestAnimationFrame(refreshViewport);
    };
    if (content._skillTreeScrollHandler) content.removeEventListener('scroll', content._skillTreeScrollHandler);
    content._skillTreeScrollHandler = content._skillTreeRefreshViewport;
    content.addEventListener('scroll', content._skillTreeScrollHandler, { passive: true });

    const startNode = nodeById.get('start_node');
    if (startNode && !content.dataset.userMoved) {
        const startPos = positions.get(startNode.id);
        requestAnimationFrame(() => {
            content.scrollLeft = (startPos.x + offsetX) * skillTreeZoom - content.clientWidth / 2 + NODE_WIDTH * skillTreeZoom / 2;
            content.scrollTop = (startPos.y + offsetY) * skillTreeZoom - content.clientHeight / 2 + NODE_HEIGHT * skillTreeZoom / 2;
            content._skillTreeRefreshViewport?.();
        });
    }
    content._skillTreeRefreshViewport();
    setupSkillTreeControls(content, nodeById, positions, offsetX, offsetY, NODE_WIDTH, NODE_HEIGHT);
}

function setupSkillTreeControls(content, nodeById, positions, offsetX, offsetY, nodeWidth, nodeHeight) {
    if (content.dataset.controlsReady === '1') return;
    content.dataset.controlsReady = '1';
    const setZoom = (next, anchorX = content.clientWidth / 2, anchorY = content.clientHeight / 2) => {
        const old = skillTreeZoom;
        skillTreeZoom = Math.max(0.02, Math.min(1.8, next));
        const world = content.querySelector('.skill-tree-world');
        const inner = content.querySelector('.skill-tree-inner');
        if (!world || !inner) return;
        const logicalX = (content.scrollLeft + anchorX) / old;
        const logicalY = (content.scrollTop + anchorY) / old;
        const width = parseFloat(inner.style.width), height = parseFloat(inner.style.height);
        world.style.width = `${width * skillTreeZoom}px`; world.style.height = `${height * skillTreeZoom}px`;
        inner.style.transform = `scale(${skillTreeZoom})`;
        content._skillTreeRefreshViewport?.();
        content.scrollLeft = logicalX * skillTreeZoom - anchorX;
        content.scrollTop = logicalY * skillTreeZoom - anchorY;
        const label = document.getElementById('skillTreeZoomLabel'); if (label) label.textContent = `${Math.round(skillTreeZoom * 100)}%`;
    };
    const bind = (id, fn) => { const el = document.getElementById(id); if (el) el.onclick = fn; };
    bind('skillTreeZoomIn', () => setZoom(skillTreeZoom + 0.1));
    bind('skillTreeZoomOut', () => setZoom(skillTreeZoom - 0.1));
    bind('skillTreeZoomReset', () => setZoom(1));
    bind('skillTreeFit', () => { const inner = content.querySelector('.skill-tree-inner'); const width = parseFloat(inner?.style.width) || 1; const height = parseFloat(inner?.style.height) || 1; setZoom(Math.min(1, (content.clientWidth - 40) / width, (content.clientHeight - 40) / height)); });
    const search = document.getElementById('skillTreeSearch');
    if (search) search.oninput = () => {
        const q = search.value.trim().toLocaleLowerCase();
        const found = q ? SKILL_TREE.nodes.find(n => n.name.toLocaleLowerCase().includes(q) || n.description.toLocaleLowerCase().includes(q)) : null;
        if (!found) return;
        const pos = positions.get(found.id);
        const x = (pos.x + offsetX + nodeWidth / 2) * skillTreeZoom;
        const y = (pos.y + offsetY + nodeHeight / 2) * skillTreeZoom;
        content.scrollTo({ left: Math.max(0, x - content.clientWidth / 2), top: Math.max(0, y - content.clientHeight / 2), behavior: 'smooth' });
    };
    let dragging = false, startX = 0, startY = 0, scrollX = 0, scrollY = 0;
    content.addEventListener('pointerdown', e => {
        if (e.target.closest('.skill-node')) return;
        dragging = true; startX = e.clientX; startY = e.clientY; scrollX = content.scrollLeft; scrollY = content.scrollTop;
        content.classList.add('is-panning'); content.setPointerCapture?.(e.pointerId);
    });
    content.addEventListener('pointermove', e => {
        if (!dragging) return;
        content.dataset.userMoved = '1'; content.scrollLeft = scrollX - (e.clientX - startX); content.scrollTop = scrollY - (e.clientY - startY);
    });
    const stop = () => { dragging = false; content.classList.remove('is-panning'); };
    content.addEventListener('pointerup', stop); content.addEventListener('pointercancel', stop);
    content.addEventListener('wheel', e => {
        e.preventDefault();
        setZoom(skillTreeZoom + (e.deltaY < 0 ? 0.08 : -0.08), e.offsetX, e.offsetY);
    }, { passive: false });
}

function showSkillDescription(node, isUnlocked, isUnlockable) {
    const descArea = document.getElementById('skillDescriptionArea');
    if (!descArea) return;
    
    let statusText = '';
    if (isUnlocked) {
        statusText = '<span class="status-unlocked">習得済み</span>';
    } else if (isUnlockable) {
        statusText = '<span class="status-unlockable">習得可能（ダブルクリックで習得）</span>';
    } else {
        statusText = '<span class="status-locked">未解放</span>';
    }
    
    descArea.style.display = 'block';
    descArea.innerHTML = `
        <h3>${node.name}</h3>
        <p><strong>タイプ:</strong> ${node.type === 'keystone' ? 'キーストーン（大きな長所と代償）' : node.type}</p>
        <p><strong>説明:</strong> ${node.description}</p>
        ${node.type === 'keystone' ? '<p class="keystone-detail-note">戦闘ルールを変える特殊効果です。効果はサーバー側の戦闘処理で判定されます。</p>' : ''}
        <p><strong>コスト:</strong> ${node.cost} スキルポイント</p>
        <p><strong>状態:</strong> ${statusText}</p>
        ${node.requires ? `<p><strong>前提スキル（すべて必要）:</strong> ${Array.isArray(node.requires) ? node.requires.join(', ') : node.requires}</p>` : ''}
        ${node.requiresAny ? `<p><strong>接続ルート（いずれか1つ）:</strong> ${Array.isArray(node.requiresAny) ? node.requiresAny.join(' / ') : node.requiresAny}</p>` : ''}
    `;
}

function renderSkillSlots(player) {
    const slotsContainer = document.getElementById('skillSlotsContainer');
    if (!slotsContainer) {
        console.log('renderSkillSlots: skillSlotsContainer not found');
        return;
    }

    console.log('renderSkillSlots: player.skillSlots =', player.skillSlots);
    
    slotsContainer.innerHTML = '';
    
    // 空のスロットを確実に表示
    if (!player.skillSlots || player.skillSlots.length === 0) {
        player.skillSlots = [null, null, null];
    }
    
    // 攻撃タイプセレクターの初期化
    const attackTypeSelector = document.querySelector('.attack-type-selector');
    if (attackTypeSelector) {
        const currentAttackType = player.attackType || 'attack';
        attackTypeSelector.querySelectorAll('.attack-type-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.attackType === currentAttackType) {
                btn.classList.add('active');
            }
        });
        
        // 攻撃タイプ選択のイベントリスナー
        attackTypeSelector.querySelectorAll('.attack-type-btn').forEach(btn => {
            btn.onclick = () => {
                const selectedType = btn.dataset.attackType;
                player.attackType = selectedType;
                localStorage.setItem("player", JSON.stringify(player));
                
                // UIの更新
                attackTypeSelector.querySelectorAll('.attack-type-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            };
        });
    }

    // サモンズロッド：モンスター選択UIの更新（武器種・サブ武器種として使っていない場合は非表示になる）
    if (typeof renderSummonMonsterUI === 'function') {
        renderSummonMonsterUI(player);
    }
    
    player.skillSlots.forEach((skill, index) => {
        const slotEl = document.createElement('div');
        slotEl.className = 'skill-slot';
        slotEl.dataset.slotIndex = index;
        
        // ドロップゾーンとして設定
        slotEl.ondragover = (e) => {
            e.preventDefault();
            slotEl.classList.add('drag-over');
        };
        
        slotEl.ondragleave = () => {
            slotEl.classList.remove('drag-over');
        };
        
        slotEl.ondrop = (e) => {
            e.preventDefault();
            slotEl.classList.remove('drag-over');
            const skillId = e.dataTransfer.getData('skillId');
            const skillName = e.dataTransfer.getData('skillName');
            
            if (skillId) {
                const result = equipSkillToSlot(getPlayerData(), skillId, index);
                if (result.success) {
                    localStorage.setItem("player", JSON.stringify(result.player));
                    renderSkillTreeUI();
                } else {
                    alert(result.error);
                }
            }
        };
        
        if (skill) {
            slotEl.classList.add('filled');
            // レガシースキルのプロパティチェック
            const skillName = skill.name || "名前なし";
            const skillId = skill.id || `legacy_${index}`;
            const skillDescription = skill.description || "説明なし";
            
            const costTxt = (window.SBCost && skill.effect) ? ` ⚖${Math.round(window.SBCost.costOfActiveSkill(skill) * 10) / 10}` : '';
            slotEl.innerHTML = `<span>${skillName}${costTxt}</span><button class="unequip-skill-btn" data-skill-id="${skillId}">X</button>`;
            slotEl.title = skillDescription;
        } else {
            slotEl.textContent = `スロット ${index + 1}`;
            slotEl.classList.add('empty');
        }
        slotsContainer.appendChild(slotEl);
    });

    slotsContainer.querySelectorAll('.unequip-skill-btn').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation(); // 親要素のクリックイベントが発火しないように
            const slotIndex = parseInt(btn.closest('.skill-slot').dataset.slotIndex);
            const result = unequipSkillFromSlot(getPlayerData(), slotIndex);
            if (result.success) { localStorage.setItem("player", JSON.stringify(result.player)); renderSkillTreeUI(); } else { alert(result.error); }
        };
    });
}

function renderCustomSkillList(player) {
    const listContainer = document.getElementById('customSkillList');
    if (!listContainer) return;
    // playerが渡されなかった場合は自分で取得する（呼び出し漏れによるクラッシュを防ぐ）
    if (!player) player = getPlayerData();
    if (!player) return;

    listContainer.innerHTML = '';
    const customSkills = player.customSkills || [];

    if (customSkills.length === 0) {
        listContainer.innerHTML = '<p>まだありません。</p>';
        return;
    }

    const ul = document.createElement('ul');
    customSkills.forEach((skill, index) => {
        // レガシースキルのプロパティチェック
        if (!skill.id) {
            skill.id = `custom_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
        }
        if (!skill.name) {
            skill.name = "名前なし";
        }
        if (!skill.description) {
            skill.description = "説明なし";
        }
        
        const li = document.createElement('li');
        li.className = 'custom-skill-item';
        li.innerHTML = `
            <div class="skill-info">
                <div class="skill-name"><strong>${skill.name}</strong></div>
                <div class="skill-description">${skill.description}</div>
            </div>
            <button class="delete-skill-btn" data-skill-index="${index}" data-skill-id="${skill.id}">削除</button>
        `;
        ul.appendChild(li);
    });
    listContainer.appendChild(ul);
    
    // 削除ボタンのイベントリスナー
    listContainer.querySelectorAll('.delete-skill-btn').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const skillIndex = parseInt(btn.dataset.skillIndex);
            const skillId = btn.dataset.skillId;
            
            if (confirm(`このスキルを削除しますか？削除したスキルは復元できません。`)) {
                const player = getPlayerData();
                if (player.customSkills && player.customSkills[skillIndex]) {
                    // スキルスロットからも削除
                    player.skillSlots = player.skillSlots.map(slot => {
                        if (slot && slot.id === skillId) {
                            return null;
                        }
                        return slot;
                    });
                    
                    // カスタムスキルを削除
                    player.customSkills.splice(skillIndex, 1);
                    
                    localStorage.setItem("player", JSON.stringify(player));
                    renderCustomSkillList(player);
                }
            }
        };
    });
}

function renderAvailableSkills(player) {
    const availableSkillsList = document.getElementById('availableSkillsList');
    if (!availableSkillsList) return;

    availableSkillsList.innerHTML = '';
    const effects = getSkillNodeEffects(player);
    let allAvailableSkills = effects.active;
    // 重複を削除
    allAvailableSkills = allAvailableSkills.filter((skill, index, self) =>
        index === self.findIndex((s) => s.id === skill.id)
    );

    if (allAvailableSkills.length === 0) {
        availableSkillsList.innerHTML = '<p>利用可能なアクティブスキルがありません。</p>';
        return;
    }

    const ul = document.createElement('ul');
    allAvailableSkills.forEach(skill => {
        // 既にスキルスロットに装備されているスキルは表示しない
        if (player.skillSlots.some(s => s && s.id === skill.id)) {
            return;
        }

        const li = document.createElement('li');
        li.className = 'available-skill-item';
        li.textContent = (skill.name || "名前なし") + ((window.SBCost && skill.effect) ? `　⚖${Math.round(window.SBCost.costOfActiveSkill(skill) * 10) / 10}` : '');
        li.title = skill.description || "説明なし";
        li.draggable = true;
        li.dataset.skillId = skill.id;
        
        // ドラッグ開始
        li.ondragstart = (e) => {
            e.dataTransfer.setData('skillId', skill.id);
            e.dataTransfer.setData('skillName', skill.name || "名前なし");
        };
        
        // クリックで装備（従来の方法も残す）
        li.onclick = () => {
            // 最初の空スロットを自動的に選択
            const emptySlotIndex = player.skillSlots.findIndex(s => s === null);
            if (emptySlotIndex === -1) {
                alert("空いているスロットがありません。まずスキルを外してください。");
                return;
            }
            
            const result = equipSkillToSlot(getPlayerData(), skill.id, emptySlotIndex);
            if (result.success) {
                localStorage.setItem("player", JSON.stringify(result.player));
                renderSkillTreeUI();
            } else {
                alert(result.error);
            }
        };
        ul.appendChild(li);
    });
    availableSkillsList.appendChild(ul);
}

function equipSkillToSlot(player, skillId, slotIndex) {
    const effects = getSkillNodeEffects(player);
    let allAvailableSkills = effects.active;

    allAvailableSkills = allAvailableSkills.filter((skill, index, self) =>
        index === self.findIndex((s) => s.id === skill.id)
    );

    const skillToEquip = allAvailableSkills.find(s => s.id === skillId);
    if (!skillToEquip) return { success: false, error: "不明なスキルです。" };
    if (player.skillSlots.includes(skillToEquip)) return { success: false, error: "そのスキルは既に装備されています。" };
    // コスト制度：装備と同じ上限を分け合う。上限を超えるなら装備できない
    if (typeof window !== 'undefined' && window.SBCost && window.HW) {
        try {
            const after = player.skillSlots.slice(); after[slotIndex] = skillToEquip;
            const r = window.SBCost.canEquip(window.HW.load(), { activeSkills: after.filter(Boolean), beforeActive: player.skillSlots.filter(Boolean) });
            if (!r.ok) return { success: false, error: r.msg };
        } catch (e) { /* コストの判定に失敗したときは、装備できるようにしておく */ }
    }
    player.skillSlots[slotIndex] = skillToEquip;
    return { success: true, player };
}

function unequipSkillFromSlot(player, slotIndex) {
    player.skillSlots[slotIndex] = null;
    return { success: true, player };
}

// グローバル関数としてエクスポート
if (typeof window !== 'undefined') {
    window.SKILL_TREE = SKILL_TREE;
    window.SKILL_POINTS_PER_LEVEL = SKILL_POINTS_PER_LEVEL;
    window.CUSTOM_SKILL_COST = CUSTOM_SKILL_COST;
    window.initializeSkillData = initializeSkillData;
    window.addSkillPointsOnLevelUp = addSkillPointsOnLevelUp;
    window.unlockSkillNode = unlockSkillNode;
    window.getSkillNodeEffects = getSkillNodeEffects;
    window.applySkillEffectsToStats = applySkillEffectsToStats;
    window.validateCustomSkill = validateCustomSkill;
    window.createCustomSkill = createCustomSkill;
    window.equipSkillToSlot = equipSkillToSlot;
    window.unequipSkillFromSlot = unequipSkillFromSlot;
    window.renderSkillTreeUI = renderSkillTreeUI;
    console.log('SkillTree functions exported to window');
}
