// PWA Install Prompt Logic
let deferredPrompt;

window.addEventListener('beforeinstallprompt', (e) => {
    // デフォルトのインストールプロンプトを抑制
    e.preventDefault();
    // イベントを後で使えるように保存
    deferredPrompt = e;
    
    const installPopup = document.getElementById('install-popup');
    if (installPopup) {
        // 既にインストール済みかチェック
        if (window.matchMedia('(display-mode: standalone)').matches || window.matchMedia('(display-mode: fullscreen)').matches || window.matchMedia('(display-mode: minimal-ui)').matches || navigator.standalone) {
            console.log('App is already installed.');
            return;
        }
        console.log('`beforeinstallprompt` event was fired.');
        installPopup.style.display = 'flex';
    }
});

window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
});

let studyStartTime = null, studyTimerInterval = null, studyElapsedBefore = 0;
// 勉強タイマーは「時間を指定して、その時間まで勉強する」カウントダウン式（最大2時間）
const STUDY_MAX_SECONDS = 2 * 60 * 60;
let studyDurationSec = 30 * 60;
function readStudyDuration() {
    const sel = document.getElementById("studyDuration");
    let m = sel ? parseInt(sel.value, 10) : 30;
    if (!(m > 0)) m = 30;
    return Math.min(STUDY_MAX_SECONDS, m * 60);
}
let socketHandlersSetup = false;
let matchmakingTimeout = null;
let pendingRandomMatchPlayer = null;

// 勉強タイマーの状態をスリープ時にも保持するための処理
const STUDY_TIMER_STORAGE_KEY = 'studyTimerState';

function saveStudyTimerState() {
    if (studyStartTime !== null) {
        const elapsed = studyElapsedBefore + Math.floor((Date.now() - studyStartTime) / 1000);
        const state = {
            elapsed: elapsed,
            duration: studyDurationSec,
            subject: document.getElementById("studyFocus")?.value || 'jp',
            timestamp: Date.now()
        };
        localStorage.setItem(STUDY_TIMER_STORAGE_KEY, JSON.stringify(state));
        console.log('Study timer state saved:', state);
    }
}

function loadStudyTimerState() {
    const savedState = localStorage.getItem(STUDY_TIMER_STORAGE_KEY);
    if (savedState) {
        try {
            const state = JSON.parse(savedState);
            // 最後の保存から24時間以内ならタイマーを復元（長時間の勉強に対応）
            if (Date.now() - state.timestamp < 86400000) {
                console.log('Study timer state loaded:', state);
                return state;
            } else {
                console.log('Study timer state too old, clearing');
                localStorage.removeItem(STUDY_TIMER_STORAGE_KEY);
            }
        } catch (e) {
            console.error('Failed to load study timer state:', e);
            localStorage.removeItem(STUDY_TIMER_STORAGE_KEY);
        }
    }
    return null;
}

function clearStudyTimerState() {
    localStorage.removeItem(STUDY_TIMER_STORAGE_KEY);
}

// 保存されたタイマー状態を実際に画面へ復元する共通処理
// (アプリが完全に終了→再起動された「フレッシュな読み込み」でも、
//  visibilitychange しか呼ばれていなかった旧実装では復元されず、
//  進捗がリセットされて見えていた。DOMContentLoaded からも必ず呼ぶ)
function restoreStudyTimerState() {
    if (studyStartTime !== null) return; // 既に動作中なら何もしない
    const studyStartBtn = document.getElementById("studyStart");
    if (!studyStartBtn) return; // まだDOMが無ければ何もしない

    const savedState = loadStudyTimerState();
    if (!savedState) return;

    const subjectSelect = document.getElementById("studyFocus");
    if (subjectSelect) {
        subjectSelect.value = savedState.subject;
    }
    // 中断中に経過した時間を加算して新しい開始時間を設定
    const gapElapsed = Math.floor((Date.now() - savedState.timestamp) / 1000);
    studyElapsedBefore = savedState.elapsed + Math.max(0, gapElapsed);
    studyDurationSec = Math.min(STUDY_MAX_SECONDS, savedState.duration || studyDurationSec);
    const durSel = document.getElementById("studyDuration");
    if (durSel) { durSel.value = String(Math.round(studyDurationSec / 60)); durSel.disabled = true; }
    studyStartTime = Date.now(); // 現在時刻から再開

    studyStartBtn.disabled = true;
    const studyStopBtn = document.getElementById("studyStop");
    if (studyStopBtn) studyStopBtn.disabled = false;
    const studyFocusBtn = document.getElementById("studyFocus");
    if (studyFocusBtn) studyFocusBtn.disabled = true;

    if (studyTimerInterval) clearInterval(studyTimerInterval);
    studyTimerInterval = setInterval(updateStudyTimerDisplay, 1000);
    updateStudyTimerDisplay();
    console.log('Study timer restored. Gap elapsed:', gapElapsed, 'Total elapsed:', studyElapsedBefore);
}

// Page Visibility API - スリープ/復帰検出
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        // ページが非表示になったらタイマー状態を保存
        saveStudyTimerState();
    } else {
        // ページが再表示されたら、日付が変わっている可能性を考慮してミッションを再初期化する
        if (typeof initializeDailyMissions === 'function') {
            initializeDailyMissions();
        }

        // 日付が変わっていればログインボーナスも確認する
        if (typeof checkAndGrantLoginBonus === 'function') {
            checkAndGrantLoginBonus();
        }

        // ページが再表示されたらタイマー状態を復元（動作中でなければ）
        restoreStudyTimerState();
    }
});

// アプリが完全に閉じられる前にタイマー状態を保存
window.addEventListener('beforeunload', () => {
    saveStudyTimerState();
});

// pagehide は beforeunload が発生しないモバイル環境(PWA/バックグラウンド化)でも
// 比較的確実に発火するため、保険として同じ保存処理を仕込む
window.addEventListener('pagehide', () => {
    saveStudyTimerState();
});

// 複数タブ防止（改善版）
const tabId = 'tab_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
let heartbeatInterval = null;

// 既存のタブ情報をチェック
const existingTabData = localStorage.getItem('activeTabData');
if (existingTabData) {
    try {
        const data = JSON.parse(existingTabData);
        const now = Date.now();
        // 5秒以上前のタブ情報は無効とみなす（タブが正常に閉じられなかった場合）
        if (now - data.timestamp < 5000) {
            // 他のタブが最近開かれている
            console.log('Another tab is already open');
            // alert('このサイトは同時に1つのタブでのみ使用できます。既存のタブを閉じてから再度開いてください。');
            // window.location.href = 'about:blank';
        }
    } catch (e) {
        // データが破損している場合は無視して続行
        console.log('Invalid tab data, continuing...');
    }
}

// 自分のタブ情報を設定
localStorage.setItem('activeTabData', JSON.stringify({
    id: tabId,
    timestamp: Date.now()
}));

// ハートビートを送信してタブが生きていることを示す
heartbeatInterval = setInterval(() => {
    localStorage.setItem('activeTabData', JSON.stringify({
        id: tabId,
        timestamp: Date.now()
    }));
}, 2000);

// 他のタブからのメッセージを監視
window.addEventListener('storage', (e) => {
    if (e.key === 'activeTabData' && e.newValue) {
        try {
            const data = JSON.parse(e.newValue);
            if (data.id !== tabId) {
                // 他のタブが開かれた
                alert('このサイトは同時に1つのタブでのみ使用できます。このタブを閉じてください。');
                window.location.href = 'about:blank';
            }
        } catch (e) {
            console.log('Invalid tab data from storage event');
        }
    }
});

// ページを離れる時にタブ情報をクリア
window.addEventListener('beforeunload', () => {
    if (heartbeatInterval) {
        clearInterval(heartbeatInterval);
    }
    const currentData = localStorage.getItem('activeTabData');
    if (currentData) {
        try {
            const data = JSON.parse(currentData);
            if (data.id === tabId) {
                localStorage.removeItem('activeTabData');
            }
        } catch (e) {
            localStorage.removeItem('activeTabData');
        }
    }
});

// Initialize socket after DOM is ready
window.socket = null;

function initializeSocket() {
    console.log("Initializing socket...");
    window.socket = io({
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        reconnectionAttempts: 10,
        transports: ["websocket", "polling"],
        forceNew: false
    });

    // SocialSystem（フレンド申請など）は script.js より先に読み込まれ、
    // 自身のDOMContentLoadedハンドラの中で window.socket の存在チェックを行うが、
    // その時点ではまだここ（initializeSocket）が実行されておらず window.socket が
    // 存在しないため、フレンド申請関連のソケットリスナーが一切登録されない状態だった。
    // ここでsocket生成後に改めて呼び直すことで、リスナーを確実に登録する。
    if (typeof socialSystem !== 'undefined' && socialSystem && typeof socialSystem.setupSocketListeners === 'function') {
        socialSystem.setupSocketListeners();
    }

    // Connection logging
    window.socket.on("connect", () => {
        console.log("接続:", window.socket.id);
        updateOnlineButtons(true); // ボタンを有効化
        
        // Call setup for online features
        if (typeof setupOnlineEventHandlers === 'function') {
            setupOnlineEventHandlers();
        }

        // 接続時は常にプレイヤーデータをサーバーへ同期する
        // （こうしないと、pendingSaveフラグが立っていない通常の接続時には一切保存されず、
        //   ランキングなどサーバー側の集計にプレイヤーが反映されないままになってしまう）
        if (localStorage.getItem('pendingSave') === 'true') {
            console.log("Found pending save, attempting to sync to server...");
        }
        setupSyncHandlers(); startAutoSync();
        syncPlayerToServer(true); // 接続時は自動で同期（送る／取り込む）

        if (pendingRandomMatchPlayer) {
            console.log("Re-emitting pending random match request after reconnect", pendingRandomMatchPlayer.id);
            window.socket.emit("requestRandomMatch", pendingRandomMatchPlayer);
        }
        
        // Request boss list from server
        window.socket.emit('bosses:get');
    });

    window.socket.on("disconnect", () => {
        console.log("切断");
        updateOnlineButtons(false); // ボタンを無効化
    });

    window.socket.on("connect_error", (error) => {
        console.log("接続エラー:", error);
        updateOnlineButtons(false); // ボタンを無効化
    });
    
    // ユニーク武器獲得通知
    window.socket.on("uniqueWeaponClaimed", (data) => {
        const message = `${data.weaponName}が${data.playerName}によって入手されました！`;
        alert(message);
        // ユニーククエストUIを更新（ショップページにいる場合）
        if (typeof renderUniqueQuests === "function" && document.getElementById("uniqueQuestList")) {
            renderUniqueQuests();
        }
    });
    
    // ユニーククエスト完了通知（クエスト自体が削除される）
    window.socket.on("uniqueQuestCompleted", (data) => {
        const message = `${data.weaponName}のクエストが${data.playerName}によって完了されました！世界にこの武器は1つしかありません。`;
        alert(message);
        // ユニーククエストUIを更新（ショップページにいる場合）
        if (typeof renderUniqueQuests === "function" && document.getElementById("uniqueQuestList")) {
            renderUniqueQuests();
        }
    });

    console.log("Socket initialized, waiting for connection...");
    console.log("Initial socket.connected state:", window.socket.connected);
    
    // イベントハンドラーを設定
    setupSocketEventHandlers();
}

function getStatsFromInputs() {
    return {
        maxHp: Math.floor(Number(document.getElementById("statMaxHp").value)),
        atk: Math.floor(Number(document.getElementById("statAtk").value)),
        def: Math.floor(Number(document.getElementById("statDef").value)),
        speed: Math.floor(Number(document.getElementById("statSpeed").value)),
        special: Math.floor(Number(document.getElementById("statSpecial").value)),
        grade: Math.floor(Number(document.getElementById("statGrade").value))
    };
}

function setStatsToInputs(stats) {
    document.getElementById("statMaxHp").value = stats.maxHp;
    document.getElementById("statAtk").value = stats.atk;
    document.getElementById("statDef").value = stats.def;
    document.getElementById("statSpeed").value = stats.speed;
    if (document.getElementById("statSpecial")) {
        document.getElementById("statSpecial").value = stats.special != null ? stats.special : Math.floor(stats.atk * 0.6);
    }
    if (stats.grade) {
        document.getElementById("statGrade").value = stats.grade;
    }
    updateRemainingPoints();
}

function updateRemainingPoints() {
    const el = document.getElementById("remainingPoints");
    if (!el) return;
    const stats = getStatsFromInputs();
    const used = sumStats(stats);
    const remaining = TOTAL_STAT_POINTS - used;
    if (getPlayerData() && used > TOTAL_STAT_POINTS) {
        el.textContent = I18N.studiedTotal.replace("{total}", used);
        el.className = "remaining-points points-trained";
        return;
    }
    el.textContent = I18N.remainingPoints.replace("{remaining}", remaining).replace("{total}", TOTAL_STAT_POINTS);
    el.className = "remaining-points" + (remaining === 0 ? " points-ok" : remaining < 0 ? " points-over" : " points-under");
}

function createCharacter() {
    const name = document.getElementById("playerName").value.trim() || I18N.unnamed;
    const stats = getStatsFromInputs();
    const existing = getPlayerData();
    const statReallocationMode = isStatReallocationMode && !!existing;

    // 名前のバリデーション（新規作成時のみ）
    if (!existing && typeof validateName === "function") {
        const validation = validateName(name);
        if (!validation.valid) {
            alert(validation.reason);
            return;
        }
    }

    if (!existing || statReallocationMode) {
        // 新規作成時、ステータス再分配チケット使用時は
        // 持ち点250ポイントちょうどを配分することを要求する
        const validation = validateStatAllocation(stats);
        if (!validation.ok) { alert(validation.message); return; }
    } else {
        for (const key of STAT_KEYS) {
            if (!Number.isFinite(stats[key]) || stats[key] < MIN_STAT) {
                alert(I18N.statMinError.replace("{min}", MIN_STAT));
                return;
            }
        }
    }

    // 転生機能は廃止された。過去の転生で得た永続ボーナス（prestigeCount / prestigeBonusPercent）は、
    // 既存プレイヤーの強さが下がらないようそのまま引き継ぐ（新たに増やす手段は無い）。
    const xp = existing ? existing.xp : 0;
    const totalStudySeconds = existing ? (existing.totalStudySeconds || 0) : 0;
    const prestigeCount = existing?.prestigeCount || 0;
    const prestigeBonusPercent = existing?.prestigeBonusPercent || 0;
    const skillTreeForPlayer = existing?.skillTree;
    const skillSlotsForPlayer = existing?.skillSlots;
    const weaponsForPlayer = existing?.weapons || [];
    const equippedWeaponForPlayer = existing?.equippedWeapon || null;
    const materialsForPlayer = existing?.materials || {};

    // ステータス再分配チケット使用時は、使用したチケットだけをdungeonItemsから取り除く
    // （レベル・スキルツリー・他のダンジョンアイテムには一切手を付けない）
    let dungeonItemsForPlayer = existing?.dungeonItems || [];
    if (statReallocationMode) {
        const ticketIndex = dungeonItemsForPlayer.findIndex(item => item.id === 'stat_reallocator');
        if (ticketIndex === -1) {
            alert('ステータス再分配チケットを持っていません。');
            return;
        }
        dungeonItemsForPlayer = dungeonItemsForPlayer.filter((item, i) => i !== ticketIndex);
    }

    const player = buildPlayer(name, stats, xp, {
        totalStudySeconds,
        grade: stats.grade,
        id: existing?.id,
        coins: existing?.coins || 0,
        weapons: weaponsForPlayer,
        equippedWeapon: equippedWeaponForPlayer,
        weaponWins: existing?.weaponWins || {},
        orbs: existing?.orbs || [],
        skillTree: skillTreeForPlayer,
        skillSlots: skillSlotsForPlayer,
        customSkills: existing?.customSkills,
        bossDefeats: existing?.bossDefeats,
        dungeonClears: existing?.dungeonClears,
        materials: materialsForPlayer,
        dungeonItems: dungeonItemsForPlayer,
        classes: existing?.classes || { main: null, sub: null },
        classTree: existing?.classTree || {},
        classPerk: existing?.classPerk || {},
        dungeonCheckpoint: existing?.dungeonCheckpoint || 0,
        pvpWins: existing?.pvpWins,
        bossRunCount: existing?.bossRunCount,
        dailyMissions: existing?.dailyMissions,
        special: existing?.special,
        prestigeCount,
        prestigeBonusPercent,
        lastLoginDate: existing?.lastLoginDate,
        loginStreak: existing?.loginStreak,
        questionLists: existing?.questionLists || [],
        craftCurrency: existing?.craftCurrency
    });
    localStorage.setItem("player", JSON.stringify(player));
    updateStatus(player);
    updateXpDisplay(player);

    // キャラクター作成直後はデイリーミッションがまだ初期化されておらず、
    // ミッション画面が「ミッションデータがありません」のままになってしまうため、
    // ここで明示的に初期化・再描画しておく。
    if (typeof initializeDailyMissions === "function") {
        initializeDailyMissions();
    }

    // 新規キャラクター作成時のみ、初回ログインボーナスも確認する
    if (!existing && typeof checkAndGrantLoginBonus === "function") {
        checkAndGrantLoginBonus();
    }
    
    // Lock stat inputs after creation
    isStatReallocationMode = false;
    lockStatInputs(true);
    document.getElementById("statAllocationDesc").textContent = I18N.fixedStats;
    
    // Update data management UI
    const playerIdEl = document.getElementById("currentPlayerId");
    if (playerIdEl) playerIdEl.textContent = player.id;
    const saveDataBtn = document.getElementById("saveDataBtn");
    if (saveDataBtn) saveDataBtn.disabled = false;

    syncPlayerToServer(true);

    if (statReallocationMode) {
        alert("ステータスを再分配しました！");
    } else {
        alert(I18N.charCreated);
        // キャラクターを新規作成したら、すぐにフィールド（町）へ送る
        if (typeof activateSection === "function") {
            activateSection('town', true);
        }
    }
}

// ステータス再分配チケット（ダンジョン報酬）：レベル・スキルツリー・武器等は一切変えずに、
// 持ち点250をもう一度最初から配分し直せる。
// 実行回数の制限はチケットの所持数だけで決まる（1回使うと1枚消費）。
let isStatReallocationMode = false;

function startStatReallocation() {
    const player = getPlayerData();
    if (!player) return;

    const hasTicket = (player.dungeonItems || []).some(item => item.id === 'stat_reallocator');
    if (!hasTicket) {
        alert("ステータス再分配チケットを持っていません。ダンジョンの宝箱で入手できます。");
        return;
    }

    const confirmed = confirm("ステータス再分配チケットを1枚使って、持ち点250を最初から配分し直しますか？（レベルや武器、スキルはそのまま維持されます）");
    if (!confirmed) return;

    isStatReallocationMode = true;
    setStatsToInputs(DEFAULT_STATS);
    lockStatInputs(false);
    document.getElementById("statAllocationDesc").textContent = "ステータス再分配：持ち点250をもう一度配分してください。";
    const createBtn = document.getElementById("createCharBtn");
    if (createBtn) createBtn.textContent = "再分配を確定する";
    updateRemainingPoints();
}

/**
 * 武器の表示名を取得する
 * @param {object} weapon - 武器オブジェクト
 * @returns {string} 武器の表示名
 */
function getWeaponDisplayName(weapon) {
    if (!weapon) return 'なし';
    return weapon.name || '名称不明の武器';
}

/**
 * 装備中の武器詳細をHTMLで整形して返す
 * @param {object} weapon - 武器オブジェクト
 * @returns {string} 武器詳細のHTML文字列
 */
// ボス選択プルダウンの下に、選択中のボスのアイコン・説明をプレビュー表示する
function updateBossPreview(selectEl, previewEl) {
    if (!selectEl || !previewEl) return;
    const bossId = selectEl.value;
    const boss = (window.bosses || []).find(b => b.id === bossId);
    if (!boss) {
        previewEl.innerHTML = "";
        return;
    }
    const iconHtml = (typeof getBossIconSVG === "function") ? getBossIconSVG(boss.id, 64) : "";
    const descHtml = boss.description ? `<p class="boss-preview-desc">${boss.description}</p>` : "";
    previewEl.innerHTML =
        `<div class="boss-preview-inner">
            <span class="boss-icon-wrap">${iconHtml}</span>
            <div class="boss-preview-text">
                <strong>${boss.name}</strong>
                ${descHtml}
            </div>
        </div>`;
}

function formatWeaponDetailsHTML(weapon) {
    if (!weapon) return "なし";

    const iconHtml = (typeof getWeaponIconSVG === "function")
        ? `<span class="weapon-icon-wrap">${getWeaponIconSVG(weapon.type, 40)}</span>`
        : "";
    let detailsHtml = `<strong>${getWeaponDisplayName(weapon)}</strong>`;
    const detailsList = [];

    // ステータスボーナス
    if (weapon.statBonuses && Object.keys(weapon.statBonuses).length > 0) {
        const bonusStrings = Object.entries(weapon.statBonuses).map(([stat, value]) => {
            const statLabel = (typeof STAT_LABELS !== 'undefined' && STAT_LABELS[stat]) ? STAT_LABELS[stat] : stat;
            return `${statLabel} +${Math.round(value * 100)}%`;
        });
        if (bonusStrings.length > 0) {
            detailsList.push(`<li><strong>補正:</strong> ${bonusStrings.join(', ')}</li>`);
        }
    }

    // 特殊能力
    if (weapon.uniqueAbilities && weapon.uniqueAbilities.length > 0) {
        const abilityNames = weapon.uniqueAbilities.map(ability => ability.name || '名称不明の能力').join(', ');
        detailsList.push(`<li><strong>特殊能力:</strong> ${abilityNames}</li>`);
    }

    if (detailsList.length > 0) {
        detailsHtml += `<ul style="margin: 5px 0 5px 0; padding-left: 20px; list-style-type: '◆ '; font-size: 0.9em; color: #ddd;">${detailsList.join('')}</ul>`;
    }

    return `<div class="weapon-display-inner">${iconHtml}<div class="item-text-col">${detailsHtml}</div></div>`;
}

function updateStatus(player) {
    // 武器補正を適用したステータスを取得
    const battleStats = getBattleStats(player);
    const weaponDetailsHtml = formatWeaponDetailsHTML(player.equippedWeapon);
    // 転生機能は廃止済み。過去の転生で得た永続ボーナスが残っている場合だけ、参考として表示する。
    const legacyPrestigeBonus = Math.round((player.prestigeBonusPercent || 0) * 10) / 10;
    const legacyPrestigeHtml = legacyPrestigeBonus > 0
        ? "<p>これまでに得た永続ボーナス（旧・転生）：全ステータス+" + legacyPrestigeBonus + "%</p>"
        : "";

    // ステータス再分配チケット所持時だけ、再分配ボタンを表示する
    const hasStatReallocationTicket = (player.dungeonItems || []).some(item => item.id === 'stat_reallocator');
    let statReallocationHtml = "";
    if (hasStatReallocationTicket) {
        statReallocationHtml =
            "<div class='prestige-box'><h3>ステータス再分配</h3>" +
            "<p>ダンジョンで入手したチケットを使って、持ち点250を配分し直せます（レベル・武器・スキルは維持されます）。</p>" +
            "<button type='button' id='statReallocationBtn' class='btn btn-secondary'>ステータスを再分配する</button>" +
            "</div>";
    }

    document.getElementById("status").innerHTML =
        "<h2>" + I18N.status + "</h2>" +
        "<p><strong>" + I18N.playerNameLabel + "</strong><span id='playerNameText'></span> <button type='button' id='renameBtn' class='btn btn-secondary' style='padding:2px 8px;font-size:.8rem'>✏️ 名前を変更</button></p>" +
        "<p><strong>プレイヤーID" + I18N.colon + "</strong>" + player.id + "</p>" +
        "<p><strong>" + I18N.level + I18N.colon + "</strong>" + (player.level || 1) + " <strong>" + I18N.xp + I18N.colon + "</strong>" + (player.xp || 0) + "</p>" +
        "<p><strong>コイン" + I18N.colon + "</strong>" + (player.coins || 0) + "</p>" +
        "<p><strong>装備武器" + I18N.colon + "</strong></p><div class='weapon-display'>" + weaponDetailsHtml + "</div><hr>" +
        "<p>HP" + I18N.colon + battleStats.maxHp + "</p>" +
        "<p>" + I18N.atk + I18N.colon + battleStats.atk + "</p>" +
        "<p>" + I18N.def + I18N.colon + battleStats.def + "</p>" +
        "<p>" + I18N.speed + I18N.colon + battleStats.speed + "</p>" +
        "<p>特殊" + I18N.colon + (battleStats.special != null ? battleStats.special : battleStats.atk) + "</p>" +
        "<p>学年" + I18N.colon + player.grade + "（" + getGradeLabel(player.grade) + "）</p><hr>" +
        "<p>" + I18N.totalStudy + formatTime(player.totalStudySeconds || 0) + "</p>" +
        "<hr>" + legacyPrestigeHtml + statReallocationHtml;

    const nameSpan = document.getElementById("playerNameText"); if (nameSpan) nameSpan.textContent = player.name;   // 名前は textContent で入れる（HTMLとして解釈されないように）
    const renameBtn = document.getElementById("renameBtn"); if (renameBtn) renameBtn.addEventListener("click", renamePlayer);
    const statReallocationBtn = document.getElementById("statReallocationBtn");
    if (statReallocationBtn) {
        statReallocationBtn.addEventListener("click", startStatReallocation);
    }
}

// 名前の変更：禁止ワード・長さのチェックをして保存し、サーバーにも反映する（IDや進行状況はそのまま）
function renamePlayer() {
    const p = getPlayerData();
    if (!p) return;
    const input = prompt("新しい名前を入力してください（20文字まで）", p.name || "");
    if (input === null) return;
    const name = String(input).replace(/[\u0000-\u001f\u007f<>]/g, "").replace(/\s+/g, " ").trim();
    if (!name) { alert("名前を入力してください"); return; }
    if (name === p.name) return;
    if (typeof validateName === "function") {
        const v = validateName(name);
        if (!v.valid) { alert(v.reason); return; }
    }
    p.name = name;
    localStorage.setItem("player", JSON.stringify(p));
    try { syncPlayerToServer(true); } catch (e) {}
    alert("名前を「" + name + "」に変更しました");
    location.reload();
}

function updateXpDisplay(player) {
    const el = document.getElementById("xpDisplay"); if (!el) return;
    const lv = player.level || 1, xp = player.xp || 0;
    el.textContent = I18N.xp + I18N.colon + xp + " (Lv." + lv + " -> " + I18N.xpNext + " " + xpToNextLevel(lv) + " XP)";
}

function startStudy() {
    if (studyStartTime !== null) return;
    if (!getPlayerData()) { alert(I18N.needChar); return; }
    studyDurationSec = readStudyDuration();
    const durSel = document.getElementById("studyDuration");
    if (durSel) durSel.disabled = true;
    studyStartTime = Date.now();
    studyElapsedBefore = 0;
    document.getElementById("studyStart").disabled = true;
    document.getElementById("studyStop").disabled = false;
    document.getElementById("studyFocus").disabled = true;
    studyTimerInterval = setInterval(updateStudyTimerDisplay, 1000);
    updateStudyTimerDisplay();
}

function stopStudy() {
    if (studyStartTime === null) return;
    clearInterval(studyTimerInterval);
    studyTimerInterval = null;
    const elapsed = Math.min(studyDurationSec, studyElapsedBefore + Math.floor((Date.now() - studyStartTime) / 1000));
    studyStartTime = null;
    studyElapsedBefore = 0;
    const durSelEnd = document.getElementById("studyDuration");
    if (durSelEnd) durSelEnd.disabled = false;
    
    // 保存されたタイマー状態をクリア
    clearStudyTimerState();
    
    // ボタンの状態を確実に更新
    const studyStartBtn = document.getElementById("studyStart");
    const studyStopBtn = document.getElementById("studyStop");
    const studyFocusBtn = document.getElementById("studyFocus");
    
    if (studyStartBtn) studyStartBtn.disabled = false;
    if (studyStopBtn) studyStopBtn.disabled = true;
    if (studyFocusBtn) studyFocusBtn.disabled = false;
    
    applyStudyRewards(elapsed);
    document.getElementById("studyTimer").textContent = "00:00:00";
}

// 勉強タイマーを「ゼロに戻す」（報酬なし）。タイマー中にステージ・オンラインマッチへ行ったときに呼ばれる
function cancelStudyTimer() {
    const wasRunning = studyStartTime !== null;
    if (studyTimerInterval) clearInterval(studyTimerInterval);
    studyTimerInterval = null;
    studyStartTime = null;
    studyElapsedBefore = 0;
    clearStudyTimerState();
    const b1 = document.getElementById("studyStart"), b2 = document.getElementById("studyStop"), b3 = document.getElementById("studyFocus"), b4 = document.getElementById("studyDuration");
    if (b1) b1.disabled = false;
    if (b2) b2.disabled = true;
    if (b3) b3.disabled = false;
    if (b4) b4.disabled = false;
    const t = document.getElementById("studyTimer");
    if (t) t.textContent = "00:00:00";
    return wasRunning;
}
window.cancelStudyTimer = cancelStudyTimer;

function updateStudyTimerDisplay() {
    if (studyStartTime === null) return;
    const elapsedNow = studyElapsedBefore + Math.floor((Date.now() - studyStartTime) / 1000);
    if (elapsedNow >= studyDurationSec) {   // 指定時間に到達：自動で終了して報酬を受け取る
        document.getElementById("studyTimer").textContent = formatTime(0);
        stopStudy();
        return;
    }
    document.getElementById("studyTimer").textContent = formatTime(studyDurationSec - elapsedNow);   // 残り時間を表示
    // 毎秒ここでも保存しておく（visibilitychange/beforeunloadが
    // 発火しないままアプリが強制終了された場合の保険）
    saveStudyTimerState();
}

// Map subjects to the 2 stats they strengthen
const SUBJECT_STATS = {
    jp: ["maxHp", "def"],     // 国語 → HP・防御・特殊
    math: ["atk", "speed",],   // 算数・数学 → 攻撃・速さ・特殊
    eng: ["def", "atk"],    // 英語 → 防御・速さ・特殊
    sci: ["atk", "special"],    // 理科 → 攻撃・HP・特殊
    soc: ["maxHp", "special"]     // 社会 → HP・防御・特殊
};

// Subject display names
const SUBJECT_DISPLAY_NAMES = {
    jp: "国語",
    math: "算数・数学",
    eng: "英語",
    sci: "理科",
    soc: "社会"
};

function getSubjectDisplayName(subject) {
    return SUBJECT_DISPLAY_NAMES[subject] || subject;
}

// Display stat growth info based on selected subject
function updateStatGrowthInfo() {
    const subject = document.getElementById("studyFocus").value;
    const [stat1, stat2, stat3] = SUBJECT_STATS[subject];
    const statNames = {
        maxHp: "HP",
        atk: I18N.atk,
        def: I18N.def,
        speed: I18N.speed,
        special: "特殊"
    };
    const infoEl = document.getElementById("statGrowthInfo");
    if (infoEl) {
        let stats;
        if (stat3) {
            stats = `${statNames[stat1]}・${statNames[stat2]}・${statNames[stat3]}`;
        } else if (stat2) {
            stats = `${statNames[stat1]}・${statNames[stat2]}`;
        } else {
            stats = statNames[stat1];
        }
        const elemNote = { jp: '🔥炎', math: '💧水', sci: '🌪️風', soc: '⛰️土', eng: '⚡雷' }[subject];
        infoEl.innerHTML = `<p><strong>${I18N.statGrowthInfo}</strong>${stats}${elemNote ? '　／　属性：' + elemNote + 'が強化されます' : ''}</p>`;
        renderElemPanel();
    }
}

// 属性ステータス（勉強で強くなる）の表示
function renderElemPanel() {
    const box = document.getElementById("elemPanel");
    if (!box || !window.SBElem) return;
    let sp = 50;
    try { const p = getPlayerData(); if (p) sp = (getStatsFromPlayer(p, true) || {}).special || 50; } catch (e) {}
    box.innerHTML = SBElem.panelHtml(sp);
}

function applyStudyRewards(seconds) {
    if (seconds < 60) { alert("勉強時間は1分以上にしてください"); return; }
    let player = getPlayerData(); if (!player) return;
    try { if (window.SBAch) { SBAch.report('study', seconds); SBAch.evaluate(); } } catch (e) { /* 実績の記録に失敗しても勉強の報酬は渡す */ }
    const subject = document.getElementById("studyFocus").value;
    const stats = getStatsFromPlayer(player);
    const gainedXp = calcStudyXp(seconds);
    let statGain = calcStatGain(seconds, player);
    const oldLevel = player.level || calcLevel(player.xp || 0);
    
    // 圧倒的成長性をチェック
    let hasOverwhelmingGrowth = false;
    if (player.equippedWeapon && player.equippedWeapon.uniqueAbilities) {
        hasOverwhelmingGrowth = player.equippedWeapon.uniqueAbilities.some(
            ability => ability.effect === "double_study_growth"
        );
    }
    
    // 叡智の頂（Tier5）は2.5倍。圧倒的成長性（Tier4）と両方持っている場合は高い方だけを適用する。
    const hasApexWisdom = !!(player.equippedWeapon && player.equippedWeapon.uniqueAbilities &&
        player.equippedWeapon.uniqueAbilities.some(ability => ability.effect === "study_growth_x2_5"));
    if (hasApexWisdom) {
        statGain = Math.floor(statGain * 2.5);
    } else if (hasOverwhelmingGrowth) {
        statGain *= 2;
    }
    
    const [stat1, stat2, stat3] = SUBJECT_STATS[subject];
    // 勉強した教科の属性ポイントも、ステータス上昇と同じだけ増える（国語→炎／数学→水／理科→風／社会→土／英語→雷）
    try { if (window.SBElem) SBElem.addStudy(subject, statGain); } catch (e) {}
    stats[stat1] += statGain;
    if (stat2) {
        stats[stat2] += statGain;
    }
    if (stat3) {
        stats[stat3] += statGain;
    }

    const hp = (stat1 === "maxHp" || stat2 === "maxHp" || stat3 === "maxHp")
        ? (player.hp || player.maxHp) + statGain
        : (player.hp || player.maxHp);

    let gainedCoins = 0;
    if (seconds >= STUDY_COIN_THRESHOLD) {
        gainedCoins = COIN_STUDY_30MIN;
    }

    // オーブドロップ判定（25分以上で確定）
    let droppedOrb = null;
    if (seconds >= 25 * 60 && typeof rollOrbDrop === "function") {
        droppedOrb = rollOrbDrop(1.0); // 100%ドロップ
    }

    // オーブ工房の結晶（累計勉強時間が一定の間隔をまたぐたびに貯まる）。
    // totalStudySecondsを加算する「前」の値を基準に計算する必要があるため、buildPlayer()より前で計算する。
    const craftGrant = (typeof grantStudyCraftCurrency === "function")
        ? grantStudyCraftCurrency(player, seconds)
        : null;

    const newXp = (player.xp || 0) + gainedXp;
    const newLevel = calcLevel(newXp);

    if (newLevel > oldLevel && typeof addSkillPointsOnLevelUp === 'function') {
        player = addSkillPointsOnLevelUp(player, oldLevel, newLevel);
        alert(`レベルアップ！ Lv${newLevel}\nスキルポイントを ${ (newLevel - oldLevel) * SKILL_POINTS_PER_LEVEL } 獲得しました！`);
    }

    const updated = buildPlayer(player.name, stats, newXp, {
        hp,
        totalStudySeconds: (player.totalStudySeconds || 0) + seconds,
        grade: player.grade,
        id: player.id,
        coins: (player.coins || 0) + gainedCoins,
        weapons: player.weapons,
        equippedWeapon: player.equippedWeapon,
        weaponWins: player.weaponWins,
        orbs: player.orbs || [],
        skillTree: player.skillTree,
        skillSlots: player.skillSlots,
        customSkills: player.customSkills,
        bossDefeats: player.bossDefeats || {},
        dungeonClears: player.dungeonClears || {},
        materials: player.materials || {},
        dungeonItems: player.dungeonItems || [],
        classes: player.classes || { main: null, sub: null },
        classTree: player.classTree || {},
        classPerk: player.classPerk || {},
        dungeonCheckpoint: player.dungeonCheckpoint || 0,
        pvpWins: player.pvpWins || 0,
        bossRunCount: player.bossRunCount || 0,
        dailyMissions: player.dailyMissions,
        special: player.special,
        prestigeCount: player.prestigeCount,
        prestigeBonusPercent: player.prestigeBonusPercent,
        lastLoginDate: player.lastLoginDate,
        loginStreak: player.loginStreak,
        questionLists: player.questionLists || [],
        craftCurrency: craftGrant ? craftGrant.currency : player.craftCurrency,
        reviewList: player.reviewList || [],
        studyHistory: player.studyHistory || [],
        studyGoals: player.studyGoals || [],
        streak: player.streak || { current: 0, best: 0, lastStudyDate: null }
    });

    // 学習管理システムに統合
    if (typeof getStudyManager === 'function') {
        const studyManager = getStudyManager();
        if (studyManager) {
            // 学習履歴を記録（問題数は仮に0、正解数も0とする）
            studyManager.recordStudy(subject, seconds, 0, 0);
        }
    }

    // オーブを追加
    if (droppedOrb) {
        if (!updated.orbs) updated.orbs = [];
        updated.orbs.push(droppedOrb);
    }

    localStorage.setItem("player", JSON.stringify(updated));
    setStatsToInputs(stats);
    updateStatus(updated);
    updateXpDisplay(updated);
    if (typeof renderSkillTreeUI === "function") renderSkillTreeUI();
    syncPlayerToServer(true);
    // 翻訳データを安全に参照
    const I18N = window.I18N || {};
    const subjectMap = {
        jp: I18N.hpDef || "HP・防御",
        math: I18N.mathAtk || "攻撃・速さ",
        eng: I18N.engDefAtk || "防御・攻撃",
        sci: I18N.sciAtkSpe || "攻撃・特殊",
        soc: I18N.socHpSpe || "HP・特殊"
    };
    const subjectLabel = subjectMap[subject] || "";

    let msg = (I18N.studyDone || "勉強を終了しました。") + "\n" +
              (I18N.time || "時間") + (I18N.colon || ": ") + formatTime(seconds) + "\n" +
              (I18N.xp || "XP") + " +" + gainedXp + "\n" +
              subjectLabel + (I18N.statUp || "の能力") + " +" + statGain;

    if (hasApexWisdom) msg += "（叡智の頂発動中！）";
    else if (hasOverwhelmingGrowth) msg += "（圧倒的成長性発動中！）";
    if (gainedCoins > 0) msg += `\n30分以上の勉強ボーナス +${gainedCoins}コイン`;
    if (droppedOrb && typeof getOrbDisplayName === "function") {
        msg += "\n\n★オーブを入手！★\n" + getOrbDisplayName(droppedOrb);
    }
    if (craftGrant && typeof formatCraftCurrencyGain === "function") {
        const craftText = formatCraftCurrencyGain(craftGrant.gain);
        if (craftText) msg += "\n\n💎 工房の結晶を獲得！\n" + craftText;
        if (craftGrant.capped) msg += "\n（結晶の計算は1回の勉強につき3時間分までです）";
    }
    alert(msg);
    if (typeof renderShop === "function") {
        renderOriginalWeapons();
        renderShop();
        renderInventory();
    }
    if (typeof refreshOrbWorkshopAll === "function") refreshOrbWorkshopAll();

    // デイリーミッションの進捗を更新
    if (typeof updateMissionProgress === 'function') {
        updateMissionProgress('study', seconds);
    }
}

// プレイヤーIDの正規化（大文字・空白・全角の揺れを吸収）
function normalizePlayerId(rawId) {
    if (rawId == null) return "";
    return String(rawId)
        // 全角英数字を半角に変換
        .replace(/[Ａ-Ｚａ-ｚ０-９]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0xFEE0))
        .replace(/[\s\u3000]/g, "")
        .trim()
        .toUpperCase();
}

// サーバーへのデータ同期（silent=true の場合は成功通知を出さない）
let pendingSilentSave = false;
function syncPlayerToServer(silent) {
    const player = getPlayerData();
    if (!player) return false;

    if (!window.socket || !window.socket.connected) {
        // 接続がない場合は保留フラグを立てる
        localStorage.setItem('pendingSave', 'true');
        console.log("Socket not connected. Marked for pending save.");
        return false;
    }

    // 以前の「保存」は、いまは端末の連携（同期）。変更があれば送り、もう一方の端末が先に更新していれば取り込む
    runSync(!silent);
    return true;
}

// ============================================================
// 端末の連携（同期）
//  2台以上の端末が、同じプレイヤーIDで「同じキャラクター」を共有する。どちらで進めても、自動で反映し合う。
//  ・サーバーは、データの「版（rev）」を持つ。端末は「最後に同期した版」と「そのときのデータの指紋(hash)」を覚えておく（sbSyncMeta。端末ごとの記録）
//  ・この端末に変更がなく、サーバーが新しければ → 自動で取り込む（再読み込み）
//  ・この端末に変更があり、サーバーが変わっていなければ → 自動で送る
//  ・両方に変更があれば（衝突）→ どちらを使うか選ぶ画面を出す
//  ・勉強タイマー中は取り込まない（タイマーが止まらないように）
// ============================================================
const SYNC_META_KEY = 'sbSyncMeta';
let syncManual = false, syncConflictOpen = false, syncBusyAt = 0, syncPushHash = null, syncReady = false, syncWanted = false;
// この端末（ブラウザ）の目印。保存のたびにサーバーへ送り、「いまの版を保存したのは自分か」を判定する。
// これが無いと、返事が届かなかった保存や、重ねて送った保存のあとで、「もう一方の端末が変更した」と取り違えて衝突の画面が出ていた
function getDeviceId() {
    let d = null;
    try { d = localStorage.getItem('sbDeviceId'); if (!d) { d = 'd' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36); localStorage.setItem('sbDeviceId', d); } } catch (e) { d = 'dx' + (window.__sbDx || (window.__sbDx = Math.random().toString(36).slice(2, 8))); }
    return d;
}
let syncInFlight = 0, syncPushAgain = false;     // 保存の返事を待っている間は、重ねて送らない（版がずれて衝突に見えるため）
function loadSyncMeta() { try { const m = JSON.parse(localStorage.getItem(SYNC_META_KEY) || 'null'); return m && typeof m === 'object' ? m : null; } catch (e) { return null; } }
function saveSyncMeta(m) { try { localStorage.setItem(SYNC_META_KEY, JSON.stringify(m)); } catch (e) { /* 容量不足 */ } renderSyncStatus(); }
function currentSyncHash() {
    let h = 5381, n = 0;
    const feed = (s) => { s = s || ''; n += s.length; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; h = ((h << 5) + h + 7) | 0; };
    feed(localStorage.getItem('player')); TRANSFER_KEYS.forEach(k => feed(localStorage.getItem(k)));
    return (h >>> 0).toString(36) + ':' + n;
}
function syncOnline() { return !!(window.socket && window.socket.connected); }
function runSync(manual) {            // 状態を問い合わせて、送る／取り込む／衝突を判断する（結果は sync:status の返事で処理）
    const player = getPlayerData();
    if (!player) return false;
    if (!syncOnline()) { localStorage.setItem('pendingSave', 'true'); if (manual) alert('サーバーに接続されていません。通信できる状態でもう一度お試しください。'); return false; }
    if (!syncReady && !manual) { syncWanted = true; return true; }   // 開いた直後の初期化が終わるまで待つ
    if (Date.now() - syncBusyAt < 1500 && !manual) return true;     // 連打防止
    syncBusyAt = Date.now(); syncManual = syncManual || !!manual;
    setSyncText('🔄 同期中…');
    window.socket.emit('sync:status', { id: player.id });
    return true;
}
function pushSync(force) {
    const player = getPlayerData(); if (!player || !syncOnline()) return;
    if (syncInFlight && Date.now() - syncInFlight < 20000 && !force) { syncPushAgain = true; return; }     // 返事待ち：あとでもう一度
    const meta = loadSyncMeta(), base = meta && meta.id === player.id ? (meta.rev || 0) : 0;
    syncPushHash = currentSyncHash(); syncInFlight = Date.now();
    window.socket.emit('sync:push', { id: player.id, baseRev: base, dev: getDeviceId(), mode: (window.SeasonSys && window.SeasonSys.mode && window.SeasonSys.mode()) || 'standard', player: player, bundle: collectBundle(), manual: syncManual, force: !!force });
}
function applyPulled(r) {              // サーバーのデータをこの端末へ反映して、再読み込み
    if (!r || !r.ok || !r.player) return false;
    const migrated = typeof migratePlayer === 'function' ? migratePlayer(r.player) : r.player;
    try {
        localStorage.setItem('player', JSON.stringify(migrated));
        TRANSFER_KEYS.forEach(k => { if (r.items && typeof r.items[k] === 'string') localStorage.setItem(k, r.items[k]); else localStorage.removeItem(k); });   // この端末に残っていた別のキャラのデータが混ざらないよう、無いものは消す
    } catch (e) { alert('データの反映に失敗しました（保存容量が足りない可能性があります）。'); return false; }
    saveSyncMeta({ id: migrated.id, rev: r.rev || 0, hash: currentSyncHash(), at: Date.now() });
    localStorage.removeItem('pendingSave');
    try { sessionStorage.setItem('sbSyncToast', r.link ? ('🔗 「' + migrated.name + '」と連携しました') : '🔄 もう一方の端末の最新データを反映しました'); } catch (e) { /* なくてもよい */ }
    location.reload();
    return true;
}
function setSyncText(t) { const el = document.getElementById('syncStatus'); if (el) el.textContent = t; }
function renderSyncStatus() {
    const el = document.getElementById('syncStatus'); if (!el) return;
    const meta = loadSyncMeta(), p = getPlayerData();
    if (!p) { el.textContent = ''; return; }
    if (!meta || meta.id !== p.id) { el.textContent = '🔗 まだ連携していません。「いますぐ同期」を押すと、このIDで連携が始まります。'; return; }
    const m = Math.floor((Date.now() - (meta.at || 0)) / 60000);
    el.textContent = '🔗 連携中（最後の同期：' + (m < 1 ? 'たった今' : m < 60 ? m + '分前' : Math.floor(m / 60) + '時間前') + '）　変更は自動で反映されます';
}
function showSyncToast(t) {
    const d = document.createElement('div'); d.textContent = t;
    d.style.cssText = 'position:fixed;left:50%;top:14px;transform:translateX(-50%);z-index:100000;background:rgba(30,60,120,.95);color:#fff;padding:8px 16px;border-radius:20px;font-weight:bold;font-size:.9rem;box-shadow:0 2px 10px rgba(0,0,0,.4)';
    document.body.appendChild(d); setTimeout(() => d.remove(), 4000);
}
function showSyncConflict(info) {       // 両方の端末に変更がある：どちらを使うか選ぶ
    if (syncConflictOpen) return; syncConflictOpen = true;
    const p = getPlayerData() || {};
    const wrap = document.createElement('div');
    wrap.style.cssText = 'position:fixed;inset:0;z-index:100001;background:rgba(0,0,0,.65);display:flex;align-items:center;justify-content:center;padding:12px';
    const when = info && info.at ? new Date(info.at).toLocaleString() : '不明';
    wrap.innerHTML = '<div style="background:#1b2340;color:#fff;border:1px solid #5a6aa8;border-radius:12px;max-width:420px;width:100%;padding:16px;line-height:1.6">' +
        '<h3 style="margin:0 0 8px">🔁 データが2か所で変わっています</h3>' +
        '<div style="font-size:.88rem;color:#c9d4f5">この端末と、もう一方の端末の両方で進めたため、自動では決められません。どちらを使うか選んでください。</div>' +
        '<div style="margin:10px 0;font-size:.9rem"><div>📱 <b>この端末</b>：Lv ' + (p.level || 1) + ' ／ コイン ' + (p.coins || 0) + '</div>' +
        '<div>☁ <b>もう一方の端末（サーバー）</b>：Lv ' + (info.level || 1) + ' ／ コイン ' + (info.coins || 0) + '（最終同期 ' + when + '）</div></div>' +
        '<div style="font-size:.78rem;color:#ffb0b0;margin-bottom:8px">選ばなかった側の、この間の進み具合は失われます。</div>' +
        '<button id="syncKeepLocal" class="btn btn-primary" style="width:100%;margin-bottom:6px">この端末のデータを使う（もう一方を上書き）</button>' +
        '<button id="syncKeepServer" class="btn btn-secondary" style="width:100%;margin-bottom:6px">もう一方の端末のデータを使う（この端末を上書き）</button>' +
        '<button id="syncLater" class="btn btn-danger-outline" style="width:100%">あとで決める</button></div>';
    document.body.appendChild(wrap);
    const close = () => { wrap.remove(); syncConflictOpen = false; };
    wrap.querySelector('#syncKeepLocal').addEventListener('click', () => { close(); syncManual = true; pushSync(true); });
    wrap.querySelector('#syncKeepServer').addEventListener('click', () => { close(); window.socket.emit('sync:pull', { id: (getPlayerData() || {}).id }); });
    wrap.querySelector('#syncLater').addEventListener('click', close);
}
function setupSyncHandlers() {
    if (!window.socket || window.__syncHandlers === window.socket) return; window.__syncHandlers = window.socket;
    window.socket.on('sync:status', (st) => {
        const p = getPlayerData(); if (!p || !st || st.id !== p.id) { syncManual = false; return; }
        // いまの版を保存したのが、この端末自身なら、「もう一方の端末の変更」ではない（保存の返事が届かなかっただけ）。版の番号だけ合わせる
        const meta0 = loadSyncMeta();
        if (meta0 && meta0.id === p.id && st.exists && st.dev && st.dev === getDeviceId() && st.rev > (meta0.rev || 0)) saveSyncMeta(Object.assign({}, meta0, { rev: st.rev }));
        const meta = loadSyncMeta(), linked = !!(meta && meta.id === p.id);
        const dirty = !linked || currentSyncHash() !== meta.hash;
        const serverNewer = st.exists && st.rev > (linked ? meta.rev : 0);
        if (!st.exists) { pushSync(false); return; }                               // サーバーにまだ無い → 初回の保存
        if (!serverNewer) {
            if (dirty) pushSync(false);                                             // この端末だけ変わっている → 送る
            else { if (linked) saveSyncMeta(Object.assign({}, meta, { at: Date.now() })); if (syncManual) alert('すでに最新です（この端末ともう一方の端末は同じ状態です）。'); syncManual = false; }
            return;
        }
        if (!dirty || !linked && st.rev === 0) {                                    // サーバーだけ新しい → 取り込む（勉強タイマー中は後回し）
            if (typeof studyStartTime !== 'undefined' && studyStartTime !== null) { setSyncText('⏳ 勉強が終わったら、もう一方の端末の変更を取り込みます'); syncManual = false; return; }
            window.socket.emit('sync:pull', { id: p.id }); return;
        }
        syncManual = false; showSyncConflict(st);                                    // 両方変わっている → 選んでもらう
    });
    window.socket.on('sync:pushed', (r) => {
        if (!r) return;
        syncInFlight = 0;
        if (syncPushAgain) { syncPushAgain = false; setTimeout(() => runSync(false), 400); }      // 返事を待っている間に変更があったので、改めて同期する
        if (r.ok) {
            const p = getPlayerData() || {};
            saveSyncMeta({ id: p.id, rev: r.rev, hash: syncPushHash || currentSyncHash(), at: Date.now() });
            localStorage.removeItem('pendingSave');
            if (r.manual && syncManual) alert('同期しました。\n（キャラクター・武器庫・防具・スキルなど）\n\nもう1台の端末に、このIDを入力して連携すると、同じデータで遊べます。\nプレイヤーID: ' + p.id);
            syncManual = false; return;
        }
        if (r.conflict) {
            const pp = getPlayerData() || {};
            if (r.dev && r.dev === getDeviceId() && pp.id) { saveSyncMeta({ id: pp.id, rev: r.rev, hash: (loadSyncMeta() || {}).hash || '', at: Date.now() }); pushSync(false); return; }    // 先に保存したのは自分の端末：衝突ではないので、版を合わせて送り直す
            syncManual = false; showSyncConflict(r); return;       // 送る直前に、もう一方の端末が先に更新した
        }
        syncManual = false;
        alert(r.reason === 'size' ? '同期に失敗しました（データが大きすぎます）。' : '同期に失敗しました。しばらくしてからもう一度お試しください。');
        renderSyncStatus();
    });
    window.socket.on('sync:pulled', (r) => {
        if (r && r.ok) { syncManual = false; applyPulled(r); return; }
        syncManual = false;
        if (r && r.notFound) alert('そのプレイヤーIDのデータは見つかりませんでした。\nもう一方の端末で、先に「いますぐ同期」を押してください。');
        else if (r) alert('データの取得に失敗しました。');
    });
}
// 自動同期：開いたとき・タブに戻ったとき・45秒ごと（見えているときだけ）
function startAutoSync() {
    if (window.__autoSyncOn) return; window.__autoSyncOn = true;
    setInterval(() => { if (!document.hidden && getPlayerData()) runSync(false); renderSyncStatus(); }, 45000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden && getPlayerData()) runSync(false); });
    // 開いた直後の初期化（保存データの整形など）による変化は「進めた」とは数えない：開いた時点で最新だったなら、整えたあとの状態を基準にし直す
    setTimeout(() => {
        const m = loadSyncMeta(), p = getPlayerData();
        if (m && p && m.id === p.id && bootSyncHash === m.hash) saveSyncMeta(Object.assign({}, m, { hash: currentSyncHash() }));
        syncReady = true; if (syncWanted) { syncWanted = false; runSync(false); }
    }, 2500);
    try { const t = sessionStorage.getItem('sbSyncToast'); if (t) { sessionStorage.removeItem('sbSyncToast'); setTimeout(() => showSyncToast(t), 600); } } catch (e) { /* なくてもよい */ }
    renderSyncStatus();
}

// ---------- データ引き継ぎ：プレイヤー以外のデータ ----------
const TRANSFER_KEYS = ['sbHack', 'sb_action_skills', 'sb_action_loadout', 'sb_unlocked_glyphs', 'sbBeginner', 'sbSeason', 'sbPvpEvent', 'sbAch'];
let lastBundleAt = 0;
// ページを開いた直後（初期化で保存データが整えられる前）のデータの指紋。同期の「この端末に変更があるか」の判定に使う
const bootSyncHash = currentSyncHash();
function collectBundle() {
    const items = {};
    TRANSFER_KEYS.forEach(k => {
        try {
            let v = localStorage.getItem(k); if (v == null) return;
            if (k === 'sbSeason') { try { const o = JSON.parse(v); delete o.preSeason; v = JSON.stringify(o); } catch (e) { /* そのまま */ } }   // 大きいバックアップは運ばない
            items[k] = v;
        } catch (e) { /* 読めないものは飛ばす */ }
    });
    return { items: items };
}
function sendBundle(manual) {
    const player = getPlayerData();
    if (!player || !window.socket || !window.socket.connected) return false;
    lastBundleAt = Date.now();
    window.socket.emit("saveBundle", { id: player.id, bundle: collectBundle(), manual: !!manual });
    return true;
}
// 画面を閉じる・切り替えるときにも、最新の状態を送っておく（変更があるときだけ。衝突しても勝手には上書きしない）
document.addEventListener('visibilitychange', () => { if (document.hidden && getPlayerData() && syncOnline()) { const m = loadSyncMeta(), p = getPlayerData(); if (m && m.id === p.id && currentSyncHash() !== m.hash) { syncManual = false; pushSync(false); } } });

function setupSocketEventHandlers() {
    if (!window.socket || socketHandlersSetup) return;
    socketHandlersSetup = true;
    
    console.log("Setting up socket event handlers...");

    // Boss list handler
    window.socket.on('bosses:list', (bosses) => {
        window.bosses = bosses; // Store bosses globally
        localStorage.setItem('bosses', JSON.stringify(bosses)); // And in localStorage for persistence

        const bossSelects = [
            { select: document.getElementById('bossSelect'), preview: document.getElementById('bossPreview') },       // For party
            { select: document.getElementById('soloBossSelect'), preview: document.getElementById('soloBossPreview') } // For solo
        ];
        bossSelects.forEach(({ select, preview }) => {
            if (!select) return;
            const currentVal = select.value;
            select.innerHTML = ''; // Clear existing options
            bosses.forEach(boss => {
                const option = document.createElement('option');
                option.value = boss.id;
                option.textContent = boss.name;
                select.appendChild(option);
            });
            // Restore previous selection if possible
            if (currentVal) select.value = currentVal;

            updateBossPreview(select, preview);
            if (!select.dataset.previewBound) {
                select.addEventListener('change', () => updateBossPreview(select, preview));
                select.dataset.previewBound = "true";
            }
        });
        console.log('Boss list updated from server.');
    });

    // Party handlers
    window.socket.on('party:update', (party) => {
        if (party) {
            if (typeof updatePartyUI === 'function') {
                updatePartyUI(party);
            }
        } else {
            if (typeof resetPartyUI === 'function') {
                resetPartyUI();
            }
        }
    });

    window.socket.on('party:closed', () => {
        if (typeof resetPartyUI === 'function') {
            resetPartyUI();
        }
        alert('The party has been disbanded.');
    });

    window.socket.on('party:error', (error) => {
        alert(`Party Error: ${error.message}`);
    });

    window.socket.on('bossBattle:start', ({ boss, party, roomId }) => {
        const player = getMatchPlayer();
        if (!player) {
            alert('Character not created.');
            return;
        }
        localStorage.setItem("isBossBattle", "true");
        // If party data is present, it's a multiplayer boss battle
        if (party && party.members.length > 1) {
            localStorage.setItem("isBotBattle", "false");
            localStorage.setItem("partyData", JSON.stringify(party));
            if (roomId) {
                localStorage.setItem("roomId", roomId);
            }
        } else {
            localStorage.setItem("isBotBattle", "true"); // Use bot battle flow for solo/fallback
        }
        localStorage.setItem("battlePlayer", JSON.stringify(player));
        localStorage.setItem("enemy", JSON.stringify(boss));
        localStorage.removeItem("rewardsApplied");
        location.href = "battle.html";
    });

    window.socket.on('bosses:details', ({ boss }) => {
        if (!boss) {
            alert('ボスの詳細の取得に失敗しました。');
            return;
        }
        const player = getMatchPlayer();
        if (!player) {
            alert('キャラクターを作成してください。');
            return;
        }
        localStorage.setItem("isBossBattle", "true"); // ボス戦フラグ
        localStorage.setItem("isBotBattle", "true"); // ボット戦の仕組みを流用
        localStorage.setItem("battlePlayer", JSON.stringify(player));
        localStorage.setItem("enemy", JSON.stringify(boss));
        localStorage.removeItem("rewardsApplied"); // Ensure rewards can be applied
        location.href = "battle.html";
    });

    // データ保存・読み込み関連のイベント
    let manualSaveWait = null;
    window.socket.on("dataSaved", (info) => {
        localStorage.removeItem('pendingSave'); // 保存成功したので保留フラグを削除
        const id = info && info.playerId ? info.playerId : (getPlayerData()?.id || "");
        if (pendingSilentSave) {
            pendingSilentSave = false;
            console.log("[Data] Auto saved to server:", id);
            return;
        }
        // 手動保存：武器庫などの保存（bundleSaved）の結果も合わせて知らせる
        if (manualSaveWait) clearTimeout(manualSaveWait.t);
        manualSaveWait = { id: id, t: setTimeout(() => {
            manualSaveWait = null;
            alert(`キャラクターは保存しましたが、武器庫・防具・スキルなどの保存が確認できませんでした。\n通信が安定した場所で、もう一度「データ保存」を押してください。\n\nプレイヤーID: ${id}`);
        }, 6000) };
    });
    window.socket.on("bundleSaved", (r) => {
        if (!r || !r.manual || !manualSaveWait) return;
        clearTimeout(manualSaveWait.t); const id = manualSaveWait.id; manualSaveWait = null;
        if (r.ok) alert(`データをサーバーに保存しました。\n（キャラクター・武器庫・防具・スキルなど）\n\nプレイヤーID: ${id}\n\nこのIDを他の端末で入力すると引き継げます。`);
        else alert(`キャラクターは保存しましたが、武器庫・防具・スキルなどの保存に失敗しました（データが大きすぎる可能性があります）。\n\nプレイヤーID: ${id}`);
    });

    window.socket.on("dataLoaded", (loadedPlayer) => {
        if (loadedPlayer && loadedPlayer.id) {
            if (studyStartTime !== null) cancelStudyTimer(); // 勉強中なら中止（報酬なし）
            // 引き継ぎ後に前回のバトル情報が残らないよう掃除する
            ["battlePlayer", "enemy", "roomId", "isBotBattle", "battleResult", "rewardsApplied", "stolenWeapon", "droppedOrb"]
                .forEach(key => localStorage.removeItem(key));
            const migrated = typeof migratePlayer === "function" ? migratePlayer(loadedPlayer) : loadedPlayer;
            // キャラクターに続けて、武器庫・防具・スキルなどを受け取ってから反映する（来なくても6秒で先へ進む）
            if (transferWait) clearTimeout(transferWait.t);
            transferWait = { migrated: migrated, t: setTimeout(() => finishTransfer(null), 6000) };
            window.socket.emit("loadBundle", migrated.id);
        } else {
            alert("指定されたIDのプレイヤーデータが見つかりませんでした。\n\n・IDが正しいか確認してください（英数字6文字）\n・引き継ぎ元の端末で「データをサーバーに保存」を実行済みか確認してください");
        }
    });

    let transferWait = null;
    window.socket.on("bundleLoaded", (r) => {
        if (!transferWait || !r || String(r.id || '').toUpperCase() !== String(transferWait.migrated.id || '').toUpperCase()) return;
        finishTransfer(r.bundle || null);
    });
    function finishTransfer(bundle) {
        if (!transferWait) return;
        clearTimeout(transferWait.t);
        const migrated = transferWait.migrated; transferWait = null;
        localStorage.setItem("player", JSON.stringify(migrated));
        let restored = false;
        if (bundle && bundle.items) {
            // この端末に残っていた「別のキャラクターのデータ」が混ざらないよう、無いものは消してから置き換える
            TRANSFER_KEYS.forEach(k => {
                try { if (typeof bundle.items[k] === 'string') { localStorage.setItem(k, bundle.items[k]); restored = true; } else localStorage.removeItem(k); } catch (e) { /* 容量不足など */ }
            });
        }
        localStorage.removeItem('pendingSave');
        alert(`プレイヤー「${migrated.name}」(ID: ${migrated.id}) のデータを引き継ぎました。` + (restored ? '\n（武器庫・防具・スキルなども引き継ぎました）' : '\n\n※武器庫・防具・スキルは、サーバーに保存されていませんでした。\n引き継ぎ元の端末で、もう一度「データ保存」を押してから読み込んでください。'));
        location.reload(); // ページをリロードしてUIを完全に更新
    }

    window.socket.on("dataError", (message) => {
        pendingSilentSave = false;
        alert(`エラー: ${message}`);
    });

    // 戦力ランキング受信は ranking.js でハンドリングされているため、ここでは重複を避けるために削除

    console.log("Socket event handlers setup complete");
}

// 戦力ランキングの描画は ranking.js の renderRanking()（#ranking-list-container を使用）が担当する。
// ここに同名の関数を重複定義すると、後から読み込まれる方が上書きしてしまい、
// ranking.js側が期待する要素(#ranking-list-container)ではなく存在しない#rankingListを
// 参照してしまうため、ランキングが「読み込み中」のまま止まる不具合の原因になっていた。
// そのため、このファイルでは定義しない。

// グローバルにアクセス可能に
window.normalizePlayerId = normalizePlayerId;

// デバッグ用: ブラウザのコンソールで giveDebugInstantKillWeapon() を実行すると、
// 必中・一撃必殺の武器を現在のプレイヤーに追加・装備する（テスト用）。
if (typeof giveDebugInstantKillWeapon === "function") {
    window.giveDebugInstantKillWeapon = giveDebugInstantKillWeapon;
}
// デバッグ用: ブラウザのコンソールで listTier4Abilities() を実行すると使えるキー一覧を表示し、
// giveDebugTier4AbilityWeapon("キー") を実行すると、そのTier4固有能力だけを持つ武器を
// 現在のプレイヤーに追加・装備する（テスト用）。
if (typeof giveDebugTier4AbilityWeapon === "function") {
    window.giveDebugTier4AbilityWeapon = giveDebugTier4AbilityWeapon;
}
if (typeof listTier4Abilities === "function") {
    window.listTier4Abilities = listTier4Abilities;
}
// デバッグ用: ブラウザのコンソールで listDebugDungeonRewards() を実行すると使えるキー一覧を表示し、
// giveDebugDungeonReward("キー", 個数) を実行すると、そのダンジョン宝箱報酬（オーブや
// ステータス再分配チケット・オーブスロット拡張チケット・武器合成チケットなど）を
// 現在のプレイヤーに付与する（テスト用）。
if (typeof listDebugDungeonRewards === "function") {
    window.listDebugDungeonRewards = listDebugDungeonRewards;
}
if (typeof giveDebugDungeonReward === "function") {
    window.giveDebugDungeonReward = giveDebugDungeonReward;
}
// デバッグ用（データ修復用）: 武器オーブスロット拡張チケットの過去の不具合で
// tier4固有能力が付与されないまま残ってしまった既存の武器に、ブラウザのコンソールから
// giveDebugWeaponUniqueAbility("武器名（部分一致可）", "キー") として手動で能力を付け直せる。
if (typeof giveDebugWeaponUniqueAbility === "function") {
    window.giveDebugWeaponUniqueAbility = giveDebugWeaponUniqueAbility;
}
window.syncPlayerToServer = syncPlayerToServer;

// グローバルにアクセス可能に
window.setupSocketEventHandlers = setupSocketEventHandlers;

function updateOnlineButtons(isConnected) {
    console.log(`updateOnlineButtons called with: ${isConnected}`);
    const randomMatchBtn = document.getElementById("randomMatch");
    const createRoomBtn = document.getElementById("createRoom");
    const joinRoomBtn = document.getElementById("joinRoom");

    if (randomMatchBtn) {
        randomMatchBtn.disabled = !isConnected;
        console.log(`randomMatchBtn.disabled set to: ${!isConnected}`);
    }
    if (createRoomBtn) {
        createRoomBtn.disabled = !isConnected;
        console.log(`createRoomBtn.disabled set to: ${!isConnected}`);
    }
    if (joinRoomBtn) {
        joinRoomBtn.disabled = !isConnected;
        console.log(`joinRoomBtn.disabled set to: ${!isConnected}`);
    }
}

// プレイヤーデータをlocalStorageから取得・移行する
function getPlayerData() {
    const raw = localStorage.getItem("player");
    if (!raw) return null;

    let parsed;
    try {
        parsed = JSON.parse(raw);
    } catch (e) {
        console.error("プレイヤーデータの解析に失敗しました:", e);
        console.error("破損した可能性のあるデータ:", raw); // 破損データをログに出力
        // localStorage.removeItem("player"); // 根本原因がわかるまで、データを自動削除しないようにします
        alert("プレイヤーデータの読み込みに失敗しました。データが破損している可能性があります。開発者コンソールで詳細を確認してください。");
        return null;
    }

    // ここから下：JSON自体は正常に読めているので、保存データは壊れていない。
    // migratePlayer()（新機能追加のたびに更新される変換処理）が何らかの理由で
    // 例外を投げても、絶対に「データが消えた」ように見せてはいけないため、
    // 失敗時は変換前の生データをそのまま返す（新フィールドの初期化が一部
    // 漏れる可能性はあるが、キャラクターごと消えたように見えるよりずっと安全）。
    if (typeof migratePlayer !== "function") return parsed;
    try {
        return migratePlayer(parsed);
    } catch (e) {
        console.error("migratePlayer()の実行中にエラーが発生しました。変換前のデータをそのまま返します:", e);
        return parsed;
    }
}

// 対戦用のプレイヤーデータを取得する
function getMatchPlayer() {
    const p = getPlayerData();
    if (!p) return null;
    const battleStats = getBattleStats(p);
    // 武器補正後のmaxHpをHPとして設定（常にフルHPで開始）
    return { ...p, ...battleStats, hp: battleStats.maxHp, battleStats };
}

// ステータス入力欄などをロック/アンロックする
function lockStatInputs(locked) {
    const statKeys = ["maxHp", "atk", "def", "speed"]; // STAT_KEYSがグローバルにない場合を想定
    statKeys.forEach(key => {
        const inputId = key === "maxHp" ? "statMaxHp" : "stat" + key.charAt(0).toUpperCase() + key.slice(1);
        const el = document.getElementById(inputId);
        if (el) {
            el.disabled = locked;
            el.readOnly = locked;
        }
    });
    const gradeSelect = document.getElementById("statGrade");
    if (gradeSelect) gradeSelect.disabled = locked;

    const playerNameInput = document.getElementById("playerName");
    if (playerNameInput) {
        playerNameInput.disabled = locked;
        playerNameInput.readOnly = locked;
    }

    const createBtn = document.getElementById("createCharBtn");
    if (createBtn) {
        createBtn.disabled = locked;
        if (window.I18N) {
            createBtn.textContent = locked ? I18N.statsLocked : I18N.createChar;
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM Content Loaded - Initializing application');
    
    // ソケット接続の初期化に失敗しても、メニュー・ステータス表示など
    // 後続の必須初期化処理が巻き込まれて止まらないようにする
    try {
        initializeSocket();
    } catch (e) {
        console.error("initializeSocket() failed:", e);
    }

    // ============================================================
    // 最優先で初期化する部分（ここでエラーが起きると困るもの）：
    // サイドバー・メニューボタンのナビゲーションと、既存プレイヤーの
    // ステータス表示。これらは、他の機能（ショップ初期化など）で
    // 何か問題が起きても、絶対に動作し続けなければならない。
    // ============================================================

    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const sidebar = document.querySelector('.sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const menuButtons = document.querySelectorAll('.menu-btn');
    const contentSections = document.querySelectorAll('.content-section');

    console.log('Menu elements found:', {
        mobileMenuToggle: !!mobileMenuToggle,
        sidebar: !!sidebar,
        sidebarOverlay: !!sidebarOverlay,
        menuButtons: menuButtons.length,
        contentSections: contentSections.length
    });

    function toggleMobileMenu() {
        console.log('Toggle mobile menu called');
        if (!sidebar) return;
        const isOpen = sidebar.classList.toggle('active');
        if (sidebarOverlay) sidebarOverlay.classList.toggle('active', isOpen);
        if (mobileMenuToggle) mobileMenuToggle.textContent = isOpen ? '✕' : '☰';
        console.log('Menu toggled, isOpen:', isOpen);
    }

    function closeMobileMenu() {
        console.log('Close mobile menu called');
        if (!sidebar) return;
        sidebar.classList.remove('active');
        if (sidebarOverlay) sidebarOverlay.classList.remove('active');
        if (mobileMenuToggle) mobileMenuToggle.textContent = '☰';
    }

    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', toggleMobileMenu);
        console.log('Mobile menu toggle event listener attached');
    } else {
        console.error('Mobile menu toggle button not found!');
    }

    const refreshRankingBtn = document.getElementById('refreshRankingBtn');
    if (refreshRankingBtn) {
        refreshRankingBtn.addEventListener('click', () => {
            if (window.socket) {
                window.socket.emit('ranking:get');
            }
        });
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', closeMobileMenu);
    }

    // フィールド（町）の建物からしか入れないセクション。
    // サイドバーの直接ボタンは「マップ／ステータス／インベントリ／勉強／オンライン」の
    // 5つだけに絞ってあるので、それ以外（ミッション・オーブ工房・スキル・ボスバトル・
    // ダンジョン・ランキング・ヘルプ・問題リスト）は町の建物に触れて入る。
    const townOnlySections = ['missions', 'workshop', 'skills', 'boss-battle', 'dungeon', 'ranking', 'help', 'questionlists'];

    function activateSection(section, fromTown) {
        if (townOnlySections.includes(section) && !fromTown) {
            alert('この機能は町の施設に入って利用してください');
            section = 'town';
        }

        menuButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.section === section));

        contentSections.forEach(sec => sec.classList.remove('active'));
        const activeSection = document.getElementById(`section-${section}`);
        if (activeSection) {
            activeSection.classList.add('active');
            console.log('Activated section:', section);
        } else {
            console.error('Section not found:', `section-${section}`);
        }

        if (section === 'ranking' && window.socket) {
            window.socket.emit('ranking:get');
        }

        // ショップ・インベントリタブを開いたときは最新状態を再描画する
        // （そうしないと、キャラクター作成直後などは何も表示されないままになる）
        if (section === 'shop' || section === 'inventory') {
            try {
                if (typeof renderShop === "function") renderShop();
                if (typeof renderInventory === "function") renderInventory();
                if (typeof renderOriginalWeapons === "function") renderOriginalWeapons();
                if (typeof renderMaterialsInventory === "function") renderMaterialsInventory();
                if (typeof renderOrbInventory === "function") renderOrbInventory();
            } catch (e) {
                console.error("Error rendering shop/inventory tab:", e);
            }
        }

        // オーブ工房タブを開いたときは、結晶の所持数・オーブ一覧を最新状態で再描画する
        if (section === 'workshop') {
            try {
                if (typeof refreshOrbWorkshopAll === "function") refreshOrbWorkshopAll();
            } catch (e) {
                console.error("Error rendering workshop tab:", e);
            }
        }

        // デイリーミッションタブを開いたときは最新状態を再描画する
        if (section === 'missions') {
            try {
                if (typeof renderDailyMissions === "function") renderDailyMissions();
            } catch (e) {
                console.error("Error rendering missions tab:", e);
            }
        }

        // スキルツリータブを開いたときは最新状態を再描画する
        if (section === 'skills') {
            try {
                if (typeof renderSkillTreeUI === "function") renderSkillTreeUI();
            } catch (e) {
                console.error("Error rendering skills tab:", e);
            }
        }

        // ダンジョンタブを開いたときは初期化する
        if (section === 'dungeon') {
            try {
                if (typeof initializeDungeonUI === "function") initializeDungeonUI();
            } catch (e) {
                console.error("Error initializing dungeon tab:", e);
            }
        }

        // 町（フィールド）セクションがアクティブになった時はworld.jsのonTownSectionActivatedを呼ぶ
        if (section === 'town') {
            console.log('[Script] Activating town section');
            try {
                if (typeof window.onTownSectionActivated === "function") {
                    window.onTownSectionActivated(true);
                } else {
                    console.error('[Script] onTownSectionActivated is not available');
                }
            } catch (e) {
                console.error("Error activating town section:", e);
            }
        } else {
            // 町以外のセクションに切り替えた時はworld.jsのループを停止
            console.log('[Script] Deactivating town section');
            try {
                if (typeof window.onTownSectionActivated === "function") {
                    window.onTownSectionActivated(false);
                }
            } catch (e) {
                console.error("Error deactivating town section:", e);
            }
        }

        // 問題リストセクションを開いたときはパネルを描画
        if (section === 'questionlists') {
            try {
                if (typeof renderQuestionListPanel === "function") {
                    renderQuestionListPanel();
                }
            } catch (e) {
                console.error("Error rendering question lists panel:", e);
            }
        }

        closeMobileMenu();
    }
    window.activateSection = activateSection;

    menuButtons.forEach(button => {
        button.addEventListener('click', () => {
            console.log('Menu button clicked:', button.dataset.section);
            activateSection(button.dataset.section, false);
        });
    });

    // プレイヤーデータの読み込みとステータス表示の初期化
    try {
        const initialPlayer = getPlayerData();
        if (initialPlayer) {
            updateStatus(initialPlayer);
            updateXpDisplay(initialPlayer);
            document.getElementById("playerName").value = initialPlayer.name;
            if (typeof getStatsFromPlayer === "function") {
                setStatsToInputs(getStatsFromPlayer(initialPlayer));
            }
            lockStatInputs(true);
            const statDesc = document.getElementById("statAllocationDesc");
            if (statDesc) {
                statDesc.textContent = (window.I18N ? I18N.fixedStats : "ステータスは固定されています。");
            }
            // データ管理UIの初期化
            // 以前はcreateCharacter()内でしかこのボタンを有効化しておらず、
            // 一度ページを再読み込みした「既存プレイヤー」はこのボタンが
            // 永久に disabled のままになり、一切データ保存ができなかった
            // （＝他端末へのデータ引き継ぎが不可能だった）不具合があった。
            const playerIdEl = document.getElementById("currentPlayerId");
            if (playerIdEl) playerIdEl.textContent = initialPlayer.id;
            const saveDataBtnEl = document.getElementById("saveDataBtn");
            if (saveDataBtnEl) saveDataBtnEl.disabled = false;

            // 既にキャラクターがいる場合は、ステータス画面ではなく
            // 直接フィールド（町）から始める
            // world.jsの初期化が完了するのを待つ
            const checkWorldInit = setInterval(() => {
                if (typeof window.onTownSectionActivated === 'function') {
                    clearInterval(checkWorldInit);
                    activateSection('town', true);
                }
            }, 50);
        } else {
            // 新規作成時の処理
            if (typeof updateRemainingPoints === "function") {
                updateRemainingPoints();
            }
            lockStatInputs(false);
        }
    } catch (e) {
        console.error("Error initializing player status display:", e);
    }

    // プレイヤー削除ボタンのイベントリスナーを再設定
    // UIの動的な書き換えでリスナーが消える問題に対応
    const deletePlayerBtn = document.getElementById("deletePlayerBtn");
    if (deletePlayerBtn && deletePlayerBtn.parentNode) {
        // 既存のリスナーを削除して再設定するために、要素をクローンして置き換える
        const newBtn = deletePlayerBtn.cloneNode(true);
        deletePlayerBtn.parentNode.replaceChild(newBtn, deletePlayerBtn);

        newBtn.addEventListener('click', () => {
            if (window.I18N && confirm(I18N.deleteConfirm)) {
                if (studyStartTime !== null) cancelStudyTimer();
                localStorage.clear();
                alert(I18N.deleted);
                location.reload();
            }
        });
    }

    // サモンズロッド：モンスター召喚ボタン（静的なHTML要素なので1回だけバインドする）
    const summonMonsterBtn = document.getElementById("summonMonsterBtn");
    if (summonMonsterBtn) {
        summonMonsterBtn.addEventListener("click", () => {
            if (typeof summonMonsterFromMaterial === "function") {
                summonMonsterFromMaterial();
            }
        });
    }

    // ============================================================
    // ここから下は、他の機能の初期化（不具合があっても
    // ナビゲーションやステータス表示を巻き込まないよう、
    // 全体をtry/catchで保護している）
    // ============================================================
    try {
        // ショップ画面（武器作成ボタンなど）のイベントを初期化する
        // ※ これを呼ばないと「武器を作成」ボタンが一切反応しなくなる
        if (typeof initShop === "function") {
            initShop();
        }

        // デイリーミッションの初期化
        if (typeof initializeDailyMissions === "function") {
            initializeDailyMissions();
        }

        // ログインボーナスの確認・付与
        if (typeof checkAndGrantLoginBonus === "function") {
            checkAndGrantLoginBonus();
        }

        // スキルセクションのサブタブ切り替えロジック
        const skillSubTabs = document.querySelectorAll('.sub-tab-btn');
        const skillSubContents = document.querySelectorAll('.sub-tab-content');

        skillSubTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                skillSubTabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');

                const subtabId = tab.dataset.subtab;
                skillSubContents.forEach(content => {
                    // `active` クラスの付け外しで表示/非表示を切り替える
                    content.classList.toggle('active', content.id === subtabId);
                });
            });
        });

        // 初期表示時に最初のサブタブをアクティブにする
        if (skillSubTabs.length > 0) {
            // 既にアクティブなタブがなければ、最初のタブをクリックして表示状態を初期化
            const hasActiveTab = Array.from(skillSubTabs).some(tab => tab.classList.contains('active'));
            if (!hasActiveTab) {
                skillSubTabs[0].click();
            }
        }

        // PWAインストールボタンのイベントリスナー
        const installButton = document.getElementById('install-button');
        if (installButton) {
            installButton.addEventListener('click', async () => {
                if (deferredPrompt) {
                    deferredPrompt.prompt();
                    const { outcome } = await deferredPrompt.userChoice;
                    console.log(`User response to the install prompt: ${outcome}`);
                    deferredPrompt = null;
                    const installPopup = document.getElementById('install-popup');
                    if (installPopup) {
                        installPopup.style.display = 'none';
                    }
                }
            });
        }
        const closeInstallPopup = document.getElementById('close-install-popup');
        if (closeInstallPopup) {
            closeInstallPopup.addEventListener('click', () => {
                const installPopup = document.getElementById('install-popup');
                if (installPopup) {
                    installPopup.style.display = 'none';
                }
            });
        }

        if (typeof setupPartyEventListeners === 'function') {
            setupPartyEventListeners();
        }

        const refreshRankingBtn = document.getElementById('refreshRankingBtn');
        if (refreshRankingBtn) {
            refreshRankingBtn.addEventListener('click', () => {
                if (window.socket) {
                    window.socket.emit('ranking:get');
                }
            });
        }

        // 勉強関連のイベントハンドラ
        const studyStartBtn = document.getElementById("studyStart");
        if (studyStartBtn) {
            studyStartBtn.addEventListener('click', startStudy);
        }
        const studyStopBtn = document.getElementById("studyStop");
        if (studyStopBtn) {
            studyStopBtn.addEventListener('click', () => {
                if (studyStartTime === null) return;
                if (confirm('途中でやめると、今回の勉強の報酬は受け取れません。やめますか？')) cancelStudyTimer();
            });
        }
        const studyFocusSelect = document.getElementById("studyFocus");
        if (studyFocusSelect) {
            studyFocusSelect.addEventListener('change', updateStatGrowthInfo);
            updateStatGrowthInfo(); // 初期表示
        }

        // 学習管理ボタン
        const studyStatsBtn = document.getElementById("studyStatsBtn");
        if (studyStatsBtn) {
            studyStatsBtn.addEventListener('click', () => {
                if (typeof showStudyStatsUI === 'function') {
                    showStudyStatsUI();
                }
            });
        }

        const reviewListBtn = document.getElementById("reviewListBtn");
        if (reviewListBtn) {
            reviewListBtn.addEventListener('click', () => {
                if (typeof showReviewUI === 'function') {
                    showReviewUI();
                }
            });
        }

        // アプリが完全終了→再起動された直後(=フレッシュな読み込み)でも
        // 保存済みのタイマー状態があれば復元する
        restoreStudyTimerState();

        // データ管理ボタン
        const saveDataBtn = document.getElementById('saveDataBtn');
        if (saveDataBtn) {
            saveDataBtn.addEventListener('click', () => { syncManual = true; runSync(true); });
        }

        const loadDataBtn = document.getElementById('loadDataBtn');
        if (loadDataBtn) {
            loadDataBtn.addEventListener('click', () => {
                const loadPlayerId = document.getElementById('loadPlayerId').value.trim().toUpperCase();
                if (!loadPlayerId || loadPlayerId.length !== 6) {
                    alert('プレイヤーIDは6文字で入力してください。');
                    return;
                }
                if (!window.socket || !window.socket.connected) {
                    alert('サーバーに接続されていません。ページを再読み込みしてください。');
                    return;
                }
                if (confirm(`プレイヤーID: ${loadPlayerId} と連携します。\n\nこの端末のデータは、そのIDのデータに置き換わります。\n以後は、2台の端末が同じキャラクターとして、自動で反映し合います。\n（連携を始める前に、もう一方の端末で「いますぐ同期」を押しておいてください）\n\nよろしいですか？`)) {
                    syncManual = true;
                    window.socket.emit('sync:pull', { id: loadPlayerId, link: true });
                }
            });
        }

        // ソロボスバトル開始ボタン
        const startSoloBossBattleBtn = document.getElementById('startSoloBossBattleBtn');
        if (startSoloBossBattleBtn) {
            startSoloBossBattleBtn.addEventListener('click', () => {
                const player = getPlayerData();
                if (!player) {
                    alert('まずはキャラクターを作成してください。');
                    return;
                }
                if (!window.socket || !window.socket.connected) {
                    alert('サーバーに接続されていません。ページを再読み込みしてください。');
                    return;
                }
                const bossId = document.getElementById('soloBossSelect').value;
                const difficulty = document.getElementById('soloBossDifficulty').value;
                if (!bossId) {
                    alert('ボスを選択してください。');
                    return;
                }
                // Save difficulty for result screen
                localStorage.setItem("battleDifficulty", difficulty);
                window.socket.emit('bosses:getDetails', { bossId, difficulty });
            });
        }

        // キャラクター作成・削除ボタン
        const createCharBtn = document.getElementById("createCharBtn");
        if (createCharBtn) {
            createCharBtn.addEventListener('click', createCharacter);
        }

        // 素材管理の初期化
        if (typeof initMaterials === "function") {
            initMaterials();
        }

        // 素材管理モーダルの開閉
        // （ボタンにクリックイベントが一切設定されておらず、押しても何も起きなかった。
        //   モーダルのHTML自体も存在しなかったため、あわせて追加した）
        const openMaterialManagementBtn = document.getElementById('openMaterialManagementBtn');
        const materialManagementModal = document.getElementById('materialManagementModal');
        if (openMaterialManagementBtn && materialManagementModal) {
            openMaterialManagementBtn.addEventListener('click', () => {
                if (typeof renderMaterialsInventory === "function") {
                    renderMaterialsInventory();
                }
                materialManagementModal.style.display = 'flex';
            });
            const closeMaterialManagementBtn = materialManagementModal.querySelector('.close');
            if (closeMaterialManagementBtn) {
                closeMaterialManagementBtn.addEventListener('click', () => {
                    materialManagementModal.style.display = 'none';
                });
            }
        }

        // スキルツリーの初期描画
        if (typeof renderSkillTreeUI === "function") {
            renderSkillTreeUI();
        }

        // 問題リスト機能（作成・編集・模擬戦闘）の初期化
        if (typeof initQuestionListsUI === "function") {
            initQuestionListsUI();
        }

        // オーブ工房（結晶によるオーブの厳選）の初期化
        if (typeof initOrbWorkshopUI === "function") {
            initOrbWorkshopUI();
        }

        // ステータス入力欄のイベントリスナー
        const statInputs = document.querySelectorAll('.stat-allocation input, .stat-allocation select');
        statInputs.forEach(input => {
            input.addEventListener('input', updateRemainingPoints);
        });
    } catch (e) {
        console.error("Error during secondary page initialization:", e);
    }
});

// （旧）デバッグ用の一撃必殺武器付与コマンドは、一撃必殺能力自体を廃止したため削除。
