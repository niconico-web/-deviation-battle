const isBotBattle = localStorage.getItem("isBotBattle") === "true";
const isBossBattle = localStorage.getItem("isBossBattle") === "true";
const isDungeonBattle = localStorage.getItem("isDungeonBattle") === "true";
// 模擬戦闘（プレイヤーが自作した問題リストを使い、ボットが次々出現する連続戦闘）かどうか。
// 実際の問題取得・勝敗処理のフックはquestionLists.js側に実装されている。
const isMockBattle = localStorage.getItem("isMockBattle") === "true";
const partyDataJSON = localStorage.getItem("partyData");
const partyData = partyDataJSON && !isBotBattle ? JSON.parse(partyDataJSON) : null;
// ダンジョンバトルの場合はソケットが必要（サーバーとの通信で階進行を管理するため）
const socket = (isBotBattle && !isDungeonBattle) ? null : io();
const roomId = localStorage.getItem("roomId");
const battlePlayerData = localStorage.getItem("battlePlayer");
const enemyData = localStorage.getItem("enemy");
let me = battlePlayerData ? JSON.parse(battlePlayerData) : null;
let enemy = enemyData ? JSON.parse(enemyData) : null;
let allies = []; // 自分以外のパーティメンバー

// ダンジョンデータの取得
let dungeonData = null;
if (isDungeonBattle) {
    const dungeonDataJSON = localStorage.getItem("dungeonData");
    if (dungeonDataJSON) {
        dungeonData = JSON.parse(dungeonDataJSON);
    }
}

// 「実戦形式」の練習バトル（オンライン画面の「スライムと練習」から開始）かどうか。
// 一度読み取ったら消費し、リロードでは再度発動しないようにする。
const isPracticeTutorial = isBotBattle && localStorage.getItem("sb_practice_tutorial") === "true";
if (isPracticeTutorial) {
    localStorage.removeItem("sb_practice_tutorial");
}
const practiceCoachShown = { question: false, gauge: false, strongAttack: false, skill: false };

let battleEnd = false, rejoined = false, currentQuestion = null, questionStartTime = null, timerInterval = null, countdownInterval = null, botDifficulty = null;
let activeSkills = [];
let selectedSkill = null;
let usedSkills = [];
let skillActivationWindow = false;
let skillActivationTimer = null;
let bossAutoAnswerTimer = null; // Boss auto-answer timer
const BOSS_AUTO_ANSWER_TIMEOUT = 3000; // 3 seconds for boss to auto-answer

// ==== ATB（アクティブ型）バトルシステム（ボス戦のみ） ====
// ボス側は素早さに応じてリアルタイムで行動ゲージが進行する。
// プレイヤー側は「正解した数」で行動ゲージが進行する方式（問題間の待ち時間は0）。
// どちらも、相手の行動待ちで完全に止まることがないのが「アクティブ型」。
let playerATB = 0;                    // 自分の行動ゲージの表示用の値（0〜100 = 正解数/必要正解数）
let playerCorrectCount = 0;           // 今の行動ゲージ内での連続正解数
let playerRequiredCount = 7;          // 行動ゲージを満タンにするために必要な正解数（素早さで決まる）
let enemyATB = 0;                     // ボスの行動ゲージ（0〜100）
let atbInterval = null;               // ボスのゲージ進行用のタイマー（毒・火傷等の継続効果もここで一緒に進行させる）
let atbPlayerActionPending = false;   // 出題中〜コマンド確定まで。この間は次の問題を出題しない
let atbBossTelegraphActive = false;   // ボスの攻撃予備動作（テレグラフ）中。この間だけボスのゲージは止まる
let atbGuardWindowOpen = false;       // ガードが間に合う受付時間中かどうか
let atbGuardActivated = false;        // 今回のテレグラフでガードを発動済みか
const ATB_TICK_MS = 100;              // ボス側ゲージ更新の間隔
const ATB_MAX = 100;
// 毒・火傷・防御低下等の継続効果の「1ターン」の定義。
// 一時期（ATB化直後）は実時間3秒に1回のペースで処理していたが、依頼により
// 「1ターン＝1回正解する」ことと定義し直した。実際の処理は、正解した瞬間
// （handleATBAnswerのisCorrect分岐内）でtickBotBattleStatus()を1回呼ぶ形で行う。
const ATB_BASE_FILL_MS = 10000;       // ボス側：素早さが五分五分なら約10秒でゲージ満タンになる基準値
const ATB_PLAYER_QUIZ_TIMEOUT_MS = 4000; // 自分が1問答えられる制限時間
const ATB_BOSS_TELEGRAPH_MS = 700;       // ボスの攻撃予備動作の時間（この間にガードできる）

// クリティカル関連
const BASE_CRIT_CHANCE = 0.05; // 通常時、常に5%の確率でクリティカルが発生する
const CRITICAL_ABILITY_CRIT_CHANCE = 0.30; // 「必殺」の固有能力を持つ武器を装備している場合の基本クリティカル率
const BASE_CRIT_MULTIPLIER = 1.5; // クリティカル発生時の基本ダメージ倍率
// スキルによる一時的な効果（ボット戦で使用）
let myPendingDamageReduction = 0; // 次に受けるダメージの軽減率
let myDefDebuff = 0;              // 自身の防御低下量
let myDefDebuffTurns = 0;         // 防御低下の残りターン
let mySkipThisTurn = false;       // このターン攻撃できない
let enemyBurnTurns = 0;           // 敵の火傷残りターン
let enemyPoisonTurns = 0;         // 敵の毒残りターン
let enemySpeedDebuff = 0;         // 敵の速度低下率
let enemySpeedDebuffTurns = 0;    // 敵の速度低下残りターン
let enemyAtkDebuff = 0;           // 敵の攻撃力低下率
let enemyAtkDebuffTurns = 0;      // 敵の攻撃力低下残りターン
let enemyDefDebuff = 0;           // 敵の防御力低下率
let enemyDefDebuffTurns = 0;      // 敵の防御力低下残りターン
let enemyAccuracyDebuff = 0;      // 敵の命中率低下率
let enemyAccuracyDebuffTurns = 0; // 敵の命中率低下残りターン
let myMultiHit = 0;               // 複数回攻撃の回数
let myMultiHitTurns = 0;          // 複数回攻撃の残りターン
let myMultiHitMultiplier = 0.6;   // 複数回攻撃1回あたりのダメージ倍率（スキルごとに変わる）
let mySpeedBuff = 0;              // 自身の速さ上昇率
let mySpeedBuffTurns = 0;         // 速さ上昇の残りターン
// 以下4つ（myDodgeChance/myDodgeTurns/myCounterActive/myCounterTurns/myShield）は
// 元々ここでの宣言（let）が無く、applySkillEffect()内の代入がどこにも束縛されない
// 暗黙のグローバルになってしまっていた。そのため「回避率アップ」「幻影（絶対回避）」
// 「反撃」「シールド」といったスキル効果が、実際の被ダメージ処理
// （resolveBossAttack）から一切参照されず、常に無効化されていた不具合を修正。
let myDodgeChance = 0;            // スキルによる自身の回避率アップ（0〜1の割合。1.0で完全回避）
let myDodgeTurns = 0;             // 回避率アップの残りターン
let myCounterActive = false;      // 反撃態勢が有効か
let myCounterTurns = 0;           // 反撃態勢の残りターン
let myShield = 0;                 // スキルで得たシールド（被ダメージから先に減算される）
let myReviveAvailable = false;    // 戦闘不能時に一度だけ復活できるか
let myPhoenixUsed = false;        // Tier5固有能力「不死鳥の加護」（1戦闘1回の復活）を使用済みか
let myRevivePercent = 0;          // 復活時のHP割合
let myFirstAttackDone = false;    // 「会心の初撃」用：自分の最初の攻撃が済んだか
let myBurnTurns = 0;              // 自分（プレイヤー）の火傷残りターン
let myPoisonTurns = 0;            // 自分（プレイヤー）の毒残りターン
let enemyNextDamageShield = 0;    // ボスが得た「次に受けるダメージ軽減」（1回限り）
let pendingSkillEffect = null;    // 正解時、コマンド選択待ちの間だけ保持するスキル効果
let pendingUsedSkill = null;      // 正解時、コマンド選択待ちの間だけ保持する使用スキル
let selectedCommand = 'attack';   // オンライン/パーティ戦で回答と同時に選ぶコマンド（攻撃/特殊/防御/必殺技）
let myUltimateReady = false;      // オンライン/パーティ戦でのサーバー側必殺技ゲージ状態

// 武器システムの関数をインポート（weapons.jsが読み込まれている前提）
// getWeaponUltimateName関数を使用するために必要

const turnText = document.getElementById("turnText");
const myName = document.getElementById("myName");
const enemyName = document.getElementById("enemyName");
const myHPBar = document.getElementById("myHPBar");
const enemyHPBar = document.getElementById("enemyHPBar");
const myHPText = document.getElementById("myHPText");
const enemyHPText = document.getElementById("enemyHPText");
const myUltimateBar = document.getElementById("myUltimateBar");
const enemyUltimateBar = document.getElementById("enemyUltimateBar");
const myUltimateText = document.getElementById("myUltimateText");
const enemyUltimateText = document.getElementById("enemyUltimateText");
const correctEffect = document.getElementById("correctEffect");
const ultimateEffect = document.getElementById("ultimateEffect");
const myAtk = document.getElementById("myAtk");
const myDef = document.getElementById("myDef");
const mySpeed = document.getElementById("mySpeed");
const mySpecial = document.getElementById("mySpecial");
const myGrade = document.getElementById("myGrade");
const enemyAtk = document.getElementById("enemyAtk");
const enemyDef = document.getElementById("enemyDef");
const enemySpeed = document.getElementById("enemySpeed");
const enemySpecial = document.getElementById("enemySpecial");
const enemyGrade = document.getElementById("enemyGrade");
const questionDisplay = document.getElementById("questionDisplay");
const choicesContainer = document.getElementById("choicesContainer");
const timerDisplay = document.getElementById("timer");
const log = document.getElementById("log");
const skillsContainer = document.getElementById("skillSlotsContainer");

// コマンドメニューのボタン配線
document.getElementById("cmdAttackBtn")?.addEventListener("click", () => selectCommand("attack"));
document.getElementById("cmdSpecialBtn")?.addEventListener("click", () => selectCommand("special"));
document.getElementById("cmdDefendBtn")?.addEventListener("click", () => selectCommand("defend"));
document.getElementById("cmdUltimateBtn")?.addEventListener("click", () => selectCommand("ultimate"));
document.getElementById("atbGuardBtn")?.addEventListener("click", () => activateATBGuard());

/**
 * コマンドボタンが押された時の共通入口。
 * ボット戦・オンライン/パーティ戦のどちらでも、ボタンを押した瞬間にコマンドを確定させる。
 * （以前はオンライン/パーティ戦の場合、ハイライト表示を切り替えるだけで実際には
 *   resolvePlayerCommand() が呼ばれておらず、コマンドボタンを押しても何も起きなかった。
 *   実際の判定・ダメージ計算やサーバーへの送信は resolvePlayerCommand() 側で
 *   isBotBattle かどうかに応じて分岐して行われる。）
 */
function selectCommand(command) {
    const isUltimateReady = isBotBattle
        ? (me.ultimateGauge && me.ultimateGauge.current >= me.ultimateGauge.max)
        : myUltimateReady;
    if (command === 'ultimate' && !isUltimateReady) {
        return; // ゲージ不足時は選択させない
    }
    selectedCommand = command;
    document.querySelectorAll('#commandMenu .btn-command').forEach(btn => btn.classList.remove('selected'));
    const btnId = { attack: 'cmdAttackBtn', special: 'cmdSpecialBtn', defend: 'cmdDefendBtn', ultimate: 'cmdUltimateBtn' }[command];
    document.getElementById(btnId)?.classList.add('selected');
    resolvePlayerCommand(command);
}

function statLabel(k, v) {
    return I18N[k] + I18N.colon + v;
}

/**
 * プレイヤーが特定のユニーク能力を持っているかチェック
 * @param {object} player - プレイヤーオブジェクト
 * @param {string} effectKey - チェックする能力のエフェクトキー
 * @returns {boolean}
 */
function hasUniqueAbility(player, effectKey) {
    return player?.equippedWeapon?.uniqueAbilities?.some(ability => ability.effect === effectKey) || false;
}

function getSubjectDisplayName(subject) {
    const subjectNames = {
        'math': '算数・数学',
        'jp': '国語',
        'english': '英語',
        'eng': '英語',
        'science': '理科',
        'sci': '理科',
        'social': '社会',
        'soc': '社会'
    };
    return subjectNames[subject] || subject;
}

/**
 * プレイヤーの学年（1〜12）を1〜12の範囲に正規化する。
 * @param {number|string} rawGrade
 * @returns {number}
 */
function normalizeBossQuestionGrade(rawGrade) {
    let grade = parseInt(rawGrade, 10);
    if (!Number.isFinite(grade) || Number.isNaN(grade)) {
        grade = 1;
    }
    if (grade < 1) grade = 1;
    if (grade > 12) grade = 12;
    return grade;
}

/**
 * 通常バトル（ボット戦・オンライン対戦）用の問題をローカル（questions.js に埋め込まれたデータ）から取得する。
 * プレイヤーの学年（me.grade）と指定された教科に応じた問題一覧を返す。
 * @param {string} subject - 教科（math/jp/eng/sci/soc など）
 * @returns {Array} 問題の配列（見つからない場合は空配列）
 */
function getLocalRegularQuestions(subject) {
    if (typeof QUESTIONS_DATA === 'undefined') {
        console.error('[Questions] QUESTIONS_DATA が読み込まれていません（questions.js の読み込みを確認してください）。');
        return [];
    }

    const rawGrade = normalizeBossQuestionGrade(me && me.grade); // 1〜12の範囲に正規化
    let schoolLevel, grade;
    if (rawGrade <= 6) {
        schoolLevel = 'elementary';
        grade = rawGrade;
    } else if (rawGrade <= 9) {
        schoolLevel = 'junior_high';
        grade = rawGrade - 6;
    } else {
        schoolLevel = 'high_school';
        grade = rawGrade - 9;
    }

    const levelData = QUESTIONS_DATA[schoolLevel];
    if (!levelData) return [];
    const gradeData = levelData[String(grade)];
    if (!gradeData) return [];
    return gradeData[subject] || [];
}

/**
 * ボス戦用の問題をローカル（boss_questions.js に埋め込まれたデータ）から取得する。
 * プレイヤーの学年（me.grade）と指定された教科に応じた問題一覧を返す。
 * @param {string} bossSubject - ボスの教科（math/jp/eng/sci/soc）
 * @returns {Array} 問題の配列（見つからない場合は空配列）
 */
function getLocalBossQuestions(bossSubject) {
    if (typeof BOSS_QUESTIONS_DATA === 'undefined' || !BOSS_QUESTIONS_DATA.boss) {
        console.error('[BossQuestions] BOSS_QUESTIONS_DATA が読み込まれていません（boss_questions.js の読み込みを確認してください）。');
        return [];
    }

    const grade = normalizeBossQuestionGrade(me && me.grade);
    const gradeData = BOSS_QUESTIONS_DATA.boss[String(grade)];
    if (!gradeData) {
        console.warn(`[BossQuestions] grade=${grade} の問題データが見つかりません。`);
        return [];
    }

    const subjectQuestions = gradeData[bossSubject];
    if (!subjectQuestions || subjectQuestions.length === 0) {
        console.warn(`[BossQuestions] grade=${grade}, subject=${bossSubject} の問題データが見つかりません。`);
        return [];
    }

    return subjectQuestions;
}

function renderPartyStatus() {
    let container = document.getElementById('ally-status-container');
    if (!container) {
        const myStatusBox = document.getElementById('my-status');
        if (myStatusBox && myStatusBox.parentElement) {
            container = document.createElement('div');
            container.id = 'ally-status-container';
            container.className = 'ally-status-container';
            // my-status の前に挿入して、味方・自分・敵の順にする
            myStatusBox.parentElement.insertBefore(container, myStatusBox);
        } else {
            // エラーをログに出力するが、処理は続行させる
            console.warn("Could not find a parent for 'my-status' to append ally statuses. Party status will not be displayed.");
            return; // パーティ表示はできないが、他の処理は続行させる
        }
    }
    container.innerHTML = '';

    allies.forEach(ally => {
        const allyDiv = document.createElement('div');
        allyDiv.className = 'ally-status-box status-box'; // 既存のスタイルを流用
        allyDiv.id = `ally-status-${ally.id}`;
        allyDiv.innerHTML = `
            <h3 class="ally-name">${ally.name}</h3>
            <div class="damage-display" id="allyDamage-${ally.id}"></div>
            <div class="hp-bar-container">
                <div class="hp-bar" id="allyHPBar-${ally.id}" style="width: 100%; background-color: #28a745;"></div>
            </div>
            <div class="hp-text" id="allyHPText-${ally.id}">${ally.hp} / ${ally.maxHp}</div>
        `;
        container.appendChild(allyDiv);
    });
}

function initialize() {
    if (!me || !enemy) {
        alert(I18N.noBattleData);
        location.href = "index.html";
        return;
    }

    console.log("Battle initialize:", { me, enemy, roomId, isBotBattle, isBossBattle, partyData, allies });
    console.log("Enemy stats:", enemy.stats);
    console.log("Enemy maxHp:", enemy.maxHp);
    console.log("Socket exists:", !!socket);
    console.log("Socket connected:", socket ? socket.connected : "N/A");
    console.log("Socket ID:", socket ? socket.id : "N/A");

    // Ensure enemy has stats if they're undefined
    if (!enemy.stats) {
        console.warn("Enemy stats undefined, using defaults");
        enemy.stats = {
            maxHp: enemy.maxHp || 100,
            atk: enemy.atk || 10,
            def: enemy.def || 10,
            speed: enemy.speed || 10
        };
    }

    // Ensure enemy maxHp is set
    if (!enemy.maxHp && enemy.stats && enemy.stats.maxHp) {
        enemy.maxHp = enemy.stats.maxHp;
    }
    if (!enemy.maxHp) {
        enemy.maxHp = 100;
    }

    // ボス戦でstatsオブジェクトがない場合、トップレベルのプロパティから作成する
    if (isBossBattle && !enemy.stats) {
        console.warn("Boss enemy.stats is missing, creating from top-level properties.");
        enemy.stats = {
            maxHp: enemy.maxHp || enemy.hp,
            atk: enemy.atk,
            def: enemy.def,
            speed: enemy.speed
        };
        if (!enemy.maxHp) enemy.maxHp = enemy.hp;
    }

    // 武器補正が適用されたmaxHpに合わせて現在のHPを調整
    // 武器による補正が減少する場合でもHPはmaxHpを超えないようにする
    if (me.hp > me.maxHp) {
        me.hp = me.maxHp;
    }
    if (enemy.hp > enemy.maxHp) {
        enemy.hp = enemy.maxHp;
    }

    myName.textContent = me.name;
    enemyName.textContent = enemy.name;

    // ボス戦の場合、相手カードにボスのアイコンイラストを表示する
    const enemyAvatarEl = document.getElementById("enemyAvatar");
    if (enemyAvatarEl) {
        if (isBossBattle && typeof getBossIconSVG === "function") {
            enemyAvatarEl.innerHTML = getBossIconSVG(enemy.id, 72);
        } else {
            enemyAvatarEl.innerHTML = "";
        }
    }

    // ユニーク能力「リ・ミゼラブル」（0.8倍）／Tier5「覇王の威圧」（0.65倍）の効果をバトル開始時に適用
    // 両方持っている場合は、より強い方（覇王の威圧）だけを適用する。
    const applyReMiserable = (player, target) => {
        if (player.equippedWeapon && player.equippedWeapon.uniqueAbilities) {
            const hasCrush = player.equippedWeapon.uniqueAbilities.some(a => a.effect === "enemy_stat_crush");
            const hasReMiserable = hasCrush || player.equippedWeapon.uniqueAbilities.some(a => a.effect === "enemy_stat_debuff");
            if (hasReMiserable) {
                const debuffRate = hasCrush ? 0.65 : 0.8;
                addLog(`${player.name}の「${hasCrush ? "覇王の威圧" : "リ・ミゼラブル"}」発動！ ${target.name}の全ステータスがダウン！`);
                target.atk = Math.floor(target.atk * debuffRate);
                target.def = Math.floor(target.def * debuffRate);
                target.speed = Math.floor(target.speed * debuffRate);
                target.maxHp = Math.floor(target.maxHp * debuffRate);
                // maxHpが減ったことに伴い、現在のHPも調整
                if (target.hp > target.maxHp) {
                    target.hp = target.maxHp;
                }
            }
        }
    };

    // 自分から相手へ
    applyReMiserable(me, enemy);
    // 相手から自分へ
    applyReMiserable(enemy, me);

    // パーティメンバーがいる場合、UIを初期化
    if (partyData) {
        allies = partyData.members
            .filter(member => member.id !== me.id)
            .map(member => ({ ...member.player, hp: member.player.maxHp, maxHp: member.player.maxHp }));
        renderPartyStatus();
    }

    updateStats();
    updateHP();
    updateUltimateGauge();
    addLog(I18N.battleBegin);

    // 実戦形式チュートリアル（練習バトル）の場合、上部にバナーを表示する
    if (isPracticeTutorial && window.PracticeCoach) {
        window.PracticeCoach.start();
    }

    // 模擬戦闘の場合、バナー表示・経過時間タイマーを開始する
    if (isMockBattle && typeof initMockBattleUI === "function") {
        initMockBattleUI();
    }

    // スキルを初期化
    initializeBattleSkills();

    if (isBotBattle) {
        console.log("Bot battle detected, starting bot battle immediately");
        startBotBattle();
    } else {
        console.log("Online battle detected, waiting for server");
        if (!socket) {
            addLog("エラー: ソケット接続エラーが発生しました。ページを再読み込みしてください。");
            return;
        }
        
        // ソケット接続を待つ
        if (!socket.connected) {
            addLog("サーバー接続待機中...");
            socket.once("connect", () => {
                console.log("Socket connected, starting battle");
                joinOnlineBattle();
            });
            
            // 接続に時間がかかっている場合の通知（ブロッキングしない）
            // ※ サーバーがスリープ状態から復帰する場合など、接続確立までに時間がかかることがあるため、
            //    ここでは alert() を使わず、ログ表示のみで待機を継続する（socket.io側は自動で再接続を試み続ける）
            setTimeout(() => {
                if (!socket.connected) {
                    addLog("サーバーへの接続に時間がかかっています。しばらくお待ちください...");
                }
            }, 8000);

            // それでも長時間接続できない場合のみ、ユーザーに再読み込みを促す
            setTimeout(() => {
                if (!socket.connected) {
                    addLog("エラー: サーバーに接続できませんでした。ページを再読み込みしてください。");
                }
            }, 30000);
        } else {
            joinOnlineBattle();
        }
    }
}

function joinOnlineBattle() {
    console.log("Joining online battle for room:", roomId);
    addLog("バトルに参加中...");
    // サーバーにバトル参加を通知し、初期状態を要求
    socket.emit("battle:join", { roomId, playerId: me.id });
}

function calculateDodgeChance(speed) {
    if (!speed || speed <= 0) return 0;
    // 素早さ7500で45%回避率に到達
    return Math.min(45, Math.floor((speed / 750000) * 45));
}

function updateStats() {
    // 各種デバフ・バフを反映した「実際の」ステータスを表示する。
    // 以前はここで me.atk / enemy.speed 等の生の値をそのまま表示していたため、
    // スキルで敵の速度を下げても表示上は何も変わらず、「デバフが一切反映されて
    // いない」ように見えてしまっていた（内部の計算では反映されていても、
    // 見た目で確認できなければ機能していないのと同じ）。
    const effectiveMyDef = Math.max(0, (me.def || 0) - myDefDebuff);
    const effectiveMySpeed = Math.floor((me.speed || 0) * (1 + (mySpeedBuff || 0)) * (hasUniqueAbility(me, 'speed_boost') ? 1.25 : 1));

    myAtk.textContent = statLabel("atk", me.atk);
    myDef.textContent = statLabel("def", effectiveMyDef);
    const myDodgeChance = calculateDodgeChance(effectiveMySpeed);
    mySpeed.textContent = statLabel("speed", effectiveMySpeed) + ` (回避${myDodgeChance}%)`;
    if (mySpecial) mySpecial.textContent = "特殊" + I18N.colon + (me.special != null ? me.special : me.atk);
    myGrade.textContent = "学年" + I18N.colon + getGradeLabel(me.grade || 1);
    
    // ボスと通常のボットでステータスの持ち方が違うため、直接プロパティを参照する
    const enemyAtkVal = Math.max(0, Math.floor((enemy.atk || 0) * (1 - (enemyAtkDebuff || 0))));
    const enemyDefVal = Math.max(0, Math.floor((enemy.def || 0) * (1 - (enemyDefDebuff || 0))));
    const enemySpeedVal = Math.max(0, Math.floor((enemy.speed || 0) * (1 - (enemySpeedDebuff || 0))));
    
    enemyAtk.textContent = statLabel("atk", enemyAtkVal);
    enemyDef.textContent = statLabel("def", enemyDefVal);
    const enemyDodgeChance = calculateDodgeChance(enemySpeedVal);
    enemySpeed.textContent = statLabel("speed", enemySpeedVal) + ` (回避${enemyDodgeChance}%)`;
    if (enemySpecial) enemySpecial.textContent = "特殊" + I18N.colon + (enemy.special != null ? enemy.special : enemy.atk);
    enemyGrade.textContent = "学年" + I18N.colon + getGradeLabel(enemy.grade || 1);
}

function updateHP() {
    // HPが0の場合にmaxHpが代入されるのを防ぐ
    const myHp = (me.hp !== null && me.hp !== undefined) ? me.hp : (me.maxHp || 100);
    const myMaxHp = me.maxHp || 100;
    const enemyHp = (enemy.hp !== null && enemy.hp !== undefined) ? enemy.hp : (enemy.maxHp || 100);
    const enemyMaxHp = enemy.maxHp || 100;
    
    myHPText.textContent = "HP " + myHp + " / " + myMaxHp;
    enemyHPText.textContent = "HP " + enemyHp + " / " + enemyMaxHp;

    // HPが0未満にならないようにし、パーセンテージを計算
    const myHpPercentage = Math.max(0, (myHp / myMaxHp) * 100);
    const enemyHpPercentage = Math.max(0, (enemyHp / enemyMaxHp) * 100);

    myHPBar.style.width = myHpPercentage + "%";
    enemyHPBar.style.width = enemyHpPercentage + "%";

    // 味方のHP更新
    allies.forEach(ally => {
        const allyHp = (ally.hp !== null && ally.hp !== undefined) ? ally.hp : (ally.maxHp || 100);
        const allyMaxHp = ally.maxHp || 100;
        const hpBar = document.getElementById(`allyHPBar-${ally.id}`);
        const hpText = document.getElementById(`allyHPText-${ally.id}`);

        if (hpBar) {
            const percentage = Math.max(0, (allyHp / allyMaxHp) * 100);
            hpBar.style.width = percentage + "%";
        }
        if (hpText) {
            hpText.textContent = `${allyHp} / ${allyMaxHp}`;
        }
    });
}

function updateUltimateGauge() {
    // 必殺技ゲージの初期化
    if (!me.ultimateGauge) {
        me.ultimateGauge = { current: 0, max: 100 };
    }
    if (!enemy.ultimateGauge) {
        enemy.ultimateGauge = { current: 0, max: 100 };
    }
    
    // 自分のゲージ更新
    const myGaugePercent = (me.ultimateGauge.current / me.ultimateGauge.max) * 100;
    myUltimateBar.style.width = myGaugePercent + "%";
    myUltimateText.textContent = `${me.ultimateGauge.current} / ${me.ultimateGauge.max}`;
    
    // 敵のゲージ更新
    const enemyGaugePercent = (enemy.ultimateGauge.current / enemy.ultimateGauge.max) * 100;
    enemyUltimateBar.style.width = enemyGaugePercent + "%";
    enemyUltimateText.textContent = `${enemy.ultimateGauge.current} / ${enemy.ultimateGauge.max}`;
    
    // ゲージが満タンの時は特別なスタイルを適用（新しいUIデザインに準拠）
    if (me.ultimateGauge.current >= me.ultimateGauge.max) {
        myUltimateBar.style.background = "linear-gradient(90deg, #007bff, #00c6ff)"; // 水色系のグラデーション
        myUltimateBar.style.boxShadow = "0 0 10px #00c6ff";
    } else {
        myUltimateBar.style.background = "#007bff"; // 単色の水色
        myUltimateBar.style.boxShadow = "none";
    }

    // 敵のゲージスタイルも同様に更新（色は変えても良い）
    if (enemy.ultimateGauge.current >= enemy.ultimateGauge.max) {
        enemyUltimateBar.style.background = "linear-gradient(90deg, #ff8c00, #ff4500)";
        enemyUltimateBar.style.boxShadow = "0 0 10px #ff8c00";
    } else {
        enemyUltimateBar.style.background = "#ff4500";
        enemyUltimateBar.style.boxShadow = "none";
    }
}

function addLog(text) {
    const div = document.createElement("div");
    div.textContent = text;
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
}

function showDamage(id, amount) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = amount > 0 ? "-" + amount : "MISS";

    // Web Animations API を使用してリッチなアニメーションを実装
    el.animate([
        { transform: 'translateY(0) scale(1.2)', opacity: 1, color: '#ff4d4d' },
        { transform: 'translateY(-30px) scale(1.5)', opacity: 1, offset: 0.2, color: '#ff1a1a' },
        { transform: 'translateY(-120px) scale(1)', opacity: 0 }
    ], {
        duration: 1500,
        easing: 'cubic-bezier(0.25, 1, 0.5, 1)' // 上に素早く消えるイージング
    });

    // ダメージを受けた時に画面を揺らす
    if (amount > 0) {
        const container = document.querySelector('.battle-container');
        if (container) {
            container.animate([
                { transform: 'translateX(0)' },
                { transform: 'translateX(-6px)' },
                { transform: 'translateX(6px)' },
                { transform: 'translateX(-6px)' },
                { transform: 'translateX(6px)' },
                { transform: 'translateX(0)' }
            ], {
                duration: 300,
                easing: 'ease-in-out'
            });
        }
    }
}

function showCorrectEffect() {
    // Web Animations API を使用
    correctEffect.animate([
        { opacity: 0, transform: 'scale(0.7)' },
        { opacity: 1, transform: 'scale(1.1)', offset: 0.3 },
        { opacity: 1, transform: 'scale(1)', offset: 0.6 },
        { opacity: 0, transform: 'scale(1.5)' }
    ], {
        duration: 1500,
        easing: 'ease-out'
    });
}

function showUltimateEffect() {
    // 画面フラッシュ
    const flash = document.createElement('div');
    flash.style.position = 'fixed';
    flash.style.top = '0';
    flash.style.left = '0';
    flash.style.width = '100%';
    flash.style.height = '100%';
    flash.style.backgroundColor = '#fff';
    flash.style.zIndex = '9998';
    flash.style.pointerEvents = 'none';
    document.body.appendChild(flash);
    flash.animate([
        { opacity: 0.9 },
        { opacity: 0 }
    ], {
        duration: 500,
        easing: 'ease-in'
    }).onfinish = () => flash.remove();

    // 必殺技エフェクト本体
    ultimateEffect.animate([
        { opacity: 0, transform: 'scale(0.5) rotate(-45deg)' },
        { opacity: 1, transform: 'scale(1.2) rotate(10deg)', offset: 0.2 },
        { opacity: 1, transform: 'scale(1) rotate(0deg)', offset: 0.4 },
        { opacity: 1, transform: 'scale(1) rotate(0deg)', offset: 0.8 },
        { opacity: 0, transform: 'scale(2) rotate(45deg)' }
    ], {
        duration: 2000,
        easing: 'ease-in-out'
    });

    // 画面揺れ（強め）
    const container = document.querySelector('.battle-container');
    if (container) {
        setTimeout(() => { // フラッシュと少しずらす
            container.animate([
                { transform: 'translateX(0) rotate(0)' },
                { transform: 'translateX(-10px) rotate(-1deg)' },
                { transform: 'translateX(10px) rotate(1deg)' },
                { transform: 'translateX(-10px) rotate(-1deg)' },
                { transform: 'translateX(10px) rotate(1deg)' },
                { transform: 'translateX(0) rotate(0)' }
            ], {
                duration: 500,
                easing: 'ease-in-out'
            });
        }, 100);
    }
}

function updateTimer() {
    if (!questionStartTime) return;
    const elapsed = Math.floor((Date.now() - questionStartTime) / 1000);
    const minutes = Math.floor(elapsed / 60);
    const seconds = elapsed % 60;
    timerDisplay.textContent = 
        String(minutes).padStart(2, "0") + ":" + String(seconds).padStart(2, "0");
}

function startTimer() {
    questionStartTime = Date.now();
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(updateTimer, 1000);
}

function startBotBattle() {
    console.log("Starting bot battle, isBossBattle:", isBossBattle);
    
    if (isBossBattle) {
        // ボス戦の場合、敵オブジェクトは既にサーバーから受け取った正しいステータスを持っています。
        // HPが設定されていない場合のみ、最大HPで初期化します。
        if (!enemy.hp) {
            enemy.hp = enemy.maxHp;
        }
        console.log("Boss battle: using pre-configured boss stats", enemy);
    } else {
        // 通常のボット戦の場合のみ、プレイヤーに合わせて難易度を計算します。
        botDifficulty = calculateBotDifficulty();
    }
    
    // ステータス更新を反映
    updateStats();
    updateHP();

    // ボット戦（ボス戦・通常戦とも）はアクティブ型ATBバトルとして進行する
    startATBBattleLoop();
}

function generateChoices(question) {
    choicesContainer.innerHTML = '';
    
    // 選択肢を生成
    let options;
    if (question.options && question.options.length === 4) {
        // サーバーから選択肢が提供されている場合
        options = question.options;
    } else {
        // クライアント側で選択肢を生成
        options = generateOptionsForQuestion(question);
    }
    
    // 選択肢ボタンを作成
    options.forEach((option, index) => {
        const button = document.createElement('button');
        button.className = 'choice-btn';
        button.textContent = option;
        button.onclick = () => handleChoiceClick(option);
        choicesContainer.appendChild(button);
    });
}

function generateOptionsForQuestion(question) {
    const options = [question.answer];
    
    // 答えが数値の場合
    if (!isNaN(question.answer)) {
        const numAnswer = parseInt(question.answer);
        const usedNumbers = new Set([numAnswer]);
        
        // よくある計算ミスを想定した誤答を生成
        const wrongAnswers = generateNumericWrongAnswers(numAnswer);
        
        for (const wrong of wrongAnswers) {
            if (!usedNumbers.has(wrong) && options.length < 4) {
                usedNumbers.add(wrong);
                options.push(String(wrong));
            }
        }
        
        // まだ足りない場合は従来の方法で追加
        // ※ 万が一候補が尽きて無限ループにならないよう、試行回数の上限と保険のフォールバックを設ける
        let numAttempts = 0;
        while (options.length < 4 && numAttempts < 50) {
            numAttempts++;
            let offset;
            if (Math.random() < 0.5) {
                offset = Math.floor(Math.random() * 5) + 1;
            } else {
                offset = -(Math.floor(Math.random() * 5) + 1);
            }
            
            const wrongAnswer = numAnswer + offset;
            if (!usedNumbers.has(wrongAnswer) && wrongAnswer >= 0) {
                usedNumbers.add(wrongAnswer);
                options.push(String(wrongAnswer));
            }
        }
        // それでも足りない場合は、確実に一意な数値を足して埋める（無限ループ防止の保険）
        let fallbackOffset = 6;
        while (options.length < 4) {
            const wrongAnswer = numAnswer + fallbackOffset;
            if (!usedNumbers.has(wrongAnswer) && wrongAnswer >= 0) {
                usedNumbers.add(wrongAnswer);
                options.push(String(wrongAnswer));
            }
            fallbackOffset++;
        }
    } else {
        // 文字列の場合は意味のある誤答を生成
        const wrongAnswers = generateStringWrongAnswers(question.answer);
        const usedAnswers = new Set([question.answer]);
        
        for (const wrong of wrongAnswers) {
            if (!usedAnswers.has(wrong) && options.length < 4) {
                usedAnswers.add(wrong);
                options.push(wrong);
            }
        }
        
        // 文学的技法の問題の場合は、類似した文字列を生成しない
        if (!isLiteraryTechniqueQuestion(question.answer)) {
            // まだ足りない場合は類似した文字列を生成
            // ※ generateSimilarString は短い文字列（特に1文字）だと毎回同じ結果を返すことがあり、
            //   無限ループでブラウザが完全にフリーズする原因になっていた。試行回数の上限を設ける。
            let attempts = 0;
            while (options.length < 4 && attempts < 30) {
                attempts++;
                const similar = generateSimilarString(question.answer);
                if (!usedAnswers.has(similar)) {
                    usedAnswers.add(similar);
                    options.push(similar);
                }
            }
            // それでも足りない場合は、記号を付加して確実に選択肢を埋める（無限ループ防止の保険）
            let fallbackSuffix = 1;
            while (options.length < 4) {
                const filler = `${question.answer}${"？".repeat(fallbackSuffix)}`;
                if (!usedAnswers.has(filler)) {
                    usedAnswers.add(filler);
                    options.push(filler);
                }
                fallbackSuffix++;
            }
        } else {
            // 文学的技法の問題で、かつ誤答候補が3つに満たない場合も保険で埋める
            let fallbackSuffix = 1;
            while (options.length < 4) {
                const filler = `${question.answer}${"？".repeat(fallbackSuffix)}`;
                if (!usedAnswers.has(filler)) {
                    usedAnswers.add(filler);
                    options.push(filler);
                }
                fallbackSuffix++;
            }
        }
    }
    
    // 選択肢をシャッフル
    return shuffleArray(options);
}

// 数値の誤答を生成（よくある計算ミスを想定）
function generateNumericWrongAnswers(correct) {
    const wrongs = [];
    
    // 符号ミス（正解が正の場合は負を、負の場合は正を追加）
    if (correct > 0) {
        wrongs.push(-correct);
    } else if (correct < 0) {
        wrongs.push(Math.abs(correct));
    }
    
    // ±1, ±2, ±5 の計算ミス
    const offsets = [1, 2, 5, -1, -2, -5];
    for (const offset of offsets) {
        const wrong = correct + offset;
        if (wrong !== correct && wrong >= 0) {
            wrongs.push(wrong);
        }
    }
    
    // 掛け算ミス（正解がxなら2xやx/2を追加）
    if (correct !== 0) {
        wrongs.push(correct * 2);
        if (correct % 2 === 0) {
            wrongs.push(correct / 2);
        }
    }
    
    // シャッフルして返す
    return shuffleArray(wrongs);
}

// 文字列の誤答を生成（意味のある誤答）
function generateStringWrongAnswers(correct) {
    const wrongs = [];
    const usedAnswers = new Set();
    usedAnswers.add(correct); // 正解を追加して重複を防ぐ
    
    // 文学的技法に関する問題の場合、技法を混ぜた誤答のみを生成（最優先）
    if (isLiteraryTechniqueQuestion(correct)) {
        const literaryWrongs = generateLiteraryTechniqueWrongAnswers(correct);
        for (const wrong of literaryWrongs) {
            if (!usedAnswers.has(wrong)) {
                usedAnswers.add(wrong);
                wrongs.push(wrong);
            }
        }
        return shuffleArray(wrongs);
    }
    
    // 文学的技法でない場合のみ、以下の処理を行う
    // ひらがなの場合、類似したひらがなを生成
    if (isHiragana(correct)) {
        const hiraganaWrongs = generateSimilarHiragana(correct);
        for (const wrong of hiraganaWrongs) {
            if (!usedAnswers.has(wrong)) {
                usedAnswers.add(wrong);
                wrongs.push(wrong);
            }
        }
    }
    // 英語の場合、類似した単語やスペルミスを生成
    else if (isEnglish(correct)) {
        const englishWrongs = generateSimilarEnglish(correct);
        for (const wrong of englishWrongs) {
            if (!usedAnswers.has(wrong)) {
                usedAnswers.add(wrong);
                wrongs.push(wrong);
            }
        }
    }
    // その他の場合、類似した文字列を生成
    else {
        const stringWrongs = generateSimilarStringArray(correct);
        for (const wrong of stringWrongs) {
            if (!usedAnswers.has(wrong)) {
                usedAnswers.add(wrong);
                wrongs.push(wrong);
            }
        }
    }
    
    return shuffleArray(wrongs);
}

// 文学的技法の問題かどうかを判定
function isLiteraryTechniqueQuestion(answer) {
    const literaryKeywords = ['倒置法', '比喩', '反復', '対句', '擬人法', '係り結び', '受動態', '使役態', '尊敬語', '謙譲語'];
    
    // 正解に技法名が含まれている場合
    if (literaryKeywords.some(keyword => answer.includes(keyword))) {
        return true;
    }
    
    // 技法の例文から技法を判定
    const exampleToTechnique = {
        '美しい、この花は': '倒置法',
        'ライオンのように強い': '比喩',
        '走った、走った、走った': '反復',
        '山と川': '対句',
        '天と地': '対句',
        '風がささやく': '擬人法',
        '～けれども、～ので': '係り結び',
        '彼に褒められた': '受動態',
        '彼を行かせた': '使役態',
        'いらっしゃる': '尊敬語',
        'おっしゃる': '尊敬語',
        '参る': '謙譲語',
        '申す': '謙譲語'
    };
    
    for (const [example, technique] of Object.entries(exampleToTechnique)) {
        if (answer.includes(example)) {
            return true;
        }
    }
    
    return false;
}

// 文学的技法の誤答を生成（技法を混ぜるのみ）
function generateLiteraryTechniqueWrongAnswers(correct) {
    const wrongs = [];
    const usedAnswers = new Set();
    usedAnswers.add(correct); // 正解を追加して重複を防ぐ
    
    // 文学的技法のマッピング
    const techniqueMap = {
        '倒置法': ['比喩のように強い', '走った、走った、走った', '山と川、天と地', '風がささやく'],
        '比喩': ['美しい、この花は', '走った、走った、走った', '山と川、天と地', '風がささやく'],
        '反復': ['美しい、この花は', 'ライオンのように強い', '山と川、天と地', '風がささやく'],
        '対句': ['美しい、この花は', 'ライオンのように強い', '走った、走った、走った', '風がささやく'],
        '擬人法': ['美しい、この花は', 'ライオンのように強い', '走った、走った、走った', '山と川、天と地'],
        '係り結び': ['美しい、この花は', 'ライオンのように強い', '走った、走った、走った', '風がささやく'],
        '受動態': ['彼を行かせた', 'いらっしゃる、おっしゃる', '参る、申す', '～けれども、～ので'],
        '使役態': ['彼に褒められた', 'いらっしゃる、おっしゃる', '参る、申す', '～けれども、～ので'],
        '尊敬語': ['彼を行かせた', '彼に褒められた', '参る、申す', '～けれども、～ので'],
        '謙譲語': ['彼を行かせた', '彼に褒められた', 'いらっしゃる、おっしゃる', '～けれども、～ので']
    };
    
    // 例文から技法を判定するマッピング
    const exampleToTechnique = {
        '美しい、この花は': '倒置法',
        'ライオンのように強い': '比喩',
        '走った、走った、走った': '反復',
        '山と川': '対句',
        '天と地': '対句',
        '風がささやく': '擬人法',
        '～けれども、～ので': '係り結び',
        '彼に褒められた': '受動態',
        '彼を行かせた': '使役態',
        'いらっしゃる': '尊敬語',
        'おっしゃる': '尊敬語',
        '参る': '謙譲語',
        '申す': '謙譲語'
    };
    
    let targetTechnique = null;
    
    // 正解に含まれる技法を特定（技法名が含まれている場合）
    for (const [technique, examples] of Object.entries(techniqueMap)) {
        if (correct.includes(technique)) {
            targetTechnique = technique;
            break;
        }
    }
    
    // 技法名が含まれていない場合、例文から技法を判定
    if (!targetTechnique) {
        for (const [example, technique] of Object.entries(exampleToTechnique)) {
            if (correct.includes(example)) {
                targetTechnique = technique;
                break;
            }
        }
    }
    
    // 技法が特定できた場合、その技法の誤答を生成
    if (targetTechnique && techniqueMap[targetTechnique]) {
        for (const example of techniqueMap[targetTechnique]) {
            if (!usedAnswers.has(example)) {
                usedAnswers.add(example);
                wrongs.push(example);
            }
        }
    }
    
    return wrongs;
}


// ひらがなかどうかを判定
function isHiragana(str) {
    return /^[\u3040-\u309F]+$/.test(str);
}

// 英語かどうかを判定
function isEnglish(str) {
    return /^[a-zA-Z\s]+$/.test(str);
}

// 類似したひらがなを生成
function generateSimilarHiragana(hiragana) {
    const similar = [];
    const hiraganaMap = {
        'あ': ['い', 'う', 'え', 'お'],
        'い': ['あ', 'う', 'え', 'お'],
        'う': ['あ', 'い', 'え', 'お'],
        'え': ['あ', 'い', 'う', 'お'],
        'お': ['あ', 'い', 'う', 'え'],
        'か': ['き', 'く', 'け', 'こ'],
        'き': ['か', 'く', 'け', 'こ'],
        'く': ['か', 'き', 'け', 'こ'],
        'け': ['か', 'き', 'く', 'こ'],
        'こ': ['か', 'き', 'く', 'け'],
        'さ': ['し', 'す', 'せ', 'そ'],
        'し': ['さ', 'す', 'せ', 'そ'],
        'す': ['さ', 'し', 'せ', 'そ'],
        'せ': ['さ', 'し', 'す', 'そ'],
        'そ': ['さ', 'し', 'す', 'せ'],
        'た': ['ち', 'つ', 'て', 'と'],
        'ち': ['た', 'つ', 'て', 'と'],
        'つ': ['た', 'ち', 'て', 'と'],
        'て': ['た', 'ち', 'つ', 'と'],
        'と': ['た', 'ち', 'つ', 'て'],
        'な': ['に', 'ぬ', 'ね', 'の'],
        'に': ['な', 'ぬ', 'ね', 'の'],
        'ぬ': ['な', 'に', 'ね', 'の'],
        'ね': ['な', 'に', 'ぬ', 'の'],
        'の': ['な', 'に', 'ぬ', 'ね'],
        'は': ['ひ', 'ふ', 'へ', 'ほ'],
        'ひ': ['は', 'ふ', 'へ', 'ほ'],
        'ふ': ['は', 'ひ', 'へ', 'ほ'],
        'へ': ['は', 'ひ', 'ふ', 'ほ'],
        'ほ': ['は', 'ひ', 'ふ', 'へ'],
        'ま': ['み', 'む', 'め', 'も'],
        'み': ['ま', 'む', 'め', 'も'],
        'む': ['ま', 'み', 'め', 'も'],
        'め': ['ま', 'み', 'む', 'も'],
        'も': ['ま', 'み', 'む', 'め'],
        'や': ['ゆ', 'よ'],
        'ゆ': ['や', 'よ'],
        'よ': ['や', 'ゆ'],
        'ら': ['り', 'る', 'れ', 'ろ'],
        'り': ['ら', 'る', 'れ', 'ろ'],
        'る': ['ら', 'り', 'れ', 'ろ'],
        'れ': ['ら', 'り', 'る', 'ろ'],
        'ろ': ['ら', 'り', 'る', 'れ'],
        'わ': ['を', 'ん'],
        'を': ['わ', 'ん'],
        'ん': ['わ', 'を']
    };
    
    for (let i = 0; i < hiragana.length; i++) {
        const char = hiragana[i];
        const similarChars = hiraganaMap[char] || [];
        for (const similarChar of similarChars) {
            if (similarChar !== char) {
                const newStr = hiragana.substring(0, i) + similarChar + hiragana.substring(i + 1);
                if (newStr !== hiragana && !similar.includes(newStr)) {
                    similar.push(newStr);
                }
            }
        }
    }
    
    return similar;
}

// 類似した英語を生成
function generateSimilarEnglish(english) {
    const similar = [];
    const lowerEnglish = english.toLowerCase();
    
    // よくある単語の関連付け
    const wordAssociations = {
        'red': ['blue', 'green', 'yellow', 'black', 'white'],
        'blue': ['red', 'green', 'yellow', 'sky', 'sea'],
        'green': ['red', 'blue', 'yellow', 'grass', 'leaf'],
        'yellow': ['red', 'blue', 'green', 'orange', 'gold'],
        'black': ['white', 'red', 'blue', 'dark', 'night'],
        'white': ['black', 'red', 'blue', 'light', 'day'],
        'dog': ['cat', 'bird', 'fish', 'animal', 'pet'],
        'cat': ['dog', 'bird', 'fish', 'animal', 'pet'],
        'bird': ['dog', 'cat', 'fish', 'fly', 'sky'],
        'fish': ['dog', 'cat', 'bird', 'swim', 'water'],
        'book': ['pen', 'paper', 'read', 'study', 'library'],
        'school': ['home', 'work', 'study', 'class', 'teacher'],
        'teacher': ['student', 'school', 'class', 'work', 'job'],
        'run': ['walk', 'jump', 'swim', 'fast', 'move'],
        'walk': ['run', 'jump', 'swim', 'slow', 'move'],
        'eat': ['drink', 'cook', 'food', 'meal', 'hungry'],
        'see': ['look', 'watch', 'hear', 'listen', 'view'],
        'hear': ['see', 'listen', 'sound', 'noise', 'speak'],
        'speak': ['hear', 'talk', 'say', 'tell', 'voice'],
        'happy': ['sad', 'glad', 'joy', 'smile', 'fun'],
        'sad': ['happy', 'glad', 'cry', 'tear', 'sorry'],
        'big': ['small', 'large', 'huge', 'tiny', 'little'],
        'small': ['big', 'large', 'tiny', 'little', 'short'],
        'hot': ['cold', 'warm', 'cool', 'fire', 'sun'],
        'cold': ['hot', 'warm', 'cool', 'ice', 'snow'],
        'good': ['bad', 'nice', 'great', 'fine', 'well'],
        'bad': ['good', 'nice', 'evil', 'wrong', 'poor'],
        'fast': ['slow', 'quick', 'rapid', 'speed', 'swift'],
        'slow': ['fast', 'quick', 'rapid', 'lazy', 'late'],
        'like': ['love', 'hate', 'enjoy', 'prefer', 'want'],
        'hate': ['like', 'love', 'dislike', 'angry', 'fear'],
        'if': ['when', 'while', 'because', 'although', 'unless'],
        'when': ['if', 'while', 'because', 'after', 'before'],
        'because': ['if', 'when', 'so', 'since', 'as'],
        'after': ['before', 'when', 'while', 'since', 'next'],
        'before': ['after', 'when', 'while', 'ago', 'previous'],
        'yes': ['no', 'maybe', 'right', 'correct', 'true'],
        'no': ['yes', 'maybe', 'wrong', 'incorrect', 'false']
    };
    
    // 関連単語を追加
    const associations = wordAssociations[lowerEnglish] || [];
    for (const assoc of associations) {
        if (assoc.toLowerCase() !== lowerEnglish && !similar.includes(assoc)) {
            similar.push(assoc);
        }
    }
    
    // スペルミスを生成（1文字変更）
    for (let i = 0; i < english.length; i++) {
        const originalChar = english[i];
        const replacementChars = 'abcdefghijklmnopqrstuvwxyz';
        for (const replacement of replacementChars) {
            if (replacement !== originalChar.toLowerCase()) {
                const misspelled = english.substring(0, i) + replacement + english.substring(i + 1);
                if (misspelled.toLowerCase() !== lowerEnglish && !similar.includes(misspelled)) {
                    similar.push(misspelled);
                    if (similar.length >= 5) break;
                }
            }
        }
        if (similar.length >= 5) break;
    }
    
    return similar;
}

// 類似した文字列配列を生成
function generateSimilarStringArray(str) {
    const similar = [];
    
    // ランダムに1文字変更
    if (str.length > 0) {
        const randomIndex = Math.floor(Math.random() * str.length);
        const replacement = String.fromCharCode(str.charCodeAt(randomIndex) + 1);
        const modified = str.substring(0, randomIndex) + replacement + str.substring(randomIndex + 1);
        if (modified !== str) {
            similar.push(modified);
        }
    }
    
    return similar;
}

// 類似した文字列を生成（単一）
function generateSimilarString(str) {
    if (str.length === 0) return '×';
    
    // ランダムに1文字変更
    const randomIndex = Math.floor(Math.random() * str.length);
    const replacement = String.fromCharCode(str.charCodeAt(randomIndex) + 1);
    return str.substring(0, randomIndex) + replacement + str.substring(randomIndex + 1);
}

function shuffleArray(array) {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
}

// ============================================
// スキルシステム（バトル中）
// ============================================

// バトルスキルの初期化
function initializeBattleSkills() {
    try {
        console.log("Initializing battle skills...");
        // プレイヤーデータからスキルツリー情報を取得
        const player = getSavedPlayer();
        if (!player) {
            console.log("Player data not found, skipping skill initialization");
            activeSkills = [];
            renderSkills();
            return;
        }
        
        console.log("Player data found:", player);
        console.log("Player skillSlots:", player.skillSlots);
        
        // スキルデータを初期化（関数が存在する場合のみ）
        if (typeof initializeSkillData === 'function') {
            const initializedPlayer = initializeSkillData(player);
            console.log("Initialized player skill data:", initializedPlayer);
            
            // アクティブスキルを取得
            if (typeof getSkillNodeEffects === 'function') {
                const skillEffects = getSkillNodeEffects(initializedPlayer);
                console.log("Skill effects:", skillEffects);
                
                // カスタムスキルも追加
                const customSkills = initializedPlayer.customSkills || [];
                console.log("Custom skills:", customSkills);
                
                // スキルスロットにあるスキルのみをアクティブスキルとして使用
                const slottedSkills = (initializedPlayer.skillSlots || []).filter(skill => skill !== null);
                console.log("Slotted skills:", slottedSkills);
                activeSkills = [];
                
                // skillEffects.activeに既にカスタムスキルが含まれているため、そのまま使用
                skillEffects.active.forEach(skill => {
                    if (slottedSkills.some(slotted => slotted.id === skill.id)) {
                        activeSkills.push(skill);
                    }
                });
                
                // 重複を削除
                activeSkills = activeSkills.filter((skill, index, self) =>
                    index === self.findIndex((s) => s.id === skill.id)
                );
                
                console.log("Final active skills:", activeSkills);
            } else {
                console.log("getSkillNodeEffects function not found");
                activeSkills = [];
            }
        } else {
            console.log("initializeSkillData function not found");
            activeSkills = [];
        }
        
        // 使用済みスキルリストを初期化
        usedSkills = [];
        
        // スキルスロットをレンダリング
        renderSkills();
    } catch (error) {
        console.error("Error initializing battle skills:", error);
        activeSkills = [];
        usedSkills = [];
        renderSkills();
    }
}

function renderSkills() {
    const container = document.getElementById('skillSlotsContainer');
    if (!container) return;
    
    container.innerHTML = '';
    
    if (activeSkills.length === 0) {
        container.innerHTML = '<p class="no-skills">アクティブスキルなし</p>';
        return;
    }
    
    activeSkills.forEach(skill => {
        const skillBtn = document.createElement('button');
        skillBtn.className = 'skill-slot';
        skillBtn.dataset.skillId = skill.id;
        
        const isUsed = usedSkills.includes(skill.id);
        const isActive = selectedSkill?.id === skill.id;
        
        skillBtn.innerHTML = `
            <span class="skill-name">${skill.name}</span>
            <span class="skill-desc">${skill.description}</span>
        `;
        
        if (isUsed) {
            skillBtn.classList.add('used');
            skillBtn.disabled = true;
        } else if (isActive) {
            skillBtn.classList.add('active');
        }
        
        skillBtn.onclick = () => activateSkill(skill);
        
        container.appendChild(skillBtn);
    });
}

// スキルのアクティブ化
function activateSkill(skill) {
    if (usedSkills.includes(skill.id)) {
        addLog('このスキルは既に使用済みです');
        return;
    }
    
    if (!skillActivationWindow) {
        addLog('スキルは問題の間の3秒間のみアクティブにできます');
        return;
    }
    
    selectedSkill = skill;
    addLog(`スキル「${skill.name}」をアクティブにしました`);
    
    // スキルボタンの状態を更新
    renderSkills();
}

// スキルボタンの有効/無効化
function enableSkillButtons(enabled) {
    const buttons = document.querySelectorAll('.skill-slot');
    buttons.forEach(btn => {
        if (!btn.classList.contains('used')) {
            btn.disabled = !enabled;
        }
    });
}

// スキルアクティベーションウィンドウの開始
function startSkillActivationWindow() {
    try {
        skillActivationWindow = true;
        enableSkillButtons(true);

        // 実戦形式チュートリアル：スキルボタンが実際にある場合のみ、使い方を教える
        if (isPracticeTutorial && !practiceCoachShown.skill && window.PracticeCoach) {
            const skillContainer = document.getElementById('skillSlotsContainer');
            if (skillContainer && skillContainer.querySelector('.skill-slot')) {
                practiceCoachShown.skill = true;
                window.PracticeCoach.point(
                    skillContainer,
                    "問題が出てから数秒間だけ、ここのスキルボタンが使えるよ。\n効果を見て、使いたいタイミングで押してみよう。",
                    { buttonLabel: 'わかった' }
                );
            }
        }
        
        // 3秒後にウィンドウを閉じる
        if (skillActivationTimer) {
            clearTimeout(skillActivationTimer);
        }
        
        skillActivationTimer = setTimeout(() => {
            skillActivationWindow = false;
            enableSkillButtons(false);
            
            // アクティブなスキルがあればログに表示
            if (selectedSkill) {
                addLog(`スキル「${selectedSkill.name}」が発動準備完了`);
            }
        }, 3000);
    } catch (error) {
        console.error("Error in skill activation window:", error);
        skillActivationWindow = false;
        enableSkillButtons(false);
    }
}

// スキル効果の適用
// 「不死身」スキルによる復活処理。HPが0以下になった時に呼び出し、
// 復活権を持っていれば消費してHPをrevivePercent分回復させtrueを返す。
// 持っていなければ何もせずfalseを返す（＝通常通り敗北処理を続ける）。
function tryReviveMe() {
    // Tier5固有能力「不死鳥の加護」：1回の戦闘中に1度だけ、HPが0になってもHP50%で復活する。
    // スキル「不死身」の復活権とは別枠なので、先にこちらを消費する（両方持っていれば2回耐えられる）。
    if (me && me.hp <= 0 && !myPhoenixUsed && hasUniqueAbility(me, 'phoenix_blessing')) {
        myPhoenixUsed = true;
        me.hp = Math.max(1, Math.floor(me.maxHp * 0.5));
        addLog(`不死鳥の加護が発動！HP${me.hp}で復活した！`);
        updateHP();
        return true;
    }
    if (myReviveAvailable && me && me.hp <= 0) {
        myReviveAvailable = false;
        me.hp = Math.max(1, Math.floor(me.maxHp * (myRevivePercent || 0.5)));
        addLog(`スキル効果: 「不死身」発動！HP${me.hp}で復活した！`);
        updateHP();
        return true;
    }
    return false;
}

function applySkillEffect(damage, attacker, defender, skill) {
    if (!skill || !skill.effect) return damage;
    
    let modifiedDamage = damage;
    const effect = skill.effect;
    
    // ダメージ倍率
    if (effect.damageMultiplier && effect.damageMultiplier !== 1) {
        modifiedDamage = Math.floor(modifiedDamage * effect.damageMultiplier);
        addLog(`スキル効果: ダメージ${effect.damageMultiplier}倍！`);
    }
    
    // 防御貫通/防御無視（実際の防御無視自体は攻撃処理側でskillEffect.ignoreDef/pierceDef/defenseIgnoreを見て行う。ここはログのみ）
    if (effect.pierceDef || effect.ignoreDef || effect.defenseIgnore) {
        addLog(`スキル効果: 防御を無視！`);
    }
    
    // ライフスティール
    if (effect.lifeSteal) {
        const healAmount = Math.floor(modifiedDamage * effect.lifeSteal);
        attacker.hp = Math.min(attacker.hp + healAmount, attacker.maxHp);
        addLog(`スキル効果: ${healAmount}回復！`);
        updateHP();
    }
    
    // 回復（固定値）
    if (effect.heal) {
        const healAmount = effect.heal;
        attacker.hp = Math.min(attacker.hp + healAmount, attacker.maxHp);
        addLog(`スキル効果: ${healAmount}回復！`);
        updateHP();
    }
    
    // 回復（割合）
    if (effect.healPercent) {
        const healAmount = Math.floor(attacker.maxHp * effect.healPercent);
        attacker.hp = Math.min(attacker.hp + healAmount, attacker.maxHp);
        addLog(`スキル効果: ${healAmount}回復！`);
        updateHP();
    }
    
    // シールド
    if (effect.shield) {
        const shieldAmount = effect.shield;
        if (attacker === me) {
            myShield = (myShield || 0) + shieldAmount;
            addLog(`スキル効果: シールド${shieldAmount}獲得！`);
        }
    }
    
    // 必中
    if (effect.sureHit) {
        addLog(`スキル効果: 攻撃が必中！`);
    }
    
    // クリティカル確定
    if (effect.nextAttackCrit) {
        addLog(`スキル効果: 次の攻撃が必ずクリティカル！`);
    }
    
    // クリティカル率アップ
    if (effect.critChance) {
        addLog(`スキル効果: クリティカル率${effect.critChance * 100}%アップ！`);
    }
    
    // 火傷付与（burnChanceが指定されている場合は確率判定、なければ確定付与）
    if (effect.burn) {
        if (defender === enemy) {
            const burnRoll = (effect.burnChance !== undefined) ? Math.random() < effect.burnChance : true;
            if (burnRoll) {
                enemyBurnTurns = effect.burnTurns || 3;
                addLog(`スキル効果: 敵に火傷付与！`);
            }
        }
    }
    
    // 毒付与（poisonChanceが指定されている場合は確率判定、なければ確定付与）
    if (effect.poison) {
        if (defender === enemy) {
            const poisonRoll = (effect.poisonChance !== undefined) ? Math.random() < effect.poisonChance : true;
            if (poisonRoll) {
                enemyPoisonTurns = effect.poisonTurns || 3;
                addLog(`スキル効果: 敵に毒付与！`);
            }
        }
    }
    
    // 「不動の心」（debuff_resist）：相手（enemy）がこの能力を持っている場合、
    // 以下のステータスデバフを50%の確率で無効化する（1回のスキル使用につき1回だけ判定）
    const enemyResistsDebuff = (defender === enemy) && hasUniqueAbility(enemy, 'debuff_resist') && Math.random() < 0.5;
    if (enemyResistsDebuff) {
        addLog(`${enemy.name}は不動の心でデバフを無効化した！`);
    }

    // 速度低下
    if (effect.speedDebuff && !enemyResistsDebuff) {
        if (defender === enemy) {
            enemySpeedDebuff = effect.speedDebuff;
            enemySpeedDebuffTurns = effect.speedDebuffTurns || effect.turns || 2;
            addLog(`スキル効果: 敵の速度${effect.speedDebuff * 100}%低下！`);
        }
    }

    // 自身の速度上昇
    if (effect.speedBuff) {
        if (attacker === me) {
            mySpeedBuff = effect.speedBuff;
            mySpeedBuffTurns = effect.turns || 2;
            addLog(`スキル効果: 自身の速度${effect.speedBuff * 100}%上昇！`);
        }
    }

    // 敵の攻撃力低下
    if (effect.enemyAtkDebuff && !enemyResistsDebuff) {
        if (defender === enemy) {
            enemyAtkDebuff = effect.enemyAtkDebuff;
            enemyAtkDebuffTurns = 2;
            addLog(`スキル効果: 敵の攻撃力${effect.enemyAtkDebuff * 100}%低下！`);
        }
    }

    // 敵の防御力低下
    if (effect.enemyDefDebuff && !enemyResistsDebuff) {
        if (defender === enemy) {
            enemyDefDebuff = effect.enemyDefDebuff;
            enemyDefDebuffTurns = 2;
            addLog(`スキル効果: 敵の防御力${effect.enemyDefDebuff * 100}%低下！`);
        }
    }

    // 敵の命中率低下
    if (effect.enemyAccuracyDebuff && !enemyResistsDebuff) {
        if (defender === enemy) {
            enemyAccuracyDebuff = effect.enemyAccuracyDebuff;
            enemyAccuracyDebuffTurns = 2;
            addLog(`スキル効果: 敵の命中率${effect.enemyAccuracyDebuff * 100}%低下！`);
        }
    }

    // 回避率アップ
    if (effect.dodgeChance || effect.evasionChance || effect.evasionBoost) {
        const dodgeValue = effect.dodgeChance || effect.evasionChance || effect.evasionBoost;
        if (attacker === me) {
            myDodgeChance = dodgeValue;
            myDodgeTurns = 2;
            addLog(`スキル効果: 回避率${dodgeValue * 100}%アップ！`);
        }
    }
    
    // 反撃
    if (effect.counter) {
        if (attacker === me) {
            myCounterActive = true;
            myCounterTurns = 2;
            addLog(`スキル効果: 反撃発動準備！`);
        }
    }
    
    // 複数回攻撃（multiHit / multiStrike どちらのキー名にも対応）
    if (effect.multiHit || effect.multiStrike) {
        if (attacker === me) {
            myMultiHit = effect.multiHit || effect.multiStrike;
            myMultiHitTurns = 1;
            myMultiHitMultiplier = (effect.multiStrikeMultiplier !== undefined) ? effect.multiStrikeMultiplier : 0.6;
            addLog(`スキル効果: ${myMultiHit}連撃！`);
        }
    }
    
    // 自身の防御デバフ
    if (effect.selfDefDebuff) {
        if (attacker === me) {
            myDefDebuff = effect.selfDefDebuff;
            myDefDebuffTurns = 2;
            addLog(`スキル効果: 自身の防御${effect.selfDefDebuff}低下！`);
        }
    }
    
    // ダメージ軽減（次の攻撃に対して）
    if (effect.damageReduction) {
        if (attacker === me) {
            myPendingDamageReduction = Math.max(myPendingDamageReduction, effect.damageReduction);
            addLog(`スキル効果: 次のダメージ${effect.damageReduction * 100}%軽減！`);
        }
    }

    // 無敵（次の攻撃を完全無効化）
    if (effect.invincible) {
        if (attacker === me) {
            myPendingDamageReduction = 1;
            addLog(`スキル効果: 次の攻撃を完全に無効化！`);
        }
    }

    // 行動不能（このターン攻撃できない代わりに防御・回避系の効果を得る）
    if (effect.skipNextTurn) {
        if (attacker === me) {
            mySkipThisTurn = true;
        }
    }

    // 自身HPを消費する
    if (effect.selfHpCost) {
        if (attacker === me) {
            const cost = Math.floor(attacker.maxHp * effect.selfHpCost);
            attacker.hp = Math.max(1, attacker.hp - cost);
            addLog(`スキル効果: 自身のHPを${cost}消費！`);
            updateHP();
        }
    }

    // 使用済みスキルを1つリセットして再使用可能にする
    if (effect.resetUsedSkill) {
        if (attacker === me && usedSkills.length > 0) {
            const resetCount = Math.min(effect.resetUsedSkill, usedSkills.length);
            usedSkills.splice(0, resetCount);
            addLog(`スキル効果: 使用済みスキルが${resetCount}個リセットされた！`);
            if (typeof renderSkills === 'function') renderSkills();
        }
    }

    // 戦闘不能時に一度だけ復活する
    if (effect.revive) {
        if (attacker === me) {
            myReviveAvailable = true;
            myRevivePercent = effect.revivePercent || 0.5;
            addLog(`スキル効果: 戦闘不能時に一度だけ復活できるようになった！`);
        }
    }
    
    // 回避率無視
    if (effect.ignoreEvasion) {
        addLog(`スキル効果: 回避率無視！`);
    }
    
    // カウンターアタック（古い互換性）
    if (effect.counterAttack) {
        addLog(`スキル効果: カウンターアタック準備！`);
    }
    
    // バーサーク（HPが低い時に強化）
    if (effect.berserk) {
        if (typeof effect.berserk === 'number') {
            const hpRatio = attacker.hp / attacker.maxHp;
            if (hpRatio <= 0.5) {
                modifiedDamage = Math.floor(modifiedDamage * effect.berserk);
                addLog(`スキル効果: バーサーク発動！ダメージ${effect.berserk}倍！`);
            }
        }
    }
    
    // エクスキュート（即死効果 / ダメージ増加効果）
    if (effect.execute === true && effect.executeThreshold) {
        const hpRatio = defender.hp / defender.maxHp;
        if (hpRatio <= effect.executeThreshold) {
            addLog(`スキル効果: オーバーキル発動！`);
            modifiedDamage = 9999999999; // 事実上の即死ダメージ
        }
    } else if (typeof effect.execute === 'number') { // エクスキュート（ダメージ増加効果）
        const hpRatio = defender.hp / defender.maxHp;
        if (hpRatio <= 0.3) { // 既存のカスタムスキル用のロジックは維持
            modifiedDamage = Math.floor(modifiedDamage * effect.execute);
            addLog(`スキル効果: エクスキュート発動！ダメージ${effect.execute}倍！`);
        }
    }
    
    // 即死確率
    if (effect.instantDeathChance) {
        if (Math.random() < effect.instantDeathChance) {
            defender.hp = 0;
            addLog(`スキル効果: 即死！`);
            updateHP();
            console.log("Skill effect applied, modified damage:", modifiedDamage);
            return modifiedDamage;
        }
    }
    
    // カース（相手ステータス低下）
    if (effect.curse && !enemyResistsDebuff) {
        defender.atk = Math.floor(defender.atk * (1 - effect.curse));
        defender.def = Math.floor(defender.def * (1 - effect.curse));
        defender.speed = Math.floor(defender.speed * (1 - effect.curse));
        addLog(`スキル効果: 相手のステータス${effect.curse * 100}%低下！`);
        updateStats();
    }
    
    console.log("Skill effect applied, modified damage:", modifiedDamage);
    return modifiedDamage;
}

// ボススキル効果の適用（プレイヤーが使用する場合も含む）
function applyBossSkillEffect(damage, attacker, defender, skill) {
    if (!skill || !skill.effect) return damage;

    let modifiedDamage = damage;
    const effect = skill.effect;

    const isPlayerUsing = attacker === me;
    addLog(`${isPlayerUsing ? 'プレイヤー' : 'ボス'}がスキル「${skill.name}」を使用！`);

    // ダメージ倍率
    if (effect.damageMultiplier) {
        modifiedDamage = Math.floor(modifiedDamage * effect.damageMultiplier);
        addLog(`スキル効果: ダメージが${effect.damageMultiplier}倍になった！`);
    }

    // ライフスティール
    if (effect.lifeSteal) {
        const healAmount = Math.floor(modifiedDamage * effect.lifeSteal);
        attacker.hp = Math.min(attacker.maxHp, attacker.hp + healAmount);
        addLog(`スキル効果: ${attacker.name}がHPを${healAmount}吸収した！`);
        if (isPlayerUsing) updateHP();
    }

    // 防御無視
    if (effect.ignoreDef) {
        addLog(`スキル効果: 防御を無視！`);
    }

    // 必中
    if (effect.sureHit) {
        addLog(`スキル効果: 攻撃が必中！`);
    }

    // 次の攻撃クリティカル確定
    if (effect.nextAttackCrit) {
        addLog(`スキル効果: 次の攻撃が必ずクリティカル！`);
    }

    // 防御貫通（一部無視）：無視した割合ぶんダメージを上乗せして近似する
    if (effect.pierceDef) {
        modifiedDamage = Math.floor(modifiedDamage * (1 + effect.pierceDef));
        addLog(`スキル効果: 防御貫通！ダメージが上昇した！`);
    }

    // 多段攻撃（ボスが使用する場合）
    if (effect.multiHit && effect.multiHit > 1) {
        const perHitRate = 0.6;
        modifiedDamage = Math.max(1, Math.floor(modifiedDamage * perHitRate)) * effect.multiHit;
        addLog(`スキル効果: ${effect.multiHit}連撃！`);
    }

    // 自己バフ（攻撃力・素早さなどを自身に付与）
    if (effect.selfBuff) {
        const buffAmount = effect.selfBuff.amount || 1.2;
        switch (effect.selfBuff.type) {
            case 'atk':
                attacker.atk = Math.floor(attacker.atk * buffAmount);
                addLog(`スキル効果: ${attacker.name}の攻撃力が上昇した！`);
                break;
            case 'speed':
                attacker.speed = Math.floor(attacker.speed * buffAmount);
                addLog(`スキル効果: ${attacker.name}の素早さが上昇した！`);
                break;
            case 'all_stats':
                attacker.atk = Math.floor(attacker.atk * buffAmount);
                attacker.def = Math.floor(attacker.def * buffAmount);
                attacker.speed = Math.floor(attacker.speed * buffAmount);
                addLog(`スキル効果: ${attacker.name}の能力が全体的に上昇した！`);
                break;
        }
    }

    // 全体強化（味方全体だが、パーティのいないソロ戦では自身に適用する）
    if (effect.partyBuff) {
        const buffAmount = effect.partyBuff.amount || 1.2;
        if (effect.partyBuff.type === 'all_stats') {
            attacker.atk = Math.floor(attacker.atk * buffAmount);
            attacker.def = Math.floor(attacker.def * buffAmount);
            attacker.speed = Math.floor(attacker.speed * buffAmount);
            addLog(`スキル効果: ${attacker.name}の能力が飛躍的に上昇した！`);
        }
    }

    // ダメージ軽減バリア（ボスが自身にかける場合、次に受けるプレイヤーの攻撃を軽減）
    if (!isPlayerUsing && effect.damageReduction) {
        enemyNextDamageShield = effect.damageReduction;
        addLog(`スキル効果: ${attacker.name}が身を守る態勢に入った！`);
    }

    // 回避率上昇（一時的にダメージ軽減バリアとして近似する）
    if (!isPlayerUsing && effect.evasionBoost) {
        enemyNextDamageShield = Math.max(enemyNextDamageShield, effect.evasionBoost);
        addLog(`スキル効果: ${attacker.name}が次の攻撃を回避しようとしている！`);
    }

    // 継続ダメージ（毒・火傷）をプレイヤーに付与（ボスが使用する場合）
    if (!isPlayerUsing && effect.poison) {
        myPoisonTurns = effect.poison.turns || 3;
        addLog(`スキル効果: ${me.name}は毒状態になった！`);
    }
    if (!isPlayerUsing && effect.burn) {
        myBurnTurns = effect.burn.turns || 3;
        addLog(`スキル効果: ${me.name}は火傷状態になった！`);
    }

    // プレイヤーへのデバフ（ボスが使用する場合）
    if (!isPlayerUsing && effect.debuff) {
        switch (effect.debuff.type) {
            case 'atk':
                me.atk = Math.floor(me.atk * (1 - effect.debuff.reduction));
                addLog(`スキル効果: ${me.name}の攻撃力が低下！`);
                break;
            case 'def':
                me.def = Math.floor(me.def * (1 - effect.debuff.reduction));
                addLog(`スキル効果: ${me.name}の防御力が低下！`);
                break;
            case 'speed':
                me.speed = Math.floor(me.speed * (1 - effect.debuff.reduction));
                addLog(`スキル効果: ${me.name}の速度が低下！`);
                break;
        }
    }

    // 敵へのデバフ（プレイヤーが使用する場合）
    if (isPlayerUsing && effect.enemyDebuff) {
        switch (effect.enemyDebuff.type) {
            case 'atk':
                enemyAtkDebuff = effect.enemyDebuff.reduction;
                enemyAtkDebuffTurns = effect.enemyDebuff.turns || 2;
                addLog(`スキル効果: 敵の攻撃力が${effect.enemyDebuff.reduction * 100}%低下！`);
                break;
            case 'def':
                enemyDefDebuff = effect.enemyDebuff.reduction;
                enemyDefDebuffTurns = effect.enemyDebuff.turns || 2;
                addLog(`スキル効果: 敵の防御力が${effect.enemyDebuff.reduction * 100}%低下！`);
                break;
            case 'speed':
                enemySpeedDebuff = effect.enemyDebuff.reduction;
                enemySpeedDebuffTurns = effect.enemyDebuff.turns || 2;
                addLog(`スキル効果: 敵の速度が${effect.enemyDebuff.reduction * 100}%低下！`);
                break;
        }
    }

    return modifiedDamage;
}

/**
 * プレイヤーが受けるダメージに、直前のスキルで得た「次のダメージ軽減」効果を適用する。
 * 使用すると1回限りで消費される。
 * @param {number} damage
 * @returns {number}
 */
function applyIncomingDamageReduction(damage) {
    if (myPendingDamageReduction > 0) {
        const reduced = Math.max(0, Math.floor(damage * (1 - myPendingDamageReduction)));
        addLog(`シールド効果でダメージを${Math.round(myPendingDamageReduction * 100)}%軽減！`);
        myPendingDamageReduction = 0; // 使い切り
        return reduced;
    }
    return damage;
}

// スキル使用後の処理
function afterSkillUse(skill) {
    if (skill && skill.id) {
        usedSkills.push(skill.id);
        selectedSkill = null;
        renderSkills();
    }
}

/**
 * 選択されたスキルを取得し、使用済みとしてマークする準備をします。
 * @returns {object|null} 選択されたスキルオブジェクト、または何も選択されていない場合はnull。
 */
function consumeSelectedSkill() {
    const skillToUse = selectedSkill;
    selectedSkill = null; // 次のターンのために選択をリセット
    // 実際の「使用済み」マーキングは、ターン解決後に行われる afterSkillUse で処理されます。
    return skillToUse;
}

/**
 * スキルの即時効果を適用します（プレースホルダー）。
 * @param {object} skillEffect - スキルの効果オブジェクト。
 */
function applyInstantSkillEffects(skillEffect) {
    // この関数は参照エラーを解決するためのプレースホルダーです。
    // 将来的に、攻撃計算の前に適用されるべき効果（自己ヒール、シールドなど）をここに実装できます。
}

function handleChoiceClick(selectedOption) {
    // Clear boss auto-answer timer if active
    if (bossAutoAnswerTimer) {
        clearTimeout(bossAutoAnswerTimer);
        bossAutoAnswerTimer = null;
    }
    
    // ボタンを無効化
    const buttons = choicesContainer.querySelectorAll('.choice-btn');
    buttons.forEach(btn => btn.disabled = true);
    enableSkillButtons(false); // スキルボタンを無効化
    
    if (isBotBattle) {
        // ボット戦（ボス戦・通常戦とも）はATB方式で処理する
        handleATBAnswer(selectedOption);
    } else {
        // サーバーに回答を送信（コマンドは送らない）
        const usedSkill = typeof consumeSelectedSkill === 'function' ? consumeSelectedSkill() : null;
        socket.emit("battle:submitAnswer", {
            answer: selectedOption,
            skillId: usedSkill ? usedSkill.id : null
        });
        if (usedSkill) {
            afterSkillUse(usedSkill);
        }
        selectedCommand = 'attack'; // 次のターンのためにリセット
        // オンライン戦では回答送信後、正解かどうかの結果を待ってからコマンド選択UIを表示
        questionDisplay.textContent = "回答送信済み。結果を待っています...";
        choicesContainer.innerHTML = '';
    }
}

function calculateBotDifficulty() {
    // 以前はここでenemyのステータス（atk/def/speed/maxHp）を、
    // プレイヤーの合計ステータスと必ず同じになるようランダムに再割り当てしていた。
    // そのため、online.js側でモンスターごとに設定した「ステータス倍率」
    // （statMultiplier、0.35倍の弱いモンスターから2.2倍以上の強いモンスターまで）が
    // 常に上書きされて無効になり、「ステータス倍率が正しく反映されない」不具合の原因になっていた。
    // ボットの実際のステータスは既にonline.js側でstatMultiplierを使って正しく計算済みのため、
    // ここではステータスを一切変更せず、正解率のみを返す。
    const botAccuracy = 0.85;

    return {
        accuracy: botAccuracy
    };
}

/**
 * 制限時間内にプレイヤーが回答できなかった場合、ボスが自動的に正解し、
 * プレイヤーを攻撃する処理。
 * ・「プレイヤーが正解した」ことにしてしまわないよう、handleChoiceClick() /
 *   handleBotAnswer() は使わず、直接ボスの攻撃処理を行う。
 * ・ボス戦の場合、通常の不正解時と同様に一定確率でボスのアクティブスキルを使用する。
 */
function performBossTimeoutAttack() {
    if (battleEnd || !currentQuestion) return;

    console.log('[Boss Auto-Answer] Player timed out. Boss answers correctly and attacks.');
    addLog(`時間切れ！ ${enemy.name} が正解した！（正解: ${currentQuestion.answer}）`);

    // 選択肢を無効化（プレイヤーはもう回答できない）
    const buttons = choicesContainer.querySelectorAll('.choice-btn');
    buttons.forEach(btn => btn.disabled = true);
    if (typeof enableSkillButtons === 'function') enableSkillButtons(false);

    // ボスの攻撃処理
    let myDef = Math.max(0, (me.def || 0) - myDefDebuff);
    let botAtk = enemy.atk;

    // ボスのアクティブスキル使用（一定確率）
    let bossUsedSkill = null;
    if (isBossBattle && enemy.skills && enemy.skills.length > 0) {
        if (Math.random() < 0.5) { // 50%の確率でスキル使用
            bossUsedSkill = enemy.skills[Math.floor(Math.random() * enemy.skills.length)];
        }
    }

    const defReduction = Math.floor(myDef * 0.1);
    let damage = Math.max(1, Math.floor(botAtk * 0.5) - defReduction);

    if (bossUsedSkill) {
        damage = applyBossSkillEffect(damage, enemy, me, bossUsedSkill);
    }

    // 鉄壁適用
    if (hasUniqueAbility(me, 'damage_cut_half')) {
        damage = Math.floor(damage * 0.5);
        addLog("鉄壁発動！ダメージ50%カット");
    }

    // ダメージ軽減と回避判定は省略（ボスの攻撃は必中とするなど、ゲームデザインによる）
    me.hp = Math.max(0, me.hp - damage);
    showDamage("myDamage", damage);
    addLog(`${enemy.name}から ${damage} のダメージ！`);

    updateHP();

    if (me.hp <= 0 && !tryReviveMe()) {
        finishBotBattle("lose");
    } else if (me.hp > 0) {
        setTimeout(generateBotQuestion, 1000);
    }
}

// ==== ここからATB（アクティブ型）バトルシステム本体 ====

/**
 * 敵（ボス）側の素早さから「1tickあたりのゲージ増加量」を求める（ボス側は今まで通りリアルタイム進行）。
 * ボスの素早さ（1万〜4万程度）とプレイヤーの素早さ（数十〜数百程度）は
 * 桁が大きく違うため、単純な比率をそのまま使うと片方がほぼ止まって
 * 見えるほどの差になってしまう。そのため比率をsqrtで圧縮したうえで、
 * 有利/不利が一定の範囲（0.5倍〜2.0倍）を超えないようクランプする。
 */
function getATBGainPerTick(selfSpeed, opponentSpeed) {
    const s = Math.max(1, selfSpeed || 1);
    const o = Math.max(1, opponentSpeed || 1);
    const rawRatio = Math.sqrt(s / o);
    const speedFactor = Math.min(2.0, Math.max(0.5, rawRatio));
    const ticksToFill = ATB_BASE_FILL_MS / ATB_TICK_MS;
    return (ATB_MAX / ticksToFill) * speedFactor;
}

/**
 * 自分の行動ゲージを満タンにするために必要な「正解数」を素早さから求める。
 * 素早さ50を基準に7回。素早さが上がるほど必要回数は減っていくが、
 * 「とてもとても上がりにくい（以前よりさらに約100倍上がりにくい）」という指定の通り、
 * 効果をかなり強く圧縮してある。以前は素早さが基準の約280倍（≒14000）で
 * 必要回数が下限の3回に達していたが、今は基準の約28000倍（≒140万）まで
 * 積まないと下限に届かない。
 * どれだけ素早さを積んでも必要回数は3回より少なくはならない（下限）。
 */
function getRequiredCorrectCount(speed) {
    const baseSpeed = 50;
    const baseCount = 7;
    const minCount = 3;
    const s = Math.max(1, speed || 1);
    // 指数を非常に小さくすることで、素早さの効果を極めて強く圧縮している
    const ratio = Math.pow(s / baseSpeed, 0.08);
    const count = baseCount / ratio;
    return Math.max(minCount, Math.min(baseCount, Math.round(count)));
}

function updateATBBars() {
    const myBar = document.getElementById('myAtbBar');
    const enemyBar = document.getElementById('enemyAtbBar');
    if (myBar) myBar.style.width = Math.min(100, Math.max(0, playerATB)) + '%';
    if (enemyBar) enemyBar.style.width = Math.min(100, Math.max(0, enemyATB)) + '%';
}

/**
 * ボス戦のATBループを開始する。
 * ・ボス側は今まで通り、素早さに応じてリアルタイムにゲージが進行する。
 * ・プレイヤー側は「正解した数」でゲージが進行する方式に変更。問題と問題の間の
 *   待ち時間は0で、正解するたびに小さな追撃ダメージ（自分の攻撃力の0.5倍）を
 *   与えつつゲージが進み、ゲージが満タンになったらコマンド（攻撃/特殊/防御/必殺技）
 *   を選べるようになる。
 */
function startATBBattleLoop() {
    playerATB = 0;
    enemyATB = 0;
    atbPlayerActionPending = false;
    atbBossTelegraphActive = false;
    atbGuardWindowOpen = false;
    atbGuardActivated = false;
    playerCorrectCount = 0;
    playerRequiredCount = getRequiredCorrectCount(me.speed);
    if (atbInterval) clearInterval(atbInterval);
    updateATBBars();
    addLog(`バトル開始！正解を重ねて行動ゲージを溜めよう！（必要な正解数: ${playerRequiredCount}回 / すばやさ ${me.name}:${me.speed || 0} vs ${enemy.name}:${enemy.speed || 0}）`);

    // 最初の1問だけ、これまでと同じ「3, 2, 1, GO!!」のカウントダウンを見せてから始める
    // （2問目以降は待ち時間なしで即座に出題される。ボス側のゲージ進行も
    // カウントダウン終了と同じタイミングで開始するので、待っている間にボスだけ
    // 先に有利になることもない）
    showCountdown(() => {
        if (battleEnd) return;

        // ボス側のゲージのみ、今まで通りリアルタイムで進行させる
        atbInterval = setInterval(() => {
            if (battleEnd) {
                clearInterval(atbInterval);
                atbInterval = null;
                return;
            }

            try {
                // 模擬戦闘では敵は攻撃してこない（ダメージを受けない）ので、敵の行動ゲージは進めない
                if (!atbBossTelegraphActive && !isMockBattle) {
                    // 敵の速度低下デバフ（enemySpeedDebuff）をゲージ進行速度に反映する
                    const effectiveEnemySpeed = Math.max(1, Math.floor((enemy.speed || 0) * (1 - enemySpeedDebuff)));
                    enemyATB += getATBGainPerTick(effectiveEnemySpeed, me.speed);
                    if (enemyATB >= ATB_MAX) {
                        enemyATB = ATB_MAX;
                        triggerBossTelegraph();
                    }
                }
                updateATBBars();
                // 毒・火傷等の継続効果は、以前は実時間3秒ごとに進行させていたが、
                // 依頼により「1ターン＝1回正解する」ことと定義し直したため、
                // ここ（実時間ベースのループ）では進行させない。
                // 実際の進行はhandleATBAnswer()の正解時にtickBotBattleStatus()を
                // 1回呼ぶ形で行う。
            } catch (error) {
                // 1tick分の処理が失敗しても、そのままバトル全体が止まってしまわないようにする
                console.error('[ATB] ループ処理でエラーが発生しました。', error);
            }
        }, ATB_TICK_MS);

        // プレイヤー側の最初の問題を出題する（2問目以降は待ち時間なし）
        askNextPlayerQuestion();
    });
}

/**
 * プレイヤーに次の問題を即座に出題する（問題と問題の間の待ち時間は0）。
 */
// 模擬戦闘で間違えた（または時間切れになった）とき、正解の選択肢を緑色に光らせて、
// 少し待ってから次の問題に進む（単語帳として、正解を確認する時間をとるため）。
const MOCK_WRONG_ANSWER_WAIT_MS = 2000;

function revealCorrectChoiceAndContinue(correctAnswer) {
    const target = String(correctAnswer == null ? '' : correctAnswer).trim();
    choicesContainer.querySelectorAll('.choice-btn').forEach(btn => {
        if (btn.textContent.trim() === target) btn.classList.add('correct-reveal');
    });
    addLog(`正解は「${target}」`);
    atbPlayerActionPending = true; // 待っている間に、次の問題が二重に出題されないようにする
    setTimeout(() => {
        if (battleEnd) return;
        atbPlayerActionPending = false;
        askNextPlayerQuestion();
    }, MOCK_WRONG_ANSWER_WAIT_MS);
}

function askNextPlayerQuestion() {
    if (battleEnd) return;
    atbPlayerActionPending = true; // 出題中〜回答確定までは二重出題を防ぐ

    try {
        let currentQuestionData = null;

        // 模擬戦闘の場合は、プレイヤーが自作した問題リストから出題する
        // （デフォルトの学年別問題・ボス専用問題は一切使用しない）
        if (isMockBattle && typeof getMockBattleQuestion === "function") {
            currentQuestionData = getMockBattleQuestion();
        }

        if (currentQuestionData) {
            currentQuestion = { ...currentQuestionData, id: Date.now() };
        } else {
            // 1つの教科のデータが（何らかの理由で）空でも出題自体が止まらないよう、
            // 教科をシャッフルして順番に確認する。
            // ボス戦はボス専用の問題（boss_questions.js）、通常のボット戦・オンライン対戦は
            // 通常の問題（questions.js、学年に応じた教科・レベル）を使用する。
            const subjectPool = isBossBattle ? ['math', 'jp', 'eng', 'sci', 'soc'] : ['math', 'jp', 'eng'];
            const shuffledSubjects = shuffleArray(subjectPool);
            let bossSubject = null;
            let bossQuestions = null;
            for (const subject of shuffledSubjects) {
                const qs = isBossBattle ? getLocalBossQuestions(subject) : getLocalRegularQuestions(subject);
                if (qs && qs.length > 0) {
                    bossSubject = subject;
                    bossQuestions = qs;
                    break;
                }
            }

            let randomQuestion;
            if (bossQuestions && bossQuestions.length > 0) {
                randomQuestion = bossQuestions[Math.floor(Math.random() * bossQuestions.length)];
            } else {
                // 保険：問題データが一切見つからない場合でも「出題が止まったまま」に
                // ならないよう、簡単な問題にフォールバックする
                // （本来は起きないはず。起きた場合は boss_questions.js / questions.js が読み込めているか要確認）
                console.error('[ATB] 問題データが見つかりません。boss_questions.js / questions.js の読み込みを確認してください。フォールバック問題を使用します。');
                bossSubject = 'math';
                randomQuestion = { question: '3 + 4 = ?', answer: '7' };
            }

            currentQuestion = { ...randomQuestion, id: Date.now(), subject: bossSubject, subjectDisplayName: getSubjectDisplayName(bossSubject) };
        }

        // 毒・火傷等の継続効果は、ここ（出題ごと）ではなくstartATBBattleLoop内のatbIntervalで
        // 実時間3秒ごとに処理する（「ターン」という概念がATB化で無くなったため）。
        if (battleEnd) return;
        if (enemy.hp <= 0) { finishBotBattle("win"); return; }

        startSkillActivationWindow();

        questionDisplay.textContent = currentQuestion.question;
        generateChoices(currentQuestion);
        startTimer();
        addLog(`問題！（行動ゲージ ${playerCorrectCount}/${playerRequiredCount}）` + (currentQuestion.subjectDisplayName ? "（" + currentQuestion.subjectDisplayName + "）" : ""));

        if (bossAutoAnswerTimer) clearTimeout(bossAutoAnswerTimer);
        bossAutoAnswerTimer = setTimeout(() => {
            // 制限時間内に答えられなければこの問題はスキップ（ペナルティなし）し、
            // 待ち時間なしで次の問題へ進む
            if (battleEnd || !atbPlayerActionPending) return;
            addLog("時間切れ！");
            const buttons = choicesContainer.querySelectorAll('.choice-btn');
            buttons.forEach(btn => btn.disabled = true);
            enableSkillButtons(false);
            const timedOutAnswer = currentQuestion ? currentQuestion.answer : null;
            currentQuestion = null;
            // 模擬戦闘では、時間切れも「間違い」と同じく正解を見せてから次へ進む
            if (isMockBattle && timedOutAnswer != null) {
                revealCorrectChoiceAndContinue(timedOutAnswer);
                return;
            }
            atbPlayerActionPending = false;
            askNextPlayerQuestion();
        }, ATB_PLAYER_QUIZ_TIMEOUT_MS);
    } catch (error) {
        // 何らかの理由でここまでの処理が失敗しても、「出題中のまま何も起きない」
        // 状態に陥らないよう、必ず状態をリセットして次の問題に備える
        console.error('[ATB] askNextPlayerQuestion でエラーが発生しました。状態をリセットします。', error);
        atbPlayerActionPending = false;
    }
}

/**
 * ATBボス戦専用の回答処理。
 * ・正解のたびに自分の攻撃力の0.5倍の追撃ダメージを与え、行動ゲージ（正解数）を1進める。
 * ・行動ゲージが満タンになったらコマンドメニューを開く（それまでは待ち時間なしで次の問題へ）。
 * ・不正解の場合はダメージなし・ゲージ増加なしで、待ち時間なしで次の問題へ進む
 *   （handleBotAnswer() と違い、不正解でボスの反撃が発生することはない。
 *   　ボスの攻撃は独立したゲージで発生するため、二重に不利にしないよう分離している）。
 */
function handleATBAnswer(selectedOption) {
    let usedSkill = typeof consumeSelectedSkill === 'function' ? consumeSelectedSkill() : null;
    const skillEffect = (usedSkill && usedSkill.effect) || {};
    applyInstantSkillEffects(skillEffect);
    if (usedSkill) afterSkillUse(usedSkill);

    const isCorrect = currentQuestion && selectedOption.trim() === currentQuestion.answer;
    const answerTime = Date.now() - questionStartTime;
    const correctAnswerText = currentQuestion ? currentQuestion.answer : null;
    currentQuestion = null;
    atbPlayerActionPending = false;

    if (isCorrect) {
        addLog("正解！回答時間: " + (answerTime / 1000).toFixed(2) + "秒");
        showCorrectEffect();

        // 攻撃タイプの選択（攻撃または特殊）- デフォルトは攻撃
        const attackType = me.attackType || 'attack';
        
        // 攻撃力または特殊攻撃力を基準にする
        let baseAtk = attackType === 'special' ? (me.special || me.atk) : (me.atk || 0);
        
        // 正解のたびに小さな追撃ダメージ（攻撃力の0.5倍）
        // 敵の防御力低下デバフ（enemyDefDebuff）を反映する
        // 神殺し（Tier5）を持っていれば、相手の防御を完全に無視する
        const godSlayer = hasUniqueAbility(me, 'god_slayer');
        const effectiveEnemyDef = godSlayer ? 0 : Math.max(0, Math.floor((enemy.def || 0) * (1 - enemyDefDebuff)));
        const defReduction = Math.floor(effectiveEnemyDef * 0.1);
        let chipDamage = Math.max(1, Math.floor(baseAtk * 0.5) - defReduction);

        // 「1ターン＝1回正解する」の定義に基づき、毒・火傷・デバフ・バフ等の継続効果を
        // 正解1回につき1回だけ進行させる。
        // ここ（このターンで新しくスキル・固有能力が付与するデバフ／バフより前）で
        // 呼ぶのが重要：以前は一番最後（このターンで新しく付与した直後）に呼んでいたため、
        // 「2ターン持続」のはずのデバフ・バフが、付与された直後に自分自身の効果で
        // 1ターン分減らされてしまい、実質1ターンしか効果が無い（＝ほぼ機能していないように
        // 見える）不具合になっていた。先に「既存の」継続効果だけを進行させ、このターンで
        // 新しく付与する分はここでは減らさないようにする。
        tickBotBattleStatus();
        if (battleEnd) return;

        // アクティブスキルの効果を適用（ダメージ倍率だけでなく、毒・火傷・デバフ・回復等も
        // 全てapplySkillEffect()経由でまとめて処理する。以前はダメージ倍率しか見ておらず、
        // 毒・火傷付与やその他の効果を持つスキルがATB戦闘では何も起こらないバグになっていた）
        if (usedSkill) {
            chipDamage = applySkillEffect(chipDamage, me, enemy, usedSkill);
            // スキルで新しく付与したデバフ・バフを、即座にステータス表示へ反映する
            updateStats();
        }
        
        // 神殺し（Tier5）：与えるダメージ1.25倍
        if (godSlayer) chipDamage = Math.floor(chipDamage * 1.25);

        // 根性（guts）：HPが1残る形で持ちこたえる（必殺技等、他の攻撃と同様の処理に統一）
        if (enemy.hp - chipDamage <= 0 && enemy.hp > 1 && hasUniqueAbility(enemy, 'guts')) {
            enemy.hp = 1;
            addLog(`${enemy.name}は根性で持ちこたえた！`);
        } else {
            enemy.hp = Math.max(0, enemy.hp - chipDamage);
        }
        showDamage("enemyDamage", chipDamage);
        addLog(`${me.name}の連続攻撃！ ${enemy.name}に ${chipDamage} のダメージ！`);

        updateHP();

        // 猛毒の一撃／灼熱の一撃（武器固有能力：攻撃がヒットした時100%で付与。
        // 以前はexecuteStrongAttack（必殺技）でしか判定しておらず、大半を占めるこの
        // 連続攻撃（正解のたびの小ダメージ）では武器を持っていても何も起こらなかった）
        if (hasUniqueAbility(me, 'poison_on_hit') && enemy.hp > 0) {
            enemyPoisonTurns = 3;
            addLog(`猛毒の一撃！${enemy.name}に毒を付与した！`);
        }
        if (hasUniqueAbility(me, 'burn_on_hit') && enemy.hp > 0) {
            enemyBurnTurns = 3;
            addLog(`灼熱の一撃！${enemy.name}に火傷を付与した！`);
        }

        // サモンズロッド：配下の召喚モンスターが、正解するたびに追加攻撃を行う
        // （召喚モンスターの情報はweapon.summonedMonstersに保存済み。以前は
        // 「プレイヤーの攻撃力の固定%」だったが、依頼によりモンスターごとの
        // 基礎合計ステータス（baseTotalStat、召喚時に確定）とプレイヤーの現在の
        // 合計ステータスから、召喚モンスター自身の「現在の攻撃力」を毎回計算し、
        // それを基にダメージを算出する方式に変更した。
        // サモンズロッドが無効化されている間（weapons.jsのSUMMONS_ROD_ENABLED=false）は、
        // 契約済みの配下がいても追加攻撃を行わない（データ自体は消えていない）。
        const summonsRodEnabled = (typeof SUMMONS_ROD_ENABLED === 'undefined') || SUMMONS_ROD_ENABLED;
        if (summonsRodEnabled && me.equippedWeapon && Array.isArray(me.equippedWeapon.summonedMonsters) && enemy.hp > 0) {
            // 配下の攻撃力は「プレイヤーの攻撃力の何割か」（割合はモンスターの強さで決まる。summons.js参照）。
            // 基準にするのは、通常の連続攻撃と同じ攻撃力（攻撃タイプが特殊なら特殊攻撃力）。
            const summonPlayerAttack = baseAtk;
            // 相手の防御力（防御ダウンのデバフ反映済み）。通常の連続攻撃と同じ扱いで、
            // 配下の追加攻撃のダメージからも差し引く。
            const summonTargetDef = Math.max(0, Math.floor((enemy.def || 0) * (1 - enemyDefDebuff)));
            me.equippedWeapon.summonedMonsters.forEach(summon => {
                if (enemy.hp <= 0) return;
                let summonAtk;
                if (summon.baseTotalStat != null && typeof getSummonCurrentAtk === 'function') {
                    summonAtk = getSummonCurrentAtk(summon, summonPlayerAttack);
                } else {
                    // 旧形式（multiplierのみを持つ召喚データ）との後方互換
                    summonAtk = Math.floor((me.atk || 0) * (summon.multiplier || 0) * 2);
                }
                const summonDamage = (typeof calcSummonDamage === 'function')
                    ? calcSummonDamage(summonAtk, summonTargetDef)
                    : Math.max(1, Math.floor(summonAtk * 0.5) - Math.floor(summonTargetDef * 0.1));
                enemy.hp = Math.max(0, enemy.hp - summonDamage);
                showDamage("enemyDamage", summonDamage);
                addLog(`${summon.monsterEmoji || ''}${summon.monsterName}の追加攻撃！ ${enemy.name}に ${summonDamage} のダメージ！`);
            });
            updateHP();
        }

        if (!me.ultimateGauge) me.ultimateGauge = { current: 0, max: 100 };
        me.ultimateGauge.current = Math.min(me.ultimateGauge.max, me.ultimateGauge.current + 10);
        updateUltimateGauge();

        if (enemy.hp <= 0) {
            finishBotBattle("win");
            return;
        }

        playerCorrectCount++;
        playerATB = Math.min(100, (playerCorrectCount / playerRequiredCount) * 100);
        updateATBBars();

        if (playerCorrectCount >= playerRequiredCount) {
            // 行動ゲージ満タン！必殺技を自動発動する（必殺技ゲージ・行動ゲージを統合）
            executeStrongAttack(skillEffect, usedSkill);
        } else {
            askNextPlayerQuestion(); // 待ち時間0で次の問題
        }
    } else {
        addLog("不正解…");
        if (isMockBattle && correctAnswerText != null) {
            // 模擬戦闘：正解の選択肢を緑に光らせて、少し待ってから次の問題へ
            revealCorrectChoiceAndContinue(correctAnswerText);
        } else {
            askNextPlayerQuestion(); // 待ち時間0で次の問題（ペナルティなし、進捗も増えない）
        }
    }
}

/**
 * 行動ゲージ満タン時に自動発動する処理。
 * 依頼により、以前は「攻撃力1倍＋低めの固定クリティカル率」という
 * 通常の必殺技（コマンド選択の必殺技、ダメージ1.5倍）とは別の弱い専用攻撃
 * だったが、これを必殺技そのものに統合した。行動ゲージが満タンになった
 * 瞬間が、必殺技ゲージが満タンになった瞬間でもあるとみなし、
 * 武器の必殺技名・ダメージ倍率（覚醒オーブがあれば2.0倍、なければ1.5倍）・
 * 各種固有能力（根性・大器晩成・貫通・必殺・猛毒の一撃・灼熱の一撃等）を
 * コマンド選択時の必殺技と同じルールで適用する。
 */
function executeStrongAttack(skillEffect, usedSkill) {
    // 必殺技ゲージも「満タン」の状態にして、コマンド選択の必殺技と完全に同じ扱いにする
    if (!me.ultimateGauge) me.ultimateGauge = { current: 0, max: 100 };
    me.ultimateGauge.current = me.ultimateGauge.max;

    // 攻撃タイプの選択（攻撃または特殊）- デフォルトは攻撃
    const attackType = me.attackType || 'attack';
    let attackerAtk = attackType === 'special' ? (me.special || me.atk) : (me.atk || 0);

    if (me.hp === 1 && hasUniqueAbility(me, 'guts')) {
        attackerAtk = Math.floor(attackerAtk * 3);
        addLog(`${me.name}の攻撃力が根性で3倍に！`);
    }
    if (hasUniqueAbility(me, 'berserker_state') && me.hp <= me.maxHp * 0.5) {
        attackerAtk = Math.floor(attackerAtk * 1.3);
        addLog(`${me.name}の攻撃力が大器晩成で1.3倍に！`);
    }

    // 貫通（相手の防御を半減）／敵の防御力低下デバフ（enemyDefDebuff）を反映する
    let enemyDef = Math.max(0, Math.floor((enemy.def || 0) * (1 - enemyDefDebuff)));
    if (hasUniqueAbility(me, 'ignore_def_half')) {
        enemyDef = Math.floor(enemyDef * 0.5);
    }
    // 神殺し（Tier5）：相手の防御を完全に無視する
    const strongGodSlayer = hasUniqueAbility(me, 'god_slayer');
    if (strongGodSlayer) enemyDef = 0;

    const defReduction = Math.floor(enemyDef * 0.1);
    let strongDamage = Math.max(1, Math.floor(attackerAtk * 0.5) - defReduction);

    // アクティブスキルの効果を適用（ダメージ倍率だけでなく、毒・火傷・デバフ・回復等も
    // 全てapplySkillEffect()経由でまとめて処理する）
    if (usedSkill) {
        strongDamage = applySkillEffect(strongDamage, me, enemy, usedSkill);
        updateStats();
    }

    // 必殺技発動：武器の必殺技名・ダメージ倍率をコマンド選択の必殺技と統一する
    // （覚醒オーブがあれば2.0倍、なければ1.5倍）
    const ultimateName = getWeaponUltimateName(me.equippedWeapon);
    const ultimateMultiplier = hasUniqueAbility(me, 'ultimate_boost') ? 2.0 : 1.5;
    strongDamage = Math.floor(strongDamage * ultimateMultiplier);
    addLog("行動ゲージが満タンになった！必殺技「" + ultimateName + "」発動！ダメージ" + ultimateMultiplier + "倍！");
    showUltimateEffect();

    // クリティカル判定（必殺オーブ・会心の一撃オーブを反映）
    const isForcedFirstStrikeCrit = hasUniqueAbility(me, 'first_strike_crit') && !myFirstAttackDone;
    myFirstAttackDone = true;
    const critBaseChance = hasUniqueAbility(me, "critical_damage") ? CRITICAL_ABILITY_CRIT_CHANCE : BASE_CRIT_CHANCE;
    if (isForcedFirstStrikeCrit || Math.random() < critBaseChance) {
        const critMultiplier = hasUniqueAbility(me, 'crit_damage_boost') ? 2.2 : BASE_CRIT_MULTIPLIER;
        strongDamage = Math.floor(strongDamage * critMultiplier);
        addLog(isForcedFirstStrikeCrit ? "会心の初撃！" : "クリティカルヒット！");
    }

    // 神殺し（Tier5）：与えるダメージ1.25倍
    if (strongGodSlayer) strongDamage = Math.floor(strongDamage * 1.25);

    // 必殺技発動後、ゲージをリセット（コマンド選択の必殺技と同じ挙動）
    me.ultimateGauge.current = 0;
    updateUltimateGauge();

    // ダメージ適用（根性で1残す処理も他の攻撃と同様に反映）
    if (enemy.hp - strongDamage <= 0 && enemy.hp > 1 && hasUniqueAbility(enemy, 'guts')) {
        enemy.hp = 1;
        addLog(`${enemy.name}は根性で持ちこたえた！`);
    } else {
        enemy.hp = Math.max(0, enemy.hp - strongDamage);
    }
    showDamage("enemyDamage", strongDamage);
    addLog(`${me.name}の必殺技！ ${enemy.name}に ${strongDamage} のダメージ！`);
    
    updateHP();
    
    // ライフドレイン処理
    if (hasUniqueAbility(me, "life_drain")) {
        const healAmount = Math.floor(strongDamage * 0.2);
        me.hp = Math.min(me.maxHp, me.hp + healAmount);
        addLog(`ライフドレインで ${healAmount} 回復！`);
        updateHP();
    }

    // 猛毒の一撃／灼熱の一撃（武器説明のとおり、攻撃ヒット時100%で付与）
    if (hasUniqueAbility(me, 'poison_on_hit') && enemy.hp > 0) {
        enemyPoisonTurns = 3;
        addLog(`猛毒の一撃！${enemy.name}に毒を付与した！`);
    }
    if (hasUniqueAbility(me, 'burn_on_hit') && enemy.hp > 0) {
        enemyBurnTurns = 3;
        addLog(`灼熱の一撃！${enemy.name}に火傷を付与した！`);
    }
    
    // 勝利判定
    if (enemy.hp <= 0) {
        finishBotBattle("win");
        return;
    }
    
    // ゲージをリセットして次の問題へ
    continueBattleLoop();

    // 実戦形式チュートリアル：初めて強攻撃が発動した時だけ、説明を教える
    if (isPracticeTutorial && !practiceCoachShown.strongAttack && window.PracticeCoach) {
        practiceCoachShown.strongAttack = true;
        const myAtbBar = document.getElementById('myAtbBar');
        if (myAtbBar) {
            window.PracticeCoach.point(
                myAtbBar,
                "行動ゲージが満タンになって、必殺技が発動したよ！\nこれを繰り返して相手を倒そう！",
                { buttonLabel: 'わかった' }
            );
        }
    }
}

/**
 * プレイヤー側の行動（コマンド確定）が終わった後に呼ばれる。
 * ボス戦のATBループ中なら、行動ゲージ（正解数）をリセットして、
 * 待ち時間なしで次の問題を出題する。それ以外（通常のボット戦）では
 * 今まで通り次の問題を生成する。
 */
function continueBattleLoop() {
    if (isBotBattle && atbInterval) {
        atbPlayerActionPending = false;
        playerCorrectCount = 0;
        playerRequiredCount = getRequiredCorrectCount(me.speed); // 素早さの変化（バフ等）を反映
        playerATB = 0;
        updateATBBars();
        askNextPlayerQuestion();
    } else {
        setTimeout(generateBotQuestion, 1000);
    }
}

/**
 * ボスのゲージが満タンになった時に呼ばれる。攻撃の予備動作（テレグラフ）を見せ、
 * その間だけプレイヤーはガードポップアップのボタンを押して反応することができる。
 */
function triggerBossTelegraph() {
    if (battleEnd) return;
    atbBossTelegraphActive = true;
    atbGuardWindowOpen = true;
    atbGuardActivated = false;

    addLog(`⚠️ ${enemy.name}が攻撃の構えを見せた！ガードで身構えよう！`);

    const guardPopup = document.getElementById('atbGuardPopup');
    const guardBtn = document.getElementById('atbGuardBtn');
    if (guardPopup) guardPopup.style.display = 'flex';
    if (guardBtn) {
        guardBtn.disabled = false;
        guardBtn.classList.remove('guard-success');
    }

    setTimeout(() => {
        atbGuardWindowOpen = false;
        if (guardBtn) guardBtn.disabled = true;
        resolveBossAttack();
    }, ATB_BOSS_TELEGRAPH_MS);
}

/** ガードボタンが押された時に呼ばれる。予備動作中のみ有効。
 *  ローカル戦（isBotBattle）はその場で判定するが、オンライン戦は
 *  サーバーに通知するだけで、実際の判定はサーバー側（socket/battle.js）で行う。
 */
function activateATBGuard() {
    if (!atbGuardWindowOpen || atbGuardActivated) return;
    atbGuardActivated = true;
    addLog("ガードの構え！");
    const guardBtn = document.getElementById('atbGuardBtn');
    if (guardBtn) {
        guardBtn.disabled = true;
        guardBtn.classList.add('guard-success');
    }

    if (!isBotBattle && typeof socket !== 'undefined' && socket) {
        socket.emit('battle:guard', { roomId });
    }
}

/** ボスの攻撃予備動作が終わった時点で実際にダメージを解決する。 */
function resolveBossAttack() {
    if (battleEnd) return;

    // 模擬戦闘ではダメージを一切受けない（敵の行動ゲージ自体を進めていないので通常は来ないが、念のため）
    if (isMockBattle) {
        const mockGuardPopup = document.getElementById('atbGuardPopup');
        if (mockGuardPopup) mockGuardPopup.style.display = 'none';
        atbBossTelegraphActive = false;
        enemyATB = 0;
        updateATBBars();
        return;
    }

    // 敵の命中率低下デバフ（enemyAccuracyDebuff）：確率でボスの攻撃を完全に外す
    if (enemyAccuracyDebuff > 0 && Math.random() < enemyAccuracyDebuff) {
        addLog(`${enemy.name}の攻撃は命中率低下で外れた！`);
        const missGuardPopup = document.getElementById('atbGuardPopup');
        if (missGuardPopup) missGuardPopup.style.display = 'none';
        atbBossTelegraphActive = false;
        enemyATB = 0;
        updateATBBars();
        return;
    }

    let myDef = Math.max(0, (me.def || 0) - myDefDebuff);
    // 敵の攻撃力低下デバフ（enemyAtkDebuff）を反映する。
    // ボットのステータスがランダム配分され、特殊寄りの個体（attackType==='special'）の
    // 場合は、攻撃力の代わりに特殊ステータスを使う。
    let botAtk = (enemy.attackType === 'special' && enemy.special != null) ? enemy.special : enemy.atk;
    if (enemyAtkDebuff > 0) {
        botAtk = Math.floor(botAtk * (1 - enemyAtkDebuff));
    }

    // ボスのアクティブスキル使用（一定確率）
    let bossUsedSkill = null;
    if (enemy.skills && enemy.skills.length > 0 && Math.random() < 0.5) {
        bossUsedSkill = enemy.skills[Math.floor(Math.random() * enemy.skills.length)];
    }

    const defReduction = Math.floor(myDef * 0.1);
    let damage = Math.max(1, Math.floor(botAtk * 0.5) - defReduction);

    if (bossUsedSkill) {
        damage = applyBossSkillEffect(damage, enemy, me, bossUsedSkill);
    }

    if (atbGuardActivated) {
        damage = Math.floor(damage * 0.2);
        addLog("ガード成功！ダメージ80%カット！");
    }

    if (hasUniqueAbility(me, 'damage_cut_half')) {
        damage = Math.floor(damage * 0.5);
        addLog("鉄壁発動！ダメージ50%カット");
    }

    // 絶対障壁（Tier5）：ダメージ60%カット。鉄壁と重ねた場合も、ここで別途0.4倍が掛かる
    // （同時に持つには「Tier4オーブ＋Tier5オーブ」が必要で、実質2枠を使うため許容範囲）。
    if (hasUniqueAbility(me, 'absolute_barrier')) {
        damage = Math.max(1, Math.floor(damage * 0.4));
        addLog("絶対障壁発動！ダメージ60%カット");
    }

    // 回避判定：素早さによる基礎回避率 + スキルによる回避率アップ（幻影など、1.0で完全回避）
    // + 「残像」（self_evasion_boost）固有能力の+15%
    const baseDodgeChance = calculateDodgeChance(me.speed);
    const skillDodgeBonus = myDodgeTurns > 0 ? Math.floor(myDodgeChance * 100) : 0;
    const selfEvasionBonus = hasUniqueAbility(me, 'self_evasion_boost') ? 15 : 0;
    const totalMyDodgeChance = Math.min(100, baseDodgeChance + skillDodgeBonus + selfEvasionBonus);
    if (Math.random() * 100 < totalMyDodgeChance) {
        showDamage("myDamage", 0);
        addLog(`${me.name}は${enemy.name}の攻撃を回避した！`);
        if (myDodgeTurns > 0) {
            myDodgeTurns = 0;
            myDodgeChance = 0; // 回避成功で消費（幻影などの単発回避スキルを想定）
        }
        const dodgeGuardPopup = document.getElementById('atbGuardPopup');
        if (dodgeGuardPopup) dodgeGuardPopup.style.display = 'none';
        atbBossTelegraphActive = false;
        enemyATB = 0;
        updateATBBars();
        return;
    }

    // スキルによるダメージ軽減／無敵（次の1回だけ有効、使い切り）
    damage = applyIncomingDamageReduction(damage);

    // シールド：スキルで得た分だけ先にダメージを吸収する
    if (myShield > 0 && damage > 0) {
        const absorbed = Math.min(myShield, damage);
        myShield -= absorbed;
        damage -= absorbed;
        addLog(`シールドが${absorbed}のダメージを吸収！（残りシールド: ${myShield}）`);
    }

    // 根性（guts）：HPが1残る形で持ちこたえる（他の攻撃と同様の処理に統一）
    if (me.hp - damage <= 0 && me.hp > 1 && hasUniqueAbility(me, 'guts')) {
        me.hp = 1;
        addLog(`${me.name}は根性で持ちこたえた！`);
    } else {
        me.hp = Math.max(0, me.hp - damage);
    }
    showDamage("myDamage", damage);
    addLog(`${enemy.name}から ${damage} のダメージ！`);
    updateHP();

    // 反撃：被弾した際、反撃態勢中なら自分の攻撃力の30%分を確実に返す（1回で消費）
    if (myCounterActive && damage > 0 && enemy.hp > 0) {
        const counterDamage = Math.max(1, Math.floor((me.atk || 0) * 0.3));
        enemy.hp = Math.max(0, enemy.hp - counterDamage);
        addLog(`反撃！${enemy.name}に${counterDamage}のダメージ！`);
        showDamage("enemyDamage", counterDamage);
        myCounterActive = false;
        myCounterTurns = 0;
    }

    const guardPopup = document.getElementById('atbGuardPopup');
    if (guardPopup) guardPopup.style.display = 'none';

    atbBossTelegraphActive = false;
    enemyATB = 0;
    updateATBBars();

    if (enemy.hp <= 0) {
        finishBotBattle("win");
        return;
    }

    if (me.hp <= 0 && !tryReviveMe()) {
        finishBotBattle("lose");
    }
}

// ==== ここまでATBバトルシステム本体 ====

function generateBotQuestion() {
    console.log("generateBotQuestion called, isBossBattle:", isBossBattle);
    
    // ステータス更新を反映
    updateStats();
    updateHP();
    
    // ボス戦の場合、ボス用の問題を使用
    if (isBossBattle) {
        console.log('[BotBattle] Using boss question system');
        const bossSubjects = ['math', 'jp', 'eng', 'sci', 'soc'];
        const bossSubject = bossSubjects[Math.floor(Math.random() * bossSubjects.length)];
        
        // Use local boss questions for bot battles
        const bossQuestions = getLocalBossQuestions(bossSubject);
        console.log(`[BotBattle] Got ${bossQuestions.length} boss questions for subject=${bossSubject}`);
        
        if (bossQuestions && bossQuestions.length > 0) {
            const randomQuestion = bossQuestions[Math.floor(Math.random() * bossQuestions.length)];
            currentQuestion = { ...randomQuestion, id: Date.now(), subject: bossSubject, subjectDisplayName: getSubjectDisplayName(bossSubject) };
            console.log('[BotBattle] Selected boss question:', currentQuestion);
            
            // 継続効果の処理（火傷・防御低下）
            tickBotBattleStatus();
            if (battleEnd) return;
            if (enemy.hp <= 0) { finishBotBattle("win"); return; }

            // スキル選択ウィンドウをカウントダウンと同時に開始
            startSkillActivationWindow();

            showCountdown(() => {
                questionDisplay.textContent = currentQuestion.question;
                // 選択肢を生成
                generateChoices(currentQuestion);
                startTimer();
                addLog("問題が出されました！" + (currentQuestion.subjectDisplayName ? "（" + currentQuestion.subjectDisplayName + "）" : ""));
                
                // ボス戦の場合、制限時間内にプレイヤーが答えられなければボスが自動で正解する
                if (isBossBattle) {
                    if (bossAutoAnswerTimer) clearTimeout(bossAutoAnswerTimer);
                    bossAutoAnswerTimer = setTimeout(performBossTimeoutAttack, BOSS_AUTO_ANSWER_TIMEOUT);
                }
            });
            return;
        } else {
            console.warn('[BotBattle] Boss questions not available, falling back to regular questions');
        }
    }
    
    // 学年に応じた問題を生成
    const playerGrade = me.grade || 1;
    const enemyGrade = enemy.grade || 1;
    
    // 学校レベルと学年を判定
    let schoolLevel, grade;
    if (playerGrade <= 6) {
        schoolLevel = 'elementary';
        grade = playerGrade;
    } else if (playerGrade <= 9) {
        schoolLevel = 'junior_high';
        grade = playerGrade - 6;
    } else {
        schoolLevel = 'high_school';
        grade = playerGrade - 9;
    }
    
    // 教科をランダムに選択
    const subjects = ['math', 'jp', 'english'];
    const subject = subjects[Math.floor(Math.random() * subjects.length)];
    
    // 固定の問題セット（学年と教科に応じた問題）
    const questionsByGrade = {
        elementary: {
            1: {
                math: [
                    { question: "1 + 1 = ?", answer: "2" },
                    { question: "2 + 3 = ?", answer: "5" },
                    { question: "5 - 2 = ?", answer: "3" },
                    { question: "10 - 5 = ?", answer: "5" },
                    { question: "3 + 4 = ?", answer: "7" }
                ],
                jp: [
                    { question: "あいのうえの「あ」は何行？", answer: "あ行" },
                    { question: "「い」の後ろのひらがなは？", answer: "う" },
                    { question: "「か」の後ろのひらがなは？", answer: "き" },
                    { question: "「さ」の後ろのひらがなは？", answer: "し" },
                    { question: "「た」の後ろのひらがなは？", answer: "ち" }
                ],
                english: [
                    { question: "「犬」の英語は？", answer: "dog" },
                    { question: "「猫」の英語は？", answer: "cat" },
                    { question: "「本」の英語は？", answer: "book" },
                    { question: "「学校」の英語は？", answer: "school" },
                    { question: "「先生」の英語は？", answer: "teacher" }
                ]
            },
            2: {
                math: [
                    { question: "7 + 8 = ?", answer: "15" },
                    { question: "15 - 7 = ?", answer: "8" },
                    { question: "9 + 6 = ?", answer: "15" },
                    { question: "20 - 12 = ?", answer: "8" },
                    { question: "5 × 2 = ?", answer: "10" }
                ],
                jp: [
                    { question: "「犬」の読み方は？", answer: "いぬ" },
                    { question: "「猫」の読み方は？", answer: "ねこ" },
                    { question: "「鳥」の読み方は？", answer: "とり" },
                    { question: "「魚」の読み方は？", answer: "さかな" },
                    { question: "「花」の読み方は？", answer: "はな" }
                ],
                english: [
                    { question: "「走る」の英語は？", answer: "run" },
                    { question: "「食べる」の英語は？", answer: "eat" },
                    { question: "「見る」の英語は？", answer: "see" },
                    { question: "「聞く」の英語は？", answer: "hear" },
                    { question: "「話す」の英語は？", answer: "speak" }
                ]
            },
            3: {
                math: [
                    { question: "23 + 47 = ?", answer: "70" },
                    { question: "100 - 35 = ?", answer: "65" },
                    { question: "6 × 7 = ?", answer: "42" },
                    { question: "81 ÷ 9 = ?", answer: "9" },
                    { question: "45 ÷ 5 = ?", answer: "9" }
                ],
                jp: [
                    { question: "「走る」の反対語は？", answer: "止まる" },
                    { question: "「大きい」の反対語は？", answer: "小さい" },
                    { question: "「明るい」の反対語は？", answer: "暗い" },
                    { question: "「新しい」の反対語は？", answer: "古い" },
                    { question: "「高い」の反対語は？", answer: "低い" }
                ],
                english: [
                    { question: "「赤」の英語は？", answer: "red" },
                    { question: "「青」の英語は？", answer: "blue" },
                    { question: "「緑」の英語は？", answer: "green" },
                    { question: "「黄色」の英語は？", answer: "yellow" },
                    { question: "「黒」の英語は？", answer: "black" }
                ]
            },
            4: {
                math: [
                    { question: "345 + 678 = ?", answer: "1023" },
                    { question: "1000 - 456 = ?", answer: "544" },
                    { question: "12 × 8 = ?", answer: "96" },
                    { question: "144 ÷ 12 = ?", answer: "12" },
                    { question: "25 × 4 = ?", answer: "100" }
                ],
                jp: [
                    { question: "「春」の次の季節は？", answer: "夏" },
                    { question: "「月曜日」の次の曜日は？", answer: "火曜日" },
                    { question: "「1月」の次の月は？", answer: "2月" },
                    { question: "「朝」の次は？", answer: "昼" },
                    { question: "「今日」の次は？", answer: "明日" }
                ],
                english: [
                    { question: "「月曜日」の英語は？", answer: "monday" },
                    { question: "「火曜日」の英語は？", answer: "tuesday" },
                    { question: "「水曜日」の英語は？", answer: "wednesday" },
                    { question: "「木曜日」の英語は？", answer: "thursday" },
                    { question: "「金曜日」の英語は？", answer: "friday" }
                ]
            },
            5: {
                math: [
                    { question: "2.5 + 3.7 = ?", answer: "6.2" },
                    { question: "10 - 4.8 = ?", answer: "5.2" },
                    { question: "1.2 × 5 = ?", answer: "6" },
                    { question: "15 ÷ 0.5 = ?", answer: "30" },
                    { question: "3.6 ÷ 1.2 = ?", answer: "3" }
                ],
                jp: [
                    { question: "「国語」の漢字で「くにご」と読む漢字は？", answer: "国" },
                    { question: "「算数」の漢字で「さんすう」と読む漢字は？", answer: "算" },
                    { question: "「理科」の漢字で「りか」と読む漢字は？", answer: "理" },
                    { question: "「社会」の漢字で「しゃかい」と読む漢字は？", answer: "社" },
                    { question: "「音楽」の漢字で「おんがく」と読む漢字は？", answer: "音" }
                ],
                english: [
                    { question: "「1月」の英語は？", answer: "january" },
                    { question: "「2月」の英語は？", answer: "february" },
                    { question: "「3月」の英語は？", answer: "march" },
                    { question: "「4月」の英語は？", answer: "april" },
                    { question: "「5月」の英語は？", answer: "may" }
                ]
            },
            6: {
                math: [
                    { question: "1/2 + 1/3 = ?", answer: "5/6" },
                    { question: "3/4 - 1/4 = ?", answer: "1/2" },
                    { question: "2/3 × 3/4 = ?", answer: "1/2" },
                    { question: "5 ÷ 1/2 = ?", answer: "10" },
                    { question: "1/5 ÷ 2 = ?", answer: "1/10" }
                ],
                jp: [
                    { question: "「友情」の意味に近い言葉は？", answer: "友達" },
                    { question: "「努力」の意味に近い言葉は？", answer: "頑張る" },
                    { question: "「成功」の反対語は？", answer: "失敗" },
                    { question: "「希望」の反対語は？", answer: "絶望" },
                    { question: "「勇気」の意味に近い言葉は？", answer: "勇敢" }
                ],
                english: [
                    { question: "「春」の英語は？", answer: "spring" },
                    { question: "「夏」の英語は？", answer: "summer" },
                    { question: "「秋」の英語は？", answer: "autumn" },
                    { question: "「冬」の英語は？", answer: "winter" },
                    { question: "「季節」の英語は？", answer: "season" }
                ]
            }
        },
        junior_high: {
            1: {
                math: [
                    { question: "-5 + 3 = ?", answer: "-2" },
                    { question: "-2 × -3 = ?", answer: "6" },
                    { question: "10 ÷ -2 = ?", answer: "-5" },
                    { question: "3x + 2x = ?", answer: "5x" },
                    { question: "2(x + 3) = ?", answer: "2x+6" }
                ],
                jp: [
                    { question: "「主語」の例は？", answer: "私,彼,彼女" },
                    { question: "「述語」の例は？", answer: "走る,食べる,見る" },
                    { question: "「修飾語」の例は？", answer: "美しい,速く,静かに" },
                    { question: "「接続詞」の例は？", answer: "そして,しかし,だから" },
                    { question: "「感動詞」の例は？", answer: "あ,おお,まあ" }
                ],
                english: [
                    { question: "「犬」の英語は？", answer: "dog" },
                    { question: "「猫」の英語は？", answer: "cat" },
                    { question: "「本」の英語は？", answer: "book" },
                    { question: "「学校」の英語は？", answer: "school" },
                    { question: "「先生」の英語は？", answer: "teacher" }
                ]
            },
            2: {
                math: [
                    { question: "x² = 16 の解は？", answer: "4,-4" },
                    { question: "2x + 5 = 15 の解は？", answer: "5" },
                    { question: "3x - 7 = 14 の解は？", answer: "7" },
                    { question: "(x + 2)(x - 3) = ?", answer: "x²-x-6" },
                    { question: "x² - 5x + 6 = 0 の解は？", answer: "2,3" }
                ],
                jp: [
                    { question: "「比喩」の例は？", answer: "ライオンのように強い" },
                    { question: "「擬人法」の例は？", answer: "風がささやく" },
                    { question: "「倒置法」の例は？", answer: "美しい、この花は" },
                    { question: "「反復法」の例は？", answer: "走った、走った、走った" },
                    { question: "「対句」の例は？", answer: "山と川,天と地" }
                ],
                english: [
                    { question: "「走る」の現在形は？", answer: "run" },
                    { question: "「食べる」の過去形は？", answer: "ate" },
                    { question: "「行く」の過去形は？", answer: "went" },
                    { question: "「見る」の過去分詞は？", answer: "seen" },
                    { question: "「持っている」の現在完了形は？", answer: "have" }
                ]
            },
            3: {
                math: [
                    { question: "√16 = ?", answer: "4" },
                    { question: "√25 = ?", answer: "5" },
                    { question: "2³ = ?", answer: "8" },
                    { question: "3² = ?", answer: "9" },
                    { question: "sin 30° = ?", answer: "0.5" }
                ],
                jp: [
                    { question: "「係り結び」の例は？", answer: "～けれども、～ので" },
                    { question: "「受動態」の例は？", answer: "彼に褒められた" },
                    { question: "「使役態」の例は？", answer: "彼を行かせた" },
                    { question: "「尊敬語」の例は？", answer: "いらっしゃる,おっしゃる" },
                    { question: "「謙譲語」の例は？", answer: "参る,申す" }
                ],
                english: [
                    { question: "「もし～なら」を表す接続詞は？", answer: "if" },
                    { question: "「～ので」を表す接続詞は？", answer: "because" },
                    { question: "「～の時」を表す接続詞は？", answer: "when" },
                    { question: "「～ながら」を表す接続詞は？", answer: "while" },
                    { question: "「～まで」を表う接続詞は？", answer: "until" }
                ]
            }
        },
        high_school: {
            1: {
                math: [
                    { question: "log₂ 8 = ?", answer: "3" },
                    { question: "log₁₀ 100 = ?", answer: "2" },
                    { question: "2x + 3y = 10, x = 2 の時 y = ?", answer: "2" },
                    { question: "y = 2x + 1 の傾きは？", answer: "2" },
                    { question: "y = -3x + 5 のy切片は？", answer: "5" }
                ],
                jp: [
                    { question: "「枕草子」の作者は？", answer: "清少納言" },
                    { question: "「源氏物語」の作者は？", answer: "紫式部" },
                    { question: "「徒然草」の作者は？", answer: "吉田兼好" },
                    { question: "「方丈記」の作者は？", answer: "鴨長明" },
                    { question: "「奥の細道」の作者は？", answer: "松尾芭蕉" },
                    { question: "「美しい、この花は」で使われている技法は？", answer: "倒置法" },
                    { question: "「ライオンのように強い」で使われている技法は？", answer: "比喩" },
                    { question: "「走った、走った、走った」で使われている技法は？", answer: "反復" },
                    { question: "「山と川、天と地」で使われている技法は？", answer: "対句" },
                    { question: "「風がささやく」で使われている技法は？", answer: "擬人法" },
                    { question: "「～けれども、～ので」で使われている技法は？", answer: "係り結び" },
                    { question: "「彼に褒められた」で使われている技法は？", answer: "受動態" },
                    { question: "「彼を行かせた」で使われている技法は？", answer: "使役態" },
                    { question: "「いらっしゃる、おっしゃる」で使われている技法は？", answer: "尊敬語" },
                    { question: "「参る、申す」で使われている技法は？", answer: "謙譲語" }
                ],
                english: [
                    { question: "「関係代名詞」で使われる単語は？", answer: "which,that,who" },
                    { question: "「現在完了形」の継続を表すのは？", answer: "have+pp" },
                    { question: "「仮定法」で使われる動詞の形は？", answer: "過去形" },
                    { question: "「受動態」の作り方は？", answer: "be過去分詞" },
                    { question: "「不定詞」の名詞的用法は？", answer: "to動詞" }
                ]
            },
            2: {
                math: [
                    { question: "微分 dy/dx (x²) = ?", answer: "2x" },
                    { question: "微分 dy/dx (x³) = ?", answer: "3x²" },
                    { question: "積分 ∫x dx = ?", answer: "x²/2" },
                    { question: "積分 ∫2x dx = ?", answer: "x²" },
                    { question: "cos 0° = ?", answer: "1" }
                ],
                jp: [
                    { question: "「吾輩は猫である」の作者は？", answer: "夏目漱石" },
                    { question: "「走れメロス」の作者は？", answer: "太宰治" },
                    { question: "「城の崎にて」の作者は？", answer: "志賀直哉" },
                    { question: "「羅生門」の作者は？", answer: "芥川龍之介" },
                    { question: "「風立ちぬ」の作者は？", answer: "堀辰雄" }
                ],
                english: [
                    { question: "「話法」の種類は？", answer: "直接,間接" },
                    { question: "「比較」の最上級の作り方は？", answer: "最+est" },
                    { question: "「分詞」の現在分詞は？", answer: "ing" },
                    { question: "「分詞」の過去分詞は？", answer: "ed" },
                    { question: "「動名詞」の形は？", answer: "ing" }
                ]
            },
            3: {
                math: [
                    { question: "∫sin x dx = ?", answer: "-cos x" },
                    { question: "∫cos x dx = ?", answer: "sin x" },
                    { question: "d/dx (eˣ) = ?", answer: "eˣ" },
                    { question: "d/dx (ln x) = ?", answer: "1/x" },
                    { question: "lim (x→0) sin x/x = ?", answer: "1" }
                ],
                jp: [
                    { question: "「山月記」の作者は？", answer: "中島敦" },
                    { question: "「注文の多い料理店」の作者は？", answer: "宮沢賢治" },
                    { question: "「高瀬舟」の作者は？", answer: "森鴎外" },
                    { question: "「舞姫」の作者は？", answer: "森鴎外" },
                    { question: "「こころ」の作者は？", answer: "夏目漱石" }
                ],
                english: [
                    { question: "「仮定法過去」の例は？", answer: "If I were you" },
                    { question: "「仮定法過去完了」の例は？", answer: "If I had known" },
                    { question: "「関係副詞」の例は？", answer: "where,when,why" },
                    { question: "「原形不定詞」の使い方は？", answer: "使役,知覚" },
                    { question: "「間接疑問」の語順は？", answer: "S+V" }
                ]
            }
        }
    };
    
    // 学年と教科に対応する問題を取得
    let questions = [];
    if (questionsByGrade[schoolLevel] && questionsByGrade[schoolLevel][grade]) {
        questions = questionsByGrade[schoolLevel][grade][subject] || [];
    }
    
    // 問題がない場合はデフォルトの問題を使用
    if (questions.length === 0) {
        questions = [
            { question: "1 + 1 = ?", answer: "2" },
            { question: "2 × 3 = ?", answer: "6" }
        ];
    }
    
    const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
    currentQuestion = { ...randomQuestion, id: Date.now(), subject: subject, subjectDisplayName: getSubjectDisplayName(subject) };

    // 継続効果の処理（火傷・防御低下）
    tickBotBattleStatus();
    if (battleEnd) return;
    if (enemy.hp <= 0) { finishBotBattle("win"); return; }

    // スキル選択ウィンドウをカウントダウンと同時に開始
    startSkillActivationWindow();

    showCountdown(() => {
        questionDisplay.textContent = currentQuestion.question;
        // 選択肢を生成
        generateChoices(currentQuestion);
        startTimer();
        addLog("問題が出されました！" + (currentQuestion.subjectDisplayName ? "（" + currentQuestion.subjectDisplayName + "）" : ""));
        
        // ボス戦の場合、制限時間内にプレイヤーが答えられなければボスが自動で正解する
        if (isBossBattle) {
            if (bossAutoAnswerTimer) clearTimeout(bossAutoAnswerTimer);
            bossAutoAnswerTimer = setTimeout(performBossTimeoutAttack, BOSS_AUTO_ANSWER_TIMEOUT);
        }
    });
}

function displayQuestion(question, isFirstQuestion = false) {
    if (!question || !question.question) {
        console.error("Invalid question data:", question);
        addLog("エラー: 無効な問題データです。");
        addLog("問題データ: " + JSON.stringify(question));
        return;
    }
    console.log("displayQuestion called with:", question);
    currentQuestion = question;

    // まずコマンドメニューを隠す（前の問題の状態をクリア）
    hideCommandMenu();

    // スキル選択ウィンドウをカウントダウンと同時に開始
    startSkillActivationWindow();

    const showQuestionNow = () => {
        questionDisplay.textContent = currentQuestion.question;
        generateChoices(currentQuestion);
        startTimer();
        
        const subjectDisplay = currentQuestion.subjectDisplayName || getSubjectDisplayName(currentQuestion.subject);
        addLog("問題が出されました！" + (subjectDisplay ? "（" + subjectDisplay + "）" : ""));

        // 実戦形式チュートリアル：最初の問題でのみ、回答方法を教える
        if (isPracticeTutorial && !practiceCoachShown.question && window.PracticeCoach) {
            practiceCoachShown.question = true;
            window.PracticeCoach.point(
                choicesContainer,
                "この中から正解だと思うものをタップしよう！\n制限時間内に答えてね。",
                { buttonLabel: 'わかった' }
            );
        }

        // 実戦形式チュートリアル：行動ゲージの説明
        if (isPracticeTutorial && !practiceCoachShown.gauge && window.PracticeCoach) {
            practiceCoachShown.gauge = true;
            const myAtbBar = document.getElementById('myAtbBar');
            if (myAtbBar) {
                window.PracticeCoach.point(
                    myAtbBar,
                    "これが「行動ゲージ」だよ！\n正解するたびに溜まって、満タンになると必殺技が自動発動するよ。",
                    { buttonLabel: 'わかった' }
                );
            }
        }
    };

    // オンライン対戦・パーティのボス戦では、以前は問題が来るたびに毎回
    // 「3, 2, 1, GO!!」のカウントダウン（3〜4秒）を表示しており、
    // ボット戦（startATBBattleLoop）とは違って2問目以降も待たされていた。
    // ボスや相手はその間もリアルタイムで行動ゲージが進み続けるため、
    // 回数を重ねるほど不利な「ずれ」がどんどん蓄積してしまっていた。
    // ボット戦と同じく、カウントダウンは最初の1問だけに限定する。
    if (isFirstQuestion) {
        showCountdown(showQuestionNow);
    } else {
        showQuestionNow();
    }
}

// ボット戦の継続効果（火傷・毒・自身の防御低下・敵デバフ）を1ターン分進める。
// 「1ターン」＝「1回正解する」と定義し、handleATBAnswer()の正解時に1回だけ呼ばれる
// （以前は実時間3秒ごとに呼んでいたが、依頼によりこの定義に変更した）。
// 火傷・毒の1ターンあたりのダメージ（最大HPに対する割合）。
// 「1ターン＝1回正解する」に変更したことで、以前（実時間3秒に1回）より
// ずっと速いペースでダメージが入るようになり、火傷・毒が強すぎる状態になっていた。
// そのため、1ターンあたりの割合を半分程度に弱体化する。
const BURN_DAMAGE_PERCENT = 0.05;   // 以前は0.10
const POISON_DAMAGE_PERCENT = 0.04; // 以前は0.08

function tickBotBattleStatus() {
    // 自然治癒（オーブ固有能力）：毎ターン、最大HPの3%を自動回復する
    if (hasUniqueAbility(me, 'hp_regen') && me.hp > 0 && me.hp < me.maxHp) {
        const regenAmount = Math.max(1, Math.floor(me.maxHp * 0.03));
        me.hp = Math.min(me.maxHp, me.hp + regenAmount);
        addLog(`自然治癒で${me.name}のHPが${regenAmount}回復した！`);
        updateHP();
    }
    if (hasUniqueAbility(enemy, 'hp_regen') && enemy.hp > 0 && enemy.hp < enemy.maxHp) {
        const regenAmount = Math.max(1, Math.floor(enemy.maxHp * 0.03));
        enemy.hp = Math.min(enemy.maxHp, enemy.hp + regenAmount);
        addLog(`自然治癒で${enemy.name}のHPが${regenAmount}回復した！`);
        updateHP();
    }
    // プレイヤー自身の毒・火傷（ボスのスキルで付与されたもの）
    // ※根性（guts）持ちはHP1残しの対象になるよう、他の攻撃と同様にガードする
    if (myBurnTurns > 0) {
        const burnDamage = Math.max(1, Math.floor(me.maxHp * BURN_DAMAGE_PERCENT));
        if (me.hp - burnDamage <= 0 && me.hp > 1 && hasUniqueAbility(me, 'guts')) {
            me.hp = 1;
            addLog(`${me.name}は根性で持ちこたえた！`);
        } else {
            me.hp = Math.max(0, me.hp - burnDamage);
        }
        myBurnTurns--;
        addLog(`火傷ダメージ！${me.name}に${burnDamage}のダメージ（残り${myBurnTurns}回）`);
        updateHP();
        if (me.hp <= 0 && !tryReviveMe()) { finishBotBattle("lose"); return; }
    }
    if (myPoisonTurns > 0) {
        const poisonDamage = Math.max(1, Math.floor(me.maxHp * POISON_DAMAGE_PERCENT));
        if (me.hp - poisonDamage <= 0 && me.hp > 1 && hasUniqueAbility(me, 'guts')) {
            me.hp = 1;
            addLog(`${me.name}は根性で持ちこたえた！`);
        } else {
            me.hp = Math.max(0, me.hp - poisonDamage);
        }
        myPoisonTurns--;
        addLog(`毒ダメージ！${me.name}に${poisonDamage}のダメージ（残り${myPoisonTurns}回）`);
        updateHP();
        if (me.hp <= 0 && !tryReviveMe()) { finishBotBattle("lose"); return; }
    }
    if (enemyBurnTurns > 0) {
        const burnDamage = Math.max(1, Math.floor(enemy.maxHp * BURN_DAMAGE_PERCENT));
        if (enemy.hp - burnDamage <= 0 && enemy.hp > 1 && hasUniqueAbility(enemy, 'guts')) {
            enemy.hp = 1;
            addLog(`${enemy.name}は根性で持ちこたえた！`);
        } else {
            enemy.hp = Math.max(0, enemy.hp - burnDamage);
        }
        enemyBurnTurns--;
        addLog(`火傷ダメージ！${enemy.name}に${burnDamage}のダメージ（残り${enemyBurnTurns}回）`);
        updateHP();
    }
    if (enemyPoisonTurns > 0) {
        const poisonDamage = Math.max(1, Math.floor(enemy.maxHp * POISON_DAMAGE_PERCENT));
        if (enemy.hp - poisonDamage <= 0 && enemy.hp > 1 && hasUniqueAbility(enemy, 'guts')) {
            enemy.hp = 1;
            addLog(`${enemy.name}は根性で持ちこたえた！`);
        } else {
            enemy.hp = Math.max(0, enemy.hp - poisonDamage);
        }
        enemyPoisonTurns--;
        addLog(`毒ダメージ！${enemy.name}に${poisonDamage}のダメージ（残り${enemyPoisonTurns}回）`);
        updateHP();
    }
    if (myDefDebuffTurns > 0) {
        myDefDebuffTurns--;
        if (myDefDebuffTurns === 0) {
            myDefDebuff = 0;
            addLog("防御低下から回復した。");
        }
    }
    // 敵のデバフターンを減らす
    if (enemySpeedDebuffTurns > 0) {
        enemySpeedDebuffTurns--;
        if (enemySpeedDebuffTurns === 0) {
            enemySpeedDebuff = 0;
            addLog("敵の速度低下が回復した。");
        }
    }
    if (enemyAtkDebuffTurns > 0) {
        enemyAtkDebuffTurns--;
        if (enemyAtkDebuffTurns === 0) {
            enemyAtkDebuff = 0;
            addLog("敵の攻撃力低下が回復した。");
        }
    }
    if (enemyDefDebuffTurns > 0) {
        enemyDefDebuffTurns--;
        if (enemyDefDebuffTurns === 0) {
            enemyDefDebuff = 0;
            addLog("敵の防御力低下が回復した。");
        }
    }
    if (enemyAccuracyDebuffTurns > 0) {
        enemyAccuracyDebuffTurns--;
        if (enemyAccuracyDebuffTurns === 0) {
            enemyAccuracyDebuff = 0;
            addLog("敵の命中率低下が回復した。");
        }
    }
    if (mySpeedBuffTurns > 0) {
        mySpeedBuffTurns--;
        if (mySpeedBuffTurns === 0) {
            mySpeedBuff = 0;
            addLog("自身の速度上昇が終了した。");
        }
    }
    if (myDodgeTurns > 0) {
        myDodgeTurns--;
        if (myDodgeTurns === 0) {
            myDodgeChance = 0;
            addLog("回避率上昇が終了した。");
        }
    }
    if (myCounterTurns > 0) {
        myCounterTurns--;
        if (myCounterTurns === 0) {
            myCounterActive = false;
            addLog("反撃態勢が終了した。");
        }
    }

    // デバフ・バフの残りターンや値がここで変化するため、
    // ステータス表示（画面上の攻撃・防御・速さの数値）もあわせて更新する。
    if (typeof updateStats === 'function') updateStats();
}

function handleBotAnswer(userAnswer) {
    let usedSkill = null;
    // consumeSelectedSkill が定義されているか確認し、未定義の場合は警告を出す
    if (typeof consumeSelectedSkill === 'function') {
        usedSkill = consumeSelectedSkill();
    } else {
        // このエラーは、古いJSファイルがキャッシュされている場合に発生する可能性が高いです
        console.error("Critical Error: consumeSelectedSkill() is not defined. This might be a caching issue. Please clear your browser cache and reload (Ctrl+Shift+R).");
    }
    const skillEffect = (usedSkill && usedSkill.effect) || {};
    applyInstantSkillEffects(skillEffect);
    // このスキルを使用済みとして記録し、戦闘中は再度使用できないようにする
    if (usedSkill) {
        afterSkillUse(usedSkill);
    }

    const isCorrect = userAnswer.trim() === currentQuestion.answer;
    const answerTime = Date.now() - questionStartTime;

    if (isCorrect) {
        addLog("正解！回答時間: " + (answerTime / 1000).toFixed(2) + "秒");
        showCorrectEffect();

        // 必殺技ゲージの初期化（存在しない場合）
        if (!me.ultimateGauge) {
            me.ultimateGauge = { current: 0, max: 100 };
        }
        if (!enemy.ultimateGauge) {
            enemy.ultimateGauge = { current: 0, max: 100 };
        }

        // 必殺技ゲージを増加（コマンドの選択に関わらず、正解すれば貯まる）
        me.ultimateGauge.current = Math.min(me.ultimateGauge.max, me.ultimateGauge.current + 20);
        updateUltimateGauge();

        // ボット戦の場合はコマンド選択UIを表示して、プレイヤーに選ばせる
        if (isBotBattle) {
            // ここで即座に攻撃を確定させず、プレイヤーに「攻撃・特殊・防御・必殺技」を選ばせる。
            // 選択後の実際の処理は resolvePlayerCommand() で行う。
            pendingSkillEffect = skillEffect;
            pendingUsedSkill = usedSkill;
            showCommandMenu();
            return;
        } else {
            // オンライン/パーティ戦の場合は、正解後にコマンドを選択させる
            pendingSkillEffect = skillEffect;
            pendingUsedSkill = usedSkill;
            showCommandMenu();
            return;
        }
    } else {
        handleWrongAnswer(skillEffect);
    }
}

/**
 * 「攻撃・特殊・防御・必殺技」のコマンド選択メニューを表示する。
 * 必殺技はゲージが満タンの時のみ選択可能。
 */
function showCommandMenu() {
    const commandMenu = document.getElementById('commandMenu');
    if (!commandMenu) {
        return;
    }
    commandMenu.style.display = 'block';
    document.querySelectorAll('#commandMenu .btn-command').forEach(btn => btn.classList.remove('selected'));
    document.getElementById('cmdAttackBtn')?.classList.add('selected');

    const ultimateBtn = document.getElementById('cmdUltimateBtn');
    const isUltimateReady = isBotBattle
        ? (me.ultimateGauge && me.ultimateGauge.current >= me.ultimateGauge.max)
        : myUltimateReady;
    if (ultimateBtn) {
        ultimateBtn.disabled = !isUltimateReady;
        ultimateBtn.title = isUltimateReady ? '' : '必殺技ゲージが満タンの時のみ選択できます';
    }

    // スキルはこのコマンド選択のタイミングでも選び直せるようにしておく
    if (typeof enableSkillButtons === 'function') {
        enableSkillButtons(true);
    }

    // 実戦形式チュートリアル：初めて正解した時だけ、コマンドの選び方を教える
    if (isPracticeTutorial && !practiceCoachShown.command && window.PracticeCoach) {
        practiceCoachShown.command = true;
        window.PracticeCoach.point(
            commandMenu,
            "正解！ここから行動を選ぼう。\nまずは「攻撃」を試してみよう。選ぶとすぐに行動が確定するよ。",
            { buttonLabel: 'わかった' }
        );
    }
}

function hideCommandMenu() {
    const commandMenu = document.getElementById('commandMenu');
    if (commandMenu) commandMenu.style.display = 'none';
}

/**
 * 相手（または他のパーティメンバー）が先にこの問題に正解した場合、
 * 自分側の回答UIをロックする。次の問題が届く（displayQuestion）まで
 * 選択肢は押せなくなる。
 */
function lockAnsweringForRound() {
    if (bossAutoAnswerTimer) {
        clearTimeout(bossAutoAnswerTimer);
        bossAutoAnswerTimer = null;
    }
    stopTimer();
    const buttons = choicesContainer.querySelectorAll('.choice-btn');
    buttons.forEach(btn => btn.disabled = true);
    enableSkillButtons(false);
    questionDisplay.textContent = "相手が正解しました。結果を待っています...";
}

/**
 * プレイヤーがコマンド（攻撃/特殊/防御/必殺技）を選択した時に呼ばれる。
 * @param {'attack'|'special'|'defend'|'ultimate'} command
 */
function resolvePlayerCommand(command) {
    hideCommandMenu();

    // コマンド選択の直前にスキルが選び直された場合、そちらを優先して反映する
    let usedSkill = pendingUsedSkill;
    let skillEffect = pendingSkillEffect || {};
    if (typeof selectedSkill !== 'undefined' && selectedSkill && (!usedSkill || selectedSkill.id !== usedSkill.id)) {
        usedSkill = typeof consumeSelectedSkill === 'function' ? consumeSelectedSkill() : selectedSkill;
        skillEffect = (usedSkill && usedSkill.effect) || {};
        applyInstantSkillEffects(skillEffect);
        if (usedSkill) afterSkillUse(usedSkill);
    }
    pendingUsedSkill = null;
    pendingSkillEffect = null;

    if (command === 'ultimate' && !(me.ultimateGauge && me.ultimateGauge.current >= me.ultimateGauge.max)) {
        // ゲージ不足時は誤操作防止のため通常攻撃にフォールバック
        command = 'attack';
    }

    // オンライン/パーティ戦の場合はサーバーにコマンドを送信
    if (!isBotBattle) {
        socket.emit("battle:submitCommand", { command });
        selectedCommand = 'attack'; // 次のターンのためにリセット
        return;
    }

    // ボット戦の場合はローカルで処理
    if (command === 'defend') {
        addLog(`${me.name}は防御の構えを取った！`);
        myPendingDamageReduction = Math.max(myPendingDamageReduction, 0.5);
        updateHP();
        updateUltimateGauge();
        continueBattleLoop();
        return;
    }

    let attackerAtk = (command === 'special' || skillEffect.useSpecialStat) ? (me.special || me.atk) : me.atk;

        // 敵の攻撃デバフ適用（自分が攻撃する場合）
        if (enemyAtkDebuff > 0) {
            // 敵の攻撃デバフは敵の攻撃力に適用されるので、ここでは適用しない
            // 敵の攻撃デバフは敵が攻撃する時に適用される
        }

        if (me.hp === 1 && hasUniqueAbility(me, 'guts')) {
            attackerAtk = Math.floor(attackerAtk * 3);
            addLog(`${me.name}の攻撃力が根性で3倍に！`);
        }

        // 大器晩成（berserker_state）：HPが50%以下の時、攻撃力が1.3倍になる
        if (hasUniqueAbility(me, 'berserker_state') && me.hp <= me.maxHp * 0.5) {
            attackerAtk = Math.floor(attackerAtk * 1.3);
            addLog(`${me.name}の攻撃力が大器晩成で1.3倍に！`);
        }
        
        // 必殺技名を取得
        const ultimateName = getWeaponUltimateName(me.equippedWeapon);
        if (command === 'ultimate') {
            // ログは下の発動判定でまとめて出す
        } else if (me.ultimateGauge.current >= me.ultimateGauge.max) {
            addLog("必殺技ゲージMAX！「" + ultimateName + "」が選択可能です！");
        }
        
        // ユニーク能力適用
        let enemyDef = enemy.def || 0;

        // 敵の防御デバフ適用
        if (enemyDefDebuff > 0) {
            enemyDef = Math.floor(enemyDef * (1 - enemyDefDebuff));
        }

        // 貫通
        if (hasUniqueAbility(me, 'ignore_def_half')) {
            enemyDef = Math.floor(enemyDef * 0.5);
        }

        // スキルによる防御無視
        if (skillEffect.ignoreDef || skillEffect.pierceDef || skillEffect.defenseIgnore) {
            enemyDef = 0;
            addLog("相手の防御を無視した！");
        }
        
        const defReduction = Math.floor(enemyDef * 0.1); // ダメージ計算式がatk*0.5と低めなので、防御効果も低めに
        let damage = Math.max(1, Math.floor(attackerAtk * 0.5) - defReduction);
        
        // 素早さによる補正（45%回避まで、それ以降は攻撃少しアップ）
        // スキルによる自身の速さ上昇（mySpeedBuff）も反映する
        const mySpeed = Math.floor((me.speed || 0) * (1 + (mySpeedBuff || 0)) * (hasUniqueAbility(me, 'speed_boost') ? 1.25 : 1));
        const dodgeChance = calculateDodgeChance(mySpeed);
        
        // 45%を超える分は攻撃ボーナスに変換
        if (mySpeed > 750000) {
            const excessSpeed = mySpeed - 750000;
            const attackBonus = Math.floor(excessSpeed * 0.001); // 超過分の0.1%を攻撃ボーナス
            damage += attackBonus;
        }
        
        // 必殺技発動判定（「必殺技」コマンドを選んだ場合のみ）
        let ultimateActivated = false;
        if (command === 'ultimate') {
            // 覚醒（ultimate_boost）を持っている場合、必殺技のダメージ倍率が2.0倍になる
            const ultimateMultiplier = hasUniqueAbility(me, 'ultimate_boost') ? 2.0 : 1.5;
            damage = Math.floor(damage * ultimateMultiplier);
            ultimateActivated = true;
            addLog("必殺技「" + ultimateName + "」発動！ダメージ" + ultimateMultiplier + "倍！");
            showUltimateEffect();
            // 必殺技発動後、ゲージをリセット
            me.ultimateGauge.current = 0;
            updateUltimateGauge();
        } else if (command === 'special') {
            addLog("特殊攻撃！");
        }
        
        // クリティカル判定：常時 BASE_CRIT_CHANCE（5%）の確率で発生する。
        // 「必殺」の固有能力を武器に持っている場合は基本率が CRITICAL_ABILITY_CRIT_CHANCE（30%）まで上がる。
        // スキルツリーの「クリティカルルート」で得た critChance / critMultiplier もここに加算される。
        // 「会心の初撃」（first_strike_crit）を持っている場合、戦闘最初の攻撃は必ずクリティカルになる。
        const isForcedFirstStrikeCrit = hasUniqueAbility(me, 'first_strike_crit') && !myFirstAttackDone;
        myFirstAttackDone = true;
        const critBaseChance = hasUniqueAbility(me, 'critical_damage') ? CRITICAL_ABILITY_CRIT_CHANCE : BASE_CRIT_CHANCE;
        const totalCritChance = Math.min(1, critBaseChance + (me.critChance || 0));
        if (isForcedFirstStrikeCrit || Math.random() < totalCritChance) {
            // 会心の一撃（crit_damage_boost）を持っている場合、クリティカル倍率が2.2倍になる
            const critMultiplier = hasUniqueAbility(me, 'crit_damage_boost')
                ? 2.2
                : (BASE_CRIT_MULTIPLIER + (me.critMultiplier || 0));
            damage = Math.floor(damage * critMultiplier);
            if (isForcedFirstStrikeCrit) {
                addLog(`会心の初撃！ダメージ${critMultiplier.toFixed(2)}倍！`);
            } else {
                addLog(`クリティカル発動！ダメージ${critMultiplier.toFixed(2)}倍！`);
            }
        }
        
        // スキル効果を適用（新しいスキルシステム）
        damage = applySkillEffect(damage, me, enemy, usedSkill);
        
        // 多段攻撃（新しいmyMultiHitシステムと統合。スキルごとの1撃あたり倍率(myMultiHitMultiplier)を使う）
        const multiHitCount = myMultiHit > 0 ? myMultiHit : 1;
        if (multiHitCount > 1) {
            const perHitRate = myMultiHitMultiplier || 0.6;
            damage = Math.max(1, Math.floor(damage * perHitRate)) * multiHitCount;
            addLog(`${multiHitCount}連撃！`);
            
            // myMultiHitターンを減らす
            if (myMultiHit > 0) {
                myMultiHitTurns--;
                if (myMultiHitTurns <= 0) {
                    myMultiHit = 0;
                    myMultiHitMultiplier = 0.6;
                }
            }
        }
        
        // 「行動できない」デメリット
        if (mySkipThisTurn) {
            mySkipThisTurn = false;
            damage = 0;
            addLog(`${me.name}は身を固めていて攻撃できない！`);
        }

        // ボスが直前に得た「次のダメージ軽減」バリアを消費する
        if (enemyNextDamageShield > 0 && damage > 0) {
            damage = Math.max(0, Math.floor(damage * (1 - enemyNextDamageShield)));
            addLog(`${enemy.name}のバリアでダメージが軽減された！`);
            enemyNextDamageShield = 0; // 使い切り
        }
        
        // 回避判定（敵の回避率）
        // デバッグ用「必中・即死」武器を装備している場合は、回避判定を無視して確実にトドメを刺す
        const isDebugInstantKill = me.equippedWeapon && me.equippedWeapon.debugInstantKill;
        if (isDebugInstantKill) {
            damage = Math.max(damage, enemy.hp, enemy.maxHp || enemy.hp, 1);
        }
        const enemyDodgeChance = calculateDodgeChance(enemy.speed);
        const dodgeRoll = Math.random() * 100;
        if (damage <= 0) {
            showDamage("enemyDamage", 0);
        } else if (!isDebugInstantKill && !skillEffect.sureHit && !hasUniqueAbility(me, 'ignore_evasion') && dodgeRoll < enemyDodgeChance) {
            showDamage("enemyDamage", 0);
            addLog("回避！ダメージなし");
            damage = 0;
        } else {
            if (isDebugInstantKill) {
                addLog("【デバッグ】必中・即死効果で確実にトドメを刺した！");
            } else if ((skillEffect.sureHit || hasUniqueAbility(me, 'ignore_evasion')) && dodgeRoll < enemyDodgeChance) {
                addLog("必中効果で回避を許さなかった！");
            }
            if (!isDebugInstantKill && enemy.hp - damage <= 0 && enemy.hp > 1 && hasUniqueAbility(enemy, 'guts')) {
                enemy.hp = 1;
                addLog(`${enemy.name}は根性で持ちこたえた！`);
            } else {
                enemy.hp = Math.max(0, enemy.hp - damage);
            }
            showDamage("enemyDamage", damage);
            addLog("ボットにダメージ: " + damage);

            // 猛毒の一撃（poison_on_hit）：相手に3ターンの毒を付与（100%）
            if (hasUniqueAbility(me, 'poison_on_hit') && enemy.hp > 0) {
                enemyPoisonTurns = 3;
                addLog(`猛毒の一撃！${enemy.name}に毒を付与した！`);
            }
            // 灼熱の一撃（burn_on_hit）：相手に3ターンの火傷を付与（100%）
            if (hasUniqueAbility(me, 'burn_on_hit') && enemy.hp > 0) {
                enemyBurnTurns = 3;
                addLog(`灼熱の一撃！${enemy.name}に火傷を付与した！`);
            }
        }
        
        // スキルによるHP吸収
        if (skillEffect.lifeSteal && damage > 0) {
            const stolen = Math.floor(damage * skillEffect.lifeSteal);
            if (stolen > 0) {
                me.hp = Math.min(me.maxHp, me.hp + stolen);
                addLog(`HP吸収！${stolen}回復`);
            }
        }
        
        // ライフドレイン（与えたダメージの20%分回復）
        if (hasUniqueAbility(me, 'life_drain') && damage > 0) {
            const healAmount = Math.floor(damage * 0.2);
            me.hp = Math.min(me.maxHp, me.hp + healAmount);
            addLog("ライフドレイン発動！" + healAmount + "回復");
        }
        
        updateHP();
        updateUltimateGauge();
        
        // 勝利判定
        if (enemy.hp <= 0) {
            finishBotBattle("win");
        } else {
            // 即座に次の問題へ（ボス戦のATBループ中なら自分のゲージをリセットして自動進行に戻す）
            continueBattleLoop();
        }
}

function handleWrongAnswer(skillEffect) {
        addLog("不正解...");
        // 模擬戦闘では、不正解でもダメージを受けない
        if (isMockBattle) return;
        
        // 依頼により、不正解時は自分のHPの半分を失う（ダンジョンに限らず統一ルール）。
        // 以前は敵の攻撃力ベースで計算していたが、敵が弱いとダメージが1〜2程度に
        // 丸め込まれてしまい「ペナルティが無い」ように見えてしまっていたため撤廃し、
        // 常に自分の現在HPの半分を基準にする（回避判定も行わない）。
        let damage = Math.max(1, Math.floor(me.hp / 2));
        
        // ボス戦の場合、ボスがスキルを使うことがある
        let bossUsedSkillOnMiss = null;
        if (isBossBattle && enemy.skills && enemy.skills.length > 0) {
            // 30%の確率でスキル使用
            if (Math.random() < 0.3) {
                bossUsedSkillOnMiss = enemy.skills[Math.floor(Math.random() * enemy.skills.length)];
                damage = applyBossSkillEffect(damage, enemy, me, bossUsedSkillOnMiss);
            }
        }

        // 鉄壁（相手からの攻撃のダメージ50%カット）
        if (hasUniqueAbility(me, 'damage_cut_half')) {
            damage = Math.floor(damage * 0.5);
            addLog("鉄壁発動！ダメージ50%カット");
        }
        
        // スキルによるダメージ軽減
        damage = applyIncomingDamageReduction(damage);

        {
            if (me.hp - damage <= 0 && me.hp > 1 && hasUniqueAbility(me, 'guts')) {
                me.hp = 1;
                addLog(`${me.name}は根性で持ちこたえた！`);
            } else {
                me.hp = Math.max(0, me.hp - damage);
            }
            showDamage("myDamage", damage);
            addLog("ダメージを受けた: " + damage);

            // 棘の鎧（damage_reflect）：受けたダメージの15%を相手に反射する
            if (hasUniqueAbility(me, 'damage_reflect') && damage > 0) {
                const reflectDamage = Math.max(1, Math.floor(damage * 0.15));
                enemy.hp = Math.max(0, enemy.hp - reflectDamage);
                addLog(`棘の鎧で${enemy.name}に${reflectDamage}のダメージを反射！`);
                showDamage("enemyDamage", reflectDamage);
            }
        }
        
        updateHP();
        
        // 勝利判定
        if (me.hp <= 0 && !tryReviveMe()) {
            finishBotBattle("lose");
            return;
        }
        
        // ボットが回答するチャンス
        setTimeout(() => {
            const botAnswerTime = Math.random() * 2000 + 500; // 0.5-2.5秒に短縮
            let botAccuracy = botDifficulty ? botDifficulty.accuracy : 0.85; // 計算された正解率を使用

            // 敵の命中率デバフ適用
            if (enemyAccuracyDebuff > 0) {
                botAccuracy = Math.max(0.1, botAccuracy * (1 - enemyAccuracyDebuff));
            }

            const botIsCorrect = Math.random() < botAccuracy;

            if (botIsCorrect) {
                addLog("ボットが正解！回答時間: " + (botAnswerTime / 1000).toFixed(2) + "秒");
                
                // ユニーク能力適用（防御側）
                let myDef = Math.max(0, (me.def || 0) - myDefDebuff);

                let botAtk = enemy.atk;

                // 敵の攻撃デバフ適用
                if (enemyAtkDebuff > 0) {
                    botAtk = Math.floor(botAtk * (1 - enemyAtkDebuff));
                }

                if (enemy.hp === 1 && hasUniqueAbility(enemy, 'guts')) {
                    botAtk = Math.floor(botAtk * 3);
                    addLog(`${enemy.name}の攻撃力が根性で3倍に！`);
                }
                
                const defReduction = Math.floor(myDef * 0.1);
                let damage = Math.max(1, Math.floor(botAtk * 0.5) - defReduction);
                
                // Boss skill usage logic
                let bossUsedSkill = null;
                if (isBossBattle && enemy.skills && enemy.skills.length > 0) {
                    // 50% chance to use a skill
                    if (Math.random() < 0.5) {
                        bossUsedSkill = enemy.skills[Math.floor(Math.random() * enemy.skills.length)];
                        damage = applyBossSkillEffect(damage, enemy, me, bossUsedSkill);
                    }
                }

                // 素早さによる補正（ボット側）
                const enemyDodgeChance = calculateDodgeChance(enemy.speed);
                
                // 45%を超える分は攻撃ボーナスに変換
                if (enemy.speed > 750000) {
                    const excessSpeed = enemy.speed - 750000;
                    const attackBonus = Math.floor(excessSpeed * 0.001);
                    damage += attackBonus;
                }
                
                // 鉄壁適用
                if (hasUniqueAbility(me, 'damage_cut_half')) {
                    damage = Math.floor(damage * 0.5);
                    addLog("鉄壁発動！ダメージ50%カット");
                }
                
                // スキルによるダメージ軽減
                damage = applyIncomingDamageReduction(damage);
                
                // 回避判定（プレイヤーの回避率）
                // 「残像」（self_evasion_boost）を持っている場合、回避率+15%
                const myDodgeChance = calculateDodgeChance(me.speed) + (hasUniqueAbility(me, 'self_evasion_boost') ? 15 : 0);
                const dodgeRoll = Math.random() * 100;
                if (dodgeRoll < myDodgeChance) {
                    showDamage("myDamage", 0);
                    addLog("回避！ダメージなし");
                } else {
                    if (me.hp - damage <= 0 && me.hp > 1 && hasUniqueAbility(me, 'guts')) {
                        me.hp = 1;
                        addLog(`${me.name}は根性で持ちこたえた！`);
                    } else {
                        me.hp = Math.max(0, me.hp - damage);
                    }
                    showDamage("myDamage", damage);
                    addLog("ボットからのダメージ: " + damage);

                    // 棘の鎧（damage_reflect）：受けたダメージの15%を相手に反射する
                    if (hasUniqueAbility(me, 'damage_reflect') && damage > 0) {
                        const reflectDamage = Math.max(1, Math.floor(damage * 0.15));
                        enemy.hp = Math.max(0, enemy.hp - reflectDamage);
                        addLog(`棘の鎧で${enemy.name}に${reflectDamage}のダメージを反射！`);
                        showDamage("enemyDamage", reflectDamage);
                    }
                }
                
                updateHP();
                
                // 勝利判定
                if (me.hp <= 0 && !tryReviveMe()) {
                    finishBotBattle("lose");
                } else if (me.hp > 0) {
                    // 即座に次の問題へ
                    setTimeout(generateBotQuestion, 1000);
                }
            } else {
                addLog("ボットは不正解...");
                // 両方不正解の場合、次の問題へ
                setTimeout(generateBotQuestion, 1000);
            }
        }, 500);
}

function finishBotBattle(result) {
    // 模擬戦闘の場合はリザルト画面へ遷移せず、勝敗に応じて戦闘を継続する
    // （勝利：新しい敵が出現／敗北：HP全回復して続行）。battleEndも立てない。
    if (isMockBattle) {
        if (typeof handleMockBattleRoundEnd === "function") {
            handleMockBattleRoundEnd(result);
        }
        return;
    }

    if (battleEnd) return;
    battleEnd = true;
    if (timerInterval) clearInterval(timerInterval);
    if (countdownInterval) clearInterval(countdownInterval);
    if (bossAutoAnswerTimer) clearTimeout(bossAutoAnswerTimer);
    if (atbInterval) { clearInterval(atbInterval); atbInterval = null; }

    const buttons = choicesContainer.querySelectorAll('.choice-btn');
    buttons.forEach(btn => btn.disabled = true);

    const win = result === "win";
    addLog(win ? I18N.victory : I18N.defeat);

    console.log(`[Battle] finishBotBattle: result=${result}, win=${win}, equippedWeapon=${me.equippedWeapon?.name}, isBossBattle=${isBossBattle}, isDungeonBattle=${isDungeonBattle}`);

    localStorage.setItem("battleResult", win ? "win" : "lose");
    localStorage.setItem("playerHP", String(me.hp));
    localStorage.setItem("enemyHP", String(enemy.hp));
    // デバッグ武器は奪えない

    // ボット戦での素材ドロップ処理
    // ショップで購入した武器（isOriginalではない通常の武器）を装備している場合は、
    // 依頼により素材ドロップを確定（100%）にする。オリジナル武器・ボス武器などは対象外。
    // 素材ドロップは、以前の 1/20（0.05）。ここを変えれば全体の素材の出やすさが変わる
    const MATERIAL_DROP_MUL = 0.05;
    if (win && enemy.isBot && enemy.materialDrops) {
        const isShopWeaponEquipped = !!(me.equippedWeapon && !me.equippedWeapon.isOriginal && !me.equippedWeapon.isDebugWeapon);
        enemy.materialDrops.forEach(drop => {
            if (Math.random() < (isShopWeaponEquipped ? 1 : drop.chance) * MATERIAL_DROP_MUL) {
                localStorage.setItem("droppedMaterial", drop.materialId);
                addLog(`${enemy.name}から${MATERIAL_DATA[drop.materialId].name}を入手！`);
            }
        });
    }

    if (win && enemy.equippedWeapon && !enemy.equippedWeapon.isDebugWeapon) {
        localStorage.setItem("stolenWeapon", JSON.stringify(enemy.equippedWeapon));
    }
    localStorage.removeItem("rewardsApplied"); // 報酬フラグをクリア（次のバトルのために）

    // ダンジョンバトルの場合はリザルト画面へ
    if (isDungeonBattle) {
        localStorage.setItem("dungeonBattleResult", win ? "win" : "lose");
        localStorage.setItem("dungeonPlayerHP", String(me.hp));
        setTimeout(() => location.href = "result.html", 2000);
        return;
    }

    if (isPracticeTutorial && window.PracticeCoach) {
        // 練習バトルの場合は、閉じるボタンを押すまで結果画面への遷移を待つ
        window.PracticeCoach.finish(
            win
                ? "問題に答えて、コマンドを選ぶ。これがバトルの基本の流れだよ。\nこの調子でオンライン対戦にも挑戦してみよう！"
                : "負けてしまったけど、操作の流れはつかめたはず。\nもう一度練習するか、オンライン対戦に挑戦してみよう！"
        );
        setTimeout(() => location.href = "result.html", 4000);
    } else {
        setTimeout(() => location.href = "result.html", 2000);
    }
}

// ===================================
// ダンジョン次の階へ進む処理
// ===================================
function handleDungeonNextFloor() {
    if (!window.socket) {
        console.error('Socket not connected for dungeon progression');
        alert('接続エラーです。ホーム画面に戻ります。');
        location.href = 'index.html';
        return;
    }
    
    addLog('次の階へ進んでいます...');
    
    window.socket.emit('dungeon:floorCleared', {}, (response) => {
        if (response.error) {
            alert(`エラー: ${response.error}`);
            location.href = 'index.html';
            return;
        }
        
        if (response.cleared) {
            // ダンジョンクリア
            alert(`🎉 ダンジョンクリア！\n報酬を獲得しました！`);
            localStorage.removeItem('dungeonData');
            localStorage.removeItem('isDungeonBattle');
            location.href = 'index.html';
        } else {
            // 次の階へ
            addLog(`第${response.dungeon.currentFloor}階に到達！`);
            
            // ダンジョンデータを更新
            localStorage.setItem('dungeonData', JSON.stringify({
                dungeon: response.dungeon,
                currentMonsters: response.nextMonsters
            }));
            
            // 敵データを更新
            const nextEnemy = response.nextMonsters[0];
            if (nextEnemy) {
                localStorage.setItem('enemy', JSON.stringify(nextEnemy));
            }
            
            // プレイヤーデータを更新（HP回復など）
            const playerHP = parseInt(localStorage.getItem('dungeonPlayerHP')) || me.hp;
            me.hp = playerHP;
            localStorage.setItem('battlePlayer', JSON.stringify(me));
            
            // 戦闘をリセットして再開
            resetDungeonBattle();
        }
    });
}

// ===================================
// ダンジョンバトルリセット
// ===================================
function resetDungeonBattle() {
    // 戦闘状態をリセット
    battleEnd = false;
    myPhoenixUsed = false; // 不死鳥の加護は「1戦闘に1回」なので、次の階（次の戦闘）では使えるように戻す
    currentQuestion = null;
    questionStartTime = null;
    
    // UIをリセット
    choicesContainer.innerHTML = '';
    questionDisplay.textContent = '次の敵が現れた！';
    
    // 敵のHPを更新
    const dungeonDataJSON = localStorage.getItem('dungeonData');
    if (dungeonDataJSON) {
        const dungeonData = JSON.parse(dungeonDataJSON);
        const nextEnemy = dungeonData.currentMonsters[0];
        if (nextEnemy) {
            enemy = nextEnemy;
            updateEnemyUI();
        }
    }
    
    // プレイヤーのHPを更新
    updatePlayerUI();
    
    // カウントダウン開始
    setTimeout(() => {
        showCountdown(() => {
            generateBotQuestion();
        });
    }, 1000);
}

// ===================================
// 敵UI更新
// ===================================
function updateEnemyUI() {
    if (!enemy) return;
    
    enemyName.textContent = enemy.name;
    enemyHPText.textContent = `HP ${enemy.hp} / ${enemy.maxHp}`;
    enemyHPBar.style.width = `${(enemy.hp / enemy.maxHp) * 100}%`;
    
    enemyAtk.textContent = `攻撃:${enemy.atk}`;
    enemyDef.textContent = `防御:${enemy.def}`;
    enemySpeed.textContent = `速さ:${enemy.speed}`;
    enemySpecial.textContent = `特殊:${enemy.special || '-'}`;
    enemyGrade.textContent = `学年:${enemy.grade || '-'}`;
}

// ===================================
// プレイヤーUI更新
// ===================================
function updatePlayerUI() {
    if (!me) return;
    
    myHPText.textContent = `HP ${me.hp} / ${me.maxHp}`;
    myHPBar.style.width = `${(me.hp / me.maxHp) * 100}%`;
    
    myAtk.textContent = `攻撃:${me.atk}`;
    myDef.textContent = `防御:${me.def}`;
    mySpeed.textContent = `速さ:${me.speed}`;
    mySpecial.textContent = `特殊:${me.special || '-'}`;
    myGrade.textContent = `学年:${me.grade || '-'}`;
}

function showCountdown(callback) {
    let count = 3;
    questionDisplay.textContent = count;
    questionDisplay.style.fontSize = "3rem";
    questionDisplay.style.fontWeight = "bold";
    questionDisplay.style.textAlign = "center";

    if (countdownInterval) clearInterval(countdownInterval);

    countdownInterval = setInterval(() => {
        count--;
        if (count > 0) {
            questionDisplay.textContent = count;
        } else if (count === 0) {
            questionDisplay.textContent = "GO!!";
            questionDisplay.style.color = "#ff6b6b";
        } else {
            clearInterval(countdownInterval);
            questionDisplay.style.fontSize = "";
            questionDisplay.style.fontWeight = "";
            questionDisplay.style.textAlign = "";
            questionDisplay.style.color = "";
            callback();
        }
    }, 1000);
}

function stopTimer() {
    if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
    }
}

function syncBattleState(stateUpdate) {
    console.log("syncBattleState called with stateUpdate:", stateUpdate);

    for (const id in stateUpdate) {
        const data = stateUpdate[id];
        if (id === me.id) {
            // 自分
            if (data.hp !== undefined) me.hp = data.hp;
            if (data.maxHp !== undefined) me.maxHp = data.maxHp;
            if (data.ultimateGauge !== undefined) {
                me.ultimateGauge = data.ultimateGauge;
                myUltimateReady = typeof me.ultimateGauge === 'object'
                    ? me.ultimateGauge.current >= me.ultimateGauge.max
                    : false;
            }
            if (data.gaugeCount !== undefined) playerCorrectCount = data.gaugeCount;
            if (data.gaugeRequired !== undefined) playerRequiredCount = data.gaugeRequired;
        } else if (id === enemy.id) {
            // 敵
            if (data.hp !== undefined) enemy.hp = data.hp;
            if (data.maxHp !== undefined) enemy.maxHp = data.maxHp;
            if (data.ultimateGauge !== undefined) enemy.ultimateGauge = data.ultimateGauge;
            if (data.gaugeCount !== undefined && data.gaugeRequired) {
                enemyATB = Math.min(100, (data.gaugeCount / data.gaugeRequired) * 100);
            }
        } else {
            // 味方
            const ally = allies.find(a => a.id === id);
            if (ally) {
                if (data.hp !== undefined) ally.hp = data.hp;
                if (data.maxHp !== undefined) ally.maxHp = data.maxHp;
            }
        }
    }
    
    console.log("Synced me.hp:", me.hp, "me.maxHp:", me.maxHp);
    console.log("Synced enemy.hp:", enemy.hp, "enemy.maxHp:", enemy.maxHp);
    
    localStorage.setItem("battlePlayer", JSON.stringify(me));
    localStorage.setItem("enemy", JSON.stringify(enemy));
    updateHP();
    updateUltimateGauge();
    if (!isBossBattle) {
        playerATB = Math.min(100, playerRequiredCount ? (playerCorrectCount / playerRequiredCount) * 100 : 0);
        updateATBBars();
    }
    
    // HPが0になった場合は即座にバトル終了チェック
    if (me.hp <= 0 || enemy.hp <= 0) {
        // 終了処理はサーバーからの'battle:finished'イベントに任せる
        console.log("HP reached zero, waiting for server to finish battle.");
    }
}

function finishBattle(winner) {
    if (battleEnd) return;
    battleEnd = true;
    stopTimer();
    
    const buttons = choicesContainer.querySelectorAll('.choice-btn');
    buttons.forEach(btn => btn.disabled = true);

    // レイドボス戦の場合、winnerは 'party'（パーティ全員の勝利）か、ボスのID（敗北）になる
    const win = winner === me.id || winner === 'party';
    addLog(win ? I18N.victory : I18N.defeat);
    
    localStorage.setItem("battleResult", win ? "win" : "lose");
    localStorage.setItem("playerHP", String(me.hp));
    localStorage.setItem("enemyHP", String(enemy.hp));

    // セーフモードチェック
    const isSafeMode = localStorage.getItem("safeMode") === "true";
    
    // デバッグ武器のみ奪えない（セーフモードの場合も奪わない）
    if (win && enemy.equippedWeapon && !enemy.equippedWeapon.isDebugWeapon && !isSafeMode) {
        localStorage.setItem("stolenWeapon", JSON.stringify(enemy.equippedWeapon));
    } else if (!win && me.equippedWeapon && !me.equippedWeapon.isDebugWeapon && !isSafeMode) {
        localStorage.setItem("lostWeapon", JSON.stringify(me.equippedWeapon));
    }
    
    // モンスターからの素材ドロップ処理
    if (win && enemy.isBot && enemy.monsterDrops) {
        const dropChance = 0.3; // 30%の確率でドロップ
        if (Math.random() < dropChance) {
            const droppedMaterial = enemy.monsterDrops[Math.floor(Math.random() * enemy.monsterDrops.length)];
            localStorage.setItem("droppedMaterial", droppedMaterial);
            addLog(`${enemy.monsterEmoji} ${enemy.monsterType}から${droppedMaterial}を入手！`);
        }
    }
    
    localStorage.removeItem("rewardsApplied"); // 報酬フラグをクリア（次のバトルのために）
    localStorage.removeItem("safeMode"); // セーフモードフラグをクリア
    
    setTimeout(() => location.href = "result.html", 2500);
}

if (!isBotBattle && socket) {
    let isFirstConnection = true;
    
    socket.on("connect", () => {
        console.log("Socket connected:", socket.id);
        addLog("サーバーに接続しました");
        
        // 初回接続時のみ、既存のバトルに再参加を試みる
        if (!isFirstConnection && roomId && me && me.id) {
            const p = getSavedPlayer();
            socket.emit("rejoinBattle", { roomId, oldPlayerId: me.id, player: p || me });
        }
        isFirstConnection = false;
    });

    socket.on("disconnect", () => {
        console.log("Socket disconnected");
        addLog("接続が切れました。再接続中...");
        
        // 自動的に再接続を試みる
        setTimeout(() => {
            if (!socket.connected) {
                addLog("再接続を試みています...");
                socket.connect();
            }
        }, 3000);
    });

    socket.on("connect_error", (error) => {
        console.error("Socket connection error:", error);
        addLog("接続エラー: " + error.message);
    });

    socket.on("reconnect", (attemptNumber) => {
        console.log("Socket reconnected after", attemptNumber, "attempts");
        addLog("再接続に成功しました");
        
        // 再接続後にバトルに再参加
        if (roomId && me && me.id) {
            const p = getSavedPlayer();
            socket.emit("rejoinBattle", { roomId, oldPlayerId: me.id, player: p || me });
        }
    });

    socket.on("reconnect_attempt", (attemptNumber) => {
        console.log("Reconnect attempt:", attemptNumber);
    });

    socket.on("reconnect_failed", () => {
        console.error("Reconnect failed");
        addLog("再接続に失敗しました。ページを再読み込みしてください。");
        alert("サーバーへの再接続に失敗しました。ページを再読み込みしてください。");
    });

    // ハートビートで接続を監視
    setInterval(() => {
        if (socket && !socket.connected) {
            console.warn("Socket disconnected, attempting to reconnect...");
            addLog("接続が切れています。再接続を試みます...");
        }
    }, 5000);

    socket.on("battleRejoined", data => {
        me = data.me;
        enemy = data.enemy;
        if (data.allies) allies = data.allies;
        rejoined = true;
        localStorage.setItem("battlePlayer", JSON.stringify(me));
        localStorage.setItem("enemy", JSON.stringify(enemy));
        updateStats();
        updateHP();
        addLog(I18N.reconnected);

        // 再接続前は「今答えるべき問題」が送られておらず、再接続した側だけ
        // 問題が更新されないまま止まってしまっていた（正解してもダメージが
        // 発生しない不具合の原因の一つ）。送られてきた問題を即座に出題し直す
        // （再開なのでカウントダウンは出さない）。
        if (data.question) {
            displayQuestion(data.question);
        }
    });

    socket.on("rejoinFailed", data => {
        alert(data && data.reason === "battle_finished" ? I18N.battleAlreadyEnd : I18N.rejoinFailed);
        location.href = "index.html";
    });

    // サーバーからの初期状態を受け取る
    socket.on('battle:initialState', (data) => {
        console.log('battle:initialState received', data);
        me = data.me;
        enemy = data.enemy;
        allies = data.allies || [];
        
        // UIを初期化
        renderPartyStatus();
        updateStats();
        updateHP();
        updateUltimateGauge();
        
        // 最初の問題を表示（ここだけカウントダウンを見せる）
        displayQuestion(data.question, true);
    });

    // 通常のPvP戦：自分専用の次の問題を受け取る（相手の問題は届かない）
    socket.on('battle:yourQuestion', (data) => {
        console.log('battle:yourQuestion received', data);
        if (data && data.question) {
            displayQuestion(data.question);
        }
    });

    // ボス・レイド戦：ボスの行動ゲージが満タンになり、攻撃の予備動作が始まったことの通知
    // （自分が狙われている時だけガードポップアップを出す）
    socket.on('battle:bossTelegraph', (data) => {
        console.log('battle:bossTelegraph received', data);
        if (!data) return;

        const isTargetingMe = data.targetId === me.id;
        const targetName = isTargetingMe ? me.name : ((allies.find(a => a.id === data.targetId) || {}).name || '仲間');
        addLog(`⚠️ ${data.bossName || enemy.name}が攻撃の構えを見せた！（狙われているのは${targetName}）`);

        if (!isTargetingMe) return;

        atbGuardWindowOpen = true;
        atbGuardActivated = false;

        const guardPopup = document.getElementById('atbGuardPopup');
        const guardBtn = document.getElementById('atbGuardBtn');
        if (guardPopup) guardPopup.style.display = 'flex';
        if (guardBtn) {
            guardBtn.disabled = false;
            guardBtn.classList.remove('guard-success');
        }

        setTimeout(() => {
            atbGuardWindowOpen = false;
            if (guardPopup) guardPopup.style.display = 'none';
        }, data.telegraphMs || 700);
    });

    socket.on('battle:update', (data) => {
        console.log('battle:update received', data);

        if (data.logs && Array.isArray(data.logs)) {
            data.logs.forEach(logMsg => addLog(logMsg));
        }

        if (data.damageEvents && Array.isArray(data.damageEvents)) {
            data.damageEvents.forEach(event => {
                let damageElId;
                if (event.targetId === me.id) {
                    damageElId = 'myDamage';
                } else if (event.targetId === enemy.id) {
                    damageElId = 'enemyDamage';
                } else {
                    damageElId = `allyDamage-${event.targetId}`;
                }
                showDamage(damageElId, event.dodged ? 0 : event.damage);
            });
        }

        // 強攻撃の自動発動処理
        if (data.autoStrongAttack && data.strongDamage) {
            addLog("行動ゲージが満タンになった！強攻撃発動！");
            addLog(`${data.playerName || me.name}の強攻撃！ ${enemy.name}に ${data.strongDamage} のダメージ！`);
        }

        if (data.effectEvents && Array.isArray(data.effectEvents)) {
            data.effectEvents.forEach(event => {
                if (event.type === 'ultimate' && (event.playerId === me.id || event.playerId === enemy.id || allies.some(a => a.id === event.playerId))) {
                    showUltimateEffect();
                }
                if (event.type === 'correct' && event.playerId === me.id) {
                    showCorrectEffect();
                    // 行動ゲージが満タンになった時は強攻撃が自動発動するため、コマンドメニューは出さない
                }
            });
        }

        // 通常のPvP戦：行動ゲージが満タンになった時は強攻撃が自動発動するため、コマンドメニューは出さない

        // 誰か（自分以外）がこの問題に正解し、コマンド選択中になった場合、
        // 自分はこの問題にはもう回答できないようにする（二重回答の防止）。
        // 以前はこの通知が無く、正解者がコマンドを選んでいる間も、
        // まだ回答していない側のプレイヤーが問題に回答できてしまっていた。
        if (data.roundLockedBy && data.roundLockedBy !== me.id) {
            lockAnsweringForRound();
        }

        if (data.stateUpdate) {
            syncBattleState(data.stateUpdate);
        }

        // サーバーは「そのバトル共有の次の問題」をそのまま送ってくる（forPlayerIdは付与されない）。
        // 以前は data.nextQuestion.forPlayerId === me.id という常に偽になる条件と、
        // displayQuestion(data.nextQuestion.question) という誤った参照になっており、
        // 最初の問題以降は永遠に次の問題が表示されなかった。
        if (data.nextQuestion) {
            displayQuestion(data.nextQuestion);
        }
    });

    socket.on('battle:finished', (data) => {
        if (data.draw) {
            addLog("引き分け！");
            localStorage.setItem("battleResult", "draw");
        } else {
            finishBattle(data.winner);
        }
    });

    socket.on("answerError", data => {
        addLog("エラー: " + data.message);
        // 「既に誰かが正解済み」が理由のエラーの場合は、ボタンを再度押せるようにしない
        // （再度押しても同じエラーになるだけで、正解者のコマンド選択を待つべきラウンドのため）
        if (data.locked) {
            lockAnsweringForRound();
            return;
        }
        const buttons = choicesContainer.querySelectorAll('.choice-btn');
        buttons.forEach(btn => btn.disabled = false);
    });

    socket.on("opponentLeft", () => {
        addLog("相手との接続が切れました。再接続を待っています...");
        
        // バトルを終了せず、再接続を待つ
        // 相手が再接続した場合はbattleRejoinedイベントが来る
        setTimeout(() => {
            if (!rejoined) {
                battleEnd = true;
                stopTimer();
                alert(I18N.opponentLeft);
                location.href = "index.html";
            }
        }, 15000); // 15秒待つ
    });
}

function getSavedPlayer() {
    const raw = localStorage.getItem("player");
    if (!raw) return null;
    const player = JSON.parse(raw);
    // Simple migration without external dependencies
    if (!player.id) player.id = "p_" + Date.now() + "_" + Math.random().toString(36).slice(2, 10);
    if (player.coins == null) player.coins = 0;
    if (!player.weapons) player.weapons = [];
    if (!player.weaponWins) player.weaponWins = {};
    if (!player.orbs) player.orbs = [];
    return player;
}

window.onload = () => initialize();
