/* SchoolBattle Job + Skill Collection + AI Fusion */
(() => {
  'use strict';
  const JOBS = {
    vanguard:{name:'剣闘士',icon:'⚔︁E,role:'攻撁E��匁E,desc:'攻撁E��が上がり、正面から押し�Eる戦ぁE��得意、E,bonus:{atk:0.10}},
    guardian:{name:'守護騎士',icon:'🛡�E�E,role:'耐乁E��匁E,desc:'最大HPと防御力が上がる。長期戦向け、E,bonus:{maxHp:0.12,def:0.10}},
    ranger:{name:'レンジャー',icon:'🏹',role:'速度特匁E,desc:'素早さが上がり、手数を活かす戦ぁE��得意、E,bonus:{speed:0.12}},
    arcanist:{name:'魔導士',icon:'🔮',role:'特殊特匁E,desc:'特殊スチE�Eタスが上がり、スキルを軸に戦ぁE��E,bonus:{special:0.14,atk:0.04}},
    tactician:{name:'軍師',icon:'📘',role:'丁E�E垁E,desc:'攻撁E�E防御・速度を少しずつ伸ばす、E,bonus:{atk:0.04,def:0.04,speed:0.04}},
    reaper:{name:'死祁E,icon:'🌑',role:'高リスク垁E,desc:'攻撁E��と素早さが上がる代わりに最大HPが少し下がる、E,bonus:{atk:0.08,speed:0.08,maxHp:-0.05}}
  };
  const STARTERS = [
    {name:'火花の弾',rarity:'normal',spec:{form:'projectile',effects:['damage','burn'],augments:[],element:'fire'}},
    {name:'守りの波紁E,rarity:'normal',spec:{form:'nova',effects:['damage','fortify'],augments:[]}},
    {name:'疾風斬めE,rarity:'magic',spec:{form:'slash',effects:['damage','knockback'],augments:['swift'],element:'wind'}}
  ];
  const $ = id => document.getElementById(id);
  const get = () => typeof getPlayerData==='function' ? getPlayerData() : null;
  const save = p => {
    localStorage.setItem('player',JSON.stringify(p));
    try { if(typeof updateStatus==='function') updateStatus(p); } catch(e){}
    try { if(typeof syncPlayerToServer==='function') syncPlayerToServer(true); } catch(e){}
  };
  const id = () => 'col_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);
  const esc = s => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function ensure(p){
    let changed=false;
    if(!p.job || !JOBS[p.job]) {p.job='vanguard';changed=true;}
    if(!Array.isArray(p.skillCollection)) {
      changed=true;
      let existing=[];try{existing=JSON.parse(localStorage.getItem('sb_action_skills')||'[]')}catch(e){}
      p.skillCollection=Array.isArray(existing)&&existing.length?existing.filter(s=>s&&typeof s==='object').map(s=>({id:s.id||id(),name:s.name||'スキル',rarity:s.rarity||'normal',spec:s.spec||{form:s.form,effects:s.effects,augments:s.augments,element:s.element,layout:s.layout},createdAt:Date.now(),source:'workshop'})):STARTERS.map(s=>({id:id(),name:s.name,rarity:s.rarity,spec:s.spec,createdAt:Date.now(),source:'starter'}));
    }
    // 同期で別端末へ渡ったコレクションも、スキル工房の一覧へ反映する、E    let action=[];try{action=JSON.parse(localStorage.getItem('sb_action_skills')||'[]')}catch(e){}
    if(!Array.isArray(action))action=[];
    const known=new Set(action.map(s=>s&&s.id));
    (p.skillCollection||[]).forEach(s=>{if(s&&s.spec&&!known.has(s.id)){action.push({...s.spec,id:s.id,name:s.name});known.add(s.id)}});
    try{localStorage.setItem('sb_action_skills',JSON.stringify(action))}catch(e){}
    if(changed) save(p);
    return p;
  }
  let selected = new Set();
  function render(){
    const p0=get(); if(!p0) return;
    const p=ensure(p0);
    const jobs=$('jobChoices');
    if(jobs) jobs.innerHTML=Object.entries(JOBS).map(([key,j])=>`<article class="job-card ${p.job===key?'selected':''}"><h4>${j.icon} ${j.name} <small>�E�E{j.role}</small></h4><p>${j.desc}</p><p class="skill-meta">${Object.entries(j.bonus).map(([k,v])=>`${({atk:'攻撁E,def:'防御',maxHp:'最大HP',speed:'素早ぁE,special:'特殁E})[k]} ${v>0?'+':''}${Math.round(v*100)}%`).join(' ・ ')}</p><button type="button" class="btn ${p.job===key?'btn-secondary':'btn-primary'}" data-job="${key}">${p.job===key?'選択中':'こ�Eジョブにする'}</button></article>`).join('');
    jobs.querySelectorAll('[data-job]').forEach(b=>b.addEventListener('click',()=>{const q=get();q.job=b.dataset.job;save(q);render();}));
    const cur=JOBS[p.job]; $('jobCurrent').innerHTML=`現在のジョブ！Eb>${cur.icon} ${cur.name}</b>  E${cur.desc}`;
    const list=$('skillCollectionList');
    if(list) list.innerHTML=p.skillCollection.length?p.skillCollection.map(s=>`<article class="collection-skill ${selected.has(s.id)?'selected':''}"><h4>${esc(s.name)}</h4><span class="skill-rarity ${esc(s.rarity)}">${esc(({normal:'ノ�Eマル',magic:'マジチE��',rare:'レア',epic:'エピック',legendary:'レジェンチE}[s.rarity]||s.rarity))}</span><p class="skill-meta">${esc(s.spec?.form||'unknown')} �E�E${(s.spec?.effects||[]).map(esc).join('・')}</p><button type="button" class="btn ${selected.has(s.id)?'btn-secondary':'btn-primary'}" data-skill="${esc(s.id)}">${selected.has(s.id)?'選択解除':'合�E素材に選ぶ'}</button></article>`).join(''):'<p>スキルがありません、E/p>';
    list.querySelectorAll('[data-skill]').forEach(b=>b.addEventListener('click',()=>{const sid=b.dataset.skill;if(selected.has(sid))selected.delete(sid);else if(selected.size<3)selected.add(sid);renderSelection();render();}));
    renderSelection();
  }
  function renderSelection(){
    const p=get();const chosen=(p?.skillCollection||[]).filter(s=>selected.has(s.id));
    $('fusionSelected').textContent=chosen.length?chosen.map(s=>s.name).join(' �E�E')+'�E�E+chosen.length+'/3�E�E:'合�E素材を2、E個選択してください、E;
    $('fuseSkillsBtn').disabled=chosen.length<2||chosen.length>3;
  }
  async function fuse(){
    const p=get();if(!p)return;
    const sources=(p.skillCollection||[]).filter(s=>selected.has(s.id));
    if(sources.length<2||sources.length>3)return;
    if(!window.socket?.connected){$('fusionMessage').textContent='サーバ�Eに接続してから合�Eしてください、E;$('fusionMessage').className='fusion-message error';return;}
    const btn=$('fuseSkillsBtn');btn.disabled=true;btn.textContent='AIがスキルを設計中…';
    $('fusionMessage').textContent='素材スキルの特徴を�E析してぁE��す、E;
    const text='次のスキルを融合した新しいオリジナルスキルを設計してください。各スキルの特徴を絁E��合わせ、名前も新しくしてください、En'+sources.map((s,i)=>`${i+1}. ${s.name} / rarity=${s.rarity} / form=${s.spec?.form} / effects=${(s.spec?.effects||[]).join(',')} / augments=${(s.spec?.augments||[]).join(',')} / element=${s.spec?.element||'none'}`).join('\n')+'\n強さ�E素材�E合計より極端に強くせず、テーマが一貫したスキルにしてください、E;
    try{
      const result=await new Promise(resolve=>window.socket.timeout(35000).emit('skillai:generate',{playerId:p.id,text,special:p.special||0},(err,res)=>resolve(err?{ok:false,reason:'timeout'}:res)));
      if(!result?.ok) throw new Error(({invalid:'プレイヤーIDを確認してください',too_short:'素材情報が不足してぁE��ぁE,too_fast:'少し征E��てから再試行してください',daily_limit:'本日のAI合�E回数の上限でぁE,timeout:'AI応答がタイムアウトしました',busy:'別のスキル生�Eが進行中でぁE}[result?.reason]||'スキル生�Eに失敗しました'));
      const newSkill={id:id(),name:String(result.spec.name||'融合スキル').slice(0,20),rarity:sources.some(s=>s.rarity==='legendary')?'legendary':sources.some(s=>s.rarity==='epic')?'epic':sources.some(s=>s.rarity==='rare')?'rare':'magic',spec:result.spec,createdAt:Date.now(),source:'fusion',fusionFrom:sources.map(s=>s.id),summary:result.summary||''};
      // 同一のアクションスキル一覧にも保存。スキル工房を開ぁE��際に編雁E�E裁E��できる、E      let actionSkills=[];try{actionSkills=JSON.parse(localStorage.getItem('sb_action_skills')||'[]')}catch(e){}
      if(!Array.isArray(actionSkills))actionSkills=[];
      actionSkills.push({...result.spec,id:newSkill.id,name:newSkill.name});
      localStorage.setItem('sb_action_skills',JSON.stringify(actionSkills));
      p.skillCollection=(p.skillCollection||[]).filter(s=>!selected.has(s.id));
      p.skillCollection.push(newSkill);save(p);selected.clear();
      $('fusionMessage').textContent=`${newSkill.name} が完�E�E�E{result.ai?' AI設訁E:'簡易設訁E}。素杁E${sources.length} 個を消費しました。`;
      $('fusionMessage').className='fusion-message success';render();
    }catch(e){$('fusionMessage').textContent=e.message||'合�Eに失敗しました。素材�E消費されてぁE��せん、E;$('fusionMessage').className='fusion-message error';}
    finally{btn.textContent='選択したスキルを合成すめE;renderSelection();}
  }
  document.addEventListener('DOMContentLoaded',()=>{
    $('fuseSkillsBtn')?.addEventListener('click',fuse);
    const jobBtn=document.querySelector('[data-section="job"]');
    jobBtn?.addEventListener('click',()=>render());
    window.addEventListener('storage',e=>{if(e.key==='player')render()});
    render();
  });
  window.SBJobSkills={JOBS,render};
})();
