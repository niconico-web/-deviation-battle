// server/socket/stage.js
// ============================================
// ステージ（ダンジョン1つ＋ボス1体）の協力プレイ用ルーム管理。
// 町(ロビー)で部屋の一覧を見る／stage.html で部屋を作る・入る。
// 敵の動きはホスト(1人)のブラウザが計算し、サーバーは中継だけ行う。
//
// イベント（クライアント → サーバー）
//   stage:list   { stageId? }                    -> stage:rooms
//   stage:create { player:{id,name,wname,rar,best}, stageId, startFloor? }   best＝無限回廊で到達した最深の階層。startFloor＝その部屋のスタート階層
//   stage:join   { roomId, player }
//   stage:quick  { player, stageId }             空いている部屋に参加、無ければ作る
//   stage:start                                  ホストだけ。出発
//   stage:relay  { t, d }                        同じ部屋の他のメンバーへ中継
//   stage:leave
// （サーバー → クライアント）
//   stage:room    ルーム状態（メンバー・ホスト）
//   stage:started 出発
//   stage:msg     { from, t, d }
//   stage:rooms   募集中の部屋一覧
//   stage:error   { message }
// ============================================

const RAID_PVP_MIN_LV = 50;      // 大討伐戦・PvPが解放されるレベル
const MAX_LV_GAP = 20;      // 一緒に行けるレベル差の上限（20を超えて離れていたら不可）
function cleanLv(v) { const n = parseInt(v, 10); return n >= 1 && n <= 100000 ? n : 0; }
const MAX_MEMBERS = 4;
const MAX_BY_STAGE = { pvp_3v3: 6, raid_increase: 20, raid_worm: 20, raid_necro: 20, raid_duality: 20, raid_machine: 20, raid_velzark: 20 };            // 3v3 は6人まで、大討伐戦は20人まで（ほかは4人）
const maxOf = (r) => MAX_BY_STAGE[r.stageId] || MAX_MEMBERS;
const HOST_ONLY = { hit: 1, hits: 1, bhit: 1, creq: 1, refl: 1 };      // ホストだけが処理するメッセージ（ほかの仲間に配っても無駄で、その人の画面が重くなる）
const MAX_RELAY_BYTES = 64000;      // ボスラッシュの終盤は弾が多く、30000だと中継が捨てられて仲間の画面が止まって見えた
const rooms = new Map();          // roomId -> room
const socketRoom = new Map();     // socket.id -> roomId

function cleanName(v, max) {
    return String(v == null ? "" : v).replace(/[<>]/g, "").slice(0, max || 20);
}
function cleanDiff(v) {
    const n = parseInt(v, 10);
    return n >= 0 && n <= 4 ? n : 0;   // 0〜4＝通常ステージの難易度（3=エクストリーム、4=インフェルノ）。ボスラッシュは0〜3
}
function cleanFloor(v) {      // 無限回廊の、部屋のスタート階層（1以上）
    const n = parseInt(v, 10);
    return n >= 1 && n <= 9999 ? n : 1;
}
function newRoomId() {
    let id;
    do { id = Math.random().toString(36).slice(2, 6).toUpperCase(); } while (rooms.has(id));
    return id;
}
function publicRoom(r) {
    return {
        id: r.id, stageId: r.stageId, diff: r.diff || 0, startFloor: r.startFloor || 1, hostId: r.hostId, state: r.state, max: maxOf(r),
        members: r.members.map(m => ({ id: m.id, name: m.name, wname: m.wname, rar: m.rar, lv: m.lv || 0 }))
    };
}

module.exports = function (io) {
    function emitRoom(r) { io.to("stage:" + r.id).emit("stage:room", publicRoom(r)); }

    function leave(socket) {
        const rid = socketRoom.get(socket.id);
        if (!rid) return;
        socketRoom.delete(socket.id);
        const r = rooms.get(rid);
        socket.leave("stage:" + rid);
        if (!r) return;
        const i = r.members.findIndex(m => m.sid === socket.id);
        if (i >= 0) r.members.splice(i, 1);
        if (r.members.length === 0) { rooms.delete(rid); return; }
        if (!r.members.some(m => m.id === r.hostId)) r.hostId = r.members[0].id; // ホストの引き継ぎ
        emitRoom(r);
    }

    function addMember(socket, r, player) {
        leave(socket);
        const id = cleanName(player && player.id, 60);
        if (!id) { socket.emit("stage:error", { message: "プレイヤー情報が不正です" }); return false; }
        if (r.members.length >= maxOf(r)) { socket.emit("stage:error", { message: "この部屋は満員です" }); return false; }
        if (r.state !== "lobby") { socket.emit("stage:error", { message: "すでに出発しています" }); return false; }
        // 無限回廊：その階層まで、一度でも到達したことがある人だけが参加できる（到達した最深の階層は、参加する人が申告する）
        if ((r.startFloor || 1) > 1) {
            const best = parseInt(player && player.best, 10) || 0;
            if (best < r.startFloor) { socket.emit("stage:error", { message: "この部屋は地下" + r.startFloor + "階からです。まだ地下" + r.startFloor + "階に到達していないので、参加できません（最深：" + (best ? "地下" + best + "階" : "未挑戦") + "）" }); return false; }
        }
        // レベル差が20を超える人とは、一緒にステージへ行けない（差が20までは参加できる）
        const lvNew = cleanLv(player && player.lv);
        if (/^(raid_|pvp_)/.test(r.stageId) && lvNew > 0 && lvNew < RAID_PVP_MIN_LV) { socket.emit("stage:error", { message: "大討伐戦とPvPは Lv" + RAID_PVP_MIN_LV + " から解放されます（あなたは Lv" + lvNew + "）" }); return false; }
        if (lvNew > 0) {
            const clash = r.members.find(m => m.id !== id && m.lv > 0 && Math.abs(m.lv - lvNew) > MAX_LV_GAP);
            if (clash) { socket.emit("stage:error", { message: "レベル差が" + MAX_LV_GAP + "を超える人とは、一緒にステージへ行けません（あなた Lv" + lvNew + " ／ " + clash.name + " Lv" + clash.lv + "）" }); return false; }
        }
        r.members = r.members.filter(m => m.id !== id); // 同一プレイヤーの二重参加を防ぐ
        r.members.push({ sid: socket.id, id: id, name: cleanName(player.name, 16) || "名無し", wname: cleanName(player.wname, 30), rar: cleanName(player.rar, 12), lv: lvNew });
        socket.join("stage:" + r.id);
        socketRoom.set(socket.id, r.id);
        emitRoom(r);
        return true;
    }

    io.on("connection", (socket) => {
        socket.on("stage:list", (data) => {
            const sid = data && data.stageId ? String(data.stageId) : null;
            const list = [];
            rooms.forEach(r => {
                if (r.state !== "lobby" || r.members.length >= maxOf(r)) return;
                if (sid && r.stageId !== sid) return;
                list.push(publicRoom(r));
            });
            socket.emit("stage:rooms", list.slice(0, 50));
        });

        socket.on("stage:create", (data) => {
            if (!data || !data.stageId) return;
            const r = { id: newRoomId(), stageId: String(data.stageId).slice(0, 40), diff: cleanDiff(data.diff), startFloor: cleanFloor(data.startFloor), hostId: null, state: "lobby", members: [] };
            r.hostId = cleanName(data.player && data.player.id, 60);
            rooms.set(r.id, r);
            if (!addMember(socket, r, data.player)) rooms.delete(r.id);
        });

        socket.on("stage:join", (data) => {
            const r = rooms.get(String(data && data.roomId || "").toUpperCase());
            if (!r) { socket.emit("stage:error", { message: "部屋が見つかりません" }); return; }
            addMember(socket, r, data.player);
        });

        socket.on("stage:quick", (data) => {
            if (!data || !data.stageId) return;
            const sid = String(data.stageId).slice(0, 40);
            let target = null;
            const wantFloor = cleanFloor(data.startFloor);
            rooms.forEach(r => { if (!target && r.stageId === sid && (r.diff || 0) === cleanDiff(data.diff) && (r.startFloor || 1) === wantFloor && r.state === "lobby" && r.members.length < maxOf(r) && !r.members.some(m => m.lv > 0 && cleanLv(data.player && data.player.lv) > 0 && Math.abs(m.lv - cleanLv(data.player.lv)) >= MAX_LV_GAP)) target = r; });      // クイック参加は、同じスタート階層の部屋だけ
            if (!target) {
                target = { id: newRoomId(), stageId: sid, diff: cleanDiff(data.diff), startFloor: wantFloor, hostId: cleanName(data.player && data.player.id, 60), state: "lobby", members: [] };
                rooms.set(target.id, target);
                if (!addMember(socket, target, data.player)) rooms.delete(target.id);
                return;
            }
            addMember(socket, target, data.player);
        });

        socket.on("stage:start", () => {
            const r = rooms.get(socketRoom.get(socket.id));
            if (!r || r.state !== "lobby") return;
            const me = r.members.find(m => m.sid === socket.id);
            if (!me || me.id !== r.hostId) return;
            r.state = "playing";
            emitRoom(r);
            io.to("stage:" + r.id).emit("stage:started", { roomId: r.id });
        });

        socket.on("stage:relay", (msg) => {
            const r = rooms.get(socketRoom.get(socket.id));
            if (!r || !msg || typeof msg.t !== "string" || msg.t.length > 12) return;
            const hot = msg.t === "pos" || msg.t === "snap" || msg.t === "mn";   // 毎秒10回以上流れる「位置」「状態スナップショット」「ミニオンの位置」
            if (!hot) {   // 高頻度メッセージは固定形式なので毎回JSON化してサイズを測る必要はない（それ自体がCPUを食う）
                let size = 0;
                try { size = JSON.stringify(msg.d || {}).length; } catch (e) { return; }
                if (size > MAX_RELAY_BYTES) return;
            }
            const me = r.members.find(m => m.sid === socket.id);
            if (!me) return;
            // 位置とスナップショットは次の更新で上書きされるので、詰まっているときは捨てる（volatile）
            if (HOST_ONLY[msg.t]) {      // ホストにだけ届ける
                const host = r.members.find(m => m.id === r.hostId);
                if (host && host.sid !== socket.id) io.to(host.sid).emit("stage:msg", { from: me.id, t: msg.t, d: msg.d });
                return;
            }
            const target = socket.to("stage:" + r.id);
            (hot ? target.volatile : target).emit("stage:msg", { from: me.id, t: msg.t, d: msg.d });
        });

        socket.on("stage:ping", (t, cb) => { if (typeof cb === "function") cb(t); });      // 通信の遅れ（Ping）の計測用
        socket.on("stage:leave", () => leave(socket));
        socket.on("disconnect", () => leave(socket));
    });
};
