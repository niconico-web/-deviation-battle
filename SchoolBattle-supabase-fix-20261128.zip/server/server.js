const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
// 最初に、Supabase から保存データを復�?する?��各機�?�がJSONファイルを読む前に終わらせる。未設定なら何もしな�??�?
require("./managers/SupabaseSync").restoreOnBootSync();
const UniqueWeaponManager = require("./managers/UniqueWeaponManager");

const app = express();
// 配信の圧縮?�?HTML/JS/CSS/JSONをgzip?��。questions.js などの大きなファイルを毎回そ�?�まま送って�?た�?�ん�?�帯域とCPU�?ちを減らす�?
// パッケージが�?�って�?な�?環�?でもサーバ�?�が落ちな�?よう、読み込みに失敗したら圧縮なしで動く�?
try { app.use(require("compression")()); } catch (e) { console.warn("[server] compression が�?�って�?な�?ため圧縮なしで起動します�?npm install で有効化�?"); }
app.use(express.json());
// シーズンの週・解放の判定に使�?サーバ�?�時刻?��端末の時計を�?じっても早まらな�?ように?�?
app.get("/api/time", (req, res) => { res.set("Cache-Control", "no-store"); res.json({ now: Date.now() }); });
const server = http.createServer(app);
const io = new Server(server, {
    maxHttpBufferSize: 20 * 1024 * 1024,   // 引き継ぎ�?ータ?��武器庫など?���?�1MBを�?えることがある。既定�?�1MB�?と、保存しようとした瞬間に接続が�?れて�?�?
    pingInterval: 25000,
    pingTimeout: 60000,
    transports: ["websocket", "polling"],
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    },
    connectionStateRecovery: {
        maxDisconnectionDuration: 2 * 60 * 1000,
        skipMiddlewares: true
    }
});

// server/socket/*.js は�?ファイルが独自に io.on("connection", ...) を登録するため�?
// 機�?�追�?のた�?�にリスナ�?�数が増えて�?く。デフォルト上限(10)を�?えると
// MaxListenersExceededWarningが�?�るだけで実害はな�?が、上限を引き上げて黙らせておく�?
io.setMaxListeners(20);

const path = require("path");
const fs = require("fs");

// ---- トップ�?��?�ジ?��OGP?���?�有時のプレビュー?��用に絶対URLを差し込んで返す ----
// client/index.html �?の %%SITE_URL%% を、実際にアクセスされたドメインに置き換える�?
// X・LINE・Discordなどは og:image に絶対URLを要求するため�?
// 独自ドメインに変えてもコード修正は不�??��環�?変数 SITE_URL を設定すれ�?�そちらを優先）�?
const INDEX_HTML_PATH = path.join(__dirname, "../client/index.html");

function getSiteBaseUrl(req) {
    if (process.env.SITE_URL) return process.env.SITE_URL.replace(/\/+$/, "");
    const proto = String(req.headers["x-forwarded-proto"] || req.protocol).split(",")[0].trim();
    const host = String(req.headers["x-forwarded-host"] || req.headers.host || "").split(",")[0].trim();
    // Hostヘッダーは外部から自由に書き換えられるため、HTMLに埋め込む前に形式を検証する
    if (!/^https?$/.test(proto) || !/^[a-z0-9.-]+(:\d{1,5})?$/i.test(host)) return "";
    return `${proto}://${host}`;
}

app.get(["/", "/index.html"], (req, res, next) => {
    fs.readFile(INDEX_HTML_PATH, "utf8", (err, html) => {
        if (err) return next();
        res.set({
            "Content-Type": "text/html; charset=utf-8",
            "Cache-Control": "no-store, no-cache, must-revalidate"
        });
        res.send(html.replace(/%%SITE_URL%%/g, getSiteBaseUrl(req)));
    });
});

app.use(express.static(path.join(__dirname, "../client"), {
    setHeaders(res, filePath) {
        // Add Service-Worker-Allowed header for sw.js to allow root scope
        if (filePath.endsWith('sw.js')) {
            res.setHeader('Service-Worker-Allowed', '/');
        }

        // Ensure manifest.json is served with correct content type
        if (filePath.endsWith('manifest.json')) {
            res.setHeader('Content-Type', 'application/manifest+json; charset=utf-8');
        }

        if (filePath.endsWith(".html") || filePath.endsWith(".js") || filePath.endsWith(".css")) {
            res.setHeader("Content-Type", `${getContentType(filePath)}; charset=utf-8`);
            // Avoid stale CDN/browser assets after redeploys.
            // no-store �?と毎回ファイル全体を再ダウンロードさせてしま�?。no-cache は「毎回サーバ�?�に確認するが�?
            // 変わって�?なければ(ETagが同じな�?) 304 で中身は送らな�?」�?�で、更新の即時反�?を保ったまま転�?量だけ減らせる�?
            res.setHeader("Cache-Control", "no-cache, must-revalidate");
        }
    }
}));

// Serve root manifest.json and sw.js explicitly
app.get('/manifest.json', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/manifest.json'), {
        headers: {
            'Content-Type': 'application/manifest+json; charset=utf-8',
            'Cache-Control': 'no-store, no-cache, must-revalidate'
        }
    });
});

app.get('/sw.js', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/sw.js'), {
        headers: {
            'Content-Type': 'application/javascript; charset=utf-8',
            'Cache-Control': 'no-store, no-cache, must-revalidate',
            'Service-Worker-Allowed': '/'
        }
    });
});

function getContentType(filePath) {
    if (filePath.endsWith(".html")) return "text/html";
    if (filePath.endsWith(".js")) return "application/javascript";
    if (filePath.endsWith(".css")) return "text/css";
    return "text/plain";
}

require("./socket/connection")(io);
require("./socket/matchmaking")(io);
require("./socket/battle")(io);
require("./socket/party")(io);
require("./socket/boss")(io);
require("./socket/ranking")(io);
require("./socket/social")(io);
require("./socket/stage")(io);
require("./socket/dungeon")(io);
require("./socket/disconnect")(io);
require("./socket/world")(io);
require("./socket/chat")(io);
require("./socket/worldboss")(io);
require("./socket/market")(io);
require("./socket/skillai")(io);
require("./managers/SurvivalRetire").run();      // サバイバルエリアは廃止。預かっていた装備・国庫・店の持ち物を、持ち主の受け取り箱へ一度だけ返す
require("./socket/guild")(io);
require("./socket/board")(io);
require("./socket/pvp")(io);
require("./socket/ghost")(io);
require("./managers/SupabaseSync").start();      // 以降、ファイルが変わるたびに Supabase へ保存する（�?�機�?�を読み込んだあとに呼ぶ?�?

app.get("/api/unique/claims", (req, res) => {
    res.json(UniqueWeaponManager.getAllClaims());
});

app.post("/api/unique/claim", (req, res) => {
    const { type, playerId, playerName, wins } = req.body || {};
    if (!type || !playerId || !playerName) {
        return res.status(400).json({ success: false, message: "Missing required fields" });
    }
    if (wins < 500) {
        return res.status(400).json({ success: false, message: "Quest not completed (need 500 wins)" });
    }
    const result = UniqueWeaponManager.tryClaim(type, playerId, playerName);
    if (!result.success) {
        return res.json({ success: false, claimedBy: result.claimedBy });
    }
    res.json({ success: true, claim: result.claim });
});

app.post("/api/unique/claimDebug", (req, res) => {
    const { type, playerId, playerName, wins } = req.body || {};
    if (!type || !playerId || !playerName) {
        return res.status(400).json({ success: false, message: "Missing required fields" });
    }
    if (wins < 1) {
        return res.status(400).json({ success: false, message: "Quest not completed (need 1 win)" });
    }
    const result = UniqueWeaponManager.tryClaimDebug(type, playerId, playerName);
    if (!result.success) {
        return res.json({ success: false, claimedBy: result.claimedBy });
    }
    res.json({ success: true, claim: result.claim });
});

const PORT = process.env.PORT || 3000;

// Diagnostic logging
io.on('connection', (socket) => {
    console.log(`[${new Date().toISOString()}] Socket connected - ID: ${socket.id}`);

    // Avoid logging every gameplay packet: high-frequency Socket.IO logs add I/O latency.

    socket.on('disconnect', (reason) => {
        console.log(`[${new Date().toISOString()}] Socket disconnected - ID: ${socket.id} reason: ${reason}`);
    });
});

io.on('error', (err) => {
    console.error(`[${new Date().toISOString()}] Socket.io error:`, err);
});

// Error handling
process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

server.on('error', (err) => {
    console.error('Server error:', err);
    if (err.code === 'EADDRINUSE') {
        console.error(`Port ${PORT} is already in use`);
    }
    process.exit(1);
});

server.listen(PORT, "0.0.0.0", () => {
    console.log(`[${new Date().toISOString()}] Server Start on port ${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'production'}`);
});