// ============================================
// School Battle
// GuildManager.js
// ============================================

const fs = require('fs');
const path = require('path');

const GUILD_DATA_FILE = path.join(__dirname, '..', 'data', 'guilds.json');
const QUEST_DATA_FILE = path.join(__dirname, '..', 'data', 'quests.json');
const DATA_DIR = path.dirname(GUILD_DATA_FILE);

let guildData = {};
let questData = {};

// ギルドランク定義
const GUILD_RANKS = {
    F: { name: 'Fランク', minContribution: 0, minMembers: 1, minLevel: 1 },
    E: { name: 'Eランク', minContribution: 100, minMembers: 3, minLevel: 5 },
    D: { name: 'Dランク', minContribution: 500, minMembers: 5, minLevel: 10 },
    C: { name: 'Cランク', minContribution: 2000, minMembers: 10, minLevel: 20 },
    B: { name: 'Bランク', minContribution: 5000, minMembers: 15, minLevel: 30 },
    A: { name: 'Aランク', minContribution: 15000, minMembers: 20, minLevel: 40 },
    S: { name: 'Sランク', minContribution: 50000, minMembers: 30, minLevel: 50 }
};

// クエストカテゴリ定義
const QUEST_CATEGORIES = {
    BATTLE: { name: '討伐依頼', icon: '⚔️' },
    DELIVERY: { name: '素材納品', icon: '📦' },
    ESCORT: { name: '護衛協力', icon: '🛡️' },
    SPECIAL: { name: '調査特殊', icon: '🔍' }
};

// ギルド施設（建物）定義：ギルドコインで強化する
// cost = baseCost * costMult^現在レベル。maxLevel まで。
// 効果の一部は addContribution / guildPower に実装済み、残りは城PvP実装時に使う予定の数値。
const BUILDINGS = {
    castle:   { name: '城',     icon: '🏰', maxLevel: 10, baseCost: 500,  costMult: 1.7, desc: 'ギルドの象徴。総合力に大きく貢献（城PvPの防衛力にもなる予定）' },
    wall:     { name: '城壁',   icon: '🧱', maxLevel: 10, baseCost: 300,  costMult: 1.6, desc: '防衛施設。総合力に貢献（城PvPの耐久力にもなる予定）' },
    barracks: { name: '兵舎',   icon: '⚔️', maxLevel: 10, baseCost: 400,  costMult: 1.7, desc: 'Lvごとにギルド貢献度の獲得量+5%（実装済み）' },
    market:   { name: '市場',   icon: '🏪', maxLevel: 10, baseCost: 350,  costMult: 1.6, desc: '交易施設。総合力に貢献（将来：コイン収入ボーナス予定）' }
};
const BUILDING_POWER = { castle: 10, wall: 8, barracks: 6, market: 5 };   // レベル1あたりの総合力
const CONTRIBUTION_BONUS_PER_LEVEL = 0.05;                              // 兵舎Lvごとの貢献度ボーナス

// データディレクトリが存在しない場合は作成
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// ギルドデータ読み込み時に、コイン・施設を持たない古いデータを初期化する
function normalizeGuild(g) {
    if (g.coins == null) g.coins = 0;
    if (!g.buildings || typeof g.buildings !== 'object') g.buildings = {};
    Object.keys(BUILDINGS).forEach(id => {
        if (g.buildings[id] == null || typeof g.buildings[id] !== 'object') g.buildings[id] = { level: 0 };
        g.buildings[id].level = Math.max(0, Math.min(BUILDINGS[id].maxLevel, g.buildings[id].level | 0));
    });
    return g;
}

// ギルドデータを読み込む
function loadGuildData() {
    try {
        if (fs.existsSync(GUILD_DATA_FILE)) {
            const fileContent = fs.readFileSync(GUILD_DATA_FILE, 'utf-8');
            guildData = JSON.parse(fileContent);
            Object.values(guildData).forEach(normalizeGuild);
            console.log('[GuildManager] Guild data loaded from file.');
        } else {
            console.log('[GuildManager] No guild data file found, starting with empty data.');
        }
    } catch (error) {
        console.error('[GuildManager] Error loading guild data:', error);
        guildData = {};
    }
}

// クエストデータを読み込む
function loadQuestData() {
    try {
        if (fs.existsSync(QUEST_DATA_FILE)) {
            const fileContent = fs.readFileSync(QUEST_DATA_FILE, 'utf-8');
            questData = JSON.parse(fileContent);
            console.log('[GuildManager] Quest data loaded from file.');
        } else {
            console.log('[GuildManager] No quest data file found, starting with empty data.');
        }
    } catch (error) {
        console.error('[GuildManager] Error loading quest data:', error);
        questData = {};
    }
}

// ギルドデータを保存
function saveGuildData() {
    try {
        fs.writeFileSync(GUILD_DATA_FILE, JSON.stringify(guildData, null, 2), 'utf-8');
    } catch (error) {
        console.error('[GuildManager] Error saving guild data:', error);
    }
}

// クエストデータを保存
function saveQuestData() {
    try {
        fs.writeFileSync(QUEST_DATA_FILE, JSON.stringify(questData, null, 2), 'utf-8');
    } catch (error) {
        console.error('[GuildManager] Error saving quest data:', error);
    }
}

// ギルドを作成
function createGuild(newGuildInput) {
    const { name, leaderId, leaderName } = newGuildInput;
    
    if (!name || !leaderId || !leaderName) {
        return { success: false, message: '必須項目が不足しています' };
    }
    
    // ギルド名の重複チェック
    // 以前はこの関数の引数名が module 直下の guildData ストアと同名だったため、
    // 重複チェックが引数オブジェクト自身を調べてしまい機能していなかった。
    if (Object.values(guildData).some(g => g.name === name)) {
        return { success: false, message: 'このギルド名は既に使用されています' };
    }
    
    const guildId = 'GUILD_' + Date.now().toString(36).toUpperCase();

    const newGuild = normalizeGuild({
        id: guildId,
        name: name,
        leaderId: leaderId,
        leaderName: leaderName,
        rank: 'F',
        contribution: 0,
        members: [{
            id: leaderId,
            name: leaderName,
            role: 'leader',
            joinedAt: Date.now(),
            contribution: 0
        }],
        createdAt: Date.now(),
        description: newGuildInput.description || ''
    });
    
    // 以前は引数のシャドーイングにより、ここで module 直下の guildData ではなく
    // 引数オブジェクトに書き込んでしまっていたため、作成したギルドが
    // 実際にはサーバーに一切保存されない（＝誰の一覧にも表示されない）不具合があった。
    guildData[guildId] = newGuild;
    saveGuildData();
    
    return { success: true, guild: newGuild };
}

// ギルドに参加
function joinGuild(guildId, playerId, playerName) {
    const guild = guildData[guildId];
    if (!guild) {
        return { success: false, message: 'ギルドが見つかりません' };
    }
    
    // 既にメンバーかチェック
    if (guild.members.some(m => m.id === playerId)) {
        return { success: false, message: '既にこのギルドのメンバーです' };
    }
    
    guild.members.push({
        id: playerId,
        name: playerName,
        role: 'member',
        joinedAt: Date.now(),
        contribution: 0
    });
    
    saveGuildData();
    return { success: true, guild: guild };
}

// ギルドを脱退
function leaveGuild(guildId, playerId) {
    const guild = guildData[guildId];
    if (!guild) {
        return { success: false, message: 'ギルドが見つかりません' };
    }

    const memberIndex = guild.members.findIndex(m => m.id === playerId);
    if (memberIndex === -1) {
        return { success: false, message: 'メンバーが見つかりません' };
    }

    guild.members.splice(memberIndex, 1);

    if (guild.leaderId === playerId) {
        if (guild.members.length === 0) {
            // 最後の一人（リーダー）が抜けた場合はギルドごと解散する
            delete guildData[guildId];
            saveGuildData();
            return { success: true, guild: null, disbanded: true };
        }
        // リーダーが抜けた場合は、残っているメンバーの中で最も古参の人に引き継ぐ
        const nextLeader = guild.members[0];
        guild.leaderId = nextLeader.id;
        guild.leaderName = nextLeader.name;
        nextLeader.role = 'leader';
    }

    saveGuildData();

    return { success: true, guild: guild };
}

// ギルド情報を取得
function getGuild(guildId) {
    const g = guildData[guildId];
    return g ? normalizeGuild(g) : null;
}

// プレイヤーのギルドを取得
function getPlayerGuild(playerId) {
    for (const guild of Object.values(guildData)) {
        if (guild.members.some(m => m.id === playerId)) {
            return normalizeGuild(guild);
        }
    }
    return null;
}

// 全ギルドを取得
function getAllGuilds() {
    return Object.values(guildData).map(normalizeGuild);
}

// ギルドランクを計算
function calculateGuildRank(guild) {
    const ranks = ['F', 'E', 'D', 'C', 'B', 'A', 'S'];
    
    for (let i = ranks.length - 1; i >= 0; i--) {
        const rank = ranks[i];
        const requirements = GUILD_RANKS[rank];
        
        if (guild.contribution >= requirements.minContribution &&
            guild.members.length >= requirements.minMembers) {
            return rank;
        }
    }
    
    return 'F';
}

// 兵舎レベルによる貢献度ボーナスを掛けた実際の加算量を返す
function contributionWithBonus(guild, amount) {
    const lv = (guild.buildings && guild.buildings.barracks && guild.buildings.barracks.level) || 0;
    return Math.round(amount * (1 + CONTRIBUTION_BONUS_PER_LEVEL * lv));
}

// ギルド貢献度を追加
function addContribution(guildId, playerId, amount) {
    const guild = guildData[guildId];
    if (!guild) {
        return { success: false, message: 'ギルドが見つかりません' };
    }
    amount = contributionWithBonus(normalizeGuild(guild), amount);

    guild.contribution += amount;
    
    const member = guild.members.find(m => m.id === playerId);
    if (member) {
        member.contribution += amount;
    }
    
    // ランクアップチェック
    const newRank = calculateGuildRank(guild);
    const rankUp = newRank !== guild.rank;
    guild.rank = newRank;
    
    saveGuildData();
    
    return { 
        success: true, 
        guild: guild, 
        rankUp: rankUp,
        newRank: newRank 
    };
}

// クエストの難易度をAIで判定
function analyzeQuestDifficulty(description, category) {
    let difficultyScore = 0;
    let estimatedRank = 'F';
    
    const desc = description.toLowerCase();
    
    // 基本スコア
    const baseScores = {
        'battle': 10,
        'delivery': 5,
        'escort': 8,
        'special': 3
    };
    difficultyScore += baseScores[category] || 5;
    
    // 数値ベースの難易度判定
    const numberMatches = desc.match(/(\d+)/g);
    if (numberMatches) {
        numberMatches.forEach(num => {
            const value = parseInt(num);
            if (value > 10) difficultyScore += value * 0.5;
            else if (value > 5) difficultyScore += value * 0.3;
            else difficultyScore += value * 0.1;
        });
    }
    
    // キーワードベースの難易度判定
    const highDifficultyKeywords = ['連勝', '连胜', 'streak', '連続', 'consecutive', '伝説', 'legendary', '極意', 'ultimate', '最強', 'strongest'];
    const mediumDifficultyKeywords = ['勝利', '胜利', 'win', '攻略', 'clear', '達成', 'achieve', '完了', 'complete'];
    const lowDifficultyKeywords = ['初心者', 'beginner', '入門', 'intro', '練習', 'practice', '簡単', 'easy', 'basic'];
    
    highDifficultyKeywords.forEach(keyword => {
        if (desc.includes(keyword)) difficultyScore += 20;
    });
    
    mediumDifficultyKeywords.forEach(keyword => {
        if (desc.includes(keyword)) difficultyScore += 10;
    });
    
    lowDifficultyKeywords.forEach(keyword => {
        if (desc.includes(keyword)) difficultyScore -= 5;
    });
    
    // 特定のモンスター名
    const bossKeywords = ['ボス', 'boss', 'ドラゴン', 'dragon', '魔王', 'demon king', '神', 'god'];
    bossKeywords.forEach(keyword => {
        if (desc.includes(keyword)) difficultyScore += 15;
    });
    
    // ランク判定
    if (difficultyScore >= 50) estimatedRank = 'S';
    else if (difficultyScore >= 40) estimatedRank = 'A';
    else if (difficultyScore >= 30) estimatedRank = 'B';
    else if (difficultyScore >= 20) estimatedRank = 'C';
    else if (difficultyScore >= 15) estimatedRank = 'D';
    else if (difficultyScore >= 10) estimatedRank = 'E';
    else estimatedRank = 'F';
    
    // 報酬の自動計算
    const baseReward = {
        'F': 30,
        'E': 50,
        'D': 100,
        'C': 200,
        'B': 400,
        'A': 800,
        'S': 1500
    };
    
    const autoReward = Math.floor(baseReward[estimatedRank] * (difficultyScore / 10));
    
    return {
        difficultyScore,
        estimatedRank,
        suggestedReward: autoReward
    };
}

// クエストを作成
function createQuest(questData) {
    const { guildId, title, description, category, rank, reward, createdBy, creatorName, type } = questData;
    
    if (!title || !description || !category) {
        return { success: false, message: '必須項目が不足しています' };
    }
    
    // カテゴリのバリデーション
    if (!QUEST_CATEGORIES[category]) {
        return { success: false, message: '無効なカテゴリです' };
    }
    
    // AIによる難易度判定（ランクと報酬が指定されていない場合）
    let finalRank = rank;
    let finalReward = reward;
    
    if (!rank || !reward) {
        const analysis = analyzeQuestDifficulty(description, category);
        if (!rank) finalRank = analysis.estimatedRank;
        if (!reward) finalReward = analysis.suggestedReward;
        
        console.log(`[GuildManager] AI Analysis for quest "${title}":`, analysis);
    }
    
    // ランクのバリデーション
    if (!GUILD_RANKS[finalRank]) {
        return { success: false, message: '無効なランクです' };
    }
    
    const questId = 'QUEST_' + Date.now().toString(36).toUpperCase();
    
    const newQuest = {
        id: questId,
        guildId: guildId || null,
        title: title,
        description: description,
        category: category,
        rank: finalRank,
        reward: finalReward,
        type: type || 'system', // 'system' or 'user'
        createdBy: createdBy,
        creatorName: creatorName,
        status: 'available', // 'available', 'accepted', 'completed', 'failed'
        acceptedBy: null,
        acceptedByName: null,
        acceptedAt: null,
        completedAt: null,
        createdAt: Date.now()
    };
    
    questData[questId] = newQuest;
    saveQuestData();
    
    console.log(`[GuildManager] Quest created: ${questId}, status: ${newQuest.status}, guildId: ${newQuest.guildId}`);
    console.log(`[GuildManager] Total quests in data: ${Object.keys(questData).length}`);
    
    return { success: true, quest: newQuest };
}

// クエストを受注
function acceptQuest(questId, playerId, playerName) {
    const quest = questData[questId];
    if (!quest) {
        return { success: false, message: 'クエストが見つかりません' };
    }
    
    if (quest.status !== 'available') {
        return { success: false, message: 'このクエストは受注できません' };
    }
    
    // ギルドクエストの場合、ギルドランクチェック
    if (quest.guildId) {
        const guild = getGuild(quest.guildId);
        if (!guild) {
            return { success: false, message: 'ギルドが見つかりません' };
        }
        
        const member = guild.members.find(m => m.id === playerId);
        if (!member) {
            return { success: false, message: 'このギルドのメンバーではありません' };
        }
        
        const rankRequirements = GUILD_RANKS[quest.rank];
        // ランクチェック（ここでは簡易的に実装）
    }
    
    quest.status = 'accepted';
    quest.acceptedBy = playerId;
    quest.acceptedByName = playerName;
    quest.acceptedAt = Date.now();
    
    saveQuestData();
    
    return { success: true, quest: quest };
}

// クエストを報告
function reportQuest(questId, playerId, evidence) {
    const quest = questData[questId];
    if (!quest) {
        return { success: false, message: 'クエストが見つかりません' };
    }
    
    if (quest.acceptedBy !== playerId) {
        return { success: false, message: 'このクエストを受注していません' };
    }
    
    if (quest.status !== 'accepted') {
        return { success: false, message: 'このクエストは報告できません' };
    }
    
    quest.status = 'completed';
    quest.completedAt = Date.now();
    quest.evidence = evidence;
    
    saveQuestData();
    
    return { success: true, quest: quest };
}

// クエスト報酬を支払う
function payQuestReward(questId) {
    const quest = questData[questId];
    if (!quest) {
        return { success: false, message: 'クエストが見つかりません' };
    }
    
    if (quest.status !== 'completed') {
        return { success: false, message: 'クエストが完了していません' };
    }
    
    // ギルドクエストの場合、ギルド貢献度を追加
    if (quest.guildId && quest.acceptedBy) {
        addContribution(quest.guildId, quest.acceptedBy, quest.reward);
    }
    
    quest.status = 'paid';
    saveQuestData();
    
    return { success: true, quest: quest };
}

// 利用可能なクエストを取得
function getAvailableQuests(guildId = null) {
    const quests = Object.values(questData).filter(q => q.status === 'available');
    
    if (guildId) {
        // ギルドメンバーの場合：そのギルドのクエスト + システムクエスト（guildIdがないもの）
        const guildQuests = quests.filter(q => q.guildId === guildId);
        const systemQuests = quests.filter(q => !q.guildId);
        console.log(`Available quests for guild ${guildId}:`, { guildQuests: guildQuests.length, systemQuests: systemQuests.length });
        return [...guildQuests, ...systemQuests];
    }
    
    // ギルド未参加の場合：システムクエストのみ
    const systemQuests = quests.filter(q => !q.guildId);
    console.log('Available quests for non-guild player:', systemQuests.length);
    return systemQuests;
}

// プレイヤーのアクティブクエストを取得
function getPlayerActiveQuests(playerId) {
    return Object.values(questData).filter(q => 
        q.acceptedBy === playerId && q.status === 'accepted'
    );
}

// システムクエストを生成
function generateSystemQuests() {
    const systemQuests = [
        {
            title: '初心者トレーニング',
            description: '対戦で3回勝利せよ',
            category: 'BATTLE',
            rank: 'D',
            reward: 200,
            type: 'system'
        },
        {
            title: '素材収集',
            description: 'ショップでアイテムを5個購入せよ',
            category: 'DELIVERY',
            rank: 'F',
            reward: 30,
            type: 'system'
        },
        {
            title: '新人護衛',
            description: 'レベル10以下のプレイヤーと対戦して勝利せよ',
            category: 'ESCORT',
            rank: 'E',
            reward: 100,
            type: 'system'
        },
        {
            title: '戦術研究',
            description: 'ギルド掲示板で新しい戦術アイデアを投稿せよ',
            category: 'SPECIAL',
            rank: 'D',
            reward: 150,
            type: 'system'
        },
        {
            title: '連勝記録',
            description: '対戦で5連勝せよ',
            category: 'BATTLE',
            rank: 'B',
            reward: 400,
            type: 'system'
        },
        {
            title: '伝説の戦士',
            description: 'Sランクプレイヤーに勝利せよ',
            category: 'BATTLE',
            rank: 'S',
            reward: 1500,
            type: 'system'
        },
        {
            title: 'ギルド貢献',
            description: 'ギルドクエストを10回完了せよ',
            category: 'SPECIAL',
            rank: 'B',
            reward: 500,
            type: 'system'
        },
        {
            title: 'ボス討伐',
            description: 'ハード難易度のボスを1体討伐せよ',
            category: 'BATTLE',
            rank: 'A',
            reward: 800,
            type: 'system'
        },
        {
            title: 'ボスハンター',
            description: 'ボスを合計5体討伐せよ',
            category: 'BATTLE',
            rank: 'S',
            reward: 2000,
            type: 'system'
        }
    ];
    
    const createdQuests = [];
    for (const questTemplate of systemQuests) {
        const result = createQuest({
            ...questTemplate,
            createdBy: 'SYSTEM',
            creatorName: 'システム'
        });
        if (result.success) {
            createdQuests.push(result.quest);
        }
    }
    
    return createdQuests;
}

// ---------- ギルドコイン（金庫）と施設強化 ----------

function isGuildMember(guild, playerId) {
    return !!(guild && guild.members && guild.members.some(m => m.id === playerId));
}

// プレイヤーのコインをギルド金庫に納める。
// プレイヤー側のコイン減算は socket 側で PlayerDataManager を使って行い、
// ここでは「ギルドへの加算」だけを担当する（coins は正の整数のみ）。
function depositCoins(guildId, playerId, amount) {
    const guild = guildData[guildId];
    if (!guild) return { success: false, message: 'ギルドが見つかりません' };
    if (!isGuildMember(guild, playerId)) return { success: false, message: 'ギルドメンバーではありません' };
    amount = Math.floor(Number(amount));
    if (!isFinite(amount) || amount <= 0) return { success: false, message: 'コイン数が不正です' };
    if (amount > 100000000) return { success: false, message: '一度に納められるのは1億コインまでです' };
    normalizeGuild(guild);
    guild.coins += amount;
    saveGuildData();
    return { success: true, guild: normalizeGuild(guild) };
}

// 施設の強化コスト（現在レベルから次のレベルへの費用）
function buildingCost(guild, buildingId) {
    const def = BUILDINGS[buildingId];
    if (!def) return null;
    const lv = (guild.buildings && guild.buildings[buildingId] && guild.buildings[buildingId].level) || 0;
    if (lv >= def.maxLevel) return null;
    return Math.round(def.baseCost * Math.pow(def.costMult, lv));
}

// 施設を強化（リーダーのみ。ギルドコインを消費）
function upgradeBuilding(guildId, playerId, buildingId) {
    const guild = guildData[guildId];
    if (!guild) return { success: false, message: 'ギルドが見つかりません' };
    const def = BUILDINGS[buildingId];
    if (!def) return { success: false, message: '不明な施設です' };
    const member = guild.members.find(m => m.id === playerId);
    if (!member) return { success: false, message: 'ギルドメンバーではありません' };
    if (member.role !== 'leader') return { success: false, message: '施設の強化はギルドリーダーのみ行えます' };
    normalizeGuild(guild);
    const cost = buildingCost(guild, buildingId);
    if (cost == null) return { success: false, message: 'この施設は最大レベルです' };
    if (guild.coins < cost) return { success: false, message: 'ギルドコインが足りません（必要: ' + cost.toLocaleString('ja-JP') + '）' };
    guild.coins -= cost;
    guild.buildings[buildingId].level += 1;
    saveGuildData();
    return { success: true, guild: normalizeGuild(guild), building: buildingId, level: guild.buildings[buildingId].level, cost: cost };
}

// ギルド総合力（ランク表示・将来の城PvPの戦力計算に使う）
function guildPower(guild) {
    if (!guild) return 0;
    normalizeGuild(guild);
    let power = (guild.members || []).length * 10 + Math.floor((guild.contribution || 0) / 100);
    Object.keys(BUILDINGS).forEach(id => {
        const lv = (guild.buildings[id] && guild.buildings[id].level) || 0;
        power += lv * (BUILDING_POWER[id] || 5);
    });
    return power;
}

// 起動時ロード
loadGuildData();
loadQuestData();

// システムクエストがなければ生成
if (Object.keys(questData).length === 0) {
    console.log('[GuildManager] Generating system quests...');
    generateSystemQuests();
}

module.exports = {
    // ギルド管理
    createGuild,
    joinGuild,
    leaveGuild,
    getGuild,
    getPlayerGuild,
    getAllGuilds,
    addContribution,

    // コイン・施設
    depositCoins,
    buildingCost,
    upgradeBuilding,
    guildPower,
    BUILDINGS,
    isGuildMember,

    // クエスト管理
    createQuest,
    acceptQuest,
    reportQuest,
    payQuestReward,
    getAvailableQuests,
    getPlayerActiveQuests,
    generateSystemQuests,
    
    // 定数
    GUILD_RANKS,
    QUEST_CATEGORIES
};
