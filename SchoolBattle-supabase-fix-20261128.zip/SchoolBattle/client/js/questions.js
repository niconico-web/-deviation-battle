// client/js/questions.js
// 通常バトル（ボット戦・オンライン対戦）用の問題データ（server/data/questions.json と同じ内容）。
// ボット戦・オンライン対戦（人対人）はローカルで進行するため、
// クライアント側にも同じ問題データを持たせておく必要がある。
// 学校レベル（elementary/junior_high/high_school）×学年×教科ごとに問題が用意されている。
const QUESTIONS_DATA = {
    "elementary": {
        "1": {
            "math": [
                {
                    "question": "1 + 1 = ?",
                    "answer": "2"
                },
                {
                    "question": "2 + 3 = ?",
                    "answer": "5"
                },
                {
                    "question": "5 - 2 = ?",
                    "answer": "3"
                },
                {
                    "question": "10 - 5 = ?",
                    "answer": "5"
                },
                {
                    "question": "3 + 4 = ?",
                    "answer": "7"
                },
                {
                    "question": "2 + 2 = ?",
                    "answer": "4"
                },
                {
                    "question": "4 + 1 = ?",
                    "answer": "5"
                },
                {
                    "question": "6 + 3 = ?",
                    "answer": "9"
                },
                {
                    "question": "8 - 4 = ?",
                    "answer": "4"
                },
                {
                    "question": "9 - 3 = ?",
                    "answer": "6"
                },
                {
                    "question": "7 - 2 = ?",
                    "answer": "5"
                },
                {
                    "question": "5 + 5 = ?",
                    "answer": "10"
                },
                {
                    "question": "6 + 4 = ?",
                    "answer": "10"
                },
                {
                    "question": "10 - 6 = ?",
                    "answer": "4"
                },
                {
                    "question": "10 - 8 = ?",
                    "answer": "2"
                },
                {
                    "question": "3 + 3 = ?",
                    "answer": "6"
                },
                {
                    "question": "4 + 4 = ?",
                    "answer": "8"
                },
                {
                    "question": "6 + 2 = ?",
                    "answer": "8"
                },
                {
                    "question": "7 + 3 = ?",
                    "answer": "10"
                },
                {
                    "question": "8 + 2 = ?",
                    "answer": "10"
                },
                {
                    "question": "9 - 4 = ?",
                    "answer": "5"
                },
                {
                    "question": "8 - 3 = ?",
                    "answer": "5"
                },
                {
                    "question": "7 - 4 = ?",
                    "answer": "3"
                },
                {
                    "question": "6 - 3 = ?",
                    "answer": "3"
                },
                {
                    "question": "5 - 3 = ?",
                    "answer": "2"
                },
                {
                    "question": "4 + 6 = ?",
                    "answer": "10"
                },
                {
                    "question": "3 + 7 = ?",
                    "answer": "10"
                },
                {
                    "question": "2 + 8 = ?",
                    "answer": "10"
                },
                {
                    "question": "1 + 9 = ?",
                    "answer": "10"
                },
                {
                    "question": "10 - 1 = ?",
                    "answer": "9"
                },
                {
                    "question": "1 + 2 = ?",
                    "answer": "3"
                },
                {
                    "question": "3 + 1 = ?",
                    "answer": "4"
                },
                {
                    "question": "4 - 2 = ?",
                    "answer": "2"
                },
                {
                    "question": "5 - 4 = ?",
                    "answer": "1"
                },
                {
                    "question": "6 - 1 = ?",
                    "answer": "5"
                },
                {
                    "question": "7 - 5 = ?",
                    "answer": "2"
                },
                {
                    "question": "8 - 6 = ?",
                    "answer": "2"
                },
                {
                    "question": "9 - 7 = ?",
                    "answer": "2"
                },
                {
                    "question": "10 - 9 = ?",
                    "answer": "1"
                },
                {
                    "question": "2 + 1 = ?",
                    "answer": "3"
                },
                {
                    "question": "3 + 2 = ?",
                    "answer": "5"
                },
                {
                    "question": "4 + 2 = ?",
                    "answer": "6"
                },
                {
                    "question": "5 + 2 = ?",
                    "answer": "7"
                },
                {
                    "question": "6 + 2 = ?",
                    "answer": "8"
                },
                {
                    "question": "7 + 2 = ?",
                    "answer": "9"
                },
                {
                    "question": "8 + 1 = ?",
                    "answer": "9"
                },
                {
                    "question": "9 + 1 = ?",
                    "answer": "10"
                },
                {
                    "question": "10 - 2 = ?",
                    "answer": "8"
                },
                {
                    "question": "10 - 3 = ?",
                    "answer": "7"
                },
                {
                    "question": "10 - 4 = ?",
                    "answer": "6"
                },
                {
                    "question": "10 - 7 = ?",
                    "answer": "3"
                },
                {
                    "question": "2 + 5 = ?",
                    "answer": "7"
                },
                {
                    "question": "3 + 5 = ?",
                    "answer": "8"
                },
                {
                    "question": "4 + 5 = ?",
                    "answer": "9"
                },
                {
                    "question": "5 + 4 = ?",
                    "answer": "9"
                },
                {
                    "question": "6 + 1 = ?",
                    "answer": "7"
                },
                {
                    "question": "7 + 1 = ?",
                    "answer": "8"
                },
                {
                    "question": "8 - 1 = ?",
                    "answer": "7"
                },
                {
                    "question": "9 - 2 = ?",
                    "answer": "7"
                }
            ],
            "jp": [
                {
                    "question": "「い」の次のひらがなは？",
                    "answer": "う"
                },
                {
                    "question": "「か」の次のひらがなは？",
                    "answer": "き"
                },
                {
                    "question": "「さ」の次のひらがなは？",
                    "answer": "し"
                },
                {
                    "question": "「た」の次のひらがなは？",
                    "answer": "ち"
                },
                {
                    "question": "「な」の次のひらがなは？",
                    "answer": "に"
                },
                {
                    "question": "「は」の次のひらがなは？",
                    "answer": "ひ"
                },
                {
                    "question": "「ま」の次のひらがなは？",
                    "answer": "み"
                },
                {
                    "question": "「や」の次のひらがなは？",
                    "answer": "ゆ"
                },
                {
                    "question": "「ら」の次のひらがなは？",
                    "answer": "り"
                },
                {
                    "question": "「わ」の次のひらがなは？",
                    "answer": "を"
                },
                {
                    "question": "「お」の前のひらがなは？",
                    "answer": "え"
                },
                {
                    "question": "「き」の前のひらがなは？",
                    "answer": "か"
                },
                {
                    "question": "「し」の前のひらがなは？",
                    "answer": "さ"
                },
                {
                    "question": "「ち」の前のひらがなは？",
                    "answer": "た"
                },
                {
                    "question": "「に」の前のひらがなは？",
                    "answer": "な"
                },
                {
                    "question": "「ひ」の前のひらがなは？",
                    "answer": "は"
                },
                {
                    "question": "「み」の前のひらがなは？",
                    "answer": "ま"
                },
                {
                    "question": "「り」の前のひらがなは？",
                    "answer": "ら"
                },
                {
                    "question": "「を」の前のひらがなは？",
                    "answer": "わ"
                },
                {
                    "question": "あ行のひらがなはいくつ？",
                    "answer": "5"
                },
                {
                    "question": "か行のひらがなはいくつ？",
                    "answer": "5"
                },
                {
                    "question": "さ行のひらがなはいくつ？",
                    "answer": "5"
                },
                {
                    "question": "た行のひらがなはいくつ？",
                    "answer": "5"
                },
                {
                    "question": "な行のひらがなはいくつ？",
                    "answer": "5"
                },
                {
                    "question": "は行のひらがなはいくつ？",
                    "answer": "5"
                },
                {
                    "question": "ま行のひらがなはいくつ？",
                    "answer": "5"
                },
                {
                    "question": "や行のひらがなはいくつ？",
                    "answer": "3"
                },
                {
                    "question": "ら行のひらがなはいくつ？",
                    "answer": "5"
                },
                {
                    "question": "「あ」から始まる言葉は？",
                    "answer": "あめ"
                },
                {
                    "question": "「か」から始まる言葉は？",
                    "answer": "かさ"
                },
                {
                    "question": "「さ」から始まる言葉は？",
                    "answer": "さくら"
                }
            ]
        },
        "2": {
            "math": [
                {
                    "question": "7 + 8 = ?",
                    "answer": "15"
                },
                {
                    "question": "15 - 7 = ?",
                    "answer": "8"
                },
                {
                    "question": "9 + 6 = ?",
                    "answer": "15"
                },
                {
                    "question": "20 - 12 = ?",
                    "answer": "8"
                },
                {
                    "question": "5 × 2 = ?",
                    "answer": "10"
                },
                {
                    "question": "6 + 9 = ?",
                    "answer": "15"
                },
                {
                    "question": "8 + 7 = ?",
                    "answer": "15"
                },
                {
                    "question": "14 - 6 = ?",
                    "answer": "8"
                },
                {
                    "question": "16 - 8 = ?",
                    "answer": "8"
                },
                {
                    "question": "3 × 3 = ?",
                    "answer": "9"
                },
                {
                    "question": "4 × 2 = ?",
                    "answer": "8"
                },
                {
                    "question": "6 × 2 = ?",
                    "answer": "12"
                },
                {
                    "question": "7 × 2 = ?",
                    "answer": "14"
                },
                {
                    "question": "8 × 2 = ?",
                    "answer": "16"
                },
                {
                    "question": "9 × 2 = ?",
                    "answer": "18"
                },
                {
                    "question": "5 × 3 = ?",
                    "answer": "15"
                },
                {
                    "question": "4 × 3 = ?",
                    "answer": "12"
                },
                {
                    "question": "6 × 3 = ?",
                    "answer": "18"
                },
                {
                    "question": "12 - 4 = ?",
                    "answer": "8"
                },
                {
                    "question": "13 - 5 = ?",
                    "answer": "8"
                },
                {
                    "question": "11 - 3 = ?",
                    "answer": "8"
                },
                {
                    "question": "17 - 9 = ?",
                    "answer": "8"
                },
                {
                    "question": "15 - 8 = ?",
                    "answer": "7"
                },
                {
                    "question": "14 - 7 = ?",
                    "answer": "7"
                },
                {
                    "question": "13 - 6 = ?",
                    "answer": "7"
                },
                {
                    "question": "10 + 5 = ?",
                    "answer": "15"
                },
                {
                    "question": "11 + 4 = ?",
                    "answer": "15"
                },
                {
                    "question": "12 + 3 = ?",
                    "answer": "15"
                },
                {
                    "question": "18 - 3 = ?",
                    "answer": "15"
                },
                {
                    "question": "19 - 4 = ?",
                    "answer": "15"
                }
            ],
            "jp": [
                {
                    "question": "犬のひらがなは？",
                    "answer": "いぬ"
                },
                {
                    "question": "猫のひらがなは？",
                    "answer": "ねこ"
                },
                {
                    "question": "鳥のひらがなは？",
                    "answer": "とり"
                },
                {
                    "question": "魚のひらがなは？",
                    "answer": "さかな"
                },
                {
                    "question": "花のひらがなは？",
                    "answer": "はな"
                },
                {
                    "question": "山のひらがなは？",
                    "answer": "やま"
                },
                {
                    "question": "川のひらがなは？",
                    "answer": "かわ"
                },
                {
                    "question": "空のひらがなは？",
                    "answer": "そら"
                },
                {
                    "question": "海のひらがなは？",
                    "answer": "うみ"
                },
                {
                    "question": "雨のひらがなは？",
                    "answer": "あめ"
                },
                {
                    "question": "雪のひらがなは？",
                    "answer": "ゆき"
                },
                {
                    "question": "風のひらがなは？",
                    "answer": "かぜ"
                },
                {
                    "question": "木のひらがなは？",
                    "answer": "き"
                },
                {
                    "question": "草のひらがなは？",
                    "answer": "くさ"
                },
                {
                    "question": "土のひらがなは？",
                    "answer": "つち"
                },
                {
                    "question": "火のひらがなは？",
                    "answer": "ひ"
                },
                {
                    "question": "水のひらがなは？",
                    "answer": "みず"
                },
                {
                    "question": "月のひらがなは？",
                    "answer": "つき"
                },
                {
                    "question": "星のひらがなは？",
                    "answer": "ほし"
                },
                {
                    "question": "雲のひらがなは？",
                    "answer": "くも"
                },
                {
                    "question": "森のひらがなは？",
                    "answer": "もり"
                },
                {
                    "question": "林のひらがなは？",
                    "answer": "はやし"
                },
                {
                    "question": "石のひらがなは？",
                    "answer": "いし"
                },
                {
                    "question": "砂のひらがなは？",
                    "answer": "すな"
                },
                {
                    "question": "池のひらがなは？",
                    "answer": "いけ"
                },
                {
                    "question": "湖のひらがなは？",
                    "answer": "みずうみ"
                },
                {
                    "question": "野のひらがなは？",
                    "answer": "の"
                },
                {
                    "question": "原のひらがなは？",
                    "answer": "はら"
                },
                {
                    "question": "岩のひらがなは？",
                    "answer": "いわ"
                },
                {
                    "question": "「赤」の反対語は？",
                    "answer": "青"
                },
                {
                    "question": "「白」の反対語は？",
                    "answer": "黒"
                }
            ]
        },
        "3": {
            "math": [
                {
                    "question": "23 + 47 = ?",
                    "answer": "70"
                },
                {
                    "question": "100 - 35 = ?",
                    "answer": "65"
                },
                {
                    "question": "6 × 7 = ?",
                    "answer": "42"
                },
                {
                    "question": "81 ÷ 9 = ?",
                    "answer": "9"
                },
                {
                    "question": "45 ÷ 5 = ?",
                    "answer": "9"
                },
                {
                    "question": "8 × 7 = ?",
                    "answer": "56"
                },
                {
                    "question": "9 × 6 = ?",
                    "answer": "54"
                },
                {
                    "question": "7 × 8 = ?",
                    "answer": "56"
                },
                {
                    "question": "64 ÷ 8 = ?",
                    "answer": "8"
                },
                {
                    "question": "72 ÷ 9 = ?",
                    "answer": "8"
                },
                {
                    "question": "56 ÷ 7 = ?",
                    "answer": "8"
                },
                {
                    "question": "54 ÷ 6 = ?",
                    "answer": "9"
                },
                {
                    "question": "63 ÷ 7 = ?",
                    "answer": "9"
                },
                {
                    "question": "32 + 18 = ?",
                    "answer": "50"
                },
                {
                    "question": "41 + 29 = ?",
                    "answer": "70"
                },
                {
                    "question": "55 + 25 = ?",
                    "answer": "80"
                },
                {
                    "question": "90 - 25 = ?",
                    "answer": "65"
                },
                {
                    "question": "80 - 34 = ?",
                    "answer": "46"
                },
                {
                    "question": "75 - 28 = ?",
                    "answer": "47"
                },
                {
                    "question": "5 × 9 = ?",
                    "answer": "45"
                },
                {
                    "question": "6 × 8 = ?",
                    "answer": "48"
                },
                {
                    "question": "7 × 7 = ?",
                    "answer": "49"
                },
                {
                    "question": "36 ÷ 4 = ?",
                    "answer": "9"
                },
                {
                    "question": "42 ÷ 6 = ?",
                    "answer": "7"
                },
                {
                    "question": "49 ÷ 7 = ?",
                    "answer": "7"
                },
                {
                    "question": "27 + 33 = ?",
                    "answer": "60"
                },
                {
                    "question": "38 + 42 = ?",
                    "answer": "80"
                },
                {
                    "question": "100 - 45 = ?",
                    "answer": "55"
                },
                {
                    "question": "100 - 28 = ?",
                    "answer": "72"
                },
                {
                    "question": "4 × 9 = ?",
                    "answer": "36"
                },
                {
                    "question": "3 × 8 = ?",
                    "answer": "24"
                }
            ],
            "jp": [
                {
                    "question": "「走る」の反対語は？",
                    "answer": "止まる"
                },
                {
                    "question": "「大きい」の反対語は？",
                    "answer": "小さい"
                },
                {
                    "question": "「明るい」の反対語は？",
                    "answer": "暗い"
                },
                {
                    "question": "「新しい」の反対語は？",
                    "answer": "古い"
                },
                {
                    "question": "「高い」の反対語は？",
                    "answer": "低い"
                },
                {
                    "question": "「来る」の反対語は？",
                    "answer": "行く"
                },
                {
                    "question": "「起きる」の反対語は？",
                    "answer": "寝る"
                },
                {
                    "question": "「笑う」の反対語は？",
                    "answer": "泣く"
                },
                {
                    "question": "「勝つ」の反対語は？",
                    "answer": "負ける"
                },
                {
                    "question": "「始まる」の反対語は？",
                    "answer": "終わる"
                },
                {
                    "question": "「遅い」の反対語は？",
                    "answer": "速い"
                },
                {
                    "question": "「重い」の反対語は？",
                    "answer": "軽い"
                },
                {
                    "question": "「長い」の反対語は？",
                    "answer": "短い"
                },
                {
                    "question": "「太い」の反対語は？",
                    "answer": "細い"
                },
                {
                    "question": "「広い」の反対語は？",
                    "answer": "狭い"
                },
                {
                    "question": "「多い」の反対語は？",
                    "answer": "少ない"
                },
                {
                    "question": "「強い」の反対語は？",
                    "answer": "弱い"
                },
                {
                    "question": "「遠い」の反対語は？",
                    "answer": "近い"
                },
                {
                    "question": "「暑い」の反対語は？",
                    "answer": "寒い"
                },
                {
                    "question": "「熱い」の反対語は？",
                    "answer": "冷たい"
                },
                {
                    "question": "「甘い」の反対語は？",
                    "answer": "辛い"
                },
                {
                    "question": "「いい」の反対語は？",
                    "answer": "悪い"
                },
                {
                    "question": "「楽しい」の反対語は？",
                    "answer": "つまらない"
                },
                {
                    "question": "「忙しい」の反対語は？",
                    "answer": "暇"
                },
                {
                    "question": "「うるさい」の反対語は？",
                    "answer": "静か"
                },
                {
                    "question": "「きれい」の反対語は？",
                    "answer": "汚い"
                },
                {
                    "question": "「安全」の反対語は？",
                    "answer": "危険"
                },
                {
                    "question": "「簡単」の反対語は？",
                    "answer": "難しい"
                },
                {
                    "question": "「正しい」の反対語は？",
                    "answer": "間違っている"
                },
                {
                    "question": "「豊か」の反対語は？",
                    "answer": "貧しい"
                }
            ]
        },
        "4": {
            "math": [
                {
                    "question": "345 + 678 = ?",
                    "answer": "1023"
                },
                {
                    "question": "1000 - 456 = ?",
                    "answer": "544"
                },
                {
                    "question": "12 × 8 = ?",
                    "answer": "96"
                },
                {
                    "question": "144 ÷ 12 = ?",
                    "answer": "12"
                },
                {
                    "question": "25 × 4 = ?",
                    "answer": "100"
                },
                {
                    "question": "15 × 6 = ?",
                    "answer": "90"
                },
                {
                    "question": "18 × 5 = ?",
                    "answer": "90"
                },
                {
                    "question": "13 × 7 = ?",
                    "answer": "91"
                },
                {
                    "question": "156 ÷ 12 = ?",
                    "answer": "13"
                },
                {
                    "question": "168 ÷ 14 = ?",
                    "answer": "12"
                },
                {
                    "question": "180 ÷ 15 = ?",
                    "answer": "12"
                },
                {
                    "question": "234 + 567 = ?",
                    "answer": "801"
                },
                {
                    "question": "456 + 789 = ?",
                    "answer": "1245"
                },
                {
                    "question": "2000 - 789 = ?",
                    "answer": "1211"
                },
                {
                    "question": "1500 - 678 = ?",
                    "answer": "822"
                },
                {
                    "question": "14 × 6 = ?",
                    "answer": "84"
                },
                {
                    "question": "16 × 7 = ?",
                    "answer": "112"
                },
                {
                    "question": "17 × 5 = ?",
                    "answer": "85"
                },
                {
                    "question": "192 ÷ 16 = ?",
                    "answer": "12"
                },
                {
                    "question": "210 ÷ 14 = ?",
                    "answer": "15"
                },
                {
                    "question": "225 ÷ 15 = ?",
                    "answer": "15"
                },
                {
                    "question": "678 + 345 = ?",
                    "answer": "1023"
                },
                {
                    "question": "890 - 234 = ?",
                    "answer": "656"
                },
                {
                    "question": "1200 - 567 = ?",
                    "answer": "633"
                },
                {
                    "question": "19 × 4 = ?",
                    "answer": "76"
                },
                {
                    "question": "21 × 6 = ?",
                    "answer": "126"
                },
                {
                    "question": "24 ÷ 8 = ?",
                    "answer": "3"
                },
                {
                    "question": "32 ÷ 4 = ?",
                    "answer": "8"
                },
                {
                    "question": "45 ÷ 9 = ?",
                    "answer": "5"
                },
                {
                    "question": "567 + 432 = ?",
                    "answer": "999"
                },
                {
                    "question": "1800 - 945 = ?",
                    "answer": "855"
                }
            ],
            "jp": [
                {
                    "question": "「枕草子」の作者は？",
                    "answer": "清少納言"
                },
                {
                    "question": "「源氏物語」の作者は？",
                    "answer": "紫式部"
                },
                {
                    "question": "「徒然草」の作者は？",
                    "answer": "吉田兼好"
                },
                {
                    "question": "「方丈記」の作者は？",
                    "answer": "鴨長明"
                },
                {
                    "question": "「奥の細道」の作者は？",
                    "answer": "松尾芭蕉"
                },
                {
                    "question": "「美しい、この花は」で使われている技法は？",
                    "answer": "倒置法"
                },
                {
                    "question": "「ライオンのように強い」で使われている技法は？",
                    "answer": "比喩"
                },
                {
                    "question": "「走った、走った、走った」で使われている技法は？",
                    "answer": "反復"
                },
                {
                    "question": "「山と川、天と地」で使われている技法は？",
                    "answer": "対句"
                },
                {
                    "question": "「風がささやく」で使われている技法は？",
                    "answer": "擬人法"
                },
                {
                    "question": "「～けれども、～ので」で使われている技法は？",
                    "answer": "係り結び"
                },
                {
                    "question": "「彼に褒められた」で使われている技法は？",
                    "answer": "受動態"
                },
                {
                    "question": "「彼を行かせた」で使われている技法は？",
                    "answer": "使役態"
                },
                {
                    "question": "「いらっしゃる、おっしゃる」で使われている技法は？",
                    "answer": "尊敬語"
                },
                {
                    "question": "「参る、申す」で使われている技法は？",
                    "answer": "謙譲語"
                },
                {
                    "question": "「春」の次の季節は？",
                    "answer": "夏"
                },
                {
                    "question": "「夏」の次の季節は？",
                    "answer": "秋"
                },
                {
                    "question": "「秋」の次の季節は？",
                    "answer": "冬"
                },
                {
                    "question": "「冬」の次の季節は？",
                    "answer": "春"
                },
                {
                    "question": "「火曜日」の次の曜日は？",
                    "answer": "水曜日"
                },
                {
                    "question": "「水曜日」の次の曜日は？",
                    "answer": "木曜日"
                },
                {
                    "question": "「木曜日」の次の曜日は？",
                    "answer": "金曜日"
                },
                {
                    "question": "「金曜日」の次の曜日は？",
                    "answer": "土曜日"
                },
                {
                    "question": "「土曜日」の次の曜日は？",
                    "answer": "日曜日"
                },
                {
                    "question": "「日曜日」の次の曜日は？",
                    "answer": "月曜日"
                },
                {
                    "question": "「2月」の次の月は？",
                    "answer": "3月"
                },
                {
                    "question": "「3月」の次の月は？",
                    "answer": "4月"
                },
                {
                    "question": "「4月」の次の月は？",
                    "answer": "5月"
                },
                {
                    "question": "「5月」の次の月は？",
                    "answer": "6月"
                },
                {
                    "question": "「6月」の次の月は？",
                    "answer": "7月"
                },
                {
                    "question": "「7月」の次の月は？",
                    "answer": "8月"
                },
                {
                    "question": "「8月」の次の月は？",
                    "answer": "9月"
                },
                {
                    "question": "「9月」の次の月は？",
                    "answer": "10月"
                },
                {
                    "question": "「10月」の次の月は？",
                    "answer": "11月"
                },
                {
                    "question": "「11月」の次の月は？",
                    "answer": "12月"
                },
                {
                    "question": "「12月」の次の月は？",
                    "answer": "1月"
                },
                {
                    "question": "「昼」の次は？",
                    "answer": "夜"
                },
                {
                    "question": "「夜」の次は？",
                    "answer": "朝"
                },
                {
                    "question": "「昨日」の次は？",
                    "answer": "今日"
                },
                {
                    "question": "「明日」の次は？",
                    "answer": "明後日"
                },
                {
                    "question": "「去年」の次は？",
                    "answer": "今年"
                },
                {
                    "question": "「今年」の次は？",
                    "answer": "来年"
                }
            ]
        },
        "5": {
            "math": [
                {
                    "question": "2.5 + 3.7 = ?",
                    "answer": "6.2"
                },
                {
                    "question": "10 - 4.8 = ?",
                    "answer": "5.2"
                },
                {
                    "question": "1.2 × 5 = ?",
                    "answer": "6"
                },
                {
                    "question": "15 ÷ 0.5 = ?",
                    "answer": "30"
                },
                {
                    "question": "3.6 ÷ 1.2 = ?",
                    "answer": "3"
                },
                {
                    "question": "4.5 + 2.8 = ?",
                    "answer": "7.3"
                },
                {
                    "question": "6.7 - 3.4 = ?",
                    "answer": "3.3"
                },
                {
                    "question": "8.9 - 5.6 = ?",
                    "answer": "3.3"
                },
                {
                    "question": "2.4 × 3 = ?",
                    "answer": "7.2"
                },
                {
                    "question": "3.5 × 2 = ?",
                    "answer": "7"
                },
                {
                    "question": "4.8 × 2 = ?",
                    "answer": "9.6"
                },
                {
                    "question": "12 ÷ 0.4 = ?",
                    "answer": "30"
                },
                {
                    "question": "18 ÷ 0.6 = ?",
                    "answer": "30"
                },
                {
                    "question": "24 ÷ 0.8 = ?",
                    "answer": "30"
                },
                {
                    "question": "5.6 ÷ 1.4 = ?",
                    "answer": "4"
                },
                {
                    "question": "7.2 ÷ 1.2 = ?",
                    "answer": "6"
                },
                {
                    "question": "8.4 ÷ 2.1 = ?",
                    "answer": "4"
                },
                {
                    "question": "3.8 + 4.2 = ?",
                    "answer": "8"
                },
                {
                    "question": "5.5 + 4.5 = ?",
                    "answer": "10"
                },
                {
                    "question": "9.9 - 4.4 = ?",
                    "answer": "5.5"
                },
                {
                    "question": "7.7 - 3.3 = ?",
                    "answer": "4.4"
                },
                {
                    "question": "1.8 × 4 = ?",
                    "answer": "7.2"
                },
                {
                    "question": "2.5 × 4 = ?",
                    "answer": "10"
                },
                {
                    "question": "3.2 × 3 = ?",
                    "answer": "9.6"
                },
                {
                    "question": "21 ÷ 0.7 = ?",
                    "answer": "30"
                },
                {
                    "question": "27 ÷ 0.9 = ?",
                    "answer": "30"
                },
                {
                    "question": "6.3 ÷ 2.1 = ?",
                    "answer": "3"
                },
                {
                    "question": "8.8 ÷ 2.2 = ?",
                    "answer": "4"
                },
                {
                    "question": "4.2 + 3.8 = ?",
                    "answer": "8"
                },
                {
                    "question": "6.6 - 2.2 = ?",
                    "answer": "4.4"
                }
            ],
            "jp": [
                {
                    "question": "「国語」の漢字で「くに」と読む漢字は？",
                    "answer": "国"
                },
                {
                    "question": "「算数」の漢字で「さん」と読む漢字は？",
                    "answer": "算"
                },
                {
                    "question": "「理科」の漢字で「り」と読む漢字は？",
                    "answer": "理"
                },
                {
                    "question": "「社会」の漢字で「しゃ」と読む漢字は？",
                    "answer": "社"
                },
                {
                    "question": "「音楽」の漢字で「おと」と読む漢字は？",
                    "answer": "音"
                },
                {
                    "question": "「図画」の漢字で「え」と読む漢字は？",
                    "answer": "画"
                },
                {
                    "question": "「体育」の漢字で「たい」と読む漢字は？",
                    "answer": "体"
                },
                {
                    "question": "「家庭」の漢字で「か」と読む漢字は？",
                    "answer": "家"
                },
                {
                    "question": "「技術」の漢字で「ぎ」と読む漢字は？",
                    "answer": "技"
                },
                {
                    "question": "「英語」の漢字で「えい」と読む漢字は？",
                    "answer": "英"
                },
                {
                    "question": "「時間」の漢字で「じ」と読む漢字は？",
                    "answer": "時"
                },
                {
                    "question": "「世界」の漢字で「せ」と読む漢字は？",
                    "answer": "世"
                },
                {
                    "question": "「日本」の漢字で「に」と読む漢字は？",
                    "answer": "日"
                },
                {
                    "question": "「文字」の漢字で「も」と読む漢字は？",
                    "answer": "文"
                },
                {
                    "question": "「数字」の漢字で「す」と読む漢字は？",
                    "answer": "数"
                },
                {
                    "question": "「言葉」の漢字で「こと」と読む漢字は？",
                    "answer": "言"
                },
                {
                    "question": "「意味」の漢字で「い」と読む漢字は？",
                    "answer": "意"
                },
                {
                    "question": "「考える」の漢字で「かんが」と読む漢字は？",
                    "answer": "考"
                },
                {
                    "question": "「学ぶ」の漢字で「まな」と読む漢字は？",
                    "answer": "学"
                },
                {
                    "question": "「読む」の漢字で「よ」と読む漢字は？",
                    "answer": "読"
                },
                {
                    "question": "「書く」の漢字で「か」と読む漢字は？",
                    "answer": "書"
                },
                {
                    "question": "「話す」の漢字で「はな」と読む漢字は？",
                    "answer": "話"
                },
                {
                    "question": "「聞く」の漢字で「き」と読む漢字は？",
                    "answer": "聞"
                },
                {
                    "question": "「見る」の漢字で「み」と読む漢字は？",
                    "answer": "見"
                },
                {
                    "question": "「食べる」の漢字で「た」と読む漢字は？",
                    "answer": "食"
                },
                {
                    "question": "「飲む」の漢字で「の」と読む漢字は？",
                    "answer": "飲"
                },
                {
                    "question": "「買う」の漢字で「か」と読む漢字は？",
                    "answer": "買"
                },
                {
                    "question": "「売る」の漢字で「う」と読む漢字は？",
                    "answer": "売"
                },
                {
                    "question": "「作る」の漢字で「つく」と読む漢字は？",
                    "answer": "作"
                }
            ]
        },
        "6": {
            "math": [
                {
                    "question": "1/2 + 1/3 = ?",
                    "answer": "5/6"
                },
                {
                    "question": "3/4 - 1/4 = ?",
                    "answer": "1/2"
                },
                {
                    "question": "2/3 × 3/4 = ?",
                    "answer": "1/2"
                },
                {
                    "question": "5 ÷ 1/2 = ?",
                    "answer": "10"
                },
                {
                    "question": "1/5 ÷ 2 = ?",
                    "answer": "1/10"
                },
                {
                    "question": "2/5 + 1/5 = ?",
                    "answer": "3/5"
                },
                {
                    "question": "3/8 + 1/8 = ?",
                    "answer": "1/2"
                },
                {
                    "question": "5/6 - 1/6 = ?",
                    "answer": "2/3"
                },
                {
                    "question": "7/8 - 3/8 = ?",
                    "answer": "1/2"
                },
                {
                    "question": "1/4 × 1/2 = ?",
                    "answer": "1/8"
                },
                {
                    "question": "2/3 × 1/3 = ?",
                    "answer": "2/9"
                },
                {
                    "question": "3/4 × 2/3 = ?",
                    "answer": "1/2"
                },
                {
                    "question": "6 ÷ 1/3 = ?",
                    "answer": "18"
                },
                {
                    "question": "8 ÷ 1/4 = ?",
                    "answer": "32"
                },
                {
                    "question": "10 ÷ 2/5 = ?",
                    "answer": "25"
                },
                {
                    "question": "1/2 ÷ 2 = ?",
                    "answer": "1/4"
                },
                {
                    "question": "3/4 ÷ 3 = ?",
                    "answer": "1/4"
                },
                {
                    "question": "4/5 ÷ 4 = ?",
                    "answer": "1/5"
                },
                {
                    "question": "2/3 + 1/6 = ?",
                    "answer": "5/6"
                },
                {
                    "question": "1/2 + 1/4 = ?",
                    "answer": "3/4"
                },
                {
                    "question": "3/5 - 1/10 = ?",
                    "answer": "1/2"
                },
                {
                    "question": "5/8 - 1/4 = ?",
                    "answer": "3/8"
                },
                {
                    "question": "1/3 × 1/4 = ?",
                    "answer": "1/12"
                },
                {
                    "question": "2/5 × 5/6 = ?",
                    "answer": "1/3"
                },
                {
                    "question": "3/8 × 4/5 = ?",
                    "answer": "3/10"
                },
                {
                    "question": "12 ÷ 3/4 = ?",
                    "answer": "16"
                },
                {
                    "question": "15 ÷ 5/6 = ?",
                    "answer": "18"
                },
                {
                    "question": "2/3 ÷ 4 = ?",
                    "answer": "1/6"
                },
                {
                    "question": "5/6 ÷ 5 = ?",
                    "answer": "1/6"
                },
                {
                    "question": "3/4 + 1/8 = ?",
                    "answer": "7/8"
                }
            ],
            "jp": [
                {
                    "question": "「成功」の反対語は？",
                    "answer": "失敗"
                },
                {
                    "question": "「希望」の反対語は？",
                    "answer": "絶望"
                },
                {
                    "question": "「平和」の反対語は？",
                    "answer": "戦争"
                },
                {
                    "question": "「健康」の反対語は？",
                    "answer": "病気"
                },
                {
                    "question": "「豊か」の反対語は？",
                    "answer": "貧しい"
                },
                {
                    "question": "「安全」の反対語は？",
                    "answer": "危険"
                },
                {
                    "question": "「自由」の反対語は？",
                    "answer": "束縛"
                },
                {
                    "question": "「幸せ」の反対語は？",
                    "answer": "不幸"
                },
                {
                    "question": "「明るい」の反対語は？",
                    "answer": "暗い"
                },
                {
                    "question": "「新しい」の反対語は？",
                    "answer": "古い"
                },
                {
                    "question": "「高い」の反対語は？",
                    "answer": "低い"
                },
                {
                    "question": "「遅い」の反対語は？",
                    "answer": "速い"
                },
                {
                    "question": "「重い」の反対語は？",
                    "answer": "軽い"
                },
                {
                    "question": "「長い」の反対語は？",
                    "answer": "短い"
                },
                {
                    "question": "「太い」の反対語は？",
                    "answer": "細い"
                },
                {
                    "question": "「広い」の反対語は？",
                    "answer": "狭い"
                },
                {
                    "question": "「多い」の反対語は？",
                    "answer": "少ない"
                },
                {
                    "question": "「強い」の反対語は？",
                    "answer": "弱い"
                },
                {
                    "question": "「遠い」の反対語は？",
                    "answer": "近い"
                },
                {
                    "question": "「暑い」の反対語は？",
                    "answer": "寒い"
                },
                {
                    "question": "「熱い」の反対語は？",
                    "answer": "冷たい"
                },
                {
                    "question": "「甘い」の反対語は？",
                    "answer": "辛い"
                },
                {
                    "question": "「いい」の反対語は？",
                    "answer": "悪い"
                },
                {
                    "question": "「楽しい」の反対語は？",
                    "answer": "つまらない"
                },
                {
                    "question": "「忙しい」の反対語は？",
                    "answer": "暇"
                },
                {
                    "question": "「うるさい」の反対語は？",
                    "answer": "静か"
                },
                {
                    "question": "「きれい」の反対語は？",
                    "answer": "汚い"
                },
                {
                    "question": "「安全」の意味は？",
                    "answer": "危なくない"
                },
                {
                    "question": "「危険」の意味は？",
                    "answer": "危ない"
                },
                {
                    "question": "「正しい」の意味は？",
                    "answer": "間違っていない"
                }
            ]
        }
    },
    "junior_high": {
        "1": {
            "math": [
                {
                    "question": "-5 + 3 = ?",
                    "answer": "-2"
                },
                {
                    "question": "-2 × -3 = ?",
                    "answer": "6"
                },
                {
                    "question": "10 ÷ -2 = ?",
                    "answer": "-5"
                },
                {
                    "question": "3x + 2x = ?",
                    "answer": "5x"
                },
                {
                    "question": "2(x + 3) = ?",
                    "answer": "2x+6"
                },
                {
                    "question": "-8 + 5 = ?",
                    "answer": "-3"
                },
                {
                    "question": "-3 × 4 = ?",
                    "answer": "-12"
                },
                {
                    "question": "-15 ÷ 3 = ?",
                    "answer": "-5"
                },
                {
                    "question": "7x - 3x = ?",
                    "answer": "4x"
                },
                {
                    "question": "5(x - 2) = ?",
                    "answer": "5x-10"
                },
                {
                    "question": "-6 - 4 = ?",
                    "answer": "-10"
                },
                {
                    "question": "-7 + (-3) = ?",
                    "answer": "-10"
                },
                {
                    "question": "-4 × -2 = ?",
                    "answer": "8"
                },
                {
                    "question": "20 ÷ -4 = ?",
                    "answer": "-5"
                },
                {
                    "question": "6x + 4x = ?",
                    "answer": "10x"
                },
                {
                    "question": "3(2x + 1) = ?",
                    "answer": "6x+3"
                },
                {
                    "question": "-9 + 6 = ?",
                    "answer": "-3"
                },
                {
                    "question": "-5 × -5 = ?",
                    "answer": "25"
                },
                {
                    "question": "-18 ÷ -6 = ?",
                    "answer": "3"
                },
                {
                    "question": "8x - 5x = ?",
                    "answer": "3x"
                },
                {
                    "question": "4(x + 5) = ?",
                    "answer": "4x+20"
                },
                {
                    "question": "-12 + 8 = ?",
                    "answer": "-4"
                },
                {
                    "question": "-3 × 6 = ?",
                    "answer": "-18"
                },
                {
                    "question": "-24 ÷ 4 = ?",
                    "answer": "-6"
                },
                {
                    "question": "9x + x = ?",
                    "answer": "10x"
                },
                {
                    "question": "2(3x - 2) = ?",
                    "answer": "6x-4"
                },
                {
                    "question": "-7 - 5 = ?",
                    "answer": "-12"
                },
                {
                    "question": "-8 + (-4) = ?",
                    "answer": "-12"
                },
                {
                    "question": "-6 × -3 = ?",
                    "answer": "18"
                },
                {
                    "question": "30 ÷ -5 = ?",
                    "answer": "-6"
                }
            ],
            "eng": [
                {
                    "question": "犬の英語は？",
                    "answer": "dog"
                },
                {
                    "question": "猫の英語は？",
                    "answer": "cat"
                },
                {
                    "question": "本の英語は？",
                    "answer": "book"
                },
                {
                    "question": "学校の英語は？",
                    "answer": "school"
                },
                {
                    "question": "先生の英語は？",
                    "answer": "teacher"
                },
                {
                    "question": "学生の英語は？",
                    "answer": "student"
                },
                {
                    "question": "友達の英語は？",
                    "answer": "friend"
                },
                {
                    "question": "家族の英語は？",
                    "answer": "family"
                },
                {
                    "question": "家の英語は？",
                    "answer": "house"
                },
                {
                    "question": "車の英語は？",
                    "answer": "car"
                },
                {
                    "question": "食べるの英語は？",
                    "answer": "eat"
                },
                {
                    "question": "飲むの英語は？",
                    "answer": "drink"
                },
                {
                    "question": "寝るの英語は？",
                    "answer": "sleep"
                },
                {
                    "question": "起きるの英語は？",
                    "answer": "wake"
                },
                {
                    "question": "走るの英語は？",
                    "answer": "run"
                },
                {
                    "question": "歩くの英語は？",
                    "answer": "walk"
                },
                {
                    "question": "話すの英語は？",
                    "answer": "speak"
                },
                {
                    "question": "聞くの英語は？",
                    "answer": "listen"
                },
                {
                    "question": "見るの英語は？",
                    "answer": "see"
                },
                {
                    "question": "読むの英語は？",
                    "answer": "read"
                },
                {
                    "question": "書くの英語は？",
                    "answer": "write"
                },
                {
                    "question": "勉強するの英語は？",
                    "answer": "study"
                },
                {
                    "question": "遊ぶの英語は？",
                    "answer": "play"
                },
                {
                    "question": "働くの英語は？",
                    "answer": "work"
                },
                {
                    "question": "来るの英語は？",
                    "answer": "come"
                },
                {
                    "question": "行くの英語は？",
                    "answer": "go"
                },
                {
                    "question": "買うの英語は？",
                    "answer": "buy"
                },
                {
                    "question": "持つの英語は？",
                    "answer": "have"
                },
                {
                    "question": "好きの英語は？",
                    "answer": "like"
                },
                {
                    "question": "嫌いの英語は？",
                    "answer": "hate"
                },
                {
                    "question": "赤の英語は？",
                    "answer": "red"
                },
                {
                    "question": "青の英語は？",
                    "answer": "blue"
                }
            ]
        },
        "2": {
            "math": [
                {
                    "question": "2x + 5 = 15 の解は？",
                    "answer": "5"
                },
                {
                    "question": "3x - 7 = 14 の解は？",
                    "answer": "7"
                },
                {
                    "question": "(x + 2)(x - 3) = ?",
                    "answer": "x²-x-6"
                },
                {
                    "question": "4x - 3 = 13 の解は？",
                    "answer": "4"
                },
                {
                    "question": "5x + 8 = 28 の解は？",
                    "answer": "4"
                },
                {
                    "question": "(x - 1)(x + 4) = ?",
                    "answer": "x²+3x-4"
                },
                {
                    "question": "6x + 2 = 20 の解は？",
                    "answer": "3"
                },
                {
                    "question": "7x - 5 = 16 の解は？",
                    "answer": "3"
                },
                {
                    "question": "(x + 3)(x + 2) = ?",
                    "answer": "x²+5x+6"
                },
                {
                    "question": "8x - 12 = 20 の解は？",
                    "answer": "4"
                },
                {
                    "question": "9x + 3 = 30 の解は？",
                    "answer": "3"
                },
                {
                    "question": "(x - 2)(x - 5) = ?",
                    "answer": "x²-7x+10"
                },
                {
                    "question": "10x - 15 = 25 の解は？",
                    "answer": "4"
                },
                {
                    "question": "11x + 7 = 40 の解は？",
                    "answer": "3"
                },
                {
                    "question": "(x + 4)(x - 2) = ?",
                    "answer": "x²+2x-8"
                },
                {
                    "question": "12x - 8 = 28 の解は？",
                    "answer": "3"
                },
                {
                    "question": "13x + 5 = 44 の解は？",
                    "answer": "3"
                },
                {
                    "question": "(x - 3)(x + 5) = ?",
                    "answer": "x²+2x-15"
                },
                {
                    "question": "14x + 6 = 62 の解は？",
                    "answer": "4"
                },
                {
                    "question": "15x - 9 = 36 の解は？",
                    "answer": "3"
                },
                {
                    "question": "(x + 5)(x - 4) = ?",
                    "answer": "x²+x-20"
                },
                {
                    "question": "16x - 20 = 44 の解は？",
                    "answer": "4"
                },
                {
                    "question": "17x + 8 = 59 の解は？",
                    "answer": "3"
                },
                {
                    "question": "(x - 6)(x + 2) = ?",
                    "answer": "x²-4x-12"
                },
                {
                    "question": "18x - 24 = 48 の解は？",
                    "answer": "4"
                },
                {
                    "question": "19x + 10 = 67 の解は？",
                    "answer": "3"
                },
                {
                    "question": "(x + 7)(x - 3) = ?",
                    "answer": "x²+4x-21"
                },
                {
                    "question": "20x - 15 = 65 の解は？",
                    "answer": "4"
                },
                {
                    "question": "21x + 12 = 75 の解は？",
                    "answer": "3"
                }
            ],
            "eng": [
                {
                    "question": "走るの現在形は？",
                    "answer": "run"
                },
                {
                    "question": "食べるの過去形は？",
                    "answer": "ate"
                },
                {
                    "question": "行くの過去形は？",
                    "answer": "went"
                },
                {
                    "question": "見るの過去分詞は？",
                    "answer": "seen"
                },
                {
                    "question": "勉強するの過去形は？",
                    "answer": "studied"
                },
                {
                    "question": "遊ぶの過去形は？",
                    "answer": "played"
                },
                {
                    "question": "働くの過去形は？",
                    "answer": "worked"
                },
                {
                    "question": "書くの過去形は？",
                    "answer": "wrote"
                },
                {
                    "question": "読むの過去形は？",
                    "answer": "read"
                },
                {
                    "question": "話すの過去形は？",
                    "answer": "spoke"
                },
                {
                    "question": "来るの過去形は？",
                    "answer": "came"
                },
                {
                    "question": "買うの過去形は？",
                    "answer": "bought"
                },
                {
                    "question": "泳ぐの過去形は？",
                    "answer": "swam"
                },
                {
                    "question": "飛ぶの過去形は？",
                    "answer": "flew"
                },
                {
                    "question": "勉強するの過去分詞は？",
                    "answer": "studied"
                },
                {
                    "question": "遊ぶの過去分詞は？",
                    "answer": "played"
                },
                {
                    "question": "働くの過去分詞は？",
                    "answer": "worked"
                },
                {
                    "question": "書くの過去分詞は？",
                    "answer": "written"
                },
                {
                    "question": "読むの過去分詞は？",
                    "answer": "read"
                },
                {
                    "question": "話すの過去分詞は？",
                    "answer": "spoken"
                },
                {
                    "question": "来るの過去分詞は？",
                    "answer": "come"
                },
                {
                    "question": "買うの過去分詞は？",
                    "answer": "bought"
                },
                {
                    "question": "泳ぐの過去分詞は？",
                    "answer": "swum"
                },
                {
                    "question": "飛ぶの過去分詞は？",
                    "answer": "flown"
                },
                {
                    "question": "歌うの過去形は？",
                    "answer": "sang"
                },
                {
                    "question": "歌うの過去分詞は？",
                    "answer": "sung"
                },
                {
                    "question": "座るの過去形は？",
                    "answer": "sat"
                },
                {
                    "question": "立つの過去形は？",
                    "answer": "stood"
                },
                {
                    "question": "知るの過去形は？",
                    "answer": "knew"
                },
                {
                    "question": "知るの過去分詞は？",
                    "answer": "known"
                }
            ]
        },
        "3": {
            "math": [
                {
                    "question": "√16 = ?",
                    "answer": "4"
                },
                {
                    "question": "√25 = ?",
                    "answer": "5"
                },
                {
                    "question": "2³ = ?",
                    "answer": "8"
                },
                {
                    "question": "3² = ?",
                    "answer": "9"
                },
                {
                    "question": "sin 30° = ?",
                    "answer": "0.5"
                },
                {
                    "question": "√36 = ?",
                    "answer": "6"
                },
                {
                    "question": "√49 = ?",
                    "answer": "7"
                },
                {
                    "question": "√64 = ?",
                    "answer": "8"
                },
                {
                    "question": "√81 = ?",
                    "answer": "9"
                },
                {
                    "question": "√100 = ?",
                    "answer": "10"
                },
                {
                    "question": "4³ = ?",
                    "answer": "64"
                },
                {
                    "question": "5² = ?",
                    "answer": "25"
                },
                {
                    "question": "6² = ?",
                    "answer": "36"
                },
                {
                    "question": "7² = ?",
                    "answer": "49"
                },
                {
                    "question": "8² = ?",
                    "answer": "64"
                },
                {
                    "question": "10² = ?",
                    "answer": "100"
                },
                {
                    "question": "cos 60° = ?",
                    "answer": "0.5"
                },
                {
                    "question": "tan 45° = ?",
                    "answer": "1"
                },
                {
                    "question": "sin 45° = ?",
                    "answer": "0.707"
                },
                {
                    "question": "cos 45° = ?",
                    "answer": "0.707"
                },
                {
                    "question": "√144 = ?",
                    "answer": "12"
                },
                {
                    "question": "√169 = ?",
                    "answer": "13"
                },
                {
                    "question": "3³ = ?",
                    "answer": "27"
                },
                {
                    "question": "4² = ?",
                    "answer": "16"
                },
                {
                    "question": "9² = ?",
                    "answer": "81"
                },
                {
                    "question": "11² = ?",
                    "answer": "121"
                },
                {
                    "question": "12² = ?",
                    "answer": "144"
                },
                {
                    "question": "sin 60° = ?",
                    "answer": "0.866"
                },
                {
                    "question": "cos 30° = ?",
                    "answer": "0.866"
                },
                {
                    "question": "tan 30° = ?",
                    "answer": "0.577"
                },
                {
                    "question": "√225 = ?",
                    "answer": "15"
                }
            ],
            "eng": [
                {
                    "question": "もし～ならを表す接続詞は？",
                    "answer": "if"
                },
                {
                    "question": "～のでを表す接続詞は？",
                    "answer": "because"
                },
                {
                    "question": "～の時を表す接続詞は？",
                    "answer": "when"
                },
                {
                    "question": "～ながらを表す接続詞は？",
                    "answer": "while"
                },
                {
                    "question": "～でもを表す接続詞は？",
                    "answer": "although"
                },
                {
                    "question": "～だからを表す接続詞は？",
                    "answer": "so"
                },
                {
                    "question": "～後にを表す前置詞は？",
                    "answer": "after"
                },
                {
                    "question": "～前にを表す前置詞は？",
                    "answer": "before"
                },
                {
                    "question": "～の間を表す前置詞は？",
                    "answer": "during"
                },
                {
                    "question": "～なしでを表す前置詞は？",
                    "answer": "without"
                },
                {
                    "question": "～のためにを表す前置詞は？",
                    "answer": "for"
                },
                {
                    "question": "～に関してを表す前置詞は？",
                    "answer": "about"
                },
                {
                    "question": "～の中にを表す前置詞は？",
                    "answer": "inside"
                },
                {
                    "question": "～の外にを表す前置詞は？",
                    "answer": "outside"
                },
                {
                    "question": "～の上にを表す前置詞は？",
                    "answer": "above"
                },
                {
                    "question": "～の下にを表す前置詞は？",
                    "answer": "below"
                },
                {
                    "question": "～の隣にを表す前置詞は？",
                    "answer": "beside"
                },
                {
                    "question": "～の間にを表す前置詞は？",
                    "answer": "between"
                },
                {
                    "question": "～を通してを表す前置詞は？",
                    "answer": "through"
                },
                {
                    "question": "～に沿ってを表す前置詞は？",
                    "answer": "along"
                },
                {
                    "question": "～の向こうにを表す前置詞は？",
                    "answer": "across"
                },
                {
                    "question": "～の周りにを表す前置詞は？",
                    "answer": "around"
                },
                {
                    "question": "～以来を表す前置詞は？",
                    "answer": "since"
                },
                {
                    "question": "～によってを表す前置詞は？",
                    "answer": "by"
                },
                {
                    "question": "～を使ってを表す前置詞は？",
                    "answer": "with"
                },
                {
                    "question": "～からを表す前置詞は？",
                    "answer": "from"
                },
                {
                    "question": "～へを表す前置詞は？",
                    "answer": "to"
                },
                {
                    "question": "～としてを表す前置詞は？",
                    "answer": "as"
                },
                {
                    "question": "～の後ろにを表す前置詞は？",
                    "answer": "behind"
                },
                {
                    "question": "～の前にを表す前置詞は？",
                    "answer": "in front of"
                }
            ]
        }
    },
    "high_school": {
        "1": {
            "math": [
                {
                    "question": "log₂ 8 = ?",
                    "answer": "3"
                },
                {
                    "question": "log₁₀ 100 = ?",
                    "answer": "2"
                },
                {
                    "question": "2x + 3y = 10, x = 2 の時 y = ?",
                    "answer": "2"
                },
                {
                    "question": "y = 2x + 1 の傾きは？",
                    "answer": "2"
                },
                {
                    "question": "y = -3x + 5 のy切片は？",
                    "answer": "5"
                },
                {
                    "question": "log₃ 27 = ?",
                    "answer": "3"
                },
                {
                    "question": "log₅ 25 = ?",
                    "answer": "2"
                },
                {
                    "question": "log₂ 32 = ?",
                    "answer": "5"
                },
                {
                    "question": "3x - 2y = 8, x = 4 の時 y = ?",
                    "answer": "2"
                },
                {
                    "question": "y = 4x - 3 の傾きは？",
                    "answer": "4"
                },
                {
                    "question": "y = -2x + 7 のy切片は？",
                    "answer": "7"
                },
                {
                    "question": "log₁₀ 1000 = ?",
                    "answer": "3"
                },
                {
                    "question": "log₂ 16 = ?",
                    "answer": "4"
                },
                {
                    "question": "log₄ 16 = ?",
                    "answer": "2"
                },
                {
                    "question": "5x + 2y = 12, x = 2 の時 y = ?",
                    "answer": "1"
                },
                {
                    "question": "y = -x + 4 の傾きは？",
                    "answer": "-1"
                },
                {
                    "question": "y = 0.5x + 2 のy切片は？",
                    "answer": "2"
                },
                {
                    "question": "log₃ 9 = ?",
                    "answer": "2"
                },
                {
                    "question": "log₂ 4 = ?",
                    "answer": "2"
                },
                {
                    "question": "log₁₀ 10 = ?",
                    "answer": "1"
                },
                {
                    "question": "4x + y = 10, x = 2 の時 y = ?",
                    "answer": "2"
                },
                {
                    "question": "y = 3x - 5 の傾きは？",
                    "answer": "3"
                },
                {
                    "question": "y = -4x + 8 のy切片は？",
                    "answer": "8"
                },
                {
                    "question": "log₅ 125 = ?",
                    "answer": "3"
                },
                {
                    "question": "log₂ 64 = ?",
                    "answer": "6"
                },
                {
                    "question": "log₃ 81 = ?",
                    "answer": "4"
                },
                {
                    "question": "2x - y = 6, x = 5 の時 y = ?",
                    "answer": "4"
                },
                {
                    "question": "y = -0.5x + 3 の傾きは？",
                    "answer": "-0.5"
                },
                {
                    "question": "y = 2x + 10 のy切片は？",
                    "answer": "10"
                },
                {
                    "question": "log₁₀ 0.1 = ?",
                    "answer": "-1"
                },
                {
                    "question": "log₂ 1 = ?",
                    "answer": "0"
                }
            ],
            "jp": [
                {
                    "question": "「枕草子」の作者は？",
                    "answer": "清少納言"
                },
                {
                    "question": "「源氏物語」の作者は？",
                    "answer": "紫式部"
                },
                {
                    "question": "「徒然草」の作者は？",
                    "answer": "吉田兼好"
                },
                {
                    "question": "「方丈記」の作者は？",
                    "answer": "鴨長明"
                },
                {
                    "question": "「奥の細道」の作者は？",
                    "answer": "松尾芭蕉"
                },
                {
                    "question": "「美しい、この花は」で使われている技法は？",
                    "answer": "倒置法"
                },
                {
                    "question": "「ライオンのように強い」で使われている技法は？",
                    "answer": "比喩"
                },
                {
                    "question": "「走った、走った、走った」で使われている技法は？",
                    "answer": "反復"
                },
                {
                    "question": "「山と川、天と地」で使われている技法は？",
                    "answer": "対句"
                },
                {
                    "question": "「風がささやく」で使われている技法は？",
                    "answer": "擬人法"
                },
                {
                    "question": "「～けれども、～ので」で使われている技法は？",
                    "answer": "係り結び"
                },
                {
                    "question": "「彼に褒められた」で使われている技法は？",
                    "answer": "受動態"
                },
                {
                    "question": "「彼を行かせた」で使われている技法は？",
                    "answer": "使役態"
                },
                {
                    "question": "「いらっしゃる、おっしゃる」で使われている技法は？",
                    "answer": "尊敬語"
                },
                {
                    "question": "「参る、申す」で使われている技法は？",
                    "answer": "謙譲語"
                }
            ],
            "eng": [
                {
                    "question": "関係代名詞で使われる単語は？",
                    "answer": "which,that,who"
                },
                {
                    "question": "現在完了形の継続を表すのは？",
                    "answer": "have+pp"
                },
                {
                    "question": "仮定法で使われる動詞の形は？",
                    "answer": "過去形"
                },
                {
                    "question": "関係代名詞の主格は？",
                    "answer": "who,which,that"
                },
                {
                    "question": "関係代名詞の目的格は？",
                    "answer": "whom,which,that"
                },
                {
                    "question": "関係代名詞の所有格は？",
                    "answer": "whose"
                },
                {
                    "question": "受動態の現在形は？",
                    "answer": "am/is/are+pp"
                },
                {
                    "question": "受動態の過去形は？",
                    "answer": "was/were+pp"
                },
                {
                    "question": "分詞の現在分詞の形は？",
                    "answer": "動詞+ing"
                },
                {
                    "question": "分詞の過去分詞の形は？",
                    "answer": "規則:ed,不規則変化"
                },
                {
                    "question": "不定冠詞は？",
                    "answer": "a,an"
                },
                {
                    "question": "定冠詞は？",
                    "answer": "the"
                },
                {
                    "question": "比較級の作り方は？",
                    "answer": "形容詞+er"
                },
                {
                    "question": "I am happyの受動態は？",
                    "answer": "なし"
                },
                {
                    "question": "He writes a letterの受動態は？",
                    "answer": "aisletterwrittenbyhim"
                },
                {
                    "question": "She wrote a bookの受動態は？",
                    "answer": "abookwaswrittenbyher"
                },
                {
                    "question": "They are playing tennisの進行形は？",
                    "answer": "areplaying"
                },
                {
                    "question": "I have finished my homeworkの完了形は？",
                    "answer": "havefinished"
                },
                {
                    "question": "He will go to schoolの未来形は？",
                    "answer": "willgo"
                },
                {
                    "question": "The book is written by meの能動態は？",
                    "answer": "Iwritethebook"
                },
                {
                    "question": "The cake was eaten by himの能動態は？",
                    "answer": "Heatethecake"
                },
                {
                    "question": "最上級の作り方は？",
                    "answer": "形容詞+est"
                },
                {
                    "question": "助動詞の過去形は？",
                    "answer": "could,would,shouldなど"
                },
                {
                    "question": "andは何詞？",
                    "answer": "接続詞"
                },
                {
                    "question": "inは何詞？",
                    "answer": "前置詞"
                },
                {
                    "question": "theは何詞？",
                    "answer": "冠詞"
                },
                {
                    "question": "現在完了進行形の形は？",
                    "answer": "havebeen+ing"
                },
                {
                    "question": "過去完了形の形は？",
                    "answer": "had+pp"
                },
                {
                    "question": "未来完了形の形は？",
                    "answer": "willhave+pp"
                },
                {
                    "question": "I want to goのto goは？",
                    "answer": "不定詞"
                },
                {
                    "question": "I like swimmingのswimmingは？",
                    "answer": "動名詞"
                },
                {
                    "question": "The book written by himのwrittenは？",
                    "answer": "過去分詞"
                },
                {
                    "question": "The sleeping babyのsleepingは？",
                    "answer": "現在分詞"
                },
                {
                    "question": "If I were youのwereは？",
                    "answer": "仮定法過去"
                },
                {
                    "question": "I wish I knewのknewは？",
                    "answer": "仮定法過去"
                },
                {
                    "question": "The man who is runningのwhoは？",
                    "answer": "関係代名詞主格"
                },
                {
                    "question": "The book which I readのwhichは？",
                    "answer": "関係代名詞目的格"
                },
                {
                    "question": "Whose pen is thisのwhoseは？",
                    "answer": "関係代名詞所有格"
                }
            ]
        },
        "2": {
            "math": [
                {
                    "question": "微分 dy/dx (x²) = ?",
                    "answer": "2x"
                },
                {
                    "question": "微分 dy/dx (x³) = ?",
                    "answer": "3x²"
                },
                {
                    "question": "積分 ∫x dx = ?",
                    "answer": "x²/2"
                },
                {
                    "question": "積分 ∫2x dx = ?",
                    "answer": "x²"
                },
                {
                    "question": "cos 0° = ?",
                    "answer": "1"
                },
                {
                    "question": "微分 dy/dx (x⁴) = ?",
                    "answer": "4x³"
                },
                {
                    "question": "微分 dy/dx (x⁵) = ?",
                    "answer": "5x⁴"
                },
                {
                    "question": "微分 dy/dx (3x²) = ?",
                    "answer": "6x"
                },
                {
                    "question": "微分 dy/dx (4x³) = ?",
                    "answer": "12x²"
                },
                {
                    "question": "積分 ∫x² dx = ?",
                    "answer": "x³/3"
                },
                {
                    "question": "積分 ∫x³ dx = ?",
                    "answer": "x⁴/4"
                },
                {
                    "question": "積分 ∫3x dx = ?",
                    "answer": "3x²/2"
                },
                {
                    "question": "積分 ∫4x² dx = ?",
                    "answer": "4x³/3"
                },
                {
                    "question": "微分 dy/dx (2x + 3) = ?",
                    "answer": "2"
                },
                {
                    "question": "微分 dy/dx (x² + 2x) = ?",
                    "answer": "2x+2"
                },
                {
                    "question": "微分 dy/dx (x³ - x) = ?",
                    "answer": "3x²-1"
                },
                {
                    "question": "積分 ∫(x + 1) dx = ?",
                    "answer": "x²/2+x"
                },
                {
                    "question": "積分 ∫(2x + 3) dx = ?",
                    "answer": "x²+3x"
                },
                {
                    "question": "積分 ∫(x² + x) dx = ?",
                    "answer": "x³/3+x²/2"
                },
                {
                    "question": "微分 dy/dx (sin x) = ?",
                    "answer": "cosx"
                },
                {
                    "question": "微分 dy/dx (cos x) = ?",
                    "answer": "-sinx"
                },
                {
                    "question": "積分 ∫sin x dx = ?",
                    "answer": "-cosx"
                },
                {
                    "question": "積分 ∫cos x dx = ?",
                    "answer": "sinx"
                },
                {
                    "question": "微分 dy/dx (eˣ) = ?",
                    "answer": "eˣ"
                },
                {
                    "question": "微分 dy/dx (ln x) = ?",
                    "answer": "1/x"
                },
                {
                    "question": "積分 ∫eˣ dx = ?",
                    "answer": "eˣ"
                },
                {
                    "question": "積分 ∫1/x dx = ?",
                    "answer": "ln|x|"
                },
                {
                    "question": "微分 dy/dx (x² + 3x + 2) = ?",
                    "answer": "2x+3"
                },
                {
                    "question": "微分 dy/dx (2x³ - x²) = ?",
                    "answer": "6x²-2x"
                },
                {
                    "question": "積分 ∫(x² + 2x + 1) dx = ?",
                    "answer": "x³/3+x²+x"
                },
                {
                    "question": "sin 90° = ?",
                    "answer": "1"
                },
                {
                    "question": "cos 90° = ?",
                    "answer": "0"
                },
                {
                    "question": "微分 dy/dx (sin 2x) = ?",
                    "answer": "2cos2x"
                },
                {
                    "question": "微分 dy/dx (cos 3x) = ?",
                    "answer": "-3sin3x"
                },
                {
                    "question": "積分 ∫sin 2x dx = ?",
                    "answer": "-cos2x/2"
                },
                {
                    "question": "積分 ∫cos 3x dx = ?",
                    "answer": "sin3x/3"
                },
                {
                    "question": "tan 45° = ?",
                    "answer": "1"
                },
                {
                    "question": "sin 0° = ?",
                    "answer": "0"
                },
                {
                    "question": "cos 0° = ?",
                    "answer": "1"
                }
            ],
            "eng": [
                {
                    "question": "話法の種類は？",
                    "answer": "直接,間接"
                },
                {
                    "question": "比較の最上級の作り方は？",
                    "answer": "最+est"
                },
                {
                    "question": "分詞の現在分詞は？",
                    "answer": "ing"
                },
                {
                    "question": "分詞の過去分詞は？",
                    "answer": "ed"
                },
                {
                    "question": "動名詞の形は？",
                    "answer": "ing"
                },
                {
                    "question": "直接話法の特徴は？",
                    "answer": "そのまま引用"
                },
                {
                    "question": "間接話法の特徴は？",
                    "answer": "文を変えて伝える"
                },
                {
                    "question": "比較級の不規則変化は？",
                    "answer": "good-better,bad-worse"
                },
                {
                    "question": "最上級の不規則変化は？",
                    "answer": "good-best,bad-worst"
                },
                {
                    "question": "関係副詞の種類は？",
                    "answer": "when,where,why"
                },
                {
                    "question": "間接疑問の形は？",
                    "answer": "if/whether+主語+動詞"
                },
                {
                    "question": "感嘆文の形は？",
                    "answer": "What/How+主語+動詞"
                },
                {
                    "question": "仮定法過去完了の時制は？",
                    "answer": "過去完了"
                },
                {
                    "question": "仮定法未来の表現は？",
                    "answer": "should+原形"
                },
                {
                    "question": "話法の転換の時制変化は？",
                    "answer": "現在→過去"
                },
                {
                    "question": "話法の転換の代名詞変化は？",
                    "answer": "人称変化"
                },
                {
                    "question": "話法の転換の時制副詞変化は？",
                    "answer": "now→then"
                },
                {
                    "question": "話法の転換の場所副詞変化は？",
                    "answer": "here→there"
                },
                {
                    "question": "強調構文のパターンは？",
                    "answer": "It is...that"
                },
                {
                    "question": "倒置が起きる条件は？",
                    "answer": "否定副詞文頭"
                },
                {
                    "question": "He said I am happyの話法転換は？",
                    "answer": "hesaidIwashappy"
                },
                {
                    "question": "whenは関係副詞？",
                    "answer": "はい"
                },
                {
                    "question": "whereは関係副詞？",
                    "answer": "はい"
                },
                {
                    "question": "whyは関係副詞？",
                    "answer": "はい"
                },
                {
                    "question": "What a nice dayは？",
                    "answer": "感嘆文"
                },
                {
                    "question": "How beautiful it isは？",
                    "answer": "感嘆文"
                },
                {
                    "question": "You are happy aren't youは？",
                    "answer": "付加疑問"
                },
                {
                    "question": "If it rains I will stayは？",
                    "answer": "条件文"
                },
                {
                    "question": "He is running nowのrunningは？",
                    "answer": "現在分詞"
                },
                {
                    "question": "I have finishedのfinishedは？",
                    "answer": "過去分詞"
                },
                {
                    "question": "I like readingのreadingは？",
                    "answer": "動名詞"
                },
                {
                    "question": "I can swimのswimは？",
                    "answer": "原形不定詞"
                },
                {
                    "question": "The girl standing thereのstandingは？",
                    "answer": "現在分詞"
                },
                {
                    "question": "The broken windowのbrokenは？",
                    "answer": "過去分詞"
                },
                {
                    "question": "Swimming is funのSwimmingは？",
                    "answer": "動名詞"
                },
                {
                    "question": "I made him goのgoは？",
                    "answer": "原形不定詞"
                }
            ]
        },
        "3": {
            "math": [
                {
                    "question": "行列 [[1,2],[3,4]] の行列式は？",
                    "answer": "-2"
                },
                {
                    "question": "ベクトル (1,2) と (3,4) の内積は？",
                    "answer": "11"
                },
                {
                    "question": "極限 lim(x→0) sinx/x = ?",
                    "answer": "1"
                },
                {
                    "question": "e^0 = ?",
                    "answer": "1"
                },
                {
                    "question": "ln e = ?",
                    "answer": "1"
                },
                {
                    "question": "行列 [[2,0],[0,3]] の行列式は？",
                    "answer": "6"
                },
                {
                    "question": "行列 [[1,0],[0,1]] の行列式は？",
                    "answer": "1"
                },
                {
                    "question": "行列 [[4,1],[2,3]] の行列式は？",
                    "answer": "10"
                },
                {
                    "question": "ベクトル (2,3) と (4,5) の内積は？",
                    "answer": "22"
                },
                {
                    "question": "ベクトル (1,1) と (2,2) の内積は？",
                    "answer": "4"
                },
                {
                    "question": "ベクトル (3,0) と (0,4) の内積は？",
                    "answer": "0"
                },
                {
                    "question": "極限 lim(x→∞) 1/x = ?",
                    "answer": "0"
                },
                {
                    "question": "極限 lim(x→0) (eˣ - 1)/x = ?",
                    "answer": "1"
                },
                {
                    "question": "極限 lim(x→0) (1 - cos x)/x = ?",
                    "answer": "0"
                },
                {
                    "question": "e¹ = ?",
                    "answer": "e"
                },
                {
                    "question": "e² = ?",
                    "answer": "7.389"
                },
                {
                    "question": "ln 1 = ?",
                    "answer": "0"
                },
                {
                    "question": "ln e² = ?",
                    "answer": "2"
                },
                {
                    "question": "行列 [[-1,2],[3,-4]] の行列式は？",
                    "answer": "-2"
                },
                {
                    "question": "行列 [[5,2],[3,4]] の行列式は？",
                    "answer": "14"
                },
                {
                    "question": "ベクトル (1,2,3) と (4,5,6) の内積は？",
                    "answer": "32"
                },
                {
                    "question": "ベクトル (0,1,0) と (1,0,1) の内積は？",
                    "answer": "0"
                },
                {
                    "question": "極限 lim(x→1) (x² - 1)/(x - 1) = ?",
                    "answer": "2"
                },
                {
                    "question": "極限 lim(x→2) (x² - 4)/(x - 2) = ?",
                    "answer": "4"
                },
                {
                    "question": "行列 [[2,3],[4,5]] の行列式は？",
                    "answer": "-2"
                },
                {
                    "question": "行列 [[1,2,3],[0,1,2],[0,0,1]] の行列式は？",
                    "answer": "1"
                },
                {
                    "question": "ln 10 = ?",
                    "answer": "2.303"
                },
                {
                    "question": "log₁₀ e = ?",
                    "answer": "0.434"
                },
                {
                    "question": "行列 [[3,1],[2,4]] の行列式は？",
                    "answer": "10"
                },
                {
                    "question": "ベクトル (2,2) と (3,3) の内積は？",
                    "answer": "12"
                }
            ],
            "math_hard": [
                {
                    "question": "複素数 (3+2i) * (1-4i) の結果は？",
                    "answer": "11-10i"
                },
                {
                    "question": "∫(x^2 + 2x) dx を不定積分せよ",
                    "answer": "(1/3)x^3 + x^2 + C"
                },
                {
                    "question": "d/dx (sin(x^2)) を微分せよ",
                    "answer": "2x*cos(x^2)"
                },
                {
                    "question": "行列A=[[1,2],[3,4]]の逆行列は？",
                    "answer": "[[-2, 1], [1.5, -0.5]]"
                },
                {
                    "question": "lim(x→∞) (1 + 1/x)^x の極限値は？",
                    "answer": "e"
                },
                {
                    "question": "オイラーの公式 e^(iπ) + 1 = ?",
                    "answer": "0"
                },
                {
                    "question": "2階微分方程式 y'' + y = 0 の一般解は？",
                    "answer": "A*sin(x) + B*cos(x)"
                },
                {
                    "question": "テイラー展開 f(x) = e^x のx=0周りでの3次までの近似は？",
                    "answer": "1 + x + x^2/2 + x^3/6"
                },
                {
                    "question": "ベクトル(1, 2, -1)と(3, 1, 5)の外積は？",
                    "answer": "(11, -8, -5)"
                },
                {
                    "question": "∫[0 to π] sin(x) dx の定積分は？",
                    "answer": "2"
                }
            ],
            "eng": [
                {
                    "question": "強調構文の形は？",
                    "answer": "It is...that"
                },
                {
                    "question": "倒置が起きるのは？",
                    "answer": "否定副詞"
                },
                {
                    "question": "仮定法過去完了の時制は？",
                    "answer": "過去完了"
                },
                {
                    "question": "no sooner...thanの意味は？",
                    "answer": "するとすぐに"
                },
                {
                    "question": "hardly...whenの意味は？",
                    "answer": "するとすぐに"
                },
                {
                    "question": "強調構文の強調対象は？",
                    "answer": "主語,目的語,副詞"
                },
                {
                    "question": "no sooner...thanの時制は？",
                    "answer": "過去完了+過去"
                },
                {
                    "question": "hardly...whenの時制は？",
                    "answer": "過去完了+過去"
                },
                {
                    "question": "scarcely...whenの意味は？",
                    "answer": "するとすぐに"
                },
                {
                    "question": "barely...whenの意味は？",
                    "answer": "するとすぐに"
                },
                {
                    "question": "強調構文の否定形は？",
                    "answer": "It is not...that"
                },
                {
                    "question": "倒置の条件は？",
                    "answer": "否定副詞が文頭"
                },
                {
                    "question": "仮定法過去完了の意味は？",
                    "answer": "過去の事実に反する"
                },
                {
                    "question": "関係詞継続用法の形は？",
                    "answer": "前置詞+関係代名詞"
                },
                {
                    "question": "非制限用法の特徴は？",
                    "answer": "コンマで区切る"
                },
                {
                    "question": "強調構文の疑問形は？",
                    "answer": "Is it...that"
                },
                {
                    "question": "仮定法の混在文は？",
                    "answer": "時制が異なる"
                },
                {
                    "question": "but forの意味は？",
                    "answer": "～がなければ"
                },
                {
                    "question": "withoutの仮定法的意味は？",
                    "answer": "～がなければ"
                },
                {
                    "question": "強調構文の省略は？",
                    "answer": "関係代名詞の省略"
                },
                {
                    "question": "仮定法の wish 用法は？",
                    "answer": "願望を表す"
                },
                {
                    "question": "if onlyの意味は？",
                    "answer": "ああ～できれば"
                },
                {
                    "question": "it is high timeの意味は？",
                    "answer": "そろそろ～すべき時"
                },
                {
                    "question": "強調構文の強調は？",
                    "answer": "文の要素を強調"
                },
                {
                    "question": "would ratherの意味は？",
                    "answer": "むしろ～したい"
                },
                {
                    "question": "it is about timeの意味は？",
                    "answer": "そろそろ～すべき時"
                },
                {
                    "question": "It was Tom that met Maryのthatは？",
                    "answer": "強調構文"
                },
                {
                    "question": "Never have I seen such a thingは？",
                    "answer": "倒置"
                },
                {
                    "question": "If I had known I would have goneは？",
                    "answer": "仮定法過去完了"
                },
                {
                    "question": "The house in which I liveのin whichは？",
                    "answer": "関係詞継続用法"
                },
                {
                    "question": "Tom who is my friendのwhoは？",
                    "answer": "非制限用法"
                }
            ]
        }
    }
};
